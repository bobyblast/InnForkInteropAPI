using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public partial class IF_AiModerator
    {
        private static void SendModerationRequest(string requestId, string prompt)
        {
            RequireNotPaused();
            string url = Storage.Get(Storage.CurrentContext, KeyOracleUrl);
            if (string.IsNullOrEmpty(url)) url = DefaultOracleUrl;
            string jsonPath = Storage.Get(Storage.CurrentContext, KeyOracleJsonPath);
            if (string.IsNullOrEmpty(jsonPath)) jsonPath = DefaultOracleJsonPath;
            Oracle.Request(url, jsonPath, nameof(OnOracleModerationResponse), requestId, (long)MinOracleFee);
        }

        public static void OnOracleModerationResponse(string requestedUrl, object userData, OracleResponseCode code, string jsonResponse)
        {
            if (Runtime.CallingScriptHash != Oracle.Hash) throw new InvalidOperationException("No Authorization! Only Oracle");
            if (code != OracleResponseCode.Success)
            {
                string err = "Oracle response failure with code " + (byte)code;
                OnModerationError("UNKNOWN", requestedUrl, err);
                throw new Exception(err);
            }
            try
            {
                ModerationResult result = ParseLLMResponse(jsonResponse);
                ValidateModerationResult(result);
                ByteString metaKey = (ByteString)(PrefixReqMeta + (string)userData);
                string metadataJson = Storage.Get(Storage.CurrentContext, metaKey);
                if (metadataJson != null && metadataJson.Length > 0)
                {
                    var metadata = (Map<string, object>)StdLib.JsonDeserialize(metadataJson);
                    bool autoEnforce = (bool)metadata["autoEnforce"];
                    string entityId = (string)metadata["entityId"];
                    string projectId = entityId.IndexOf("|") > 0 ? entityId.Substring(0, entityId.IndexOf("|")) : entityId;
                    if (autoEnforce && !result.IsApproved)
                    {
                        ApplyAutoEnforcementActions(result, entityId, projectId);
                    }
                }
                SaveModerationResult(result);
                OnModerationCompleted(result.RequestId, result.ViolationCategory, result.IsApproved, result.ConfidenceScore);
            }
            catch (Exception ex)
            {
                OnModerationError("PARSE_ERROR", requestedUrl, ex.Message);
                throw;
            }
        }

        private static ModerationResult ParseLLMResponse(string json)
        {
            var map = (Map<string, object>)StdLib.JsonDeserialize(json);
            bool approved = (bool)map["is_approved"];
            BigInteger confidence = (BigInteger)map["confidence_score"];
            BigInteger flags = (BigInteger)map["violation_flags"];
            string category = (string)map["violation_category"];
            string explanation = (string)map["explanation"];
            return new ModerationResult { IsApproved = approved, ConfidenceScore = confidence, ViolationFlags = flags, ViolationCategory = category, Explanation = explanation, Timestamp = Runtime.Time };
        }

        private static void ValidateModerationResult(ModerationResult result)
        {
            if (result.ConfidenceScore < 0 || result.ConfidenceScore > 100) throw new Exception("Invalid confidence");
            if (result.ViolationFlags < 0) throw new Exception("Invalid flags");
            string[] valid = new string[] { "None", "Scam", "Spam", "LowQuality", "Illegal", "Unrealistic", "MissingInfo", "Offensive", "False" };
            bool ok = false;
            for (int i = 0; i < valid.Length; i++) { if (result.ViolationCategory == valid[i]) { ok = true; break; } }
            if (!ok) throw new Exception("Invalid category:" + result.ViolationCategory);
            if (!result.IsApproved && result.ViolationFlags == 0) throw new Exception("Not approved but flags=0");
        }
    }
}
