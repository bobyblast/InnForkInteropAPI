using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public partial class IF_AiModerator
    {
        [Neo.SmartContract.Framework.Attributes.Safe]
        public static bool IsModerationApproved(string requestId)
        {
            ModerationResult r = GetModerationResult(requestId);
            return r.IsApproved;
        }

        [Neo.SmartContract.Framework.Attributes.Safe]
        public static BigInteger GetConfidenceScore(string requestId)
        {
            ModerationResult r = GetModerationResult(requestId);
            return r.ConfidenceScore;
        }

        [Neo.SmartContract.Framework.Attributes.Safe]
        public static bool HasViolationFlag(string requestId, ViolationFlag flag)
        {
            ModerationResult r = GetModerationResult(requestId);
            return (r.ViolationFlags & (int)flag) != 0;
        }

        [Neo.SmartContract.Framework.Attributes.Safe]
        public static Map<string, BigInteger> GetModerationStats(string requestId)
        {
            ModerationResult r = GetModerationResult(requestId);
            return new Map<string, BigInteger>
            {
                ["isApproved"] = r.IsApproved ? 1 : 0,
                ["confidenceScore"] = r.ConfidenceScore,
                ["violationFlags"] = r.ViolationFlags,
                ["timestamp"] = r.Timestamp
            };
        }

        [Neo.SmartContract.Framework.Attributes.Safe]
        public static Map<string, BigInteger> GetEnhancedModerationStats(string requestId, string projectId)
        {
            ModerationResult result = GetModerationResult(requestId);
            var stats = new Map<string, BigInteger>
            {
                ["isApproved"] = result.IsApproved ? 1 : 0,
                ["confidenceScore"] = result.ConfidenceScore,
                ["violationFlags"] = result.ViolationFlags,
                ["timestamp"] = result.Timestamp
            };
            if (!string.IsNullOrEmpty(projectId))
            {
                try
                {
                    var fraud = (System.Numerics.BigInteger)Contract.Call(StateStorageContract, "GetFraudScore", CallFlags.ReadOnly, projectId, result.Requester);
                    stats["currentFraudScore"] = fraud;
                    var susp = (System.Numerics.BigInteger)Contract.Call(StateStorageContract, "GetSuspiciousActivityScore", CallFlags.ReadOnly, projectId, result.Requester);
                    stats["suspiciousScore"] = susp;
                    bool banned = (bool)Contract.Call(StateStorageContract, "IsParticipantBanned", CallFlags.ReadOnly, projectId, result.Requester);
                    stats["isBanned"] = banned ? 1 : 0;
                }
                catch { }
            }
            return stats;
        }

        [Neo.SmartContract.Framework.Attributes.Safe]
        public static object[] GetModerationHistoryWithContext(UInt160 address, string projectId)
        {
            string[] requestIds = GetModerationHistory(address);
            Neo.SmartContract.Framework.List<object> res = new Neo.SmartContract.Framework.List<object>();
            for (int i = 0; i < requestIds.Length; i++)
            {
                try
                {
                    ModerationResult r = GetModerationResult(requestIds[i]);
                    var entry = new Map<string, object>
                    {
                        ["requestId"] = r.RequestId,
                        ["type"] = r.ModerationType,
                        ["approved"] = r.IsApproved,
                        ["confidence"] = r.ConfidenceScore,
                        ["category"] = r.ViolationCategory,
                        ["timestamp"] = r.Timestamp
                    };
                    res.Add(entry);
                }
                catch { }
            }
            return res;
        }

        public static void ManuallyApplySanctions(string requestId, string projectId, UInt160 admin)
        {
            if (!Runtime.CheckWitness(admin)) throw new Exception("Unauthorized");
            ModerationResult result = GetModerationResult(requestId);
            if (result.IsApproved) throw new Exception("Cannot apply to approved");
            ApplyAutoEnforcementActions(result, projectId, projectId);
        }

        public static void RehabilitateParticipant(string projectId, UInt160 participant, UInt160 admin)
        {
            if (!Runtime.CheckWitness(admin)) throw new Exception("Unauthorized");
            try
            {
                Contract.Call(StateStorageContract, "UnbanParticipant", CallFlags.All, projectId, participant, true);
                Contract.Call(StateStorageContract, "SetFraudScore", CallFlags.All, projectId, participant, 0);
                Contract.Call(StateStorageContract, "SetSuspiciousActivityScore", CallFlags.All, projectId, participant, 0);
            }
            catch (Exception ex)
            {
                throw new Exception("Rehabilitation failed: " + ex.Message);
            }
        }
    }
}
