using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.IF_AiModerator;

namespace InnFork.NeoN3
{
    public partial class IF_AiModerator
    {
        private static void ApplyAutoEnforcementActions(ModerationResult result, string entityId, string projectId)
        {
            if (result.IsApproved) return;
            var severity = DetermineSeverity(result.ViolationFlags, result.ConfidenceScore);
            UInt160 violator = result.Requester;
            try
            {
                switch (severity)
                {
                    case ViolationSeverity.Low:
                        ApplyFraudScoreIncrease(projectId, violator, 10);
                        break;
                    case ViolationSeverity.Medium:
                        ApplyFraudScoreIncrease(projectId, violator, 25);
                        CreateAutomatedDispute(projectId, violator, result);
                        break;
                    case ViolationSeverity.High:
                        ApplyFraudScoreIncrease(projectId, violator, 50);
                        ApplyTemporaryBan(projectId, violator, result);
                        CreateAutomatedDispute(projectId, violator, result);
                        break;
                    case ViolationSeverity.Critical:
                        ApplyFraudScoreIncrease(projectId, violator, 100);
                        ApplyPermanentBan(projectId, violator, result);
                        break;
                }
            }
            catch (Exception ex)
            {
                OnModerationError(result.RequestId, "AUTO_ENFORCEMENT", ex.Message);
            }
        }

        private static void ApplyFraudScoreIncrease(string projectId, UInt160 participant, BigInteger increase)
        {
            BigInteger current = 0;
            try { current = (BigInteger)Contract.Call(StateStorageContract, "GetFraudScore", CallFlags.ReadOnly, projectId, participant); } catch { }
            Contract.Call(StateStorageContract, "SetFraudScore", CallFlags.All, projectId, participant, current + increase);
        }

        private static void CreateAutomatedDispute(string projectId, UInt160 violator, ModerationResult result)
        {
            int disputeType = MapModerationTypeToDisputeType(result.ModerationType);
            string description = "Automated dispute by AI Moderator. Violation: " + result.ViolationCategory + ". Explanation: " + result.Explanation;
            string disputeId = (string)Contract.Call(StateStorageContract, "CreateDispute", CallFlags.All, projectId, Runtime.ExecutingScriptHash, disputeType, description, violator, (byte)0);
            if (result.ConfidenceScore >= 85)
            {
                Contract.Call(StateStorageContract, "EscalateDispute", CallFlags.All, projectId, disputeId, "Auto-escalated due to high confidence");
            }
        }

        private static void ApplyTemporaryBan(string projectId, UInt160 violator, ModerationResult result)
        {
            int reason = MapViolationFlagToBanReason(result.ViolationFlags);
            Contract.Call(StateStorageContract, "BanParticipant", CallFlags.All, projectId, violator, true, reason);
            Contract.Call(StateStorageContract, "SetSuspiciousActivityScore", CallFlags.All, projectId, violator, result.ConfidenceScore);
        }

        private static void ApplyPermanentBan(string projectId, UInt160 violator, ModerationResult result)
        {
            int reason = MapViolationFlagToBanReason(result.ViolationFlags);
            Contract.Call(StateStorageContract, "BanParticipant", CallFlags.All, projectId, violator, true, reason);
            Contract.Call(StateStorageContract, "SetFraudScore", CallFlags.All, projectId, violator, 1000);
            Contract.Call(StateStorageContract, "SetSuspiciousActivityScore", CallFlags.All, projectId, violator, 100);
        }

        private static int MapModerationTypeToDisputeType(byte moderationType)
        {
            switch ((ModerationType)moderationType)
            {
                case ModerationType.ProjectOffer:
                case ModerationType.ManufacturerProfile:
                    return 8; // FraudAccusation
                case ModerationType.ProductDescription:
                    return 2; // QualityDispute
                case ModerationType.DisputeEvidence:
                    return 6; // ContractBreach
                default:
                    return 11; // Fraud
            }
        }

        private static int MapViolationFlagToBanReason(BigInteger violationFlags)
        {
            if ((violationFlags & (int)ViolationFlag.Scam) != 0) return 1; // FraudulentActivity
            if ((violationFlags & (int)ViolationFlag.Spam) != 0) return 17; // SpamVoting
            if ((violationFlags & (int)ViolationFlag.OffensiveLanguage) != 0) return 9; // InappropriateBehavior
            if ((violationFlags & (int)ViolationFlag.FalseInformation) != 0) return 35; // FalseDispute
            if ((violationFlags & (int)ViolationFlag.Copyright) != 0) return 33; // IP Theft
            if ((violationFlags & (int)ViolationFlag.IllegalContent) != 0) return 31; // RegulatoryViolation
            if ((violationFlags & (int)ViolationFlag.LowQuality) != 0) return 4; // QualityIssues
            if ((violationFlags & (int)ViolationFlag.Unrealistic) != 0) return 11; // FraudSuspicion
            return 2; // ViolationOfTerms
        }
    }
}
