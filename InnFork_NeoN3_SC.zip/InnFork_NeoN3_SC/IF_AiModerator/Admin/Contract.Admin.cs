using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public partial class IF_AiModerator : SmartContract
    {
        public IF_AiModerator()
        {
        }

        // Admin controls
        public static void Initialize(UInt160 owner)
        {
            ByteString raw = Storage.Get(Storage.CurrentContext, KeyOwner);
            if (raw != null && raw.Length > 0) throw new Exception("Already initialized");
            if (!Runtime.CheckWitness(owner)) throw new Exception("Owner witness required");
            Storage.Put(Storage.CurrentContext, KeyOwner, owner);
            Storage.Put(Storage.CurrentContext, KeyPaused, 0);
            Storage.Put(Storage.CurrentContext, KeyOracleUrl, DefaultOracleUrl);
            Storage.Put(Storage.CurrentContext, KeyOracleJsonPath, DefaultOracleJsonPath);
        }

        public static void TransferOwnership(UInt160 newOwner)
        {
            RequireOwner();
            if (newOwner is null) throw new Exception("null owner");
            UInt160 old = Owner;
            Storage.Put(Storage.CurrentContext, KeyOwner, newOwner);
            OnOwnerChanged(old, newOwner);
        }

        public static void SetPaused(bool paused)
        {
            RequireOwner();
            Storage.Put(Storage.CurrentContext, KeyPaused, paused ? 1 : 0);
            OnPaused(paused);
        }

        public static void ConfigureOracle(string url, string jsonPath)
        {
            RequireOwner();
            if (string.IsNullOrEmpty(url)) throw new Exception("url empty");
            if (string.IsNullOrEmpty(jsonPath)) throw new Exception("jsonPath empty");
            Storage.Put(Storage.CurrentContext, KeyOracleUrl, url);
            Storage.Put(Storage.CurrentContext, KeyOracleJsonPath, jsonPath);
        }

        public static void SetStateStorageContract(UInt160 newAddress)
        {
            RequireOwner();
            if (newAddress is null) throw new Exception("null addr");
            Storage.Put(Storage.CurrentContext, nameof(StateStorageContract), newAddress);
        }

        public static void SetMainGatewayContract(UInt160 newAddress)
        {
            RequireOwner();
            if (newAddress is null) throw new Exception("null addr");
            Storage.Put(Storage.CurrentContext, nameof(MainGatewayContract), newAddress);
        }

        // Simple rate limiting per requester (timestamp bucket)
        private static void EnforceRateLimit(UInt160 requester)
        {
            var key = (ByteString)(KeyRateLimit + requester.ToAddress());
            ulong now = Runtime.Time;
            ByteString raw = Storage.Get(Storage.CurrentContext, key);
            if (raw != null && raw.Length > 0)
            {
                BigInteger saved = (BigInteger)raw;
                ulong last = (ulong)saved;
                if (now - last < 10)
                {
                    throw new Exception("Rate limited: try later");
                }
            }
            Storage.Put(Storage.CurrentContext, key, now);
        }
    }
}
