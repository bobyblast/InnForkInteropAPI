using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public partial class IF_AiModerator
    {
        public static string ModerateProjectOffer(string offerId, string offerJson, UInt160 requester, bool autoEnforce = false)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(requester)) throw new Exception("Unauthorized");
            EnforceRateLimit(requester);
            ByteString offerIdBytes = (ByteString)offerId;
            ByteString offerData = (ByteString)Contract.Call(StateStorageContract, "GetRawOfferPackage", CallFlags.ReadOnly, offerIdBytes);
            if (offerData == null) throw new Exception("Offer not found");
            ValidateInput(offerJson, "Project Offer");
            string prompt = BuildProjectOfferPrompt(offerJson);
            string requestId = GenerateRequestId(offerId, ModerationType.ProjectOffer);
            SaveRequestMetadata(requestId, (byte)ModerationType.ProjectOffer, requester, offerId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, offerId, Runtime.Time);
            return requestId;
        }

        public static string ModerateProjectDescription(string projectId, string descriptionJson, UInt160 requester, bool autoEnforce = false)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(requester)) throw new Exception("Unauthorized");
            EnforceRateLimit(requester);
            ByteString projectCore = TryGetProjectCoreBytes(projectId);
            if (projectCore == null) throw new Exception("Project not found");
            ValidateInput(descriptionJson, "Project Description");
            string prompt = BuildProjectDescriptionPrompt(descriptionJson);
            string requestId = GenerateRequestId(projectId, ModerationType.ProjectDescription);
            SaveRequestMetadata(requestId, (byte)ModerationType.ProjectDescription, requester, projectId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, projectId, Runtime.Time);
            return requestId;
        }

        public static string ModerateManufacturerProfile(string projectId, UInt160 manufacturerAddress, string profileJson, UInt160 requester, bool autoEnforce = true)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(requester)) throw new Exception("Unauthorized");
            EnforceRateLimit(requester);
            bool isRegistered = (bool)Contract.Call(StateStorageContract, "IsManufacturerRegistered", CallFlags.ReadOnly, projectId, manufacturerAddress);
            if (!isRegistered) throw new Exception("Manufacturer not registered");
            bool isBanned = false;
            try { isBanned = (bool)Contract.Call(StateStorageContract, "IsParticipantBanned", CallFlags.ReadOnly, projectId, manufacturerAddress); } catch { }
            if (isBanned) throw new Exception("Manufacturer banned");
            ValidateInput(profileJson, "Manufacturer Profile");
            string prompt = BuildManufacturerProfilePrompt(profileJson, projectId, manufacturerAddress);
            string requestId = GenerateRequestId(manufacturerAddress.ToAddress() + "_" + projectId, ModerationType.ManufacturerProfile);
            SaveRequestMetadata(requestId, (byte)ModerationType.ManufacturerProfile, requester, manufacturerAddress.ToAddress() + "|" + projectId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, manufacturerAddress.ToAddress(), Runtime.Time);
            return requestId;
        }

        public static string ModerateDisputeEvidence(string projectId, string disputeId, string evidenceJson, UInt160 requester, bool autoEnforce = true)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(requester)) throw new Exception("Unauthorized");
            EnforceRateLimit(requester);
            object disputeObj = Contract.Call(StateStorageContract, "GetDispute", CallFlags.ReadOnly, projectId, disputeId);
            if (disputeObj == null) throw new Exception("Dispute not found");
            ValidateInput(evidenceJson, "Dispute Evidence");
            string prompt = BuildDisputeEvidencePrompt(evidenceJson, projectId, disputeId);
            string requestId = GenerateRequestId(disputeId, ModerationType.DisputeEvidence);
            SaveRequestMetadata(requestId, (byte)ModerationType.DisputeEvidence, requester, projectId + "|" + disputeId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, disputeId, Runtime.Time);
            return requestId;
        }

        public static string ModerateProjectUpdate(string projectId, string updateId, string updateJson, UInt160 requester, bool autoEnforce = false)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(requester)) throw new Exception("Unauthorized");
            EnforceRateLimit(requester);
            ValidateInput(updateJson, "Project Update");
            string prompt = BuildProjectDescriptionPrompt(updateJson);
            string requestId = GenerateRequestId(projectId + "|update:" + updateId, ModerationType.ProjectUpdate);
            SaveRequestMetadata(requestId, (byte)ModerationType.ProjectUpdate, requester, projectId + "|" + updateId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, updateId, Runtime.Time);
            return requestId;
        }

        public static string ModerateUserComment(string projectId, string commentId, string commentJson, UInt160 author, bool autoEnforce = false)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(author)) throw new Exception("Unauthorized");
            EnforceRateLimit(author);
            ValidateInput(commentJson, "User Comment");
            string prompt = BuildProjectDescriptionPrompt(commentJson);
            string requestId = GenerateRequestId(projectId + "|comment:" + commentId, ModerationType.UserComment);
            SaveRequestMetadata(requestId, (byte)ModerationType.UserComment, author, projectId + "|" + commentId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, commentId, Runtime.Time);
            return requestId;
        }

        // New endpoints
        public static string ModerateProductDescription(string productId, string productJson, UInt160 requester, bool autoEnforce = false)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(requester)) throw new Exception("Unauthorized");
            EnforceRateLimit(requester);
            ValidateInput(productJson, "Product Description");
            string prompt = BuildProductDescriptionPrompt(productJson);
            string requestId = GenerateRequestId(productId, ModerationType.ProductDescription);
            SaveRequestMetadata(requestId, (byte)ModerationType.ProductDescription, requester, productId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, productId, Runtime.Time);
            return requestId;
        }

        public static string ModerateRefundRequest(string projectId, string refundId, string refundJson, UInt160 requester, bool autoEnforce = true)
        {
            RequireNotPaused();
            if (!Runtime.CheckWitness(requester)) throw new Exception("Unauthorized");
            EnforceRateLimit(requester);
            ValidateInput(refundJson, "Refund Request");
            string prompt = BuildRefundRequestPrompt(refundJson);
            string requestId = GenerateRequestId(projectId + "|refund:" + refundId, ModerationType.RefundRequest);
            SaveRequestMetadata(requestId, (byte)ModerationType.RefundRequest, requester, projectId + "|" + refundId, autoEnforce);
            SendModerationRequest(requestId, prompt);
            OnModerationRequested(requestId, refundId, Runtime.Time);
            return requestId;
        }
    }
}
