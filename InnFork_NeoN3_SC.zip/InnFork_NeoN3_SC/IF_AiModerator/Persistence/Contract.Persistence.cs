using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;

namespace InnFork.NeoN3
{
    public partial class IF_AiModerator
    {
        private static void SaveRequestMetadata(string requestId, byte moderationType, UInt160 requester, string entityId, bool autoEnforce)
        {
            var key = (ByteString)(PrefixReqMeta + requestId);
            // store requester as hex via ToString() removing0x if present
            string requesterHex = requester.ToString();
            if (requesterHex.Length > 2 && (requesterHex[0] == '0' || requesterHex[0] == '0') && (requesterHex[1] == 'x' || requesterHex[1] == 'X'))
            {
                requesterHex = requesterHex.Substring(2);
            }
            string metadata = StdLib.JsonSerialize(new Map<string, object>
            {
                ["requestId"] = requestId,
                ["type"] = moderationType,
                ["requester"] = requesterHex,
                ["entityId"] = entityId,
                ["timestamp"] = Runtime.Time,
                ["autoEnforce"] = autoEnforce
            });
            Storage.Put(Storage.CurrentContext, key, metadata);
        }

        private static void SaveModerationResult(ModerationResult result)
        {
            ByteString metaKey = (ByteString)(PrefixReqMeta + result.RequestId);
            string metadataJson = Storage.Get(Storage.CurrentContext, metaKey);
            if (metadataJson == null || metadataJson.Length == 0) throw new Exception("Request metadata not found");
            var metadata = (Map<string, object>)StdLib.JsonDeserialize(metadataJson);
            result.RequestId = (string)metadata["requestId"];
            result.ModerationType = (byte)metadata["type"];
            string requesterHex = (string)metadata["requester"];
            ByteString reqBytes = HexToByteString(requesterHex);
            result.Requester = (UInt160)reqBytes;
            ByteString resultKey = (ByteString)(PrefixResult + result.RequestId);
            Storage.Put(Storage.CurrentContext, resultKey, StdLib.Serialize(result));
            AddToHistory(result);
        }

        [Neo.SmartContract.Framework.Attributes.Safe]
        public static ModerationResult GetModerationResult(string requestId)
        {
            ByteString key = (ByteString)(PrefixResult + requestId);
            ByteString data = Storage.Get(Storage.CurrentContext, key);
            if (data == null || data.Length == 0) throw new Exception("Moderation result not found: " + requestId);
            return (ModerationResult)StdLib.Deserialize(data);
        }

        [Neo.SmartContract.Framework.Attributes.Safe]
        public static string[] GetModerationHistory(UInt160 address)
        {
            ByteString key = (ByteString)(PrefixHistory + address.ToAddress());
            ByteString raw = Storage.Get(Storage.CurrentContext, key);
            if (raw == null || raw.Length == 0) return new string[0];
            return (string[])StdLib.Deserialize(raw);
        }
    }
}
