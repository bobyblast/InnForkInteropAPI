using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public partial class IF_AiModerator
    {
        private static void ValidateInput(string input, string field)
        {
            if (string.IsNullOrEmpty(input)) throw new Exception(field + " empty");
            if (input.Length > MaxTextLength) throw new Exception(field + " too long");
        }

        private static string GenerateRequestId(string entityId, ModerationType type)
        {
            string combined = entityId + ((byte)type).ToString() + Runtime.Time.ToString();
            return CryptoLib.Sha256(combined);
        }

        private static ByteString HexToByteString(string hex)
        {
            if (hex == null) throw new Exception("hex is null");
            if ((hex.Length & 1) != 0) throw new Exception("Invalid hex length");
            int len = hex.Length >> 1;
            byte[] buf = new byte[len];
            for (int i = 0; i < len; i++)
            {
                int hi = HexNibble(hex[(i << 1)]);
                int lo = HexNibble(hex[(i << 1) + 1]);
                if (hi < 0 || lo < 0) throw new Exception("Invalid hex char");
                buf[i] = (byte)((hi << 4) | lo);
            }
            return (ByteString)buf;
        }
        private static int HexNibble(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return -1;
        }

        private static void AddToHistory(ModerationResult result)
        {
            ByteString key = (ByteString)(PrefixHistory + result.Requester.ToAddress());
            ByteString raw = Storage.Get(Storage.CurrentContext, key);
            string[] history;
            if (raw == null || raw.Length == 0)
            {
                history = new string[1];
                history[0] = result.RequestId;
            }
            else
            {
                string[] old = (string[])StdLib.Deserialize(raw);
                int n = old.Length;
                history = new string[n + 1];
                for (int i = 0; i < n; i++) history[i] = old[i];
                history[n] = result.RequestId;
            }
            Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(history));
        }

        private static ViolationSeverity DetermineSeverity(BigInteger flags, BigInteger confidence)
        {
            if ((flags & (int)ViolationFlag.Scam) != 0 && confidence >= 90) return ViolationSeverity.Critical;
            if ((flags & (int)ViolationFlag.IllegalContent) != 0 && confidence >= 85) return ViolationSeverity.Critical;
            if ((flags & (int)ViolationFlag.FalseInformation) != 0 && confidence >= 80) return ViolationSeverity.High;
            if ((flags & (int)ViolationFlag.Unrealistic) != 0 && confidence >= 75) return ViolationSeverity.High;
            if ((flags & (int)ViolationFlag.LowQuality) != 0 && confidence >= 70) return ViolationSeverity.Medium;
            if ((flags & (int)ViolationFlag.MissingInfo) != 0 && confidence >= 65) return ViolationSeverity.Medium;
            return ViolationSeverity.Low;
        }
        private static ByteString TryGetProjectCoreBytes(string projectId)
        {
            // Try new API name first
            try
            {
                var pkg = (ByteString)Contract.Call(StateStorageContract, "GetRawProjectPackage", CallFlags.ReadOnly, projectId);
                if (pkg != null && pkg.Length > 0) return pkg;
            }
            catch { }
            // Fallback to legacy name
            try
            {
                var core = (ByteString)Contract.Call(StateStorageContract, "GetProjectCoreBytes", CallFlags.ReadOnly, projectId);
                return core;
            }
            catch { return null; }
        }
    }
}
