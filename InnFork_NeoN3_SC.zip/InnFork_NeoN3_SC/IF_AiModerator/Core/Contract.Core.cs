using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;
using System.Numerics;
using System.ComponentModel;

namespace InnFork.NeoN3
{
    [ContractAuthor("InnFork Team", "contact@innfork.io")]
    [ContractDescription("AI-powered moderation system for crowdfunding platform using OpenRouter LLM API with Storage API integration")]
    [ContractVersion("2.1.0")] // bumped after refactor
    [ContractSourceCode("https://github.com/innfork/neo-ai-moderator")]
    [ContractPermission(Permission.Any, Method.Any)]
    public partial class IF_AiModerator
    {
        // Addresses configured at deploy by InitialValue but can be overridden by Set* methods
        [InitialValue("NQdq7Ud4q2VSjtPFW43cns3aP5SZtRL5pE", ContractParameterType.Hash160)]
        private static readonly UInt160 StateStorageContract = default;

        [InitialValue("NQdq7Ud4q2VSjtPFW43cns3aP5SZtRL5pE", ContractParameterType.Hash160)]
        private static readonly UInt160 MainGatewayContract = default;

        // Oracle defaults
        private const string DefaultOracleUrl = "https://openrouter.ai/api/v1/chat/completions";
        private const string DefaultOracleJsonPath = "$.choices[0].message.content";
        private static readonly ulong MinOracleFee = Oracle.MinimumResponseFee;

        // Storage keys / prefixes
        private const string PrefixResult = "MOD_RESULT_";
        private const string PrefixHistory = "MOD_HISTORY_";
        private const string PrefixReqMeta = "REQ_META_";
        private const string KeyOracleUrl = "CFG_ORACLE_URL";
        private const string KeyOracleJsonPath = "CFG_ORACLE_JSONPATH";
        private const string KeyOwner = "CFG_OWNER";
        private const string KeyPaused = "CFG_PAUSED";
        private const string KeyRateLimit = "CFG_RATELIM_"; // per requester
        private const int MaxTextLength = 4000;

        [DisplayName("ModerationRequested")] public static event Action<string, string, ulong> OnModerationRequested;
        [DisplayName("ModerationCompleted")] public static event Action<string, string, bool, BigInteger> OnModerationCompleted;
        [DisplayName("ModerationError")] public static event Action<string, string, string> OnModerationError;
        [DisplayName("Paused")] public static event Action<bool> OnPaused;
        [DisplayName("OwnerChanged")] public static event Action<UInt160, UInt160> OnOwnerChanged;

        // Entry point init helpers
        private static UInt160 Owner
        {
            get
            {
                ByteString raw = Storage.Get(Storage.CurrentContext, KeyOwner);
                if (raw == null || raw.Length == 0) return (UInt160)Runtime.CallingScriptHash; // fallback for first deploy
                return (UInt160)raw;
            }
        }

        private static bool IsPaused
        {
            get
            {
                ByteString raw = Storage.Get(Storage.CurrentContext, KeyPaused);
                if (raw == null || raw.Length == 0) return false;
                BigInteger v = (BigInteger)raw;
                return v > 0;
            }
        }

        private static void RequireNotPaused()
        {
            if (IsPaused) throw new Exception("Contract is paused");
        }

        private static void RequireOwner()
        {
            if (!Runtime.CheckWitness(Owner)) throw new Exception("Only owner");
        }
    }
}
