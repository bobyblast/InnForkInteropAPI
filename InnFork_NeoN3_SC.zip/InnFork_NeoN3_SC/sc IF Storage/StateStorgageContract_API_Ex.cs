using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;

using System;
using System.ComponentModel;
using System.Numerics;

namespace InnFork.NeoN3;

[DisplayName("InnFork_ProjectStateStorage")]
[ContractAuthor("InnFork", "info@innfork.com")]
[ContractDescription("InnFork crowdfunding platform")]
[ContractVersion("<1>")]
[ContractSourceCode("https://github.com/InnFork")]
public partial class InnForkProjectStateStorage : Neo.SmartContract.Framework.SmartContract
{



    private static ProjectAccount GetRawProjectAccount(string projectId)
    {
        ByteString data = GetRawProjectAccount((ByteString)projectId);
        if (data is null) return null;
        return (ProjectAccount)StdLib.Deserialize(data);
    }

    public static string ResetProjectWinnerStatus(string projectId)
    {
        PrivateMethods.RequireAuth();
        if (string.IsNullOrEmpty(projectId)) throw new Exception("ResetProjectWinnerStatus: projectId empty");
        ProjectAccount project = GetRawProjectAccount(projectId);
        if (project == null) throw new Exception("ResetProjectWinnerStatus: project not found");
        // If there is no winner there is nothing to reset
        if (!project.IsProjectHasWinner)
            return "false";
        // Refund any reserved funds allocated to the winning manufacturer
        project.ResetProjectWinnerStatus();
        return "true";
    }


    public static UInt160 GetManufacturerWinner(string projectId)
    {
        if (string.IsNullOrEmpty(projectId)) throw new Exception("GetManufacturerWinner: projectId empty");
        ProjectAccount project = GetRawProjectAccount(projectId);
        if (project == null) throw new Exception("GetManufacturerWinner: project not found");

        if (project.IsProjectHasWinner == false) throw new Exception("GetManufacturerWinner: project has no winner");

        return project.ManufacturerWinnerAddress;

    }

    private static readonly byte[] DisputesPrefix = "disputes".ToByteArray();
    private static byte[] CreateDisputeKey(string projectId, string disputeId) => PrivateMethods.CreateProjectComplexKey(DisputesPrefix, projectId, "id_" + disputeId);
    private static byte[] CreateDisputeProjectPrefix(string projectId) => PrivateMethods.CreateProjectKey(DisputesPrefix, projectId);

    private static bool IsValidStatusTransition(DisputeStatus from, DisputeStatus to)
    {
        if (from == DisputeStatus.Created && (to == DisputeStatus.UnderReview || to == DisputeStatus.Escalated || to == DisputeStatus.Resolved || to == DisputeStatus.Rejected)) return true;
        if (from == DisputeStatus.UnderReview && (to == DisputeStatus.Escalated || to == DisputeStatus.Resolved || to == DisputeStatus.Rejected)) return true;
        if (from == DisputeStatus.Escalated && (to == DisputeStatus.Resolved || to == DisputeStatus.Rejected)) return true;
        if ((from == DisputeStatus.Resolved || from == DisputeStatus.Rejected) && to == DisputeStatus.Closed) return true;
        return false;
    }

    private static void DeleteMilestone_Public(string projectId, UInt160 manufacturer, byte step)
    {
        // Thin wrapper to keep API available for dispute sanctions
        PrivateMethods.DeleteMilestone(projectId, manufacturer, step);
    }

    private static void ApplySanctionsInternal(string projectId, ref DisputeRecord rec)
    {
        if (rec.SanctionsApplied) return;

        if (rec.ManufacturerInvolved != null && rec.ManufacturerInvolved != UInt160.Zero)
        {
            BanReason reason = rec.BanReasonApplied;

            if (rec.Type == DisputeType.MilestoneCompletion)
                reason = BanReason.MilestoneFailure;
            else if (rec.Type == DisputeType.ContractBreach)
                reason = BanReason.ContractViolation;
            else if (rec.Type == DisputeType.FraudAccusation)
                reason = BanReason.SmartContractExploit;
            else if (rec.Type == DisputeType.PaymentDispute)
                reason = BanReason.PaymentIssues;
            else if (rec.Type == DisputeType.QualityDispute)
                reason = BanReason.QualityIssues;
            else if (rec.Type == DisputeType.DeliveryDispute)
                reason = BanReason.DeliveryFailure;
            else if (rec.Type == DisputeType.IntellectualProperty)
                reason = BanReason.IntellectualPropertyTheft;
            else if (rec.Type == DisputeType.TechnicalIssues)
                reason = BanReason.TechnicalViolations;
            else if (rec.Type == DisputeType.CommunicationFailure)
                reason = BanReason.CommunicationIssues;
            else if (rec.Type == DisputeType.Fraud)
                reason = BanReason.FraudulentActivity;

            try { PrivateMethods.BanParticipant(projectId, rec.ManufacturerInvolved, true, reason); } catch { }

            if (rec.PenaltyAmount > 0)
            {
                try
                {
                    PrivateMethods.SetManufacturerPenalty(projectId, rec.ManufacturerInvolved, PrivateMethods.GetManufacturerPenalty(projectId, rec.ManufacturerInvolved) + rec.PenaltyAmount);
                    PrivateMethods.SetPenaltyTimestamp(projectId, rec.ManufacturerInvolved, Runtime.Time);
                }
                catch { }
            }

            if (rec.Type == DisputeType.MilestoneCompletion && rec.MilestoneStepInvolved > 0)
            {
                try
                {
                    DeleteMilestone_Public(projectId, rec.ManufacturerInvolved, rec.MilestoneStepInvolved);
                }
                catch { }
            }
        }

        rec.SanctionsApplied = true;
    }

    public static void SetDisputeBanReason(string projectId, string disputeId, BanReason reason)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("SetDisputeBanReason: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);
        rec.BanReasonApplied = reason;
        rec.UpdatedAt = Runtime.Time;
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }


    public static string CreateDispute(string projectId, UInt160 initiator, DisputeType disputeType, string description, UInt160 manufacturerInvolved, byte milestoneStepInvolved)
    {
        PrivateMethods.RequireAuth();
        if (string.IsNullOrEmpty(projectId)) throw new Exception("CreateDispute: projectId empty");
        if (initiator is null || initiator.Length != 20) throw new Exception("CreateDispute: initiator invalid");
        if (description is null) description = "";
        if (manufacturerInvolved is null) manufacturerInvolved = UInt160.Zero;

        string disputeId = projectId + "|" + initiator.ToString() + "|" + ((int)disputeType).ToString() + "|" + Runtime.Time.ToString();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        if (Storage.Get(Storage.CurrentContext, key) != null) throw new Exception("CreateDispute: duplicate");

        DisputeRecord rec = new DisputeRecord
        {
            DisputeId = disputeId,
            ProjectId = projectId,
            Initiator = initiator,
            Type = disputeType,
            Status = DisputeStatus.Created,
            Description = description,
            ManufacturerInvolved = manufacturerInvolved,
            MilestoneStepInvolved = milestoneStepInvolved,
            CreatedAt = Runtime.Time,
            UpdatedAt = Runtime.Time,
            ResolutionNote = "",
            SanctionsApplied = false,
            PenaltyAmount = 0,
            InitiatorPenalized = false,
            InitiatorPenaltyAmount = 0,
            BanReasonApplied = BanReason.ContractViolation
        };

        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
        return disputeId;
    }

    public static DisputeRecord GetDispute(string projectId, string disputeId)
    {
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) return null;
        return (DisputeRecord)StdLib.Deserialize(data);
    }

    public static string[] GetDisputeIds(string projectId, int statusFilter)
    {
        byte[] prefix = CreateDisputeProjectPrefix(projectId);
        Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
        List<string> ids = new Neo.SmartContract.Framework.List<string>();

        while (it.Next())
        {
            byte[] key = (byte[])it.Value;
            ByteString val = Storage.Get(Storage.CurrentContext, key);
            if (val == null) continue;

            DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(val);
            if (statusFilter <= 0 || (int)rec.Status == statusFilter)
            {
                ids.Add(rec.DisputeId);
            }
        }

        return ids;
    }

    public static void UpdateDisputeStatus(string projectId, string disputeId, DisputeStatus newStatus, string note)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("UpdateDisputeStatus: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);

        if (!IsValidStatusTransition(rec.Status, newStatus))
            throw new Exception("UpdateDisputeStatus: invalid transition");

        rec.Status = newStatus;
        rec.UpdatedAt = Runtime.Time;
        rec.ResolutionNote = note ?? "";

        if (newStatus == DisputeStatus.Rejected)
        {
            BigInteger currentScore = PrivateMethods.GetFraudScore(projectId, rec.Initiator);
            PrivateMethods.SetFraudScore(projectId, rec.Initiator, currentScore + 10);
            rec.InitiatorPenalized = true;
            rec.InitiatorPenaltyAmount = 0;
        }

        if (newStatus == DisputeStatus.Resolved && !rec.SanctionsApplied)
        {
            ApplySanctionsInternal(projectId, ref rec);
        }

        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }

    public static void SetDisputePenaltyAmount(string projectId, string disputeId, BigInteger penaltyAmount)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("SetDisputePenaltyAmount: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);
        rec.PenaltyAmount = penaltyAmount < 0 ? 0 : penaltyAmount;
        rec.UpdatedAt = Runtime.Time;
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }

    public static void ApplyDisputeSanctions(string projectId, string disputeId)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("ApplyDisputeSanctions: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);
        ApplySanctionsInternal(projectId, ref rec);
        rec.UpdatedAt = Runtime.Time;
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }


    public static void CloseDispute(string projectId, string disputeId)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("CloseDispute: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);
        if (!IsValidStatusTransition(rec.Status, DisputeStatus.Closed))
            throw new Exception("CloseDispute: invalid transition");

        rec.Status = DisputeStatus.Closed;
        rec.UpdatedAt = Runtime.Time;
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }

    public static void SetDisputeResolutionNote(string projectId, string disputeId, string note)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("SetDisputeResolutionNote: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);
        rec.ResolutionNote = note ?? "";
        rec.UpdatedAt = Runtime.Time;
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }

    public static void LinkDisputeToMilestone(string projectId, string disputeId, UInt160 manufacturer, byte step)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("LinkDisputeToMilestone: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);
        rec.ManufacturerInvolved = manufacturer ?? UInt160.Zero;
        rec.MilestoneStepInvolved = step;
        rec.UpdatedAt = Runtime.Time;
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }

    public static void PenalizeInitiator(string projectId, string disputeId, BigInteger penaltyScore)
    {
        PrivateMethods.RequireAuth();
        byte[] key = CreateDisputeKey(projectId, disputeId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) throw new Exception("PenalizeInitiator: not found");

        DisputeRecord rec = (DisputeRecord)StdLib.Deserialize(data);
        BigInteger currentScore = PrivateMethods.GetFraudScore(projectId, rec.Initiator);
        PrivateMethods.SetFraudScore(projectId, rec.Initiator, currentScore + (penaltyScore < 0 ? 0 : penaltyScore));
        rec.InitiatorPenalized = true;
        rec.InitiatorPenaltyAmount = penaltyScore < 0 ? 0 : penaltyScore;
        rec.UpdatedAt = Runtime.Time;
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(rec));
    }

    public static void SetDisputeStatusUnderReview(string projectId, string disputeId)
    {
        UpdateDisputeStatus(projectId, disputeId, DisputeStatus.UnderReview, "");
    }

    public static void EscalateDispute(string projectId, string disputeId, string note)
    {
        UpdateDisputeStatus(projectId, disputeId, DisputeStatus.Escalated, note);
    }

    public static void ResolveDispute(string projectId, string disputeId, string note)
    {
        UpdateDisputeStatus(projectId, disputeId, DisputeStatus.Resolved, note);
    }

    public static void RejectDispute(string projectId, string disputeId, string note)
    {
        UpdateDisputeStatus(projectId, disputeId, DisputeStatus.Rejected, note);
    }

    public static void SetDisputeManufacturerPenaltyAndApply(string projectId, string disputeId, BigInteger penaltyAmount, BanReason reason, string note)
    {
        PrivateMethods.RequireAuth();
        SetDisputePenaltyAmount(projectId, disputeId, penaltyAmount);
        SetDisputeBanReason(projectId, disputeId, reason);
        UpdateDisputeStatus(projectId, disputeId, DisputeStatus.Resolved, note);
        ApplyDisputeSanctions(projectId, disputeId);
    }

}