using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.ProjectAccount;


namespace InnFork.NeoN3;

public partial class InnForkProjectStateStorage : Neo.SmartContract.Framework.SmartContract
{
    // First, private helpers referenced by entry
    public static void SetVoteDelegation_Internal(string projectId, string votingType, UInt160 delegator, UInt160 delegateAddr)
    {
        PrivateMethods.RequireAuth();
        byte[] delegationKey = PrivateMethods.CreateProjectComplexKey(VoteDelegationPrefix, projectId, votingType);
        ByteString delegationData = Storage.Get(Storage.CurrentContext, delegationKey);
        Map<UInt160, UInt160> delegationMap = delegationData != null
        ? (Map<UInt160, UInt160>)StdLib.Deserialize(delegationData)
        : new Map<UInt160, UInt160>();
        delegationMap[delegator] = delegateAddr;
        Storage.Put(Storage.CurrentContext, delegationKey, StdLib.Serialize(delegationMap));
    }

    public static void RemoveVoteDelegation_Internal(string projectId, string votingType, UInt160 delegator)
    {
        PrivateMethods.RequireAuth();
        byte[] delegationKey = PrivateMethods.CreateProjectComplexKey(VoteDelegationPrefix, projectId, votingType);
        ByteString delegationData = Storage.Get(Storage.CurrentContext, delegationKey);
        if (delegationData != null)
        {
            Map<UInt160, UInt160> delegationMap = (Map<UInt160, UInt160>)StdLib.Deserialize(delegationData);
            if (delegationMap.HasKey(delegator))
            {
                delegationMap.Remove(delegator);
                Storage.Put(Storage.CurrentContext, delegationKey, StdLib.Serialize(delegationMap));
            }
        }
    }

    public static (UInt160[] voters, BackerVotesEnum[] votes) GetVotesSnapshot_Internal(string projectId, string votingType, int skip, int take)
    {
        var (voters, votes) = PrivateMethods.GetVotesSnapshot(projectId, votingType, skip, take);
        return (voters, votes);
    }

    public static UInt160 GetDelegateForInternal(string projectId, string votingType, UInt160 delegator)
    {
        byte[] delegationKey = PrivateMethods.CreateProjectComplexKey(VoteDelegationPrefix, projectId, votingType);
        ByteString delegationData = Storage.Get(Storage.CurrentContext, delegationKey);
        if (delegationData == null) return UInt160.Zero;
        Map<UInt160, UInt160> delegationMap = (Map<UInt160, UInt160>)StdLib.Deserialize(delegationData);
        if (!delegationMap.HasKey(delegator)) return UInt160.Zero;
        return delegationMap[delegator];
    }

    // Dispatcher ops to keep ABI compact
    private enum StorageOp : byte
    {
        // Backer donations
        GetBackerDonation = 0x01,
        SetBackerDonation = 0x02,

        // Totals
        GetProjectTotalBalance = 0x03,
        SetProjectTotalBalance = 0x04,

        // Fraud / activity
        GetVoteSwitchingCount = 0x05,
        SetVoteSwitchingCount = 0x06,
        GetLastVoteTimestamp = 0x07,
        SetLastVoteTimestamp = 0x08,
        GetFraudScore = 0x09,
        SetFraudScore = 0x0A,

        // Eligibility / bans
        IsBackerEligible = 0x0B,
        IsParticipantBanned = 0x0C,

        // Voting snapshots and counts
        GetVotesSnapshot = 0x0D,
        GetEligibleVotersCount = 0x0E,
        RecordVote = 0x0F,

        // Delegations
        GetDelegateFor = 0x10,
        SetVoteDelegation = 0x11,
        RemoveVoteDelegation = 0x12,
        ClearVotes = 0x13,

        // Simple settings
        GetVotingDeadline = 0x20,
        SetVotingDeadline = 0x21,

        // Reserved funds
        GetReservedFunds = 0x30,
        SetReservedFunds = 0x31,

        // Bans
        BanParticipant = 0x40,
        UnbanParticipant = 0x41
    }

    public static object entry(byte op, object[] args)
    {
        var code = (StorageOp)op;
        switch (code)
        {
            // Backer donations
            case StorageOp.GetBackerDonation:
                {
                    string projectId = (string)args[0];
                    UInt160 backer = (UInt160)args[1];
                    return PrivateMethods.GetBackerDonation(projectId, backer);
                }
            case StorageOp.SetBackerDonation:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    UInt160 backer = (UInt160)args[1];
                    BigInteger amount = (BigInteger)args[2];
                    PrivateMethods.SetBackerDonation(projectId, backer, amount);
                    return true;
                }

            // Totals
            case StorageOp.GetProjectTotalBalance:
                {
                    string projectId = (string)args[0];
                    return PrivateMethods.GetProjectTotalBalance(projectId);
                }
            case StorageOp.SetProjectTotalBalance:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    BigInteger balance = (BigInteger)args[1];
                    PrivateMethods.SetProjectTotalBalance(projectId, balance);
                    return true;
                }

            // Fraud / activity
            case StorageOp.GetVoteSwitchingCount:
                {
                    string projectId = (string)args[0];
                    UInt160 voter = (UInt160)args[1];
                    return PrivateMethods.GetVoteSwitchingCount(projectId, voter);
                }
            case StorageOp.SetVoteSwitchingCount:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    UInt160 voter = (UInt160)args[1];
                    int count = (int)(BigInteger)args[2];
                    PrivateMethods.SetVoteSwitchingCount(projectId, voter, count);
                    return true;
                }
            case StorageOp.GetLastVoteTimestamp:
                {
                    string projectId = (string)args[0];
                    UInt160 voter = (UInt160)args[1];
                    return PrivateMethods.GetLastVoteTimestamp(projectId, voter);
                }
            case StorageOp.SetLastVoteTimestamp:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    UInt160 voter = (UInt160)args[1];
                    ulong ts = (ulong)(BigInteger)args[2];
                    PrivateMethods.SetLastVoteTimestamp(projectId, voter, ts);
                    return true;
                }
            case StorageOp.GetFraudScore:
                {
                    string projectId = (string)args[0];
                    UInt160 participant = (UInt160)args[1];
                    return PrivateMethods.GetFraudScore(projectId, participant);
                }
            case StorageOp.SetFraudScore:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    UInt160 participant = (UInt160)args[1];
                    BigInteger score = (BigInteger)args[2];
                    PrivateMethods.SetFraudScore(projectId, participant, score);
                    return true;
                }

            // Eligibility / bans
            case StorageOp.IsBackerEligible:
                {
                    string projectId = (string)args[0];
                    UInt160 backer = (UInt160)args[1];
                    return PrivateMethods.IsBackerEligible(projectId, backer);
                }
            case StorageOp.IsParticipantBanned:
                {
                    string projectId = (string)args[0];
                    UInt160 participant = (UInt160)args[1];
                    return PrivateMethods.IsParticipantBanned(projectId, participant);
                }

            // Voting snapshots and counts
            case StorageOp.GetVotesSnapshot:
                {
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    int skip = (int)(BigInteger)args[2];
                    int take = (int)(BigInteger)args[3];
                    var (voters, votes) = GetVotesSnapshot_Internal(projectId, votingType, skip, take);
                    // Wrap into object[] for cross-contract
                    return new object[] { voters, votes };
                }
            case StorageOp.GetEligibleVotersCount:
                {
                    string projectId = (string)args[0];
                    return PrivateMethods.GetEligibleVotersCount(projectId);
                }
            case StorageOp.RecordVote:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    UInt160 backer = (UInt160)args[2];
                    BackerVotesEnum vote = (BackerVotesEnum)(int)(BigInteger)args[3];
                    PrivateMethods.RecordVote(projectId, votingType, backer, vote);
                    return true;
                }

            // Delegations
            case StorageOp.GetDelegateFor:
                {
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    UInt160 delegator = (UInt160)args[2];
                    return GetDelegateForInternal(projectId, votingType, delegator);
                }
            case StorageOp.SetVoteDelegation:
                {
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    UInt160 delegator = (UInt160)args[2];
                    UInt160 del = (UInt160)args[3];
                    SetVoteDelegation_Internal(projectId, votingType, delegator, del);
                    return true;
                }
            case StorageOp.RemoveVoteDelegation:
                {
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    UInt160 delegator = (UInt160)args[2];
                    RemoveVoteDelegation_Internal(projectId, votingType, delegator);
                    return true;
                }
            case StorageOp.ClearVotes:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    PrivateMethods.ClearVotes(projectId, votingType);
                    return true;
                }

            // Simple settings
            case StorageOp.GetVotingDeadline:
                {
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    return PrivateMethods.GetVotingDeadline(projectId, votingType);
                }
            case StorageOp.SetVotingDeadline:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    string votingType = (string)args[1];
                    ulong deadline = (ulong)(BigInteger)args[2];
                    PrivateMethods.SetVotingDeadline(projectId, votingType, deadline);
                    return true;
                }

            // Reserved funds
            case StorageOp.GetReservedFunds:
                {
                    string projectId = (string)args[0];
                    UInt160 manufacturer = (UInt160)args[1];
                    return PrivateMethods.GetReservedFunds(projectId, manufacturer);
                }
            case StorageOp.SetReservedFunds:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    UInt160 manufacturer = (UInt160)args[1];
                    BigInteger amount = (BigInteger)args[2];
                    PrivateMethods.SetReservedFunds(projectId, manufacturer, amount);
                    return true;
                }

            // Bans
            case StorageOp.BanParticipant:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    UInt160 participant = (UInt160)args[1];
                    bool isManufacturer = (bool)args[2];
                    BanReason reason = (BanReason)(int)(BigInteger)args[3];
                    PrivateMethods.BanParticipant(projectId, participant, isManufacturer, reason);
                    return true;
                }
            case StorageOp.UnbanParticipant:
                {
                    PrivateMethods.RequireAuth();
                    string projectId = (string)args[0];
                    UInt160 participant = (UInt160)args[1];
                    bool isManufacturer = (bool)args[2];
                    PrivateMethods.UnbanParticipant(projectId, participant, isManufacturer);
                    return true;
                }
        }

        throw new Exception("Unknown op");
    }



    public static object entryLogic(string methodName, object[] args)
    {
        PrivateMethods.RequireAuth();  // �������� �����������

        switch (methodName)
        {
            case nameof(PrivateMethods.GetSuspiciousActivityScore):
                return PrivateMethods.GetSuspiciousActivityScore((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.SetSuspiciousActivityScore):
                PrivateMethods.SetSuspiciousActivityScore((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;


            // ============ GET METHODS (Read-Only) ============

            // Backer & Voting
            case nameof(PrivateMethods.IsBackerEligible):
                return PrivateMethods.IsBackerEligible((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetBackerDonation):
                return PrivateMethods.GetBackerDonation((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetEligibleVotersCount):
                return PrivateMethods.GetEligibleVotersCount((string)args[0]);

            case nameof(PrivateMethods.GetBackerVoteWeight):
                return PrivateMethods.GetBackerVoteWeight((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetBackerVoteWeightValue):
                return PrivateMethods.GetBackerVoteWeightValue((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetBackerReservation):
                return PrivateMethods.GetBackerReservation((string)args[0], (UInt160)args[1], (UInt160)args[2]);

            case nameof(PrivateMethods.GetBackersWithDonations):
                return PrivateMethods.GetBackersWithDonations((string)args[0]);

            case nameof(PrivateMethods.GetBackerTokenReward):
                return PrivateMethods.GetBackerTokenReward((string)args[0], (UInt160)args[1]);

            // Manufacturer
            case nameof(PrivateMethods.IsManufacturerRegistered):
                return PrivateMethods.IsManufacturerRegistered((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetManufacturerCandidates):
                return PrivateMethods.GetManufacturerCandidates((string)args[0]);

            case nameof(PrivateMethods.GetManufacturerQualityScore):
                return PrivateMethods.GetManufacturerQualityScore((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetManufacturerVoteWeight):
                return PrivateMethods.GetManufacturerVoteWeight((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetManufacturerReliabilityTier):
                return PrivateMethods.GetManufacturerReliabilityTier((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetManufacturerPenalty):
                return PrivateMethods.GetManufacturerPenalty((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetManufacturerPreferredTemplate):
                return PrivateMethods.GetManufacturerPreferredTemplate((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetPenaltyTimestamp):
                return PrivateMethods.GetPenaltyTimestamp((string)args[0], (UInt160)args[1]);

            // Project State
            case nameof(PrivateMethods.GetProjectTotalBalance):
                return PrivateMethods.GetProjectTotalBalance((string)args[0]);

            case nameof(PrivateMethods.GetProjectCoreBytes):
                return PrivateMethods.GetProjectCoreBytes((string)args[0]);

            case nameof(PrivateMethods.GetProjectStatus):
                return PrivateMethods.GetProjectStatus((string)args[0]);

            case nameof(PrivateMethods.GetProjectFlags):
                return PrivateMethods.GetProjectFlags((string)args[0]);

            case nameof(PrivateMethods.GetProjectActivityScore):
                return PrivateMethods.GetProjectActivityScore((string)args[0]);

            case nameof(PrivateMethods.GetLastActivityTime):
                return PrivateMethods.GetLastActivityTime((string)args[0]);

            case nameof(PrivateMethods.GetLockedFunds):
                return PrivateMethods.GetLockedFunds((string)args[0]);

            // Voting Deadlines
            case nameof(PrivateMethods.GetVotingDeadline):
                return PrivateMethods.GetVotingDeadline((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.GetProjectVotingDeadlines):
                return PrivateMethods.GetProjectVotingDeadlines((string)args[0]);

            case nameof(PrivateMethods.GetVotingConfiguration):
                return PrivateMethods.GetVotingConfiguration((string)args[0]);

            // Fraud Detection
            case nameof(PrivateMethods.GetFraudScore):
                return PrivateMethods.GetFraudScore((string)args[0], (UInt160)args[1]);



            case nameof(PrivateMethods.GetLastVoteTimestamp):
                return PrivateMethods.GetLastVoteTimestamp((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetVoteSwitchingCount):
                return PrivateMethods.GetVoteSwitchingCount((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.IsParticipantBanned):
                return PrivateMethods.IsParticipantBanned((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetParticipantBanReason):
                return PrivateMethods.GetParticipantBanReason((string)args[0], (UInt160)args[1]);

            // Milestones
            case nameof(PrivateMethods.GetMilestoneCompletionVotesStruct):
                return PrivateMethods.GetMilestoneCompletionVotesStruct((string)args[0], (UInt160)args[1], (byte)args[2]);

            case nameof(PrivateMethods.GetMilestoneKeys):
                return PrivateMethods.GetMilestoneKeys((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetMilestoneBackerVote):
                return PrivateMethods.GetMilestoneBackerVote((string)args[0], (UInt160)args[1], (byte)args[2], (UInt160)args[3]);

            case nameof(PrivateMethods.HasMilestoneBackerVote):
                return PrivateMethods.HasMilestoneBackerVote((string)args[0], (UInt160)args[1], (byte)args[2], (UInt160)args[3]);

            case nameof(PrivateMethods.GetMilestoneFraudFlag):
                return PrivateMethods.GetMilestoneFraudFlag((string)args[0], (UInt160)args[1], (byte)args[2], (UInt160)args[3]);

            case nameof(PrivateMethods.GetMilestoneTemplate):
                return PrivateMethods.GetMilestoneTemplate((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.GetMilestoneTemplateParam):
                return PrivateMethods.GetMilestoneTemplateParam((string)args[0], (string)args[1], (string)args[2]);

            case nameof(PrivateMethods.GetMilestonePerformanceAnalytics):
                return PrivateMethods.GetMilestonePerformanceAnalytics((string)args[0], (UInt160)args[1]);

            // Winner Selection
            case nameof(PrivateMethods.GetWinnerSelectionVote):
                return PrivateMethods.GetWinnerSelectionVote((string)args[0], (UInt160)args[1], (UInt160)args[2]);

            case nameof(PrivateMethods.GetCandidateWinnerVotes):
                return PrivateMethods.GetCandidateWinnerVotes((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetWinnerVoteFraudFlag):
                return PrivateMethods.GetWinnerVoteFraudFlag((string)args[0], (UInt160)args[1], (UInt160)args[2]);

            case nameof(PrivateMethods.GetAutoSelectWinner):
                return PrivateMethods.GetAutoSelectWinner((string)args[0], (UInt160)args[1]);

            // Management Transfer
            case nameof(PrivateMethods.GetManagementTransferVote):
                return PrivateMethods.GetManagementTransferVote((string)args[0], (UInt160)args[1]);

            // Project Updates
            case nameof(PrivateMethods.IsProjectUpdateVotingActive):
                return PrivateMethods.IsProjectUpdateVotingActive((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.IsProjectUpdateVotingFinalized):
                return PrivateMethods.IsProjectUpdateVotingFinalized((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.GetProjectUpdateVotingResults):
                return PrivateMethods.GetProjectUpdateVotingResults((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.IsUpdateApproved):
                return PrivateMethods.IsUpdateApproved((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.GetProjectUpdateVote):
                return PrivateMethods.GetProjectUpdateVote((string)args[0], (string)args[1], (UInt160)args[2]);

            case nameof(PrivateMethods.GetProjectUpdateVotingDeadline):
                return PrivateMethods.GetProjectUpdateVotingDeadline((string)args[0], (string)args[1]);

            // Referral System
            case nameof(PrivateMethods.GetReferrer):
                return PrivateMethods.GetReferrer((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetReferralReward):
                return PrivateMethods.GetReferralReward((string)args[0], (UInt160)args[1]);

            // Conditional Voting
            case nameof(PrivateMethods.GetConditionalVotingRule):
                return PrivateMethods.GetConditionalVotingRule((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.GetConditionalThreshold):
                return PrivateMethods.GetConditionalThreshold((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.GetMultiTierVoting):
                return PrivateMethods.GetMultiTierVoting((string)args[0], (string)args[1], (UInt160)args[2]);

            case nameof(PrivateMethods.GetVoteWeightByTier):
                return PrivateMethods.GetVoteWeightByTier((string)args[0], (string)args[1]);

            case nameof(PrivateMethods.GetVotingTierWeightsKeys):
                return PrivateMethods.GetVotingTierWeightsKeys((string)args[0]);

            // Analytics
            case nameof(PrivateMethods.GetDailyParticipationStats):
                return PrivateMethods.GetDailyParticipationStats((string)args[0], (ulong)(BigInteger)args[1]);

            case nameof(PrivateMethods.GetTotalRefundsProcessed):
                return PrivateMethods.GetTotalRefundsProcessed((string)args[0]);

            case nameof(PrivateMethods.GetRefundHistory):
                return PrivateMethods.GetRefundHistory((string)args[0], (UInt160)args[1]);

            // Notifications
            case nameof(PrivateMethods.GetNotificationPreference):
                return PrivateMethods.GetNotificationPreference((string)args[0], (UInt160)args[1]);

            case nameof(PrivateMethods.GetVotingReminderTimestamp):
                return PrivateMethods.GetVotingReminderTimestamp((string)args[0], (int)(BigInteger)args[1]);

            case nameof(PrivateMethods.GetDeadlineNotificationSent):
                return PrivateMethods.GetDeadlineNotificationSent((string)args[0], (UInt160)args[1]);

            // Reserved Funds
            case nameof(PrivateMethods.GetReservedFunds):
                return PrivateMethods.GetReservedFunds((string)args[0], (UInt160)args[1]);

            // Offers
            case nameof(PrivateMethods.GetOfferReservedDonation):
                return PrivateMethods.GetOfferReservedDonation((string)args[0], (UInt160)args[1]);

            // Delegation
            case nameof(PrivateMethods.ResolveFinalDelegate):
                return PrivateMethods.ResolveFinalDelegate((string)args[0], (string)args[1], (UInt160)args[2]);

            case nameof(PrivateMethods.ValidateDelegationIntegrity):
                return PrivateMethods.ValidateDelegationIntegrity((string)args[0]);

            // Vote Outcome (Compute)
            case nameof(PrivateMethods.CalculateVoteOutcome):
                return PrivateMethods.CalculateVoteOutcome(
                    (string)args[0],
                    (string)args[1],
                    (bool)args[2],
                    (bool)args[3],
                    (BigInteger)args[4],
                    (BigInteger)args[5]
                );

            // Votes Snapshot
            case nameof(PrivateMethods.GetVotesSnapshot):
                {
                    var (voters, votes) = PrivateMethods.GetVotesSnapshot(
                        (string)args[0],
                        (string)args[1],
                        (int)(BigInteger)args[2],
                        (int)(BigInteger)args[3]
                    );
                    return new object[] { voters, votes };
                }

            // Authorization Check
            case nameof(PrivateMethods.IsAuthorized):
                return PrivateMethods.IsAuthorized();

            // ============ SET METHODS (Write) ============

            // Backer & Donations
            case nameof(PrivateMethods.SetBackerDonation):
                PrivateMethods.SetBackerDonation((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetBackerReservation):
                PrivateMethods.SetBackerReservation((string)args[0], (UInt160)args[1], (UInt160)args[2], (BigInteger)args[3]);
                return true;

            case nameof(PrivateMethods.SetBackerTokenReward):
                PrivateMethods.SetBackerTokenReward((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetBackerVoteWeightValue):
                PrivateMethods.SetBackerVoteWeightValue((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            // Manufacturer
            case nameof(PrivateMethods.RegisterManufacturer):
                PrivateMethods.RegisterManufacturer((string)args[0], (UInt160)args[1], (string)args[2]);
                return true;

            case nameof(PrivateMethods.UnregisterManufacturer):
                PrivateMethods.UnregisterManufacturer((string)args[0], (UInt160)args[1]);
                return true;

            case nameof(PrivateMethods.SetManufacturerQualityScore):
                PrivateMethods.SetManufacturerQualityScore((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetManufacturerVoteWeight):
                PrivateMethods.SetManufacturerVoteWeight((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetManufacturerReliabilityTier):
                PrivateMethods.SetManufacturerReliabilityTier((string)args[0], (UInt160)args[1], (byte)args[2]);
                return true;

            case nameof(PrivateMethods.SetManufacturerPenalty):
                PrivateMethods.SetManufacturerPenalty((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetManufacturerPreferredTemplate):
                PrivateMethods.SetManufacturerPreferredTemplate((string)args[0], (UInt160)args[1], (string)args[2]);
                return true;

            case nameof(PrivateMethods.SetPenaltyTimestamp):
                PrivateMethods.SetPenaltyTimestamp((string)args[0], (UInt160)args[1], (ulong)(BigInteger)args[2]);
                return true;

            // Project State
            case nameof(PrivateMethods.SetProjectCore):
                PrivateMethods.SetProjectCore((string)args[0], (ByteString)args[1]);
                return true;

            case nameof(PrivateMethods.SetProjectTotalBalance):
                PrivateMethods.SetProjectTotalBalance((string)args[0], (BigInteger)args[1]);
                return true;

            case nameof(PrivateMethods.SetProjectStatus):
                PrivateMethods.SetProjectStatus((string)args[0], (int)(BigInteger)args[1]);
                return true;

            case nameof(PrivateMethods.SetProjectFlags):
                PrivateMethods.SetProjectFlags((string)args[0], (bool)args[1], (bool)args[2], (bool)args[3], (bool)args[4]);
                return true;

            case nameof(PrivateMethods.SetProjectActivityScore):
                PrivateMethods.SetProjectActivityScore((string)args[0], (BigInteger)args[1]);
                return true;

            case nameof(PrivateMethods.SetLastActivityTime):
                PrivateMethods.SetLastActivityTime((string)args[0], (ulong)(BigInteger)args[1]);
                return true;

            case nameof(PrivateMethods.SetLockedFunds):
                PrivateMethods.SetLockedFunds((string)args[0], (BigInteger)args[1]);
                return true;

            case nameof(PrivateMethods.UpdateLockedFunds):
                PrivateMethods.UpdateLockedFunds((string)args[0], (BigInteger)args[1]);
                return true;

            // Voting
            case nameof(PrivateMethods.RecordVote):
                PrivateMethods.RecordVote((string)args[0], (string)args[1], (UInt160)args[2], (BackerVotesEnum)(int)(BigInteger)args[3]);
                return true;

            case nameof(PrivateMethods.ClearVotes):
                PrivateMethods.ClearVotes((string)args[0], (string)args[1]);
                return true;

            case nameof(PrivateMethods.SetVotingDeadline):
                PrivateMethods.SetVotingDeadline((string)args[0], (string)args[1], (ulong)(BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetProjectVotingDeadlines):
                PrivateMethods.SetProjectVotingDeadlines(
                    (string)args[0],
                    (ulong)(BigInteger)args[1],
                    (ulong)(BigInteger)args[2],
                    (ulong)(BigInteger)args[3]
                );
                return true;

            case nameof(PrivateMethods.SetVotingConfiguration):
                PrivateMethods.SetVotingConfiguration(
                    (string)args[0],
                    (BigInteger)args[1],
                    (BigInteger)args[2],
                    (bool)args[3],
                    (bool)args[4]
                );
                return true;

            // Fraud Detection
            case nameof(PrivateMethods.SetFraudScore):
                PrivateMethods.SetFraudScore((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;


            case nameof(PrivateMethods.SetLastVoteTimestamp):
                PrivateMethods.SetLastVoteTimestamp((string)args[0], (UInt160)args[1], (ulong)(BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetVoteSwitchingCount):
                PrivateMethods.SetVoteSwitchingCount((string)args[0], (UInt160)args[1], (int)(BigInteger)args[2]);
                return true;

            // Bans
            case nameof(PrivateMethods.BanParticipant):
                PrivateMethods.BanParticipant((string)args[0], (UInt160)args[1], (bool)args[2], (BanReason)(int)(BigInteger)args[3]);
                return true;

            case nameof(PrivateMethods.UnbanParticipant):
                PrivateMethods.UnbanParticipant((string)args[0], (UInt160)args[1], (bool)args[2]);
                return true;

            // Milestones
            case nameof(PrivateMethods.SetMilestoneCompletionVotesStruct):
                PrivateMethods.SetMilestoneCompletionVotesStruct((string)args[0], (UInt160)args[1], (byte)args[2], args[3]);
                return true;

            case nameof(PrivateMethods.DeleteMilestone):
                PrivateMethods.DeleteMilestone((string)args[0], (UInt160)args[1], (byte)args[2]);
                return true;

            case nameof(PrivateMethods.SetMilestoneBackerVote):
                PrivateMethods.SetMilestoneBackerVote((string)args[0], (UInt160)args[1], (byte)args[2], (UInt160)args[3], (BackerVotesEnum)(int)(BigInteger)args[4]);
                return true;

            case nameof(PrivateMethods.RemoveMilestoneBackerVote):
                PrivateMethods.RemoveMilestoneBackerVote((string)args[0], (UInt160)args[1], (byte)args[2], (UInt160)args[3]);
                return true;

            case nameof(PrivateMethods.ClearMilestoneVotes):
                PrivateMethods.ClearMilestoneVotes((string)args[0], (UInt160)args[1], (byte)args[2]);
                return true;

            case nameof(PrivateMethods.SetMilestoneFraudFlag):
                PrivateMethods.SetMilestoneFraudFlag((string)args[0], (UInt160)args[1], (byte)args[2], (UInt160)args[3], (bool)args[4]);
                return true;

            case nameof(PrivateMethods.ClearMilestoneFraudFlags):
                PrivateMethods.ClearMilestoneFraudFlags((string)args[0], (UInt160)args[1], (byte)args[2]);
                return true;

            case nameof(PrivateMethods.SetMilestoneTemplate):
                PrivateMethods.SetMilestoneTemplate((string)args[0], (string)args[1], args[2]);
                return true;

            case nameof(PrivateMethods.SetMilestoneTemplateParam):
                PrivateMethods.SetMilestoneTemplateParam((string)args[0], (string)args[1], (string)args[2], (string)args[3]);
                return true;

            case nameof(PrivateMethods.RemoveMilestoneTemplateParam):
                PrivateMethods.RemoveMilestoneTemplateParam((string)args[0], (string)args[1], (string)args[2]);
                return true;

            case nameof(PrivateMethods.ClearMilestoneTemplateParams):
                PrivateMethods.ClearMilestoneTemplateParams((string)args[0], (string)args[1]);
                return true;

            // Winner Selection
            case nameof(PrivateMethods.SetWinnerSelectionVote):
                PrivateMethods.SetWinnerSelectionVote((string)args[0], (UInt160)args[1], (UInt160)args[2], (int)(BigInteger)args[3]);
                return true;

            case nameof(PrivateMethods.SetCandidateWinnerVotes):
                PrivateMethods.SetCandidateWinnerVotes((string)args[0], (UInt160)args[1], args[2]);
                return true;

            case nameof(PrivateMethods.SetWinnerVoteFraudFlag):
                PrivateMethods.SetWinnerVoteFraudFlag((string)args[0], (UInt160)args[1], (UInt160)args[2], (bool)args[3]);
                return true;

            case nameof(PrivateMethods.ClearWinnerVoteFraudFlags):
                PrivateMethods.ClearWinnerVoteFraudFlags((string)args[0], (UInt160)args[1]);
                return true;

            case nameof(PrivateMethods.SetAutoSelectWinner):
                PrivateMethods.SetAutoSelectWinner((string)args[0], (UInt160)args[1], (UInt160)args[2]);
                return true;

            case nameof(PrivateMethods.ClearAutoSelections):
                PrivateMethods.ClearAutoSelections((string)args[0]);
                return true;

            // Management Transfer
            case nameof(PrivateMethods.SetManagementTransferVote):
                PrivateMethods.SetManagementTransferVote((string)args[0], (UInt160)args[1], (int)(BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetManagementTransferResults):
                PrivateMethods.SetManagementTransferResults(
                    (string)args[0],
                    (BigInteger)args[1],
                    (BigInteger)args[2],
                    (BigInteger)args[3],
                    (BigInteger)args[4]
                );
                return true;

            // Project Updates
            case nameof(PrivateMethods.SetProjectUpdateVotingStatus):
                PrivateMethods.SetProjectUpdateVotingStatus((string)args[0], (string)args[1], (bool)args[2], (bool)args[3]);
                return true;

            case nameof(PrivateMethods.SetProjectUpdateVotingResults):
                PrivateMethods.SetProjectUpdateVotingResults(
                    (string)args[0],
                    (string)args[1],
                    (BigInteger)args[2],
                    (BigInteger)args[3],
                    (BigInteger)args[4],
                    (BigInteger)args[5]
                );
                return true;

            case nameof(PrivateMethods.SetApprovedUpdate):
                PrivateMethods.SetApprovedUpdate((string)args[0], (string)args[1], (bool)args[2]);
                return true;

            case nameof(PrivateMethods.SetProjectUpdateVote):
                PrivateMethods.SetProjectUpdateVote((string)args[0], (string)args[1], (UInt160)args[2], (BackerVotesEnum)(int)(BigInteger)args[3]);
                return true;

            case nameof(PrivateMethods.SetProjectUpdateVotingDeadline):
                PrivateMethods.SetProjectUpdateVotingDeadline((string)args[0], (string)args[1], (ulong)(BigInteger)args[2]);
                return true;

            // Referral System
            case nameof(PrivateMethods.SetReferrer):
                PrivateMethods.SetReferrer((string)args[0], (UInt160)args[1], (UInt160)args[2]);
                return true;

            case nameof(PrivateMethods.SetReferralReward):
                PrivateMethods.SetReferralReward((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            // Conditional Voting
            case nameof(PrivateMethods.SetConditionalVotingRule):
                PrivateMethods.SetConditionalVotingRule((string)args[0], (string)args[1], (bool)args[2]);
                return true;

            case nameof(PrivateMethods.SetConditionalThreshold):
                PrivateMethods.SetConditionalThreshold((string)args[0], (string)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetMultiTierVoting):
                PrivateMethods.SetMultiTierVoting((string)args[0], (string)args[1], (UInt160)args[2], (byte)args[3]);
                return true;

            case nameof(PrivateMethods.SetVoteWeightByTier):
                PrivateMethods.SetVoteWeightByTier((string)args[0], (string)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.RemoveVoteWeightByTier):
                PrivateMethods.RemoveVoteWeightByTier((string)args[0], (string)args[1]);
                return true;

            case nameof(PrivateMethods.ClearVotingTierWeights):
                PrivateMethods.ClearVotingTierWeights((string)args[0]);
                return true;

            // Analytics
            case nameof(PrivateMethods.SetDailyParticipationStats):
                PrivateMethods.SetDailyParticipationStats((string)args[0], (ulong)(BigInteger)args[1], (BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetTotalRefundsProcessed):
                PrivateMethods.SetTotalRefundsProcessed((string)args[0], (BigInteger)args[1]);
                return true;

            case nameof(PrivateMethods.SetRefundHistory):
                PrivateMethods.SetRefundHistory((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            // Notifications
            case nameof(PrivateMethods.SetNotificationPreference):
                PrivateMethods.SetNotificationPreference((string)args[0], (UInt160)args[1], (bool)args[2]);
                return true;

            case nameof(PrivateMethods.SetVotingReminderTimestamp):
                PrivateMethods.SetVotingReminderTimestamp((string)args[0], (int)(BigInteger)args[1], (ulong)(BigInteger)args[2]);
                return true;

            case nameof(PrivateMethods.SetDeadlineNotificationSent):
                PrivateMethods.SetDeadlineNotificationSent((string)args[0], (UInt160)args[1], (bool)args[2]);
                return true;

            // Reserved Funds
            case nameof(PrivateMethods.SetReservedFunds):
                PrivateMethods.SetReservedFunds((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            // Offers
            case nameof(PrivateMethods.SetOfferReservedDonation):
                PrivateMethods.SetOfferReservedDonation((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                return true;

            // Logic Contract
            case nameof(PrivateMethods.SetLogicContract):
                PrivateMethods.SetLogicContract((UInt160)args[0]);
                return true;

            default:
                throw new Exception("Unknown method: " + methodName);
        }
    }


    public static class PrivateMethods
    {


        // ========= EXISTING API (compute-heavy) made private to reduce ABI size =========
        public static void SetProjectUpdateVotingStatus(string projectId, string updateId, bool isActive, bool isFinalized)
        {
            RequireAuth();
            byte[] activeKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_active", updateId);
            byte[] finalizedKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_finalized", updateId);

            if (isActive)
                Storage.Put(Storage.CurrentContext, activeKey, 1);
            else
                Storage.Delete(Storage.CurrentContext, activeKey);

            if (isFinalized)
                Storage.Put(Storage.CurrentContext, finalizedKey, 1);
            else
                Storage.Delete(Storage.CurrentContext, finalizedKey);
        }

        public static void SetProjectCore(string projectId, ByteString coreBytes)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "core");
            Storage.Put(Storage.CurrentContext, key, coreBytes);
        }

        public static ByteString GetProjectCoreBytes(string projectId)
        {
            byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "core");
            return Storage.Get(Storage.CurrentContext, key);
        }

        public static bool IsAuthorized()
        {
            UInt160 logicContract = (UInt160)Storage.Get(Storage.CurrentContext, LogicContractHashKey);
            return Runtime.CallingScriptHash == logicContract;
        }

        public static void RequireAuth()
        {
            if (!IsAuthorized())
                throw new Exception("Unauthorized access");
        }

        public static void SetLogicContract(UInt160 newLogicContract)
        {
            if (!IsAuthorized())
                throw new Exception("Only current logic contract can update authorization");
            Storage.Put(Storage.CurrentContext, LogicContractHashKey, newLogicContract);
        }

        public static byte[] CreateProjectKey(byte[] prefix, string projectId)
        {
            return prefix.Concat(projectId.ToByteArray());
        }

        public static byte[] CreateProjectActorKey(byte[] prefix, string projectId, UInt160 actor)
        {
            return prefix.Concat(projectId.ToByteArray()).Concat(actor);
        }

        public static byte[] CreateProjectComplexKey(byte[] prefix, string projectId, string complexKey)
        {
            return prefix.Concat(projectId.ToByteArray()).Concat(complexKey.ToByteArray());
        }

        public static bool IsBackerEligible(string projectId, UInt160 backer)
        {
            byte[] key = CreateProjectActorKey(BackerDonationsPrefix, projectId, backer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            BigInteger donation = result != null ? (BigInteger)result : 0;

            byte[] banKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_backers", backer);
            bool isBanned = Storage.Get(Storage.CurrentContext, banKey) != null;

            return donation > 0 && !isBanned;
        }

        public static BigInteger GetBackerDonation(string projectId, UInt160 backer)
        {
            byte[] key = CreateProjectActorKey(BackerDonationsPrefix, projectId, backer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        public static void SetBackerDonation(string projectId, UInt160 backer, BigInteger amount)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(BackerDonationsPrefix, projectId, backer);
            if (amount > 0)
                Storage.Put(Storage.CurrentContext, key, amount);
            else
                Storage.Delete(Storage.CurrentContext, key);
        }

        public static BigInteger GetEligibleVotersCount(string projectId)
        {
            byte[] prefix = CreateProjectKey(BackerDonationsPrefix, projectId);
            Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.ValuesOnly);

            BigInteger count = 0;
            while (iterator.Next())
            {
                BigInteger value = (BigInteger)iterator.Value;
                if (value > 0)
                {
                    count++;
                }
            }
            return count;
        }

        public static (UInt160[], BackerVotesEnum[]) GetVotesSnapshot(string projectId, string votingType, int skip, int take)
        {
            byte[] prefix = CreateProjectKey(VotingMapsPrefix, projectId + "_" + votingType);
            Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

            Neo.SmartContract.Framework.List<UInt160> voters = new Neo.SmartContract.Framework.List<UInt160>();
            Neo.SmartContract.Framework.List<BackerVotesEnum> votes = new Neo.SmartContract.Framework.List<BackerVotesEnum>();

            int current = 0;
            int taken = 0;

            while (iterator.Next() && taken < take)
            {
                if (current >= skip)
                {
                    byte[] keyBytes = (byte[])iterator.Value;
                    byte[] voterBytes = keyBytes.Range(keyBytes.Length - 20, 20);
                    UInt160 voter = (UInt160)voterBytes;

                    ByteString voteResult = Storage.Get(Storage.CurrentContext, keyBytes);
                    BackerVotesEnum vote = (BackerVotesEnum)(int)(BigInteger)voteResult;

                    voters.Add(voter);
                    votes.Add(vote);
                    taken++;
                }
                current++;
            }

            return (voters, votes);
        }

        public static void RecordVote(string projectId, string votingType, UInt160 backer, BackerVotesEnum vote)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(VotingMapsPrefix, projectId + "_" + votingType, backer);
            Storage.Put(Storage.CurrentContext, key, (int)vote);
        }

        public static void ClearVotes(string projectId, string votingType)
        {
            RequireAuth();
            byte[] prefix = CreateProjectKey(VotingMapsPrefix, projectId + "_" + votingType);
            Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

            while (iterator.Next())
            {
                Storage.Delete(Storage.CurrentContext, (byte[])iterator.Value);
            }
        }

        public static CalculatedVoteOutcome CalculateVoteOutcome(string projectId, string votingType,
        bool autoAssignVoiceless, bool abstainAsSupport, BigInteger minParticipationPct, BigInteger minApprovalPct)
        {
            // Moved to SC_NewLogic; keep private fallback if ever needed internally
            CalculatedVoteOutcome outcome = new CalculatedVoteOutcome();
            return outcome;
        }

        public static bool ValidateDelegationIntegrity(string projectId)
        {
            return true;
        }

        public static BigInteger GetBackerVoteWeight(string projectId, UInt160 backer)
        {
            // Moved to SC_NewLogic; keep minimal fallback
            BigInteger donation = GetBackerDonation(projectId, backer);
            if (donation <= 0) return 1;
            BigInteger totalProjectBalance = GetProjectTotalBalance(projectId);
            if (totalProjectBalance <= 0) return 1;
            BigInteger sharePercentage = (donation * 1000) / totalProjectBalance;
            BigInteger weight = 1 + (sharePercentage / 10);
            if (weight > 101) weight = 101;
            if (weight <= 0) weight = 1;
            return weight;
        }

        public static UInt160 ResolveFinalDelegate(string projectId, string votingType, UInt160 backer)
        {
            // Moved to SC_NewLogic; keep minimal fallback using local storage
            byte[] delegationKey = CreateProjectComplexKey(VoteDelegationPrefix, projectId, votingType);
            ByteString delegationData = Storage.Get(Storage.CurrentContext, delegationKey);
            Map<UInt160, UInt160> delegationMap;
            if (delegationData != null)
            {
                delegationMap = (Map<UInt160, UInt160>)StdLib.Deserialize(delegationData);
            }
            else
            {
                delegationMap = new Map<UInt160, UInt160>();
            }

            Map<UInt160, bool> visited = new Map<UInt160, bool>();
            UInt160 current = backer;
            int maxDepth = 100;

            for (int i = 0; i < maxDepth; i++)
            {
                if (visited.HasKey(current)) break;
                visited[current] = true;

                if (!delegationMap.HasKey(current)) return current;
                current = delegationMap[current];
            }

            return current;
        }

        public static ulong GetVotingDeadline(string projectId, string votingType)
        {
            byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_" + votingType);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (ulong)(BigInteger)result : 0;
        }

        public static void SetVotingDeadline(string projectId, string votingType, ulong deadline)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_" + votingType);
            Storage.Put(Storage.CurrentContext, key, (BigInteger)deadline);
        }

        public static BigInteger GetProjectTotalBalance(string projectId)
        {
            byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "total_balance");
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        public static void SetProjectTotalBalance(string projectId, BigInteger balance)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "total_balance");
            Storage.Put(Storage.CurrentContext, key, balance);
        }

        public static void RegisterManufacturer(string projectId, UInt160 manufacturer, string data)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_candidates", manufacturer);
            Storage.Put(Storage.CurrentContext, key, data);
        }

        public static void UnregisterManufacturer(string projectId, UInt160 manufacturer)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_candidates", manufacturer);
            Storage.Delete(Storage.CurrentContext, key);
        }

        public static void SetReservedFunds(string projectId, UInt160 manufacturer, BigInteger amount)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(ReservedFundsPrefix, projectId, manufacturer);
            if (amount > 0)
                Storage.Put(Storage.CurrentContext, key, amount);
            else
                Storage.Delete(Storage.CurrentContext, key);
        }

        public static BigInteger GetReservedFunds(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(ReservedFundsPrefix, projectId, manufacturer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        public static void BanParticipant(string projectId, UInt160 participant, bool isManufacturer, BanReason reason)
        {
            RequireAuth();
            string participantType = isManufacturer ? "_manufacturers" : "_backers";
            byte[] key = CreateProjectActorKey(BanMapsPrefix, projectId + participantType, participant);
            Storage.Put(Storage.CurrentContext, key, (int)reason);
        }

        public static void UnbanParticipant(string projectId, UInt160 participant, bool isManufacturer)
        {
            RequireAuth();
            string participantType = isManufacturer ? "_manufacturers" : "_backers";
            byte[] key = CreateProjectActorKey(BanMapsPrefix, projectId + participantType, participant);
            Storage.Delete(Storage.CurrentContext, key);
        }

        // ===== Milestone CRUD (blob) =====
        public static void DeleteMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            RequireAuth();
            string complexKey = manufacturer.ToString() + "_" + stepNumber.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId, complexKey);
            Storage.Delete(Storage.CurrentContext, key);
        }

        public static bool IsParticipantBanned(string projectId, UInt160 participant)
        {
            byte[] manufacturerKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_manufacturers", participant);
            byte[] backerKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_backers", participant);

            return Storage.Get(Storage.CurrentContext, manufacturerKey) != null ||
            Storage.Get(Storage.CurrentContext, backerKey) != null;
        }

        // ===================== FRAUD DETECTION =====================

        public static int GetVoteSwitchingCount(string projectId, UInt160 voter)
        {
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_vote_switching", voter);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (int)(BigInteger)result : 0;
        }

        public static void SetFraudScore(string projectId, UInt160 participant, BigInteger score)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_fraud_scores", participant);
            Storage.Put(Storage.CurrentContext, key, score);
        }

        public static BigInteger GetFraudScore(string projectId, UInt160 participant)
        {
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_fraud_scores", participant);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        public static void SetLastVoteTimestamp(string projectId, UInt160 voter, ulong timestamp)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_last_vote", voter);
            Storage.Put(Storage.CurrentContext, key, (BigInteger)timestamp);
        }

        public static ulong GetLastVoteTimestamp(string projectId, UInt160 voter)
        {
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_last_vote", voter);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (ulong)(BigInteger)result : 0;
        }

        public static void SetVoteSwitchingCount(string projectId, UInt160 voter, int count)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_vote_switching", voter);
            Storage.Put(Storage.CurrentContext, key, count);
        }

        // ===================== PROJECT UPDATE VOTING =====================

        public static bool IsProjectUpdateVotingActive(string projectId, string updateId)
        {
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_active", updateId);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static bool IsProjectUpdateVotingFinalized(string projectId, string updateId)
        {
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_finalized", updateId);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static void SetProjectUpdateVotingResults(string projectId, string updateId,
        BigInteger positiveVotes, BigInteger negativeVotes, BigInteger abstainedVotes, BigInteger totalVotes)
        {
            RequireAuth();
            byte[] positiveKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_positive", updateId);
            byte[] negativeKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_negative", updateId);
            byte[] abstainedKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_abstained", updateId);
            byte[] totalKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_total", updateId);

            Storage.Put(Storage.CurrentContext, positiveKey, positiveVotes);
            Storage.Put(Storage.CurrentContext, negativeKey, negativeVotes);
            Storage.Put(Storage.CurrentContext, abstainedKey, abstainedVotes);
            Storage.Put(Storage.CurrentContext, totalKey, totalVotes);
        }

        public static object[] GetProjectUpdateVotingResults(string projectId, string updateId)
        {
            byte[] positiveKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_positive", updateId);
            byte[] negativeKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_negative", updateId);
            byte[] abstainedKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_abstained", updateId);
            byte[] totalKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_total", updateId);

            ByteString positiveResult = Storage.Get(Storage.CurrentContext, positiveKey);
            ByteString negativeResult = Storage.Get(Storage.CurrentContext, negativeKey);
            ByteString abstainedResult = Storage.Get(Storage.CurrentContext, abstainedKey);
            ByteString totalResult = Storage.Get(Storage.CurrentContext, totalKey);

            BigInteger positive = positiveResult != null ? (BigInteger)positiveResult : 0;
            BigInteger negative = negativeResult != null ? (BigInteger)negativeResult : 0;
            BigInteger abstained = abstainedResult != null ? (BigInteger)abstainedResult : 0;
            BigInteger total = totalResult != null ? (BigInteger)totalResult : 0;

            return new object[] { positive, negative, abstained, total };
        }

        public static void SetApprovedUpdate(string projectId, string updateId, bool approved)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_approved", updateId);
            if (approved)
                Storage.Put(Storage.CurrentContext, key, 1);
            else
                Storage.Delete(Storage.CurrentContext, key);
        }

        public static bool IsUpdateApproved(string projectId, string updateId)
        {
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_approved", updateId);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static void SetProjectUpdateVote(string projectId, string updateId, UInt160 backer, BackerVotesEnum vote)
        {
            RequireAuth();
            string complexKey = updateId + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_votes", complexKey);
            Storage.Put(Storage.CurrentContext, key, (int)vote);
        }

        public static BackerVotesEnum GetProjectUpdateVote(string projectId, string updateId, UInt160 backer)
        {
            string complexKey = updateId + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_votes", complexKey);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BackerVotesEnum)(int)(BigInteger)result : BackerVotesEnum.Abstained;
        }

        public static void SetProjectUpdateVotingDeadline(string projectId, string updateId, ulong deadline)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_deadlines", updateId);
            Storage.Put(Storage.CurrentContext, key, (BigInteger)deadline);
        }

        public static ulong GetProjectUpdateVotingDeadline(string projectId, string updateId)
        {
            byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_deadlines", updateId);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (ulong)(BigInteger)result : 0;
        }

        // ===================== PROJECT SETTINGS/VOTING DEADLINES ETC. =====================

        public static void SetProjectVotingDeadlines(string projectId, ulong launchDeadline, ulong fundraisingDeadline, ulong manufacturerSelectionDeadline)
        {
            RequireAuth();
            byte[] launchKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_launch");
            byte[] fundraisingKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_fundraising");
            byte[] selectionKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_selection");

            Storage.Put(Storage.CurrentContext, launchKey, (BigInteger)launchDeadline);
            Storage.Put(Storage.CurrentContext, fundraisingKey, (BigInteger)fundraisingDeadline);
            Storage.Put(Storage.CurrentContext, selectionKey, (BigInteger)manufacturerSelectionDeadline);
        }

        public static object[] GetProjectVotingDeadlines(string projectId)
        {
            byte[] launchKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_launch");
            byte[] fundraisingKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_fundraising");
            byte[] selectionKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_selection");

            ByteString launchResult = Storage.Get(Storage.CurrentContext, launchKey);
            ByteString fundraisingResult = Storage.Get(Storage.CurrentContext, fundraisingKey);
            ByteString selectionResult = Storage.Get(Storage.CurrentContext, selectionKey);

            ulong launch = launchResult != null ? (ulong)(BigInteger)launchResult : 0;
            ulong fundraising = fundraisingResult != null ? (ulong)(BigInteger)fundraisingResult : 0;
            ulong selection = selectionResult != null ? (ulong)(BigInteger)selectionResult : 0;

            return new object[] { launch, fundraising, selection };
        }

        public static void SetAutoSelectWinner(string projectId, UInt160 backer, UInt160 manufacturer)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(AutoSelectionPrefix, projectId + "_auto_votes", backer);
            Storage.Put(Storage.CurrentContext, key, manufacturer);
        }

        public static UInt160 GetAutoSelectWinner(string projectId, UInt160 backer)
        {
            byte[] key = CreateProjectActorKey(AutoSelectionPrefix, projectId + "_auto_votes", backer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (UInt160)result : UInt160.Zero;
        }

        public static void ClearAutoSelections(string projectId)
        {
            RequireAuth();
            byte[] prefix = CreateProjectKey(AutoSelectionPrefix, projectId + "_auto_votes");
            Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

            while (iterator.Next())
            {
                Storage.Delete(Storage.CurrentContext, (byte[])iterator.Value);
            }
        }

        public static void SetVotingConfiguration(string projectId, BigInteger minParticipation, BigInteger minApproval,
        bool autoAssignVoiceless, bool abstainAsSupport)
        {
            RequireAuth();
            byte[] participationKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_participation");
            byte[] approvalKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_approval");
            byte[] voicelessKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "auto_assign_voiceless");
            byte[] abstainKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "abstain_as_support");

            Storage.Put(Storage.CurrentContext, participationKey, minParticipation);
            Storage.Put(Storage.CurrentContext, approvalKey, minApproval);
            Storage.Put(Storage.CurrentContext, voicelessKey, autoAssignVoiceless ? 1 : 0);
            Storage.Put(Storage.CurrentContext, abstainKey, abstainAsSupport ? 1 : 0);
        }

        public static VotingConfiguration GetVotingConfiguration(string projectId)
        {
            VotingConfiguration config = new VotingConfiguration();

            byte[] participationKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_participation");
            byte[] approvalKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_approval");
            byte[] voicelessKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "auto_assign_voiceless");
            byte[] abstainKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "abstain_as_support");

            ByteString participationResult = Storage.Get(Storage.CurrentContext, participationKey);
            ByteString approvalResult = Storage.Get(Storage.CurrentContext, approvalKey);
            ByteString voicelessResult = Storage.Get(Storage.CurrentContext, voicelessKey);
            ByteString abstainResult = Storage.Get(Storage.CurrentContext, abstainKey);

            config.MinParticipation = participationResult != null ? (BigInteger)participationResult : 0;
            config.MinApproval = approvalResult != null ? (BigInteger)approvalResult : 0;
            config.AutoAssignVoiceless = voicelessResult != null && (BigInteger)voicelessResult > 0;
            config.AbstainAsSupport = abstainResult != null && (BigInteger)abstainResult > 0;

            return config;
        }

        // ===================== REFERRAL SYSTEM =====================

        public static void SetReferrer(string projectId, UInt160 backer, UInt160 referrer)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_referrers", backer);
            Storage.Put(Storage.CurrentContext, key, referrer);
        }

        public static UInt160 GetReferrer(string projectId, UInt160 backer)
        {
            byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_referrers", backer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (UInt160)result : UInt160.Zero;
        }

        public static void SetReferralReward(string projectId, UInt160 referrer, BigInteger amount)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_rewards", referrer);
            Storage.Put(Storage.CurrentContext, key, amount);
        }

        public static BigInteger GetReferralReward(string projectId, UInt160 referrer)
        {
            byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_rewards", referrer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        // ===================== CONDITIONAL VOTING =====================
        public static string[] GetVotingTierWeightsKeys(string projectId)
        {
            // FIX: strip full key to tierId suffix, consistent with SetVoteWeightByTier
            byte[] prefix = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", "");
            Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            Neo.SmartContract.Framework.List<string> keys = new Neo.SmartContract.Framework.List<string>();
            while (it.Next())
            {
                byte[] fullKey = (byte[])it.Value;
                byte[] basePrefix = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", "");
                if (fullKey.Length >= basePrefix.Length)
                {
                    byte[] tail = fullKey.Range(basePrefix.Length, fullKey.Length - basePrefix.Length);
                    keys.Add(tail.ToByteString().ToString());
                }
            }
            return keys;
        }

        public static void ClearVotingTierWeights(string projectId)
        {
            RequireAuth();
            // FIX: iterate same prefix space as Set/Get for weights
            byte[] prefix = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", "");
            Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (it.Next())
            {
                Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
            }
        }

        public static void SetConditionalVotingRule(string projectId, string ruleId, bool isActive)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_rules", ruleId);
            if (isActive)
                Storage.Put(Storage.CurrentContext, key, 1);
            else
                Storage.Delete(Storage.CurrentContext, key);
        }

        public static bool GetConditionalVotingRule(string projectId, string ruleId)
        {
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_rules", ruleId);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static void SetConditionalThreshold(string projectId, string ruleId, BigInteger threshold)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_thresholds", ruleId);
            Storage.Put(Storage.CurrentContext, key, threshold);
        }

        public static BigInteger GetConditionalThreshold(string projectId, string ruleId)
        {
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_thresholds", ruleId);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        public static void SetMultiTierVoting(string projectId, string voteId, UInt160 voter, byte tierLevel)
        {
            RequireAuth();
            string complexKey = voteId + "_" + voter.ToString();
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_multitier", complexKey);
            Storage.Put(Storage.CurrentContext, key, tierLevel);
        }

        public static byte GetMultiTierVoting(string projectId, string voteId, UInt160 voter)
        {
            string complexKey = voteId + "_" + voter.ToString();
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_multitier", complexKey);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return (byte)(result != null ? (byte)(BigInteger)result : 1);
        }

        public static void SetVoteWeightByTier(string projectId, string tierId, BigInteger weight)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", tierId);
            Storage.Put(Storage.CurrentContext, key, weight);
        }

        public static BigInteger GetVoteWeightByTier(string projectId, string tierId)
        {
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", tierId);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 1;
        }

        // NEW: VotingTierWeights CRUD helpers
        public static void RemoveVoteWeightByTier(string projectId, string tierId)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", tierId);
            Storage.Delete(Storage.CurrentContext, key);
        }



        // ===================== TOKEN REWARDS =====================

        public static void SetBackerTokenReward(string projectId, UInt160 backer, BigInteger tokenAmount)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(TokenRewardsPrefix, projectId + "_backer_tokens", backer);
            Storage.Put(Storage.CurrentContext, key, tokenAmount);
        }

        public static BigInteger GetBackerTokenReward(string projectId, UInt160 backer)
        {
            byte[] key = CreateProjectActorKey(TokenRewardsPrefix, projectId + "_backer_tokens", backer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        // ===================== PENALTIES =====================

        public static void SetManufacturerPenalty(string projectId, UInt160 manufacturer, BigInteger penaltyAmount)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_manufacturer_penalties", manufacturer);
            Storage.Put(Storage.CurrentContext, key, penaltyAmount);
        }

        public static BigInteger GetManufacturerPenalty(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_manufacturer_penalties", manufacturer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (BigInteger)result : 0;
        }

        public static void SetPenaltyTimestamp(string projectId, UInt160 manufacturer, ulong timestamp)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_penalty_timestamps", manufacturer);
            Storage.Put(Storage.CurrentContext, key, (BigInteger)timestamp);
        }

        public static ulong GetPenaltyTimestamp(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_penalty_timestamps", manufacturer);
            ByteString result = Storage.Get(Storage.CurrentContext, key);
            return result != null ? (ulong)(BigInteger)result : 0;
        }

        // ===================== NEW: Milestone votes and fraud flags (externalized from in-memory maps) =====================

        public static void SetMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer, BackerVotesEnum vote)
        {
            RequireAuth();
            string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
            Storage.Put(Storage.CurrentContext, key, (int)vote);
        }

        public static BackerVotesEnum GetMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        {
            string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (BackerVotesEnum)(int)(BigInteger)v : BackerVotesEnum.Abstained;
        }

        public static void RemoveMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        {
            RequireAuth();
            string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
            Storage.Delete(Storage.CurrentContext, key);
        }

        public static void ClearMilestoneVotes(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            RequireAuth();
            string prefixKeyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_";
            byte[] prefix = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", prefixKeyPart);
            Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (it.Next())
            {
                Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
            }
        }

        public static void SetMilestoneFraudFlag(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer, bool detected)
        {
            RequireAuth();
            string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_fraud", keyPart);
            if (detected)
                Storage.Put(Storage.CurrentContext, key, 1);
            else
                Storage.Delete(Storage.CurrentContext, key);
        }

        public static bool GetMilestoneFraudFlag(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        {
            string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_fraud", keyPart);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static void ClearMilestoneFraudFlags(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            RequireAuth();
            string prefixKeyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_";
            byte[] prefix = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_fraud", prefixKeyPart);
            Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (it.Next())
            {
                Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
            }
        }

        // ===================== NEW: Winner vote fraud flags (externalized) =====================

        public static void SetWinnerVoteFraudFlag(string projectId, UInt160 manufacturer, UInt160 backer, bool detected)
        {
            RequireAuth();
            string keyPart = manufacturer.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_fraud", keyPart);
            if (detected)
                Storage.Put(Storage.CurrentContext, key, 1);
            else
                Storage.Delete(Storage.CurrentContext, key);
        }

        public static bool GetWinnerVoteFraudFlag(string projectId, UInt160 manufacturer, UInt160 backer)
        {
            string keyPart = manufacturer.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_fraud", keyPart);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static void ClearWinnerVoteFraudFlags(string projectId, UInt160 manufacturer)
        {
            RequireAuth();
            string prefixPart = manufacturer.ToString() + "_";
            byte[] prefix = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_fraud", prefixPart);
            Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (it.Next())
            {
                Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
            }
        }

        // ===================== NEW: Milestone Template CustomParameters CRUD =====================

        public static void SetMilestoneTemplateParam(string projectId, string templateId, string paramKey, string paramValue)
        {
            RequireAuth();
            string bucket = "_template_params_" + templateId;
            byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, paramKey);
            Storage.Put(Storage.CurrentContext, key, paramValue);
        }

        public static string GetMilestoneTemplateParam(string projectId, string templateId, string paramKey)
        {
            string bucket = "_template_params_" + templateId;
            byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, paramKey);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? v.ToString() : "";
        }

        public static void RemoveMilestoneTemplateParam(string projectId, string templateId, string paramKey)
        {
            RequireAuth();
            string bucket = "_template_params_" + templateId;
            byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, paramKey);
            Storage.Delete(Storage.CurrentContext, key);
        }

        public static void ClearMilestoneTemplateParams(string projectId, string templateId)
        {
            RequireAuth();
            string bucket = "_template_params_" + templateId;
            byte[] prefix = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, "");
            Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (it.Next())
            {
                Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
            }
        }



        // ===================== NEW: Check existence of milestone vote =====================

        public static bool HasMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        {
            string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        // ===================== ADDITIONS TO MATCH IFMiniAdapter =====================

        public static bool IsManufacturerRegistered(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_candidates", manufacturer);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static UInt160[] GetManufacturerCandidates(string projectId)
        {
            byte[] prefix = CreateProjectKey(ManufacturerMapsPrefix, projectId + "_candidates");
            // count
            int count = 0;
            var itCount = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (itCount.Next()) count++;
            UInt160[] result = new UInt160[count];
            int i = 0;
            var it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (it.Next())
            {
                byte[] keyBytes = (byte[])it.Value;
                byte[] addrBytes = keyBytes.Range(keyBytes.Length - 20, 20);
                result[i++] = (UInt160)addrBytes;
            }
            return result;
        }

        public static void SetBackerReservation(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount)
        {
            RequireAuth();
            string complex = backer.ToString() + "_" + manufacturer.ToString();
            byte[] key = CreateProjectComplexKey(ReservedFundsPrefix, projectId, "backer_res_" + complex);
            if (amount > 0)
                Storage.Put(Storage.CurrentContext, key, amount);
            else
                Storage.Delete(Storage.CurrentContext, key);
        }

        public static BigInteger GetBackerReservation(string projectId, UInt160 backer, UInt160 manufacturer)
        {
            string complex = backer.ToString() + "_" + manufacturer.ToString();
            byte[] key = CreateProjectComplexKey(ReservedFundsPrefix, projectId, "backer_res_" + complex);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (BigInteger)v : 0;
        }

        public static object GetMilestoneCompletionVotesStruct(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            string complexKey = manufacturer.ToString() + "_" + stepNumber.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId, complexKey);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            if (v is null) return null;
            return (MilestoneCompletionVotesStruct)StdLib.Deserialize(v);
        }

        public static void SetMilestoneCompletionVotesStruct(string projectId, UInt160 manufacturer, byte stepNumber, object milestone)
        {
            RequireAuth();
            string complexKey = manufacturer.ToString() + "_" + stepNumber.ToString();
            byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId, complexKey);
            Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(milestone));
        }

        public static Neo.SmartContract.Framework.ByteString[] GetMilestoneKeys(string projectId, UInt160 manufacturer)
        {
            byte[] basePrefix = CreateProjectKey(MilestoneMapsPrefix, projectId);
            Iterator it = Storage.Find(Storage.CurrentContext, basePrefix, FindOptions.KeysOnly);
            string man = manufacturer.ToString() + "_";
            Neo.SmartContract.Framework.List<ByteString> keys = new();
            while (it.Next())
            {
                byte[] fullKey = (byte[])it.Value;
                if (fullKey.Length <= basePrefix.Length) continue;
                byte[] tail = fullKey.Range(basePrefix.Length, fullKey.Length - basePrefix.Length);
                ByteString tailStr = tail.ToByteString();
                if (tailStr.StartWith(man)) keys.Add(tailStr);
            }
            return keys;
        }

        public static int GetParticipantBanReason(string projectId, UInt160 participant)
        {
            byte[] mKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_manufacturers", participant);
            ByteString m = Storage.Get(Storage.CurrentContext, mKey);
            if (m != null) return (int)(BigInteger)m;
            byte[] bKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_backers", participant);
            ByteString b = Storage.Get(Storage.CurrentContext, bKey);
            if (b != null) return (int)(BigInteger)b;
            return -1;
        }

        public static void SetSuspiciousActivityScore(string projectId, UInt160 participant, BigInteger score)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_suspicious", participant);
            Storage.Put(Storage.CurrentContext, key, score);
        }

        public static BigInteger GetSuspiciousActivityScore(string projectId, UInt160 participant)
        {
            byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_suspicious", participant);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetManagementTransferVote(string projectId, UInt160 backer, int vote)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(ManagementTransferPrefix, projectId + "_votes", backer);
            Storage.Put(Storage.CurrentContext, key, vote);
        }

        public static int GetManagementTransferVote(string projectId, UInt160 backer)
        {
            byte[] key = CreateProjectActorKey(ManagementTransferPrefix, projectId + "_votes", backer);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (int)(BigInteger)v : 0;
        }

        public static void SetManagementTransferResults(string projectId, BigInteger positive, BigInteger negative, BigInteger abstained, BigInteger total)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ManagementTransferPrefix, projectId, "pos"), positive);
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ManagementTransferPrefix, projectId, "neg"), negative);
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ManagementTransferPrefix, projectId, "abs"), abstained);
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ManagementTransferPrefix, projectId, "tot"), total);
        }

        public static void SetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 manufacturer, int vote)
        {
            RequireAuth();
            string complex = manufacturer.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_votes", complex);
            Storage.Put(Storage.CurrentContext, key, vote);
        }

        public static int GetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 manufacturer)
        {
            string complex = manufacturer.ToString() + "_" + backer.ToString();
            byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_votes", complex);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (int)(BigInteger)v : 0;
        }

        public static void SetCandidateWinnerVotes(string projectId, UInt160 manufacturer, object votes)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_candidate_struct", manufacturer.ToString());
            Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(votes));
        }

        public static object GetCandidateWinnerVotes(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_candidate_struct", manufacturer.ToString());
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            if (v is null) return null;
            return StdLib.Deserialize(v);
        }

        public static void SetManufacturerQualityScore(string projectId, UInt160 manufacturer, BigInteger score)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(QualityScoresPrefix, projectId + "_quality", manufacturer);
            Storage.Put(Storage.CurrentContext, key, score);
        }

        public static BigInteger GetManufacturerQualityScore(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(QualityScoresPrefix, projectId + "_quality", manufacturer);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetManufacturerVoteWeight(string projectId, UInt160 manufacturer, BigInteger weight)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_man_weight", manufacturer);
            Storage.Put(Storage.CurrentContext, key, weight);
        }

        public static BigInteger GetManufacturerVoteWeight(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_man_weight", manufacturer);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetBackerVoteWeightValue(string projectId, UInt160 backer, BigInteger weight)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_backer_weight", backer);
            Storage.Put(Storage.CurrentContext, key, weight);
        }

        public static BigInteger GetBackerVoteWeightValue(string projectId, UInt160 backer)
        {
            byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_backer_weight", backer);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetManufacturerReliabilityTier(string projectId, UInt160 manufacturer, byte tier)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_reliability", manufacturer);
            Storage.Put(Storage.CurrentContext, key, tier);
        }

        public static byte GetManufacturerReliabilityTier(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_reliability", manufacturer);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (byte)(BigInteger)v : (byte)0;
        }

        public static void SetMilestoneTemplate(string projectId, string templateId, object template)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + "_templates", templateId);
            Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(template));
        }

        public static object GetMilestoneTemplate(string projectId, string templateId)
        {
            byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + "_templates", templateId);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            if (v is null) return null;
            return StdLib.Deserialize(v);
        }

        public static void SetManufacturerPreferredTemplate(string projectId, UInt160 manufacturer, string templateId)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(TemplatesPrefix, projectId + "_preferred", manufacturer);
            Storage.Put(Storage.CurrentContext, key, templateId);
        }

        public static string GetManufacturerPreferredTemplate(string projectId, UInt160 manufacturer)
        {
            byte[] key = CreateProjectActorKey(TemplatesPrefix, projectId + "_preferred", manufacturer);
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? v.ToString() : "";
        }

        public static Map<string, BigInteger> GetMilestonePerformanceAnalytics(string projectId, UInt160 manufacturer)
        {
            // Placeholder: return empty map or previously stored aggregated data



            return new Map<string, BigInteger>();
        }

        public static void SetDailyParticipationStats(string projectId, ulong timestamp, BigInteger participantsCount)
        {
            RequireAuth();
            string complex = "daily_" + timestamp.ToString();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, complex), participantsCount);
        }

        public static BigInteger GetDailyParticipationStats(string projectId, ulong timestamp)
        {
            string complex = "daily_" + timestamp.ToString();
            ByteString v = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, complex));
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetTotalRefundsProcessed(string projectId, BigInteger amount)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, "refunds_total"), amount);
        }

        public static BigInteger GetTotalRefundsProcessed(string projectId)
        {
            ByteString v = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, "refunds_total"));
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetRefundHistory(string projectId, UInt160 participant, BigInteger amount)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectActorKey(AnalyticsPrefix, projectId + "_refunds", participant), amount);
        }

        public static BigInteger GetRefundHistory(string projectId, UInt160 participant)
        {
            ByteString v = Storage.Get(Storage.CurrentContext, CreateProjectActorKey(AnalyticsPrefix, projectId + "_refunds", participant));
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetNotificationPreference(string projectId, UInt160 participant, bool enabled)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_prefs", participant);
            if (enabled) Storage.Put(Storage.CurrentContext, key, 1);
            else Storage.Delete(Storage.CurrentContext, key);
        }

        public static bool GetNotificationPreference(string projectId, UInt160 participant)
        {
            byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_prefs", participant);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static void SetVotingReminderTimestamp(string projectId, int voteType, ulong timestamp)
        {
            RequireAuth();
            byte[] key = CreateProjectComplexKey(NotificationsPrefix, projectId, "reminder_" + voteType.ToString());
            Storage.Put(Storage.CurrentContext, key, (BigInteger)timestamp);
        }

        public static ulong GetVotingReminderTimestamp(string projectId, int voteType)
        {
            byte[] key = CreateProjectComplexKey(NotificationsPrefix, projectId, "reminder_" + voteType.ToString());
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (ulong)(BigInteger)v : 0;
        }

        public static void SetDeadlineNotificationSent(string projectId, UInt160 participant, bool sent)
        {
            RequireAuth();
            byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_deadline", participant);
            if (sent) Storage.Put(Storage.CurrentContext, key, 1);
            else Storage.Delete(Storage.CurrentContext, key);
        }

        public static bool GetDeadlineNotificationSent(string projectId, UInt160 participant)
        {
            byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_deadline", participant);
            return Storage.Get(Storage.CurrentContext, key) != null;
        }

        public static void SetProjectActivityScore(string projectId, BigInteger score)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, "activity_score"), score);
        }

        public static BigInteger GetProjectActivityScore(string projectId)
        {
            ByteString v = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, "activity_score"));
            return v != null ? (BigInteger)v : 0;
        }

        public static void SetLastActivityTime(string projectId, ulong timestamp)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, "last_activity"), (BigInteger)timestamp);
        }

        public static ulong GetLastActivityTime(string projectId)
        {
            ByteString v = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(AnalyticsPrefix, projectId, "last_activity"));
            return v != null ? (ulong)(BigInteger)v : 0;
        }

        public static void SetProjectStatus(string projectId, int status)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "status"), status);
        }

        public static int GetProjectStatus(string projectId)
        {
            ByteString v = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "status"));
            return v != null ? (int)(BigInteger)v : 0;
        }

        public static void SetProjectFlags(string projectId, bool isArchived, bool isPaused, bool isClosed, bool hasWinner)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_archived"), isArchived ? 1 : 0);
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_paused"), isPaused ? 1 : 0);
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_closed"), isClosed ? 1 : 0);
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_has_winner"), hasWinner ? 1 : 0);
        }

        public static object GetProjectFlags(string projectId)
        {
            bool archived = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_archived")) != null;
            bool paused = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_paused")) != null;
            bool closed = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_closed")) != null;
            bool winner = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flag_has_winner")) != null;
            ProjectFlags flags = new ProjectFlags { IsArchived = archived, IsPaused = paused, IsClosed = closed, HasWinner = winner };
            return flags;
        }

        public static void SetLockedFunds(string projectId, BigInteger amount)
        {
            RequireAuth();
            Storage.Put(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "locked_funds"), amount);
        }

        public static BigInteger GetLockedFunds(string projectId)
        {
            ByteString v = Storage.Get(Storage.CurrentContext, CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "locked_funds"));
            return v != null ? (BigInteger)v : 0;
        }

        public static void UpdateLockedFunds(string projectId, BigInteger deltaAmount)
        {
            RequireAuth();
            BigInteger current = GetLockedFunds(projectId);
            SetLockedFunds(projectId, current + deltaAmount);
        }

        // Offer reserved donations (offerId + backer)
        public static void SetOfferReservedDonation(string offerId, UInt160 backer, BigInteger amount)
        {
            RequireAuth();
            byte[] key = ("offer_res_" + offerId + "_" + backer.ToString()).ToByteArray();
            Storage.Put(Storage.CurrentContext, key, amount);
        }

        public static BigInteger GetOfferReservedDonation(string offerId, UInt160 backer)
        {
            byte[] key = ("offer_res_" + offerId + "_" + backer.ToString()).ToByteArray();
            ByteString v = Storage.Get(Storage.CurrentContext, key);
            return v != null ? (BigInteger)v : 0;
        }

        public static UInt160[] GetBackersWithDonations(string projectId)
        {
            byte[] prefix = CreateProjectKey(BackerDonationsPrefix, projectId);
            // count
            int count = 0;
            var itCount = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (itCount.Next()) count++;
            UInt160[] arr = new UInt160[count];
            int i = 0;
            var it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
            while (it.Next())
            {
                byte[] keyBytes = (byte[])it.Value;
                ByteString val = Storage.Get(Storage.CurrentContext, keyBytes);
                if (val == null || (BigInteger)val <= 0) continue;
                byte[] addrBytes = keyBytes.Range(keyBytes.Length - 20, 20);
                arr[i++] = (UInt160)addrBytes;
            }
            return arr;
        }
    }








}




























































































































































































































































































































































































































































































































































































































































































































































































































































