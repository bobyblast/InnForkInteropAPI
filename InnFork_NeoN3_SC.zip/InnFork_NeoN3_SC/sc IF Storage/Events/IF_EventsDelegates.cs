﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using System;
using System.ComponentModel;
using System.Numerics;

namespace InnFork.NeoN3;

/// <summary>
/// Централизованные делегаты и события для платформы InnFork.
/// </summary>
/* 

Зачем последнее звено IF_ProjectStorage_State

•	Стабильный адрес событий.Если логику обновляете/мигрируете(новый hash), подписчики на события продолжают слушать прежний StorageState.
•	Централизация прав: можно ограничить вызов emitEvent только доверенными логиками.
•	Консистентность: все события выходят из одного контракта, даже если логик несколько.


 StorageLogic как «шлюз» безопасности и совместимости. Если убрать его из цепочки, нужно решить авторизацию и согласованность.

Почему оставлять цепочку AppContract → StorageLogicContract → StorageStateContract :


•	Единая авторизация: StorageState может проверять Runtime.CallingScriptHash и принимать emit только от доверенной логики. 
•	Тогда не нужно хранить/обновлять белый список всех прикладных контрактов.

•	Стабильность API: приложения не знают ни op-кодов, ни внутренней схемы аргументов. Это инкапсулировано в логике.
•	Эволюция/апгрейды: можно менять mapping оп-кодов и правила эмита в логике без затрагивания приложений и StorageState.
•	Инварианты: логика может гарантировать порядок “сначала запись/валидция, потом emit” и не допустить «пустых» событий от сторонних контрактов.

*/


// ===== Event dispatcher entry-point raised by StorageLogic =====

public partial class InnForkProjectStateStorage : Neo.SmartContract.Framework.SmartContract
{
    private enum EventOp : byte
    {
        // Investment
        EmitAgreementCreated = 0x50,
        EmitAgreementConfirmed = 0x51,
        EmitAgreementCompleted = 0x52,
        EmitAgreementDefaulted = 0x53,
        EmitRepaymentMade = 0x54,
        EmitInvestmentPaymentMade = 0x55,

        // Voting
        EmitProjectLaunchApproved = 0x60,
        EmitFundraisingCompletionApproved = 0x61,
        EmitProjectUpdatesApproved = 0x62,
        EmitManufacturerWinnerSelectionApproved = 0x63,
        EmitMilestoneCompletionApproved = 0x64,
        EmitProjectPauseResumeVoted = 0x65,
        EmitSuccessfulClosureApproved = 0x66,
        EmitTerminationWithRefundApproved = 0x67,
        EmitVoteAbstained = 0x68,
        EmitVoteCasted = 0x69,
        EmitVotingStarted = 0x6A,
        EmitVotingCompleted = 0x6B,
        EmitVotingFinalized = 0x6C,
        EmitWinnerSelected = 0x6D,
        EmitManufacturerSelected = 0x6E,

        // Delegation
        EmitVoteDelegated = 0x70,
        EmitVoteDelegationRevoked = 0x71,
        EmitBulkDelegationRevoked = 0x72,
        EmitDelegationIntegrityViolation = 0x73,

        // Milestones
        EmitMilestoneCompleted = 0x80,
        EmitMilestoneFundingRolledBack = 0x81,
        EmitMilestoneResetForRestart = 0x82,

        // Disputes
        EmitDisputeCreated = 0x90,
        EmitDisputeStatusChanged = 0x91,
        EmitDisputeStatusUpdated = 0x92,

        // Bans & penalties
        EmitManufacturerBanned = 0xA0,
        EmitBackerBanned = 0xA1,
        EmitManufacturerPenalized = 0xA2,
        EmitManufacturerPenaltyCleared = 0xA3,
        EmitBackerFundsBlocked = 0xA4,
        EmitBackerFundsUnblocked = 0xA5,

        // Emergency
        EmitEmergencyRefundExecuted = 0xB0,

        // System
        EmitProjectSaved = 0xC0,
    }

    [Safe]
    public static void emitEvent(byte eventOp, params object[] args)
    {
        switch ((EventOp)eventOp)
        {
            // Investment
            case EventOp.EmitAgreementCreated:
                AgreementCreated((byte[])args[0], (UInt160)args[1], (UInt160)args[2], (BigInteger)args[3]);
                break;
            case EventOp.EmitAgreementConfirmed:
                AgreementConfirmed((byte[])args[0]);
                break;
            case EventOp.EmitAgreementCompleted:
                AgreementCompleted((byte[])args[0]);
                break;
            case EventOp.EmitAgreementDefaulted:
                AgreementDefaulted((byte[])args[0]);
                break;
            case EventOp.EmitRepaymentMade:
                RepaymentMade((byte[])args[0], (BigInteger)args[1]);
                break;
            case EventOp.EmitInvestmentPaymentMade:
                InvestmentPaymentMade((byte[])args[0], (BigInteger)args[1]);
                break;

            // Voting
            case EventOp.EmitProjectLaunchApproved:
                ProjectLaunchApproved((string)args[0], (bool)args[1]);
                break;
            case EventOp.EmitFundraisingCompletionApproved:
                FundraisingCompletionApproved((string)args[0], (bool)args[1]);
                break;
            case EventOp.EmitProjectUpdatesApproved:
                ProjectUpdatesApproved((string)args[0], (bool)args[1]);
                break;
            case EventOp.EmitManufacturerWinnerSelectionApproved:
                ManufacturerWinnerSelectionApproved((string)args[0], (UInt160)args[1], (bool)args[2]);
                break;
            case EventOp.EmitMilestoneCompletionApproved:
                MilestoneCompletionApproved((string)args[0], (string)args[1], (bool)args[2]);
                break;
            case EventOp.EmitProjectPauseResumeVoted:
                ProjectPauseResumeVoted((string)args[0], (bool)args[1], (bool)args[2]);
                break;
            case EventOp.EmitSuccessfulClosureApproved:
                SuccessfulClosureApproved((string)args[0], (bool)args[1]);
                break;
            case EventOp.EmitTerminationWithRefundApproved:
                TerminationWithRefundApproved((string)args[0], (bool)args[1]);
                break;
            case EventOp.EmitVoteAbstained:
                VoteAbstained((string)args[0], (string)args[1], (UInt160)args[2]);
                break;
            case EventOp.EmitVoteCasted:
                VoteCasted((string)args[0], (UInt160)args[1], (int)args[2]);
                break;
            case EventOp.EmitVotingStarted:
                VotingStarted((string)args[0], (string)args[1]);
                break;
            case EventOp.EmitVotingCompleted:
                VotingCompleted((string)args[0], (string)args[1], (BackerVotesEnum)(int)args[2]);
                break;
            case EventOp.EmitVotingFinalized:
                VotingFinalized((string)args[0], (int)args[1]);
                break;
            case EventOp.EmitWinnerSelected:
                WinnerSelected((string)args[0], (string)args[1]);
                break;
            case EventOp.EmitManufacturerSelected:
                ManufacturerSelected((string)args[0], (UInt160)args[1]);
                break;

            // Delegation
            case EventOp.EmitVoteDelegated:
                VoteDelegated((string)args[0], (string)args[1], (string)args[2], (string)args[3]);
                break;
            case EventOp.EmitVoteDelegationRevoked:
                VoteDelegationRevoked((string)args[0], (string)args[1], (string)args[2], (string)args[3]);
                break;
            case EventOp.EmitBulkDelegationRevoked:
                BulkDelegationRevoked((string)args[0], (string)args[1], (int)args[2]);
                break;
            case EventOp.EmitDelegationIntegrityViolation:
                DelegationIntegrityViolation((string)args[0], (string)args[1], (string)args[2], (string)args[3]);
                break;

            // Milestones
            case EventOp.EmitMilestoneCompleted:
                MilestoneCompleted((string)args[0], (byte)args[1], (bool)args[2]);
                break;
            case EventOp.EmitMilestoneFundingRolledBack:
                MilestoneFundingRolledBack((string)args[0], (UInt160)args[1], (byte)args[2], (string)args[3], (BigInteger)args[4]);
                break;
            case EventOp.EmitMilestoneResetForRestart:
                MilestoneResetForRestart((string)args[0], (UInt160)args[1], (byte)args[2], (string)args[3]);
                break;

            // Disputes
            case EventOp.EmitDisputeCreated:
                DisputeCreated((string)args[0], (UInt160)args[1], (int)args[2], (string)args[3]);
                break;
            case EventOp.EmitDisputeStatusChanged:
                DisputeStatusChanged((string)args[0], (int)args[1], (int)args[2]);
                break;
            case EventOp.EmitDisputeStatusUpdated:
                DisputeStatusUpdated((string)args[0], (DisputeStatus)(int)args[1]);
                break;

            // Bans & penalties
            case EventOp.EmitManufacturerBanned:
                ManufacturerBanned((UInt160)args[0], (int)args[1]);
                break;
            case EventOp.EmitBackerBanned:
                BackerBanned((UInt160)args[0], (int)args[1]);
                break;
            case EventOp.EmitManufacturerPenalized:
                ManufacturerPenalized((UInt160)args[0], (BigInteger)args[1]);
                break;
            case EventOp.EmitManufacturerPenaltyCleared:
                ManufacturerPenaltyCleared((UInt160)args[0], (BigInteger)args[1]);
                break;
            case EventOp.EmitBackerFundsBlocked:
                BackerFundsBlocked((UInt160)args[0], (BigInteger)args[1], (int)args[2]);
                break;
            case EventOp.EmitBackerFundsUnblocked:
                BackerFundsUnblocked((UInt160)args[0], (BigInteger)args[1]);
                break;

            // Emergency
            case EventOp.EmitEmergencyRefundExecuted:
                EmergencyRefundExecuted((string)args[0], (BigInteger)args[1]);
                break;

            // System
            case EventOp.EmitProjectSaved:
                ProjectSaved((string)args[0], (UInt160)args[1]);
                break;

            default:
                ExecutionEngine.Assert(false, "Unknown event opcode");
                break;
        }
    }
}



// ===== Uniform Action<>-based events (no custom delegate types) =====

public partial class InnForkProjectStateStorage : Neo.SmartContract.Framework.SmartContract
{
    // ===== INVESTMENT AGREEMENT EVENTS =====

    [DisplayName("AgreementCreated")]
    public static event Action<byte[], UInt160, UInt160, BigInteger> AgreementCreated;

    [DisplayName("AgreementConfirmed")]
    public static event Action<byte[]> AgreementConfirmed;

    [DisplayName("AgreementCompleted")]
    public static event Action<byte[]> AgreementCompleted;

    [DisplayName("AgreementDefaulted")]
    public static event Action<byte[]> AgreementDefaulted;

    [DisplayName("RepaymentMade")]
    public static event Action<byte[], BigInteger> RepaymentMade;

    [DisplayName("InvestmentPaymentMade")]
    public static event Action<byte[], BigInteger> InvestmentPaymentMade;

    // ===== VOTING SYSTEM EVENTS =====

    [DisplayName("ProjectLaunchApproved")]
    public static event Action<string, bool> ProjectLaunchApproved;

    [DisplayName("FundraisingCompletionApproved")]
    public static event Action<string, bool> FundraisingCompletionApproved;

    [DisplayName("ProjectUpdatesApproved")]
    public static event Action<string, bool> ProjectUpdatesApproved;

    [DisplayName("ManufacturerWinnerSelectionApproved")]
    public static event Action<string, UInt160, bool> ManufacturerWinnerSelectionApproved;

    [DisplayName("MilestoneCompletionApproved")]
    public static event Action<string, string, bool> MilestoneCompletionApproved;

    [DisplayName("ProjectPauseResumeVoted")]
    public static event Action<string, bool, bool> ProjectPauseResumeVoted;

    [DisplayName("SuccessfulClosureApproved")]
    public static event Action<string, bool> SuccessfulClosureApproved;

    [DisplayName("TerminationWithRefundApproved")]
    public static event Action<string, bool> TerminationWithRefundApproved;

    [DisplayName("VoteAbstained")]
    public static event Action<string, string, UInt160> VoteAbstained;

    [DisplayName("VoteCasted")]
    public static event Action<string, UInt160, int> VoteCasted;

    [DisplayName("VotingStarted")]
    public static event Action<string, string> VotingStarted;

    [DisplayName("VotingCompleted")]
    public static event Action<string, string, BackerVotesEnum> VotingCompleted;

    [DisplayName("VotingFinalized")]
    public static event Action<string, int> VotingFinalized;

    [DisplayName("WinnerSelected")]
    public static event Action<string, string> WinnerSelected;

    [DisplayName("ManufacturerSelected")]
    public static event Action<string, UInt160> ManufacturerSelected;

    // ===== VOTE DELEGATION EVENTS =====

    [DisplayName("VoteDelegated")]
    public static event Action<string, string, string, string> VoteDelegated;

    [DisplayName("VoteDelegationRevoked")]
    public static event Action<string, string, string, string> VoteDelegationRevoked;

    [DisplayName("BulkDelegationRevoked")]
    public static event Action<string, string, int> BulkDelegationRevoked;

    [DisplayName("DelegationIntegrityViolation")]
    public static event Action<string, string, string, string> DelegationIntegrityViolation;

    // ===== MILESTONE SYSTEM EVENTS =====

    [DisplayName("MilestoneCompleted")]
    public static event Action<string, byte, bool> MilestoneCompleted;

    [DisplayName("MilestoneFundingRolledBack")]
    public static event Action<string, UInt160, byte, string, BigInteger> MilestoneFundingRolledBack;

    [DisplayName("MilestoneResetForRestart")]
    public static event Action<string, UInt160, byte, string> MilestoneResetForRestart;

    // ===== DISPUTE SYSTEM EVENTS =====

    [DisplayName("DisputeCreated")]
    public static event Action<string, UInt160, int, string> DisputeCreated;

    [DisplayName("DisputeStatusChanged")]
    public static event Action<string, int, int> DisputeStatusChanged;

    [DisplayName("DisputeStatusUpdated")]
    public static event Action<string, DisputeStatus> DisputeStatusUpdated;

    // ===== BAN & PENALTY EVENTS =====

    [DisplayName("ManufacturerBanned")]
    public static event Action<UInt160, int> ManufacturerBanned;

    [DisplayName("BackerBanned")]
    public static event Action<UInt160, int> BackerBanned;

    [DisplayName("ManufacturerPenalized")]
    public static event Action<UInt160, BigInteger> ManufacturerPenalized;

    [DisplayName("ManufacturerPenaltyCleared")]
    public static event Action<UInt160, BigInteger> ManufacturerPenaltyCleared;

    [DisplayName("BackerFundsBlocked")]
    public static event Action<UInt160, BigInteger, int> BackerFundsBlocked;

    [DisplayName("BackerFundsUnblocked")]
    public static event Action<UInt160, BigInteger> BackerFundsUnblocked;

    // ===== EMERGENCY & REFUND EVENTS =====

    [DisplayName("EmergencyRefundExecuted")]
    public static event Action<string, BigInteger> EmergencyRefundExecuted;

    // ===== GENERAL SYSTEM EVENTS =====

    [DisplayName("ProjectSaved")]
    public static event Action<string, UInt160> ProjectSaved;
}
