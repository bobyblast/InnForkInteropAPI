using Neo.SmartContract.Framework;
using System.ComponentModel;
using System.Numerics;
using static InnFork.NeoN3.InnForkProjectStateStorage.IF_Constants;

namespace InnFork.NeoN3;



// DisputeRecord is defined in SharedModels (InnFork.NeoN3.DisputeRecord)


public class ProjectPackage
{
    public string ProjectOfferId_Sha256 { get; set; } = string.Empty;
    public string ProjectOfferShortJson { get; set; } = string.Empty;

    public string ProjectId_Sha256 { get; set; } = string.Empty;
    public string ProjectJson { get; set; } = string.Empty;

    public UInt160 AuthorAccount = UInt160.Zero;

    public byte[] AuthorPubKey = new byte[33];
    public byte[] Signature = new byte[64];
}

public partial class ProjectSettings
{
    // ��������������� �������� ������ (�������������)
    public bool IsWinnerSelectionFinalized { get; set; }
    public ulong ManagementTransferVotingDeadline { get; set; }

    public ProjectFundingType projectFundingType = ProjectFundingType.Flexible;
    public BigInteger AutoPauseLockThresholdPercent { get; set; } = 50;

    // �����������
    public BigInteger MinimumVotesRequired { get; set; } = 0;
    public BigInteger MinRequiredVotingParticipation { get; set; } = 50;
    public BigInteger MinApprovalPercentage { get; set; } = 66;
    public bool AutoAssignVoicelessToAbstain { get; internal set; }
    public bool AutoAbstainVoteAsSupport { get; internal set; }

    // �����/�������
    public MilestoneFundingType DefaultFundingType { get; set; } = MilestoneFundingType.Before;
    public ulong DefaultVotingDuration { get; set; } = 0;
    public bool AllowSteppedFinancing { get; set; } = true;
    public byte MaxMilestoneSteps { get; set; } = 10;
    public int MaxManufacturers { get; set; } = 5;
    public ulong FundraisingDeadline { get; set; } = 0;
    public ulong ManufacturerSelectionDeadline { get; set; } = 0;
    public ulong LaunchVotingDeadline { get; set; } = 0;
    public ulong FundraisingVotingDeadline { get; set; } = 0;

    // �������
    public byte DefaultPrizeFundAllocation { get; set; } = 0;
    public BigInteger CreatorFeePercentage { get; set; } = 1;
    public BigInteger CreatorFixedReward { get; set; } = 0;
    public BigInteger FLMUSD_PrizeFundGoal { get; set; } = 100000;
    public BigInteger WithdrawalTimeout { get; set; } = 15552000;
    public BigInteger PrizeFundExcessWithdrawalMultiplier { get; internal set; } = 2;

    // �����/�������������/������������
    public bool EnableFraudDetection { get; set; } = true;
    public bool AutoDistributeConsentedFunds { get; set; } = true;
    public bool AutoPauseEnabled { get; set; } = true;
    public bool AutoFinishExpiredVotings { get; set; } = true;

    // �������� �������
    public string ProjectDescription_NeoFS_Address { get; set; } = string.Empty;

}


public class MilestoneCompletionVotesStruct
{
    public MilestoneCompletionVotesStruct() { }

    public string Sha256Hash_Id = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    public string ProjectSha256_Id { get; set; } = string.Empty;
    public UInt160 ManufacturerCandidate { get; set; } = UInt160.Zero;
    public string ManufacturerProductId_Sha256 { get; set; } = string.Empty;

    public byte StepNumber { get; set; } = 0;

    public BigInteger FinancialAmount { get; set; } = 0;
    public BigInteger RequestedFinancialAmount { get; set; } = 0;

    public BigInteger TotalVotesCount { get; set; } = 0;
    public BigInteger PositiveVotesCount { get; set; } = 0;
    public BigInteger NegativeVotesCount { get; set; } = 0;
    public BigInteger AbstainedVotesCount { get; set; } = 0;

    public ulong Deadline_UnixTime { get; set; } = 0;
    public ulong VotingStartTime { get; set; } = 0;
    public ulong VotingDuration { get; set; } = 0;

    public BigInteger MinimumVotesRequired { get; set; } = 0;

    public bool isVotingStepComplete = false;


    public bool isFundingSent = false;
    public bool IsVotingSuccessful { get; set; }
    public bool isManufacturerCandidateUsedSteppedFinancial { get; set; } = false;
    public bool IsDisputed { get; set; }


}



public class CandidateWinnerVotesStruct
{
    public CandidateWinnerVotesStruct() { }

    public string Sha256Hash_Id { get; set; } = string.Empty;
    public string ProjectSha256_Id { get; set; } = string.Empty;
    public UInt160 ManufacturerCandidate { get; set; } = UInt160.Zero;
    public string ManufacturerProductId_Sha256 { get; set; } = string.Empty;

    public BigInteger TotalVotesCount { get; set; } = 0;
    public BigInteger PositiveVotesCount { get; set; } = 0;
    public BigInteger NegativeVotesCount { get; set; } = 0;
    public BigInteger AbstainedVotesCount { get; set; } = 0;

    public ulong VotingStartTime { get; set; } = 0;
    public ulong VotingDuration = 0;

    public BigInteger MinimumVotesRequired;
    public bool IsVotingSuccessful;


}


public class MilestoneTemplate
{
    public string Name { get; set; }
    public string Description { get; set; }
    public BigInteger RequestedAmount { get; set; }
    public ulong Duration { get; set; }
    public string TemplateType { get; set; }

}

