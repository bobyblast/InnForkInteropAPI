
using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Linq;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.ComponentModel;
using System.Numerics;
using static InnFork.NeoN3.ProjectAccount;


namespace InnFork.NeoN3;




public partial class InnForkProjectStateStorage : Neo.SmartContract.Framework.SmartContract
{





    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // This method saves a project to the projects account store ! MUST be  PRIVATE
    public static void saveProjectAccountToProjectsAccountStore(string ProjectAddress, ProjectAccount project)
    {
        if (project == null) throw new Exception("Project param is null: " + ProjectAddress);

        if (ProjectAddress.Length != 32 && ProjectAddress.Length != 64)
            throw new Exception("saveProjectAccountToProjectsAccountStore: Invalid ProjectId_Sha256 format. Lenght is: " + ProjectAddress.Length.ToString());

        StorageMap projectsAccountStore = new(Storage.CurrentContext, ProjectSettingsPrefix);

        projectsAccountStore.Put(ProjectAddress, StdLib.Serialize(project));
    }


    private static readonly byte[] LogicContractHashKey = new byte[] { 0x01 };
    private static readonly byte[] BackerDonationsPrefix = new byte[] { 0x02 };
    private static readonly byte[] VotingMapsPrefix = new byte[] { 0x03 };
    private static readonly byte[] ManufacturerMapsPrefix = new byte[] { 0x04 };
    private static readonly byte[] MilestoneMapsPrefix = new byte[] { 0x05 };
    private static readonly byte[] DisputeMapsPrefix = new byte[] { 0x06 };
    private static readonly byte[] FraudDetectionPrefix = new byte[] { 0x07 };
    private static readonly byte[] ProjectSettingsPrefix = new byte[] { 0x08 };
    private static readonly byte[] BanMapsPrefix = new byte[] { 0x09 };
    private static readonly byte[] ReservedFundsPrefix = new byte[] { 0x0A };
    private static readonly byte[] VoteDelegationPrefix = new byte[] { 0x0B };
    private static readonly byte[] ProjectUpdateVotingPrefix = new byte[] { 0x0C };
    private static readonly byte[] ManagementTransferPrefix = new byte[] { 0x0D };
    private static readonly byte[] WinnerSelectionPrefix = new byte[] { 0x0E };
    private static readonly byte[] QualityScoresPrefix = new byte[] { 0x0F };
    private static readonly byte[] VoteWeightsPrefix = new byte[] { 0x10 };
    private static readonly byte[] TemplatesPrefix = new byte[] { 0x11 };
    private static readonly byte[] AnalyticsPrefix = new byte[] { 0x12 };
    private static readonly byte[] NotificationsPrefix = new byte[] { 0x13 };
    private static readonly byte[] ReferralPrefix = new byte[] { 0x14 };
    private static readonly byte[] ConditionalVotingPrefix = new byte[] { 0x15 };
    private static readonly byte[] TokenRewardsPrefix = new byte[] { 0x16 };
    private static readonly byte[] PenaltiesPrefix = new byte[] { 0x17 };
    private static readonly byte[] AutoSelectionPrefix = new byte[] { 0x18 };



    public partial class FraudAnalysisResult
    {
        public BigInteger SuspiciousScore { get; set; }
        public int VoteSwitchingCount { get; set; }
        public ulong LastVoteTime { get; set; }
        public bool IsSuspicious { get; set; }
        public string RiskLevel { get; set; }
    }


    public partial class ProjectFinalizationBatch
    {
        public string ProjectId { get; set; }
        public Map<string, CalculatedVoteOutcome> Results { get; set; }
    }


    public partial class ProjectStateSnapshot
    {
        public string ProjectId { get; set; }
        public BigInteger EligibleVotersCount { get; set; }
        public BigInteger TotalBalance { get; set; }
        public int ManufacturerCount { get; set; }
    }




    public partial class VotingConfiguration
    {
        public BigInteger MinParticipation { get; set; }
        public BigInteger MinApproval { get; set; }
        public bool AutoAssignVoiceless { get; set; }
        public bool AbstainAsSupport { get; set; }
    }


    public partial class ProjectFlags
    {
        public bool IsArchived { get; set; }
        public bool IsPaused { get; set; }
        public bool IsClosed { get; set; }
        public bool HasWinner { get; set; }
    }


}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////








public partial class ProjectSettings
{
    public static void ImportNewProjectSettings(string jsonSettings)
    {
        ProjectSettings projectSettings = new ProjectSettings();

        projectSettings = (ProjectSettings)StdLib.Deserialize(jsonSettings);

        // ����� ����� �������� ������ ��� ���������� ��� ������������� ��������

        // ��������, ��������� � ��������� ��� ������������ � �������
    }

}








// Milestone template system implementation

public partial class MilestoneTemplate
{

    public Map<string, string> CustomParameters { get; set; }

    public MilestoneTemplate()
    {
        CustomParameters = new Map<string, string>();
    }

    /*     public static void createMilestoneFromTemplate(UInt160 manufacturerAddress, string projectId,
             byte stepNumber, string templateType, BigInteger customAmount)
         {
             if (!Runtime.CheckWitness(manufacturerAddress))
                 throw new Exception("Only manufacturer can create milestone from template");

             ProjectAccount project = getProjectAccount(projectId);
             if (project == null) throw new Exception("Project not found");

             if (!project.ManufacturerCandidateAddress_ManufactureAccount_Map.HasKey(manufacturerAddress))
                 throw new Exception("Manufacturer not registered in project");

             MilestoneTemplate template = getMilestoneTemplate(project, manufacturerAddress, stepNumber, templateType);
             if (template == null) throw new Exception("Template not found");

             BigInteger amount = customAmount > 0 ? customAmount : template.RequestedAmount;

             project.createMilestoneRequest(
                 manufacturerAddress,
                 stepNumber,
                 template.Name,
                 template.Description,
                 amount,
                 Runtime.Time + template.Duration,
                 project.DefaultVotingDuration,
                 project.MinRequiredVotingParticipation
             );

             saveProjectAccountToProjectsAccountStore(projectId, project);
         }*/

    public static MilestoneTemplate getMilestoneTemplate(ProjectAccount project, UInt160 manufacturer,
        byte stepNumber, string templateType = "default")
    {
        // Template selection logic based on project type and manufacturer preferences
        switch (templateType.ToLower())
        {
            case "manufacturing":
                return createManufacturingTemplate(stepNumber);
            case "development":
                return createDevelopmentTemplate(stepNumber);
            case "research":
                return createResearchTemplate(stepNumber);
            case "testing":
                return createTestingTemplate(stepNumber);
            default:
                return createDefaultTemplate(stepNumber, project);
        }
    }

    public static MilestoneTemplate createManufacturingTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Design and Prototyping";
                template.Description = "Initial design phase and prototype development";
                template.Duration = 21 * 24 * 3600; // 21 days
                break;
            case 2:
                template.Name = "Materials Procurement";
                template.Description = "Sourcing and procurement of manufacturing materials";
                template.Duration = 14 * 24 * 3600; // 14 days
                break;
            case 3:
                template.Name = "Production Setup";
                template.Description = "Manufacturing line setup and initial production";
                template.Duration = 30 * 24 * 3600; // 30 days
                break;
            case 4:
                template.Name = "Quality Assurance";
                template.Description = "Quality testing and certification";
                template.Duration = 14 * 24 * 3600; // 14 days
                break;
            case 5:
                template.Name = "Final Delivery";
                template.Description = "Final product delivery and documentation";
                template.Duration = 7 * 24 * 3600; // 7 days
                break;
            default:
                template.Name = $"Manufacturing Step {stepNumber}";
                template.Description = $"Manufacturing milestone step {stepNumber}";
                template.Duration = 21 * 24 * 3600;
                break;
        }

        template.TemplateType = "manufacturing";
        return template;
    }

    public static MilestoneTemplate createDevelopmentTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Requirements Analysis";
                template.Description = "Requirements gathering and analysis phase";
                template.Duration = 14 * 24 * 3600;
                break;
            case 2:
                template.Name = "Technical Design";
                template.Description = "Technical architecture and design documentation";
                template.Duration = 21 * 24 * 3600;
                break;
            case 3:
                template.Name = "Core Development";
                template.Description = "Core functionality development and implementation";
                template.Duration = 45 * 24 * 3600;
                break;
            case 4:
                template.Name = "Integration Testing";
                template.Description = "System integration and comprehensive testing";
                template.Duration = 21 * 24 * 3600;
                break;
            case 5:
                template.Name = "Deployment";
                template.Description = "Production deployment and go-live support";
                template.Duration = 14 * 24 * 3600;
                break;
            default:
                template.Name = $"Development Step {stepNumber}";
                template.Description = $"Development milestone step {stepNumber}";
                template.Duration = 21 * 24 * 3600;
                break;
        }

        template.TemplateType = "development";
        return template;
    }

    public static MilestoneTemplate createResearchTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Literature Review";
                template.Description = "Comprehensive literature review and state-of-art analysis";
                template.Duration = 30 * 24 * 3600;
                break;
            case 2:
                template.Name = "Methodology Development";
                template.Description = "Research methodology design and validation";
                template.Duration = 21 * 24 * 3600;
                break;
            case 3:
                template.Name = "Experimental Phase";
                template.Description = "Experimental work and data collection";
                template.Duration = 60 * 24 * 3600;
                break;
            case 4:
                template.Name = "Analysis and Validation";
                template.Description = "Data analysis and results validation";
                template.Duration = 30 * 24 * 3600;
                break;
            case 5:
                template.Name = "Documentation";
                template.Description = "Final research documentation and reporting";
                template.Duration = 21 * 24 * 3600;
                break;
            default:
                template.Name = $"Research Step {stepNumber}";
                template.Description = $"Research milestone step {stepNumber}";
                template.Duration = 30 * 24 * 3600;
                break;
        }

        template.TemplateType = "research";
        return template;
    }

    public static MilestoneTemplate createTestingTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Test Planning";
                template.Description = "Test strategy and planning phase";
                template.Duration = 7 * 24 * 3600;
                break;
            case 2:
                template.Name = "Unit Testing";
                template.Description = "Component and unit testing implementation";
                template.Duration = 14 * 24 * 3600;
                break;
            case 3:
                template.Name = "Integration Testing";
                template.Description = "System integration testing and validation";
                template.Duration = 21 * 24 * 3600;
                break;
            case 4:
                template.Name = "Performance Testing";
                template.Description = "Performance and load testing execution";
                template.Duration = 14 * 24 * 3600;
                break;
            case 5:
                template.Name = "Acceptance Testing";
                template.Description = "User acceptance testing and final validation";
                template.Duration = 14 * 24 * 3600;
                break;
            default:
                template.Name = $"Testing Step {stepNumber}";
                template.Description = $"Testing milestone step {stepNumber}";
                template.Duration = 14 * 24 * 3600;
                break;
        }

        template.TemplateType = "testing";
        return template;
    }

    public static MilestoneTemplate createDefaultTemplate(byte stepNumber, ProjectAccount project)
    {
        var template = new MilestoneTemplate();
        template.Name = $"Milestone {stepNumber}";
        template.Description = $"Project milestone step {stepNumber}";
        template.Duration = 21 * 24 * 3600; // 21 days default
        template.TemplateType = "default";
        template.RequestedAmount = project.FLMUSD_PrizeFundBalance /
            (project.MaxMilestoneSteps - stepNumber + 1); // Distribute remaining funds

        return template;
    }
}




public partial class MilestoneCompletionVotesStruct
{

    // <--- ������ �������� �� �������������� ����� ���������� �������� ��������������. ���� ����� UInt160 ������. Get\Put ������ - enum BackerVotesEnum
    public Map<UInt160, BackerVotesEnum> MilestoneCompletionBackerVotes_Map { get; set; } = new();// <--- ������ �������� �� �������������� ����� ���������� �������� ��������������

    public Map<UInt160, bool> VotingFraudDetected_Map { get; internal set; } = new Map<UInt160, bool>();// <--- VotingFraudDetected ��� ������������ ������� ���������� ����������� ��������

    // 
    public bool isMilestoneStepStillRunning()
    {
        // ���������, ��������� �� �����������
        if (isVotingStepComplete)
            return false; // --- ����������� ���������, �.�. ���� ��������

        // ���������, �� ����� �� ���� �� �������
        if (Runtime.Time > Deadline_UnixTime)
            return false;
        // ���� ��� �� ��������
        return true;
    }

    public bool IsMilestoneStepCompletedSuccessfully()
    {
        // ���� �� ��������� ��������, ���� ����������� �� ���������
        if (!isVotingStepComplete)
        {
            return false;
        }

        // ���� ����������� ���������, ��������� ������� �� IsVotingSuccessful,
        // ������� ��������������� � checkAndFinalizeMilestoneVoting ����� ������ _calculateInternalVoteOutcome
        return IsVotingSuccessful;
    }
}





public partial class CandidateWinnerVotesStruct
{

    // <--- ������ �������� �� �������������� ����� ���������� �������� ��������������. ���� ����� UInt160 ������. Get\Put ������ - enum BackerVotesEnum
    public Map<UInt160, BackerVotesEnum> BackerVotes_Map { get; set; } = new Map<UInt160, BackerVotesEnum>(); // <--- ������ �������� �� ��������������  �������� ��������������

    public Map<UInt160, bool> VotingFraudDetected_Map { get; set; } = new(); // <--- VotingFraudDetected ��� ������������ ������� ���������� ����������� ��������

}



