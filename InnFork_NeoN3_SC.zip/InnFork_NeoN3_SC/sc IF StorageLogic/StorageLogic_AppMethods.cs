using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;

using System;
using System.ComponentModel;
using System.Numerics;
using InnFork.NeoN3;
using InnFork.NeoN3.Enums;
using static InnFork.NeoN3.ProjectAccount;

namespace InnFork.NeoN3.StorageLogic
{
    [ContractPermission(Permission.Any, Method.Any)]
    public partial class IF_MainGateway
    {
        // Local models
        public class FraudAnalysisResult
        {
            public BigInteger SuspiciousScore { get; set; }
            public int VoteSwitchingCount { get; set; }
            public ulong LastVoteTime { get; set; }
            public bool IsSuspicious { get; set; }
            public string RiskLevel { get; set; }
        }

        // ===== Storage contract binding (dispatcher) =====
        private static readonly byte[] StorageHashKey = "if_storage_hash".ToByteArray();

        [Safe]
        public static UInt160 GetStorageContract() => (UInt160)Storage.Get(StorageHashKey);

        public static void SetStorageContract(UInt160 storage)
        {
            if (!IsOwner()) throw new InvalidOperationException("No Authorization!");
            ExecutionEngine.Assert(storage.IsValid && !storage.IsZero, "storage must be valid");
            Storage.Put(StorageHashKey, storage);
        }

        // OpCodes ��� ������� ������� (���������� ����� entry(byte, object[]))
        private enum Op : byte
        {
            GetBackerDonation = 0x01,
            SetBackerDonation = 0x02,
            GetProjectTotalBalance = 0x03,
            SetProjectTotalBalance = 0x04,
            GetVoteSwitchingCount = 0x05,
            SetVoteSwitchingCount = 0x06,
            GetLastVoteTimestamp = 0x07,
            SetLastVoteTimestamp = 0x08,
            GetFraudScore = 0x09,
            SetFraudScore = 0x0A,
            IsBackerEligible = 0x0B,
            IsParticipantBanned = 0x0C,
            GetVotesSnapshot = 0x0D,
            GetEligibleVotersCount = 0x0E,
            RecordVote = 0x0F,
            GetDelegateFor = 0x10,
            SetVoteDelegation = 0x11,
            RemoveVoteDelegation = 0x12,
            ClearVotes = 0x13,
            GetVotingDeadline = 0x20,
            SetVotingDeadline = 0x21,
            GetReservedFunds = 0x30,
            SetReservedFunds = 0x31,
            BanParticipant = 0x40,
            UnbanParticipant = 0x41,
        }

        // ����� Storage ����� OpCode (������� ����)
        private static object CallStorage(Op op, params object[] args)
        {
            UInt160 target = GetStorageContract();
            if (target is null || target.IsZero) throw new Exception("Storage contract not set");
            return Contract.Call(target, "entry", CallFlags.All, (byte)op, args);
        }

        // ? �����: ����� Storage ����� entryLogic ��� ������� ��� OpCode
        private static object CallStorageLogic(string methodName, CallFlags flags, params object[] args)
        {
            UInt160 target = GetStorageContract();
            if (target is null || target.IsZero) throw new Exception("Storage contract not set");
            return Contract.Call(target, "entryLogic", flags, methodName, args);
        }

        // ====== Compute logic moved from storage ======

        [Safe]
        public static BigInteger GetBackerVoteWeight(string projectId, UInt160 backer)
        {
            BigInteger donation = (BigInteger)CallStorage(Op.GetBackerDonation, projectId, backer);
            if (donation <= 0) return 1;
            BigInteger totalProjectBalance = (BigInteger)CallStorage(Op.GetProjectTotalBalance, projectId);
            if (totalProjectBalance <= 0) return 1;
            BigInteger sharePercentage = (donation * 1000) / totalProjectBalance;
            BigInteger weight = 1 + (sharePercentage / 10);
            if (weight > 101) weight = 101;
            if (weight <= 0) weight = 1;
            return weight;
        }

        [Safe]
        public static CalculatedVoteOutcome CalculateVoteOutcome(string projectId, string votingType,
            bool autoAssignVoiceless, bool abstainAsSupport, BigInteger minParticipationPct, BigInteger minApprovalPct)
        {
            CalculatedVoteOutcome outcome = new CalculatedVoteOutcome();
            BigInteger totalEligible = (BigInteger)CallStorage(Op.GetEligibleVotersCount, projectId);
            outcome.TotalEligibleVoters = totalEligible;

            BigInteger positiveVotes = 0;
            BigInteger negativeVotes = 0;
            BigInteger abstainedVotes = 0;
            BigInteger totalCasted = 0;

            int skip = 0;
            const int take = 64;

            while (true)
            {
                object[] page = (object[])CallStorage(Op.GetVotesSnapshot, projectId, votingType, skip, take);
                UInt160[] voters = (UInt160[])page[0];
                BackerVotesEnum[] votes = (BackerVotesEnum[])page[1];
                if (voters.Length == 0) break;

                for (int i = 0; i < voters.Length; i++)
                {
                    UInt160 voter = voters[i];
                    bool eligible = (bool)CallStorage(Op.IsBackerEligible, projectId, voter);
                    if (!eligible) continue;

                    BigInteger weight = GetBackerVoteWeight(projectId, voter);
                    totalCasted += weight;
                    var v = votes[i];
                    if (v == BackerVotesEnum.Positive) positiveVotes += weight;
                    else if (v == BackerVotesEnum.Negative) negativeVotes += weight;
                    else if (v == BackerVotesEnum.Abstained) abstainedVotes += weight;
                }

                skip += voters.Length;
                if (voters.Length < take) break;
            }

            BigInteger voiceless = totalEligible - totalCasted;
            if (autoAssignVoiceless && voiceless > 0)
            {
                abstainedVotes += voiceless;
                totalCasted += voiceless;
            }

            if (abstainAsSupport)
            {
                positiveVotes += abstainedVotes;
            }

            outcome.FinalPositiveVotes = positiveVotes;
            outcome.FinalNegativeVotes = negativeVotes;
            outcome.FinalAbstainedVotes = abstainedVotes;
            outcome.TotalParticipatedOrAssigned = totalCasted;

            bool meetsMinParticipation = true;
            if (minParticipationPct > 0 && totalEligible > 0)
            {
                meetsMinParticipation = (totalCasted * 100) >= (totalEligible * minParticipationPct);
            }

            outcome.IsSuccessful = false;
            if (meetsMinParticipation && totalCasted > 0)
            {
                outcome.IsSuccessful = (positiveVotes * 100) >= (totalCasted * minApprovalPct);
            }

            return outcome;
        }

        public static bool DetectFraudPattern(string projectId, UInt160 voter, string votingType)
        {
            ulong currentTime = Runtime.Time;
            ulong lastVoteTime = (ulong)(BigInteger)CallStorage(Op.GetLastVoteTimestamp, projectId, voter);

            bool detected = false;
            if (lastVoteTime > 0 && (currentTime - lastVoteTime) < 5)
            {
                BigInteger fraudScore = (BigInteger)CallStorage(Op.GetFraudScore, projectId, voter);
                CallStorage(Op.SetFraudScore, projectId, voter, fraudScore + 10);
                detected = true;
            }

            CallStorage(Op.SetLastVoteTimestamp, projectId, voter, (BigInteger)currentTime);
            return detected;
        }

        [Safe]
        public static FraudAnalysisResult AnalyzeFraudPatterns(string projectId, UInt160 voter)
        {
            FraudAnalysisResult result = new FraudAnalysisResult();
            result.SuspiciousScore = (BigInteger)CallStorage(Op.GetFraudScore, projectId, voter);
            result.VoteSwitchingCount = (int)(BigInteger)CallStorage(Op.GetVoteSwitchingCount, projectId, voter);
            result.LastVoteTime = (ulong)(BigInteger)CallStorage(Op.GetLastVoteTimestamp, projectId, voter);
            result.IsSuspicious = result.SuspiciousScore > 50 || result.VoteSwitchingCount > 3;
            result.RiskLevel = result.SuspiciousScore > 100 ? "HIGH" :
                result.SuspiciousScore > 50 ? "MEDIUM" : "LOW";
            return result;
        }

        [Safe]
        public static UInt160 ResolveFinalDelegate(string projectId, string votingType, UInt160 backer)
        {
            UInt160 current = backer;
            Map<UInt160, bool> visited = new Map<UInt160, bool>();
            int maxDepth = 100;
            for (int i = 0; i < maxDepth; i++)
            {
                if (visited.HasKey(current)) break;
                visited[current] = true;
                UInt160 next = (UInt160)CallStorage(Op.GetDelegateFor, projectId, votingType, current);
                if (next is null || next.IsZero) return current;
                current = next;
            }
            return current;
        }

        [Safe]
        public static bool ValidateDelegationIntegrity(string projectId)
        {
            return true;
        }

        // ====== PUBLIC API WRAPPERS (matching IFMiniAdapter) ======

        // ? OpCode ������ (����� entry)
        public static bool IsBackerEligible(string projectId, UInt160 backer)
            => (bool)CallStorage(Op.IsBackerEligible, projectId, backer);

        public static BigInteger GetBackerDonation(string projectId, UInt160 backer)
            => (BigInteger)CallStorage(Op.GetBackerDonation, projectId, backer);

        public static void SetBackerDonation(string projectId, UInt160 backer, BigInteger amount)
            => CallStorage(Op.SetBackerDonation, projectId, backer, amount);

        public static BigInteger GetEligibleVotersCount(string projectId)
            => (BigInteger)CallStorage(Op.GetEligibleVotersCount, projectId);

        public static object[] GetVotesSnapshot(string projectId, string votingType, int skip, int take)
            => (object[])CallStorage(Op.GetVotesSnapshot, projectId, votingType, skip, take);

        public static void RecordVote(string projectId, string votingType, UInt160 backer, BackerVotesEnum vote)
            => CallStorage(Op.RecordVote, projectId, votingType, backer, (int)vote);

        public static void ClearVotes(string projectId, string votingType)
            => CallStorage(Op.ClearVotes, projectId, votingType);

        public static ulong GetVotingDeadline(string projectId, string votingType)
            => (ulong)(BigInteger)CallStorage(Op.GetVotingDeadline, projectId, votingType);

        public static void SetVotingDeadline(string projectId, string votingType, ulong deadline)
            => CallStorage(Op.SetVotingDeadline, projectId, votingType, deadline);

        public static BigInteger GetProjectTotalBalance(string projectId)
            => (BigInteger)CallStorage(Op.GetProjectTotalBalance, projectId);

        public static void SetProjectTotalBalance(string projectId, BigInteger balance)
            => CallStorage(Op.SetProjectTotalBalance, projectId, balance);

        public static void SetReservedFunds(string projectId, UInt160 manufacturer, BigInteger amount)
            => CallStorage(Op.SetReservedFunds, projectId, manufacturer, amount);

        public static BigInteger GetReservedFunds(string projectId, UInt160 manufacturer)
            => (BigInteger)CallStorage(Op.GetReservedFunds, projectId, manufacturer);

        public static void BanParticipant(string projectId, UInt160 participant, bool isManufacturer, BanReason reason)
            => CallStorage(Op.BanParticipant, projectId, participant, isManufacturer, (int)reason);

        public static void UnbanParticipant(string projectId, UInt160 participant, bool isManufacturer)
            => CallStorage(Op.UnbanParticipant, projectId, participant, isManufacturer);

        public static bool IsParticipantBanned(string projectId, UInt160 participant)
            => (bool)CallStorage(Op.IsParticipantBanned, projectId, participant);

        public static void SetFraudScore(string projectId, UInt160 participant, BigInteger score)
            => CallStorage(Op.SetFraudScore, projectId, participant, score);

        public static BigInteger GetFraudScore(string projectId, UInt160 participant)
            => (BigInteger)CallStorage(Op.GetFraudScore, projectId, participant);

        public static void SetLastVoteTimestamp(string projectId, UInt160 voter, ulong timestamp)
            => CallStorage(Op.SetLastVoteTimestamp, projectId, voter, timestamp);

        public static ulong GetLastVoteTimestamp(string projectId, UInt160 voter)
            => (ulong)(BigInteger)CallStorage(Op.GetLastVoteTimestamp, projectId, voter);

        public static void SetVoteSwitchingCount(string projectId, UInt160 voter, int count)
            => CallStorage(Op.SetVoteSwitchingCount, projectId, voter, count);

        public static int GetVoteSwitchingCount(string projectId, UInt160 voter)
            => (int)(BigInteger)CallStorage(Op.GetVoteSwitchingCount, projectId, voter);

        public static void SetVoteDelegation(string projectId, string votingType, UInt160 delegator, UInt160 delegateAddr)
            => CallStorage(Op.SetVoteDelegation, projectId, votingType, delegator, delegateAddr);

        public static void RemoveVoteDelegation(string projectId, string votingType, UInt160 delegator)
            => CallStorage(Op.RemoveVoteDelegation, projectId, votingType, delegator);

        // ? ������ ��� OpCode (����� entryLogic)
        public static void SetProjectCore(string projectId, ByteString coreBytes)
            => CallStorageLogic(nameof(SetProjectCore), CallFlags.All, projectId, coreBytes);

        public static ByteString GetProjectCoreBytes(string projectId)
            => (ByteString)CallStorageLogic(nameof(GetProjectCoreBytes), CallFlags.ReadOnly, projectId);

        public static void SetLogicContract(UInt160 newLogicContract)
            => CallStorageLogic(nameof(SetLogicContract), CallFlags.All, newLogicContract);

        public static void RegisterManufacturer(string projectId, UInt160 manufacturer, string data)
            => CallStorageLogic(nameof(RegisterManufacturer), CallFlags.All, projectId, manufacturer, data);

        public static void UnregisterManufacturer(string projectId, UInt160 manufacturer)
            => CallStorageLogic(nameof(UnregisterManufacturer), CallFlags.All, projectId, manufacturer);

        public static void DeleteMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
            => CallStorageLogic(nameof(DeleteMilestone), CallFlags.All, projectId, manufacturer, stepNumber);

        public static void SetProjectUpdateVotingStatus(string projectId, string updateId, bool isActive, bool isFinalized)
            => CallStorageLogic(nameof(SetProjectUpdateVotingStatus), CallFlags.All, projectId, updateId, isActive, isFinalized);

        public static bool IsProjectUpdateVotingActive(string projectId, string updateId)
            => (bool)CallStorageLogic(nameof(IsProjectUpdateVotingActive), CallFlags.ReadOnly, projectId, updateId);

        public static bool IsProjectUpdateVotingFinalized(string projectId, string updateId)
            => (bool)CallStorageLogic(nameof(IsProjectUpdateVotingFinalized), CallFlags.ReadOnly, projectId, updateId);

        public static void SetProjectUpdateVotingResults(string projectId, string updateId, BigInteger positiveVotes, BigInteger negativeVotes, BigInteger abstainedVotes, BigInteger totalVotes)
            => CallStorageLogic(nameof(SetProjectUpdateVotingResults), CallFlags.All, projectId, updateId, positiveVotes, negativeVotes, abstainedVotes, totalVotes);

        public static object[] GetProjectUpdateVotingResults(string projectId, string updateId)
            => (object[])CallStorageLogic(nameof(GetProjectUpdateVotingResults), CallFlags.ReadOnly, projectId, updateId);

        public static void SetApprovedUpdate(string projectId, string updateId, bool approved)
            => CallStorageLogic(nameof(SetApprovedUpdate), CallFlags.All, projectId, updateId, approved);

        public static bool IsUpdateApproved(string projectId, string updateId)
            => (bool)CallStorageLogic(nameof(IsUpdateApproved), CallFlags.ReadOnly, projectId, updateId);

        public static void SetProjectUpdateVote(string projectId, string updateId, UInt160 backer, BackerVotesEnum vote)
            => CallStorageLogic(nameof(SetProjectUpdateVote), CallFlags.All, projectId, updateId, backer, vote);

        public static BackerVotesEnum GetProjectUpdateVote(string projectId, string updateId, UInt160 backer)
            => (BackerVotesEnum)CallStorageLogic(nameof(GetProjectUpdateVote), CallFlags.ReadOnly, projectId, updateId, backer);

        public static void SetProjectUpdateVotingDeadline(string projectId, string updateId, ulong deadline)
            => CallStorageLogic(nameof(SetProjectUpdateVotingDeadline), CallFlags.All, projectId, updateId, deadline);

        public static ulong GetProjectUpdateVotingDeadline(string projectId, string updateId)
            => (ulong)(BigInteger)CallStorageLogic(nameof(GetProjectUpdateVotingDeadline), CallFlags.ReadOnly, projectId, updateId);

        public static void SetProjectVotingDeadlines(string projectId, ulong launchDeadline, ulong fundraisingDeadline, ulong manufacturerSelectionDeadline)
            => CallStorageLogic(nameof(SetProjectVotingDeadlines), CallFlags.All, projectId, launchDeadline, fundraisingDeadline, manufacturerSelectionDeadline);

        public static object[] GetProjectVotingDeadlines(string projectId)
            => (object[])CallStorageLogic(nameof(GetProjectVotingDeadlines), CallFlags.ReadOnly, projectId);

        public static void SetAutoSelectWinner(string projectId, UInt160 backer, UInt160 manufacturer)
            => CallStorageLogic(nameof(SetAutoSelectWinner), CallFlags.All, projectId, backer, manufacturer);

        public static UInt160 GetAutoSelectWinner(string projectId, UInt160 backer)
            => (UInt160)CallStorageLogic(nameof(GetAutoSelectWinner), CallFlags.ReadOnly, projectId, backer);

        public static void ClearAutoSelections(string projectId)
            => CallStorageLogic(nameof(ClearAutoSelections), CallFlags.All, projectId);

        public static void SetVotingConfiguration(string projectId, BigInteger minParticipation, BigInteger minApproval, bool autoAssignVoiceless, bool abstainAsSupport)
            => CallStorageLogic(nameof(SetVotingConfiguration), CallFlags.All, projectId, minParticipation, minApproval, autoAssignVoiceless, abstainAsSupport);

        public static object GetVotingConfiguration(string projectId)
            => CallStorageLogic(nameof(GetVotingConfiguration), CallFlags.ReadOnly, projectId);

        public static void SetReferrer(string projectId, UInt160 backer, UInt160 referrer)
            => CallStorageLogic(nameof(SetReferrer), CallFlags.All, projectId, backer, referrer);

        public static UInt160 GetReferrer(string projectId, UInt160 backer)
            => (UInt160)CallStorageLogic(nameof(GetReferrer), CallFlags.ReadOnly, projectId, backer);

        public static void SetReferralReward(string projectId, UInt160 referrer, BigInteger amount)
            => CallStorageLogic(nameof(SetReferralReward), CallFlags.All, projectId, referrer, amount);

        public static BigInteger GetReferralReward(string projectId, UInt160 referrer)
            => (BigInteger)CallStorageLogic(nameof(GetReferralReward), CallFlags.ReadOnly, projectId, referrer);

        public static void SetConditionalVotingRule(string projectId, string ruleId, bool isActive)
            => CallStorageLogic(nameof(SetConditionalVotingRule), CallFlags.All, projectId, ruleId, isActive);

        public static bool GetConditionalVotingRule(string projectId, string ruleId)
            => (bool)CallStorageLogic(nameof(GetConditionalVotingRule), CallFlags.ReadOnly, projectId, ruleId);

        public static void SetConditionalThreshold(string projectId, string ruleId, BigInteger threshold)
            => CallStorageLogic(nameof(SetConditionalThreshold), CallFlags.All, projectId, ruleId, threshold);

        public static BigInteger GetConditionalThreshold(string projectId, string ruleId)
            => (BigInteger)CallStorageLogic(nameof(GetConditionalThreshold), CallFlags.ReadOnly, projectId, ruleId);

        public static void SetMultiTierVoting(string projectId, string voteId, UInt160 voter, byte tierLevel)
            => CallStorageLogic(nameof(SetMultiTierVoting), CallFlags.All, projectId, voteId, voter, tierLevel);

        public static byte GetMultiTierVoting(string projectId, string voteId, UInt160 voter)
            => (byte)(BigInteger)CallStorageLogic(nameof(GetMultiTierVoting), CallFlags.ReadOnly, projectId, voteId, voter);

        public static void SetVoteWeightByTier(string projectId, string tierId, BigInteger weight)
            => CallStorageLogic(nameof(SetVoteWeightByTier), CallFlags.All, projectId, tierId, weight);

        public static BigInteger GetVoteWeightByTier(string projectId, string tierId)
            => (BigInteger)CallStorageLogic(nameof(GetVoteWeightByTier), CallFlags.ReadOnly, projectId, tierId);

        public static void RemoveVoteWeightByTier(string projectId, string tierId)
            => CallStorageLogic(nameof(RemoveVoteWeightByTier), CallFlags.All, projectId, tierId);

        public static string[] GetVotingTierWeightsKeys(string projectId)
            => (string[])CallStorageLogic(nameof(GetVotingTierWeightsKeys), CallFlags.ReadOnly, projectId);

        public static void ClearVotingTierWeights(string projectId)
            => CallStorageLogic(nameof(ClearVotingTierWeights), CallFlags.All, projectId);

        public static void SetBackerTokenReward(string projectId, UInt160 backer, BigInteger tokenAmount)
            => CallStorageLogic(nameof(SetBackerTokenReward), CallFlags.All, projectId, backer, tokenAmount);

        public static BigInteger GetBackerTokenReward(string projectId, UInt160 backer)
            => (BigInteger)CallStorageLogic(nameof(GetBackerTokenReward), CallFlags.ReadOnly, projectId, backer);

        public static void SetManufacturerPenalty(string projectId, UInt160 manufacturer, BigInteger penaltyAmount)
            => CallStorageLogic(nameof(SetManufacturerPenalty), CallFlags.All, projectId, manufacturer, penaltyAmount);

        public static BigInteger GetManufacturerPenalty(string projectId, UInt160 manufacturer)
            => (BigInteger)CallStorageLogic(nameof(GetManufacturerPenalty), CallFlags.ReadOnly, projectId, manufacturer);

        public static void SetPenaltyTimestamp(string projectId, UInt160 manufacturer, ulong timestamp)
            => CallStorageLogic(nameof(SetPenaltyTimestamp), CallFlags.All, projectId, manufacturer, timestamp);

        public static ulong GetPenaltyTimestamp(string projectId, UInt160 manufacturer)
            => (ulong)(BigInteger)CallStorageLogic(nameof(GetPenaltyTimestamp), CallFlags.ReadOnly, projectId, manufacturer);

        // ? �������� ��������� ������ �� �������� (~50 �������)



    }
}