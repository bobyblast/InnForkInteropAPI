using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Attributes;
using System;
using System.ComponentModel;
using System.Numerics;
using InnFork.NeoN3.Enums;

namespace InnFork.NeoN3.StorageLogic
{
    public partial class IF_MainGateway
    {
        // OpCodes ��� �������
        private enum EventOp : byte
        {
            // Investment Agreement Events
            EmitAgreementCreated = 0x50,
            EmitAgreementConfirmed = 0x51,
            EmitAgreementCompleted = 0x52,
            EmitAgreementDefaulted = 0x53,
            EmitRepaymentMade = 0x54,
            EmitInvestmentPaymentMade = 0x55,

            // Voting Events
            EmitProjectLaunchApproved = 0x60,
            EmitFundraisingCompletionApproved = 0x61,
            EmitProjectUpdatesApproved = 0x62,
            EmitManufacturerWinnerSelectionApproved = 0x63,
            EmitMilestoneCompletionApproved = 0x64,
            EmitProjectPauseResumeVoted = 0x65,
            EmitSuccessfulClosureApproved = 0x66,
            EmitTerminationWithRefundApproved = 0x67,
            EmitVoteAbstained = 0x68,
            EmitVoteCasted = 0x69,
            EmitVotingStarted = 0x6A,
            EmitVotingCompleted = 0x6B,
            EmitVotingFinalized = 0x6C,
            EmitWinnerSelected = 0x6D,
            EmitManufacturerSelected = 0x6E,

            // Vote Delegation Events
            EmitVoteDelegated = 0x70,
            EmitVoteDelegationRevoked = 0x71,
            EmitBulkDelegationRevoked = 0x72,
            EmitDelegationIntegrityViolation = 0x73,

            // Milestone Events
            EmitMilestoneCompleted = 0x80,
            EmitMilestoneFundingRolledBack = 0x81,
            EmitMilestoneResetForRestart = 0x82,

            // Dispute Events
            EmitDisputeCreated = 0x90,
            EmitDisputeStatusChanged = 0x91,
            EmitDisputeStatusUpdated = 0x92,

            // Ban & Penalty Events
            EmitManufacturerBanned = 0xA0,
            EmitBackerBanned = 0xA1,
            EmitManufacturerPenalized = 0xA2,
            EmitManufacturerPenaltyCleared = 0xA3,
            EmitBackerFundsBlocked = 0xA4,
            EmitBackerFundsUnblocked = 0xA5,

            // Emergency & Refund Events
            EmitEmergencyRefundExecuted = 0xB0,

            // General System Events
            EmitProjectSaved = 0xC0,
        }

        // ===== CONFIG: ����� StorageState ��������� =====

        private static readonly byte[] StorageStateHashKey = "if_storage_state_hash".ToByteArray();



        // ===== ������������� ��������� ������� =====

        /// <summary>
        /// ������������� ����� ��� ������ ������ ������� ����� storage contract.
        /// ���� ����� ������������ ��� ���������� ��������� ��� ���� ��������� ������� emit.
        /// </summary>
        /// <param name="eventOp">OpCode ������� �� enum EventOp</param>
        /// <param name="args">��������� ������� � ���� ������� ��������</param>
        private static void DispatchEvent(EventOp eventOp, params object[] args)
        {
            UInt160 storageContract = GetStorageContract();
            Contract.Call(storageContract, "emitEvent", CallFlags.All, (byte)eventOp, args);
        }

        // ===== INVESTMENT AGREEMENT EVENT DISPATCHER METHODS =====

        public static void EmitAgreementCreated(byte[] agreementId, UInt160 investor, UInt160 manufacturer, BigInteger amount)
            => DispatchEvent(EventOp.EmitAgreementCreated, agreementId, investor, manufacturer, amount);

        public static void EmitAgreementConfirmed(byte[] agreementId)
            => DispatchEvent(EventOp.EmitAgreementConfirmed, agreementId);

        public static void EmitAgreementCompleted(byte[] agreementId)
            => DispatchEvent(EventOp.EmitAgreementCompleted, agreementId);

        public static void EmitAgreementDefaulted(byte[] agreementId)
            => DispatchEvent(EventOp.EmitAgreementDefaulted, agreementId);

        public static void EmitRepaymentMade(byte[] agreementId, BigInteger amount)
            => DispatchEvent(EventOp.EmitRepaymentMade, agreementId, amount);

        public static void EmitInvestmentPaymentMade(byte[] agreementId, BigInteger amount)
            => DispatchEvent(EventOp.EmitInvestmentPaymentMade, agreementId, amount);

        // ===== VOTING SYSTEM EVENT DISPATCHER METHODS =====

        public static void EmitProjectLaunchApproved(string projectId, bool approved)
            => DispatchEvent(EventOp.EmitProjectLaunchApproved, projectId, approved);

        public static void EmitFundraisingCompletionApproved(string projectId, bool approved)
            => DispatchEvent(EventOp.EmitFundraisingCompletionApproved, projectId, approved);

        public static void EmitProjectUpdatesApproved(string projectId, bool approved)
            => DispatchEvent(EventOp.EmitProjectUpdatesApproved, projectId, approved);

        public static void EmitManufacturerWinnerSelectionApproved(string projectId, UInt160 manufacturerAddress, bool approved)
            => DispatchEvent(EventOp.EmitManufacturerWinnerSelectionApproved, projectId, manufacturerAddress, approved);

        public static void EmitMilestoneCompletionApproved(string projectId, string milestoneId, bool approved)
            => DispatchEvent(EventOp.EmitMilestoneCompletionApproved, projectId, milestoneId, approved);

        public static void EmitProjectPauseResumeVoted(string projectId, bool isPause, bool approved)
            => DispatchEvent(EventOp.EmitProjectPauseResumeVoted, projectId, isPause, approved);

        public static void EmitSuccessfulClosureApproved(string projectId, bool approved)
            => DispatchEvent(EventOp.EmitSuccessfulClosureApproved, projectId, approved);

        public static void EmitTerminationWithRefundApproved(string projectId, bool approved)
            => DispatchEvent(EventOp.EmitTerminationWithRefundApproved, projectId, approved);

        public static void EmitVoteAbstained(string projectId, string voteType, UInt160 voterAddress)
            => DispatchEvent(EventOp.EmitVoteAbstained, projectId, voteType, voterAddress);

        public static void EmitVoteCasted(string projectId, UInt160 voterAddress, int voteValue)
            => DispatchEvent(EventOp.EmitVoteCasted, projectId, voterAddress, voteValue);

        public static void EmitVotingStarted(string projectId, string voteType)
            => DispatchEvent(EventOp.EmitVotingStarted, projectId, voteType);

        public static void EmitVotingCompleted(string projectId, string voteType, int result)
            => DispatchEvent(EventOp.EmitVotingCompleted, projectId, voteType, result);

        public static void EmitVotingFinalized(string projectId, int voteType)
            => DispatchEvent(EventOp.EmitVotingFinalized, projectId, voteType);

        public static void EmitWinnerSelected(string projectId, string winnerId)
            => DispatchEvent(EventOp.EmitWinnerSelected, projectId, winnerId);

        public static void EmitManufacturerSelected(string projectId, UInt160 manufacturerAddress)
            => DispatchEvent(EventOp.EmitManufacturerSelected, projectId, manufacturerAddress);

        // ===== VOTE DELEGATION EVENT DISPATCHER METHODS =====

        public static void EmitVoteDelegated(string projectId, string delegatorAddress, string delegateAddress, string votingType)
            => DispatchEvent(EventOp.EmitVoteDelegated, projectId, delegatorAddress, delegateAddress, votingType);

        public static void EmitVoteDelegationRevoked(string projectId, string delegatorAddress, string delegateAddress, string votingType)
            => DispatchEvent(EventOp.EmitVoteDelegationRevoked, projectId, delegatorAddress, delegateAddress, votingType);

        public static void EmitBulkDelegationRevoked(string projectId, string participantAddress, int revokedCount)
            => DispatchEvent(EventOp.EmitBulkDelegationRevoked, projectId, participantAddress, revokedCount);

        public static void EmitDelegationIntegrityViolation(string projectId, string participantAddress, string violationType, string details)
            => DispatchEvent(EventOp.EmitDelegationIntegrityViolation, projectId, participantAddress, violationType, details);

        // ===== MILESTONE SYSTEM EVENT DISPATCHER METHODS =====

        public static void EmitMilestoneCompleted(string projectId, byte stepNumber, bool successful)
            => DispatchEvent(EventOp.EmitMilestoneCompleted, projectId, stepNumber, successful);

        public static void EmitMilestoneFundingRolledBack(string projectId, UInt160 manufacturerAddress, byte stepNumber, string reason, BigInteger amount)
            => DispatchEvent(EventOp.EmitMilestoneFundingRolledBack, projectId, manufacturerAddress, stepNumber, reason, amount);

        public static void EmitMilestoneResetForRestart(string projectId, UInt160 manufacturerAddress, byte stepNumber, string reason)
            => DispatchEvent(EventOp.EmitMilestoneResetForRestart, projectId, manufacturerAddress, stepNumber, reason);

        // ===== DISPUTE SYSTEM EVENT DISPATCHER METHODS =====

        public static void EmitDisputeCreated(string disputeId, UInt160 initiator, int disputeType, string description)
            => DispatchEvent(EventOp.EmitDisputeCreated, disputeId, initiator, disputeType, description);

        public static void EmitDisputeStatusChanged(string disputeId, int oldStatus, int newStatus)
            => DispatchEvent(EventOp.EmitDisputeStatusChanged, disputeId, oldStatus, newStatus);

        public static void EmitDisputeStatusUpdated(string disputeId, int newStatus)
            => DispatchEvent(EventOp.EmitDisputeStatusUpdated, disputeId, newStatus);

        // ===== BAN & PENALTY EVENT DISPATCHER METHODS =====

        public static void EmitManufacturerBanned(UInt160 manufacturerAddress, int banReason)
            => DispatchEvent(EventOp.EmitManufacturerBanned, manufacturerAddress, banReason);

        public static void EmitBackerBanned(UInt160 backerAddress, int banReason)
            => DispatchEvent(EventOp.EmitBackerBanned, backerAddress, banReason);

        public static void EmitManufacturerPenalized(UInt160 manufacturerAddress, BigInteger penaltyAmount)
            => DispatchEvent(EventOp.EmitManufacturerPenalized, manufacturerAddress, penaltyAmount);

        public static void EmitManufacturerPenaltyCleared(UInt160 manufacturerAddress, BigInteger clearedAmount)
            => DispatchEvent(EventOp.EmitManufacturerPenaltyCleared, manufacturerAddress, clearedAmount);

        public static void EmitBackerFundsBlocked(UInt160 backerAddress, BigInteger blockedAmount, int blockReason)
            => DispatchEvent(EventOp.EmitBackerFundsBlocked, backerAddress, blockedAmount, blockReason);

        public static void EmitBackerFundsUnblocked(UInt160 backerAddress, BigInteger unblockedAmount)
            => DispatchEvent(EventOp.EmitBackerFundsUnblocked, backerAddress, unblockedAmount);

        // ===== EMERGENCY & REFUND EVENT DISPATCHER METHODS =====

        public static void EmitEmergencyRefundExecuted(string projectId, BigInteger refundAmount)
            => DispatchEvent(EventOp.EmitEmergencyRefundExecuted, projectId, refundAmount);

        // ===== GENERAL SYSTEM EVENT DISPATCHER METHODS =====

        public static void EmitProjectSaved(string projectId, UInt160 author)
            => DispatchEvent(EventOp.EmitProjectSaved, projectId, author);
    }
}