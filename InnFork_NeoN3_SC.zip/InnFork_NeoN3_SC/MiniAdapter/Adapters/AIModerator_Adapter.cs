using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;

/// <summary>
/// Mini-адаптер для интеграции AI Moderator в бизнес-логику платформы
/// Обеспечивает простой интерфейс для вызова функций модерации из других контрактов
/// </summary>
public static partial class AIModerator
{
    /// <summary>
    /// Адрес контракта AI Moderator
    /// NOTE: Заменить на реальный адрес после деплоя
    /// </summary>
    [InitialValue("NQdq7Ud4q2VSjtPFW43cns3aP5SZtRL5pE", ContractParameterType.Hash160)]
    public static readonly UInt160 DefaultModeratorContract = "NQdq7Ud4q2VSjtPFW43cns3aP5SZtRL5pE";

    public static UInt160 GetModeratorContractHash()
    {
        return UInt160.Zero; // Заглушка для отключения модерации

        // error compilation
        //   ByteString stored = Storage.Get(Storage.CurrentContext, ModeratorContractStorageKey);
        //   return stored is null || stored.Length == 0 ? DefaultModeratorContract : (UInt160)stored;
    }


    // МЕТОДЫ МОДЕРАЦИИ (ЗАПРОСЫ)
    // ============================================

    /// <summary>
    /// Модерация предложения проекта с автоприменением санкций
    /// </summary>
    /// <param name="offerId">SHA256 хэш предложения</param>
    /// <param name="offerJson">JSON содержимое предложения</param>
    /// <param name="requester">Адрес запрашивающего</param>
    /// <param name="autoEnforce">Автоматически применять санкции при нарушениях</param>
    /// <returns>ID запроса модерации для последующего отслеживания</returns>
    public static string ModerateProjectOffer(string offerId, string offerJson, UInt160 requester, bool autoEnforce = false)
    {
        return (string)Contract.Call(GetModeratorContractHash(), "ModerateProjectOffer",
            CallFlags.All, offerId, offerJson, requester, autoEnforce);
    }

    /// <summary>
    /// Модерация описания проекта
    /// </summary>
    public static string ModerateProjectDescription(string projectId, string descriptionJson, UInt160 requester, bool autoEnforce = false)
    {
        return (string)Contract.Call(GetModeratorContractHash(), "ModerateProjectDescription",
            CallFlags.All, projectId, descriptionJson, requester, autoEnforce);
    }

    /// <summary>
    /// Модерация профиля производителя с проверкой репутации
    /// </summary>
    public static string ModerateManufacturerProfile(string projectId, UInt160 manufacturerAddress,
        string profileJson, UInt160 requester, bool autoEnforce = true)
    {
        return (string)Contract.Call(GetModeratorContractHash(), "ModerateManufacturerProfile",
            CallFlags.All, projectId, manufacturerAddress, profileJson, requester, autoEnforce);
    }

    /// <summary>
    /// Модерация доказательств в споре
    /// </summary>
    public static string ModerateDisputeEvidence(string projectId, string disputeId,
        string evidenceJson, UInt160 requester, bool autoEnforce = true)
    {
        return (string)Contract.Call(GetModeratorContractHash(), "ModerateDisputeEvidence",
            CallFlags.All, projectId, disputeId, evidenceJson, requester, autoEnforce);
    }

    // ============================================
    // МЕТОДЫ ПОЛУЧЕНИЯ РЕЗУЛЬТАТОВ
    // ============================================

    /// <summary>
    /// Проверка статуса модерации (одобрено/отклонено)
    /// </summary>
    public static bool IsModerationApproved(string requestId)
    {
        return (bool)Contract.Call(GetModeratorContractHash(), "IsModerationApproved",
            CallFlags.ReadOnly, requestId);
    }

    /// <summary>
    /// Получение оценки уверенности модели
    /// </summary>
    public static BigInteger GetConfidenceScore(string requestId)
    {
        return (BigInteger)Contract.Call(GetModeratorContractHash(), "GetConfidenceScore",
            CallFlags.ReadOnly, requestId);
    }

    /// <summary>
    /// Получение расширенной статистики модерации с данными из Storage API
    /// </summary>
    public static Map<string, BigInteger> GetEnhancedModerationStats(string requestId, string projectId)
    {
        return (Map<string, BigInteger>)Contract.Call(GetModeratorContractHash(), "GetEnhancedModerationStats",
            CallFlags.ReadOnly, requestId, projectId);
    }

    /// <summary>
    /// Анализ паттернов нарушений участника
    /// </summary>
    public static Map<string, object> AnalyzeParticipantViolationPatterns(UInt160 participant, string projectId)
    {
        return (Map<string, object>)Contract.Call(GetModeratorContractHash(), "AnalyzeParticipantViolationPatterns",
            CallFlags.ReadOnly, participant, projectId);
    }

    /// <summary>
    /// Получение истории модераций с контекстом
    /// </summary>
    public static object[] GetModerationHistoryWithContext(UInt160 address, string projectId)
    {
        return (object[])Contract.Call(GetModeratorContractHash(), "GetModerationHistoryWithContext",
            CallFlags.ReadOnly, address, projectId);
    }

    // ============================================
    // АДМИНИСТРАТИВНЫЕ МЕТОДЫ
    // ============================================

    /// <summary>
    /// Ручное применение санкций администратором
    /// </summary>
    public static void ManuallyApplySanctions(string requestId, string projectId, UInt160 admin)
    {
        Contract.Call(GetModeratorContractHash(), "ManuallyApplySanctions",
            CallFlags.All, requestId, projectId, admin);
    }

    /// <summary>
    /// Реабилитация участника (снятие бана, сброс fraud score)
    /// </summary>
    public static void RehabilitateParticipant(string projectId, UInt160 participant, UInt160 admin)
    {
        Contract.Call(GetModeratorContractHash(), "RehabilitateParticipant",
            CallFlags.All, projectId, participant, admin);
    }

    /// <summary>
    /// Проверка наличия конкретного флага нарушения
    /// </summary>
    public static bool HasViolationFlag(string requestId, int flag)
    {
        return (bool)Contract.Call(GetModeratorContractHash(), "HasViolationFlag",
            CallFlags.ReadOnly, requestId, flag);
    }
}
