using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;

public static class ProjectState
{
    public static string ResetProjectWinnerStatus(string projectId)
    {
        return (string)RW(nameof(ResetProjectWinnerStatus), projectId);
    }

    [InitialValue("NQdq7Ud4q2VSjtPFW43cns3aP5SZtRL5pE", ContractParameterType.Hash160)]
    private static readonly UInt160 DefaultStateContract = default;

    // Optional: logic contract for compute operations
    [InitialValue("NQdq7Ud4q2VSjtPFW43cns3aP5SZtRL5pE", ContractParameterType.Hash160)]
    private static readonly UInt160 DefaultLogicContract = default;

    private static readonly byte[] StateContractStorageKey = "if:state:hash".ToByteArray();
    private static readonly byte[] LogicContractStorageKey = "if:logic:hash".ToByteArray();

    public static UInt160 GetStateContractHash()
    {
        return UInt160.Zero;
        /* ByteString stored = Storage.Get(Storage.CurrentContext, StateContractStorageKey);
         return stored is null || stored.Length ==0 ? DefaultStateContract : (UInt160)stored; */
    }

    public static UInt160 GetLogicContractHash()
    {
        return UInt160.Zero;
        /* ByteString stored = Storage.Get(Storage.CurrentContext, LogicContractStorageKey);
         return stored is null || stored.Length ==0 ? DefaultLogicContract : (UInt160)stored; */
    }

    // Map method names to storage dispatcher opcodes
    private static bool TryGetStorageOp(string method, out byte op)
    {
        // Keep this mapping in sync with storage contract's StorageOp
        switch (method)
        {
            case nameof(GetBackerDonation): op = 0x01; return true;
            case nameof(SetBackerDonation): op = 0x02; return true;

            case nameof(GetProjectTotalBalance): op = 0x03; return true;
            case nameof(SetProjectTotalBalance): op = 0x04; return true;

            case nameof(GetVoteSwitchingCount): op = 0x05; return true;
            case nameof(SetVoteSwitchingCount): op = 0x06; return true;
            case nameof(GetLastVoteTimestamp): op = 0x07; return true;
            case nameof(SetLastVoteTimestamp): op = 0x08; return true;
            case nameof(GetFraudScore): op = 0x09; return true;
            case nameof(SetFraudScore): op = 0x0A; return true;

            case nameof(IsBackerEligible): op = 0x0B; return true;
            case nameof(IsParticipantBanned): op = 0x0C; return true;

            case nameof(GetVotesSnapshot): op = 0x0D; return true;
            case nameof(GetEligibleVotersCount): op = 0x0E; return true;

            case nameof(GetVotingDeadline): op = 0x20; return true;
            case nameof(SetVotingDeadline): op = 0x21; return true;

            case nameof(GetReservedFunds): op = 0x30; return true;
            case nameof(SetReservedFunds): op = 0x31; return true;

            case nameof(BanParticipant): op = 0x40; return true;
            case nameof(UnbanParticipant): op = 0x41; return true;

            // Delegations (note: wrappers below already expose Set/Remove)
            case nameof(SetVoteDelegation): op = 0x11; return true;
            case nameof(RemoveVoteDelegation): op = 0x12; return true;
        }
        op = 0; return false;
    }

    private static object RO(string method, params object[] args)
    {
        UInt160 storage = GetStateContractHash();
        if (TryGetStorageOp(method, out byte op))
        {
            return Contract.Call(storage, "entry", CallFlags.ReadOnly, (byte)op, args);
        }
        else
        {
            return Contract.Call(storage, "entryLogic", CallFlags.ReadOnly, args);
        }
    }

    private static object RW(string method, params object[] args)
    {
        UInt160 storage = GetStateContractHash();
        if (TryGetStorageOp(method, out byte op))
        {
            return Contract.Call(storage, "entry", CallFlags.All, (byte)op, args);
        }
        else
        {
            return Contract.Call(storage, "entryLogic", CallFlags.All, args);
        }
    }

    // Logic-contract calls (compute moved out of storage)
    private static object RO_L(string method, params object[] args)
        => Contract.Call(GetLogicContractHash(), method, CallFlags.ReadOnly, args);
    private static object RW_L(string method, params object[] args)
        => Contract.Call(GetLogicContractHash(), method, CallFlags.All, args);

    public static UInt160 GetManufacturerWinner(string projectId)
    {
        return (UInt160)RO(nameof(GetManufacturerWinner), projectId);

    }

    public static void SetOfferReservedDonation(string offerId, UInt160 backer, BigInteger amount)
        => RW(nameof(SetOfferReservedDonation), offerId, backer, amount);

    public static BigInteger GetOfferReservedDonation(string offerId, UInt160 backer)
    {
        return (BigInteger)RO(nameof(GetOfferReservedDonation), offerId, backer);
    }

    public static string CreateDispute(string projectId, UInt160 initiator, DisputeType disputeType, string description, UInt160 manufacturerInvolved, byte milestoneStepInvolved)
    {
        return (string)RW(nameof(CreateDispute), projectId, initiator, disputeType, description, manufacturerInvolved, milestoneStepInvolved);
    }

    public static DisputeRecord GetDispute(string projectId, string disputeId)
        => (DisputeRecord)RO(nameof(GetDispute), projectId, disputeId);

    public static string[] GetDisputeIds(string projectId, int statusFilter)
        => (string[])RO(nameof(GetDisputeIds), projectId, statusFilter);

    public static void UpdateDisputeStatus(string projectId, string disputeId, DisputeStatus newStatus, string note)
        => RW(nameof(UpdateDisputeStatus), projectId, disputeId, newStatus, note);

    public static void SetDisputePenaltyAmount(string projectId, string disputeId, BigInteger penaltyAmount)
        => RW(nameof(SetDisputePenaltyAmount), projectId, disputeId, penaltyAmount);

    public static void ApplyDisputeSanctions(string projectId, string disputeId)
        => RW(nameof(ApplyDisputeSanctions), projectId, disputeId);

    public static void SetDisputeBanReason(string projectId, string disputeId, InnFork.NeoN3.Enums.BanReason reason)
        => RW(nameof(SetDisputeBanReason), projectId, disputeId, reason);

    public static void CloseDispute(string projectId, string disputeId)
        => RW(nameof(CloseDispute), projectId, disputeId);

    public static void SetDisputeResolutionNote(string projectId, string disputeId, string note)
        => RW(nameof(SetDisputeResolutionNote), projectId, disputeId, note);

    public static void LinkDisputeToMilestone(string projectId, string disputeId, UInt160 manufacturer, byte step)
        => RW(nameof(LinkDisputeToMilestone), projectId, disputeId, manufacturer, step);

    public static void PenalizeInitiator(string projectId, string disputeId, BigInteger penaltyScore)
        => RW(nameof(PenalizeInitiator), projectId, disputeId, penaltyScore);

    public static void SetDisputeStatusUnderReview(string projectId, string disputeId)
        => RW(nameof(SetDisputeStatusUnderReview), projectId, disputeId);

    public static void EscalateDispute(string projectId, string disputeId, string note)
        => RW(nameof(EscalateDispute), projectId, disputeId, note);

    public static void ResolveDispute(string projectId, string disputeId, string note)
        => RW(nameof(ResolveDispute), projectId, disputeId, note);

    public static void RejectDispute(string projectId, string disputeId, string note)
        => RW(nameof(RejectDispute), projectId, disputeId, note);

    public static void SetDisputeManufacturerPenaltyAndApply(string projectId, string disputeId, BigInteger penaltyAmount, BanReason reason, string note)
        => RW(nameof(SetDisputeManufacturerPenaltyAndApply), projectId, disputeId, penaltyAmount, reason, note);


    public static UInt160[] GetBackersWithDonations(string projectId)
        => (UInt160[])Contract.Call(GetStateContractHash(), nameof(GetBackersWithDonations), CallFlags.ReadOnly, projectId);


    public static void SetRawOfferPackage(ByteString offerIdKey, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetRawOfferPackage), CallFlags.All, offerIdKey, bytes);

    public static ByteString GetRawOfferPackage(ByteString offerIdKey)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetRawOfferPackage), CallFlags.ReadOnly, offerIdKey);

    public static bool DeleteRawOfferPackage(ByteString offerIdKey)
        => (bool)Contract.Call(GetStateContractHash(), nameof(DeleteRawOfferPackage), CallFlags.All, offerIdKey);

    public static void SetRawProjectPackage(ByteString projectIdKey, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetRawProjectPackage), CallFlags.All, projectIdKey, bytes);

    public static ByteString GetRawProjectPackage(ByteString projectIdKey)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetRawProjectPackage), CallFlags.ReadOnly, projectIdKey);

    public static void SetRawProjectAccount(ByteString projectIdKey, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetRawProjectAccount), CallFlags.All, projectIdKey, bytes);

    public static ByteString GetRawProjectAccount(ByteString projectIdKey)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetRawProjectAccount), CallFlags.ReadOnly, projectIdKey);

    public static void SetRawProjectCreatorAccount(UInt160 owner, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetRawProjectCreatorAccount), CallFlags.All, owner, bytes);

    public static ByteString GetRawProjectCreatorAccount(UInt160 owner)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetRawProjectCreatorAccount), CallFlags.ReadOnly, owner);

    public static void SetRawBackerAccount(UInt160 owner, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetRawBackerAccount), CallFlags.All, owner, bytes);

    public static ByteString GetRawBackerAccount(UInt160 owner)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetRawBackerAccount), CallFlags.ReadOnly, owner);

    public static void SetRawManufacturerAccount(UInt160 owner, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetRawManufacturerAccount), CallFlags.All, owner, bytes);

    public static ByteString GetRawManufacturerAccount(UInt160 owner)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetRawManufacturerAccount), CallFlags.ReadOnly, owner);

    public static void SetRawInvestorAccount(UInt160 owner, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetRawInvestorAccount), CallFlags.All, owner, bytes);

    public static ByteString GetRawInvestorAccount(UInt160 owner)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetRawInvestorAccount), CallFlags.ReadOnly, owner);

    public static void SetAgreement(ByteString agreementId, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetAgreement), CallFlags.All, agreementId, bytes);

    public static ByteString GetAgreement(ByteString agreementId)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetAgreement), CallFlags.ReadOnly, agreementId);

    public static void LinkInvestorAgreement(UInt160 investor, ByteString agreementId)
        => Contract.Call(GetStateContractHash(), nameof(LinkInvestorAgreement), CallFlags.All, investor, agreementId);

    public static ByteString GetInvestorAgreement(UInt160 investor)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetInvestorAgreement), CallFlags.ReadOnly, investor);

    public static void LinkManufacturerAgreement(UInt160 manufacturer, ByteString agreementId)
        => Contract.Call(GetStateContractHash(), nameof(LinkManufacturerAgreement), CallFlags.All, manufacturer, agreementId);

    public static ByteString GetManufacturerAgreement(UInt160 manufacturer)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetManufacturerAgreement), CallFlags.ReadOnly, manufacturer);

    public static void SetGlobalProjectsList(ByteString arrayBytes)
        => Contract.Call(GetStateContractHash(), nameof(SetGlobalProjectsList), CallFlags.All, arrayBytes);

    public static ByteString GetGlobalProjectsList()
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetGlobalProjectsList), CallFlags.ReadOnly);

    public static void SetGlobalProjectPackagesList(ByteString arrayBytes)
        => Contract.Call(GetStateContractHash(), nameof(SetGlobalProjectPackagesList), CallFlags.All, arrayBytes);

    public static ByteString GetGlobalProjectPackagesList()
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetGlobalProjectPackagesList), CallFlags.ReadOnly);

    public static void SetInvestmentRecord(ByteString compositeKey, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetInvestmentRecord), CallFlags.All, compositeKey, bytes);

    public static ByteString GetInvestmentRecord(ByteString compositeKey)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetInvestmentRecord), CallFlags.ReadOnly, compositeKey);

    public static void SetInvestmentSystemState(ByteString key, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetInvestmentSystemState), CallFlags.All, key, bytes);

    public static ByteString GetInvestmentSystemState(ByteString key)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetInvestmentSystemState), CallFlags.ReadOnly, key);

    public static void SetProjectCloseReason(ByteString projectIdKey, int reason)
        => Contract.Call(GetStateContractHash(), nameof(SetProjectCloseReason), CallFlags.All, projectIdKey, reason);

    public static int GetProjectCloseReason(ByteString projectIdKey)
        => (int)(BigInteger)Contract.Call(GetStateContractHash(), nameof(GetProjectCloseReason), CallFlags.ReadOnly, projectIdKey);

    public static void SetGlobalProjectOfferPackage(ByteString key, ByteString bytes)
        => Contract.Call(GetStateContractHash(), nameof(SetGlobalProjectOfferPackage), CallFlags.All, key, bytes);

    public static ByteString GetGlobalProjectOfferPackage(ByteString key)
        => (ByteString)Contract.Call(GetStateContractHash(), nameof(GetGlobalProjectOfferPackage), CallFlags.ReadOnly, key);

    public static void SetProjectCore(string projectId, ByteString coreBytes) => RW(nameof(SetProjectCore), projectId, coreBytes);
    public static ByteString GetProjectCoreBytes(string projectId)
    {
        return (ByteString)RO(nameof(GetProjectCoreBytes), projectId);
    }

    public static void SetLogicContract(UInt160 newLogicContract) => RW(nameof(SetLogicContract), newLogicContract);

    public static bool IsBackerEligible(string projectId, UInt160 backer) => (bool)RO(nameof(IsBackerEligible), projectId, backer);
    public static BigInteger GetBackerDonation(string projectId, UInt160 backer) => (BigInteger)RO(nameof(GetBackerDonation), projectId, backer);
    public static void SetBackerDonation(string projectId, UInt160 backer, BigInteger amount) => RW(nameof(SetBackerDonation), projectId, backer, amount);
    public static BigInteger GetEligibleVotersCount(string projectId) => (BigInteger)RO(nameof(GetEligibleVotersCount), projectId);
    public static object[] GetVotesSnapshot(string projectId, string votingType, int skip, int take) => (object[])RO(nameof(GetVotesSnapshot), projectId, votingType, skip, take);
    public static void RecordVote(string projectId, string votingType, UInt160 backer, int vote) => RW(nameof(RecordVote), projectId, votingType, backer, vote);
    public static void ClearVotes(string projectId, string votingType) => RW(nameof(ClearVotes), projectId, votingType);

    // Compute now routed to logic contract
    public static object CalculateVoteOutcome(string projectId, string votingType, bool autoAssignVoiceless, bool abstainAsSupport, BigInteger minParticipationPct, BigInteger minApprovalPct)
        => RO_L(nameof(CalculateVoteOutcome), projectId, votingType, autoAssignVoiceless, abstainAsSupport, minParticipationPct, minApprovalPct);
    public static BigInteger GetBackerVoteWeight(string projectId, UInt160 backer)
        => (BigInteger)RO_L(nameof(GetBackerVoteWeight), projectId, backer);
    public static UInt160 ResolveFinalDelegate(string projectId, string votingType, UInt160 backer)
        => (UInt160)RO_L(nameof(ResolveFinalDelegate), projectId, votingType, backer);

    public static ulong GetVotingDeadline(string projectId, string votingType) => (ulong)(BigInteger)RO(nameof(GetVotingDeadline), projectId, votingType);
    public static void SetVotingDeadline(string projectId, string votingType, ulong deadline) => RW(nameof(SetVotingDeadline), projectId, votingType, deadline);
    public static BigInteger GetProjectTotalBalance(string projectId) => (BigInteger)RO(nameof(GetProjectTotalBalance), projectId);
    public static void SetProjectTotalBalance(string projectId, BigInteger balance) => RW(nameof(SetProjectTotalBalance), projectId, balance);

    public static bool IsManufacturerRegistered(string projectId, UInt160 manufacturer) => (bool)RO(nameof(IsManufacturerRegistered), projectId, manufacturer);
    public static void RegisterManufacturer(string projectId, UInt160 manufacturer, string data) => RW(nameof(RegisterManufacturer), projectId, manufacturer, data);
    public static void UnregisterManufacturer(string projectId, UInt160 manufacturer) => RW(nameof(UnregisterManufacturer), projectId, manufacturer);
    public static UInt160[] GetManufacturerCandidates(string projectId) => (UInt160[])RO(nameof(GetManufacturerCandidates), projectId);

    public static void SetReservedFunds(string projectId, UInt160 manufacturer, BigInteger amount) => RW(nameof(SetReservedFunds), projectId, manufacturer, amount);
    public static BigInteger GetReservedFunds(string projectId, UInt160 manufacturer) => (BigInteger)RO(nameof(GetReservedFunds), projectId, manufacturer);
    public static void SetBackerReservation(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount) => RW(nameof(SetBackerReservation), projectId, backer, manufacturer, amount);
    public static BigInteger GetBackerReservation(string projectId, UInt160 backer, UInt160 manufacturer) => (BigInteger)RO(nameof(GetBackerReservation), projectId, backer, manufacturer);

    public static object GetMilestoneCompletionVotesStruct(string projectId, UInt160 manufacturer, byte stepNumber) => RO(nameof(GetMilestoneCompletionVotesStruct), projectId, manufacturer, stepNumber);
    public static void SetMilestoneCompletionVotesStruct(string projectId, UInt160 manufacturer, byte stepNumber, object milestone) => RW(nameof(SetMilestoneCompletionVotesStruct), projectId, manufacturer, stepNumber, milestone);
    public static void DeleteMilestone(string projectId, UInt160 manufacturer, byte stepNumber) => RW(nameof(DeleteMilestone), projectId, manufacturer, stepNumber);
    public static string[] GetMilestoneKeys(string projectId, UInt160 manufacturer) => (string[])RO(nameof(GetMilestoneKeys), projectId, manufacturer);

    public static void BanParticipant(string projectId, UInt160 participant, bool isManufacturer, int reason) => RW(nameof(BanParticipant), projectId, participant, isManufacturer, reason);
    public static void UnbanParticipant(string projectId, UInt160 participant, bool isManufacturer) => RW(nameof(UnbanParticipant), projectId, participant, isManufacturer);
    public static bool IsParticipantBanned(string projectId, UInt160 participant) => (bool)RO(nameof(IsParticipantBanned), projectId, participant);
    public static int GetParticipantBanReason(string projectId, UInt160 participant) => (int)(BigInteger)RO(nameof(GetParticipantBanReason), projectId, participant);

    public static void SetFraudScore(string projectId, UInt160 participant, BigInteger score) => RW(nameof(SetFraudScore), projectId, participant, score);
    public static BigInteger GetFraudScore(string projectId, UInt160 participant) => (BigInteger)RO(nameof(GetFraudScore), projectId, participant);
    public static void SetLastVoteTimestamp(string projectId, UInt160 voter, ulong timestamp) => RW(nameof(SetLastVoteTimestamp), projectId, voter, timestamp);
    public static ulong GetLastVoteTimestamp(string projectId, UInt160 voter) => (ulong)(BigInteger)RO(nameof(GetLastVoteTimestamp), projectId, voter);
    public static void SetVoteSwitchingCount(string projectId, UInt160 voter, int count) => RW(nameof(SetVoteSwitchingCount), projectId, voter, count);
    public static int GetVoteSwitchingCount(string projectId, UInt160 voter) => (int)(BigInteger)RO(nameof(GetVoteSwitchingCount), projectId, voter);
    public static void SetSuspiciousActivityScore(string projectId, UInt160 participant, BigInteger score) => RW(nameof(SetSuspiciousActivityScore), projectId, participant, score);
    public static BigInteger GetSuspiciousActivityScore(string projectId, UInt160 participant) => (BigInteger)RO(nameof(GetSuspiciousActivityScore), projectId, participant);

    // Compute moved to logic contract
    public static bool DetectFraudPattern(string projectId, UInt160 voter, string votingType) => (bool)RW_L(nameof(DetectFraudPattern), projectId, voter, votingType);
    public static object AnalyzeFraudPatterns(string projectId, UInt160 voter) => RO_L(nameof(AnalyzeFraudPatterns), projectId, voter);

    public static void SetManagementTransferVote(string projectId, UInt160 backer, int vote) => RW(nameof(SetManagementTransferVote), projectId, backer, vote);
    public static int GetManagementTransferVote(string projectId, UInt160 backer) => (int)(BigInteger)RO(nameof(GetManagementTransferVote), projectId, backer);
    public static void SetManagementTransferResults(string projectId, BigInteger positive, BigInteger negative, BigInteger abstained, BigInteger total) => RW(nameof(SetManagementTransferResults), projectId, positive, negative, abstained, total);

    public static void SetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 manufacturer, int vote) => RW(nameof(SetWinnerSelectionVote), projectId, backer, manufacturer, vote);
    public static int GetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 manufacturer) => (int)(BigInteger)RO(nameof(GetWinnerSelectionVote), projectId, backer, manufacturer);
    public static void SetCandidateWinnerVotes(string projectId, UInt160 manufacturer, object votes) => RW(nameof(SetCandidateWinnerVotes), projectId, manufacturer, votes);
    public static object GetCandidateWinnerVotes(string projectId, UInt160 manufacturer) => RO(nameof(GetCandidateWinnerVotes), projectId, manufacturer);

    public static void SetManufacturerQualityScore(string projectId, UInt160 manufacturer, BigInteger score) => RW(nameof(SetManufacturerQualityScore), projectId, manufacturer, score);
    public static BigInteger GetManufacturerQualityScore(string projectId, UInt160 manufacturer) => (BigInteger)RO(nameof(GetManufacturerQualityScore), projectId, manufacturer);
    public static void SetManufacturerVoteWeight(string projectId, UInt160 manufacturer, BigInteger weight) => RW(nameof(SetManufacturerVoteWeight), projectId, manufacturer, weight);
    public static BigInteger GetManufacturerVoteWeight(string projectId, UInt160 manufacturer) => (BigInteger)RO(nameof(GetManufacturerVoteWeight), projectId, manufacturer);
    public static void SetBackerVoteWeightValue(string projectId, UInt160 backer, BigInteger weight) => RW(nameof(SetBackerVoteWeightValue), projectId, backer, weight);
    public static BigInteger GetBackerVoteWeightValue(string projectId, UInt160 backer) => (BigInteger)RO(nameof(GetBackerVoteWeightValue), projectId, backer);
    public static void SetManufacturerReliabilityTier(string projectId, UInt160 manufacturer, byte tier) => RW(nameof(SetManufacturerReliabilityTier), projectId, manufacturer, tier);
    public static byte GetManufacturerReliabilityTier(string projectId, UInt160 manufacturer) => (byte)(BigInteger)RO(nameof(GetManufacturerReliabilityTier), projectId, manufacturer);

    public static void SetMilestoneTemplate(string projectId, string templateId, object template) => RW(nameof(SetMilestoneTemplate), projectId, templateId, template);
    public static object GetMilestoneTemplate(string projectId, string templateId) => RO(nameof(GetMilestoneTemplate), projectId, templateId);
    public static void SetManufacturerPreferredTemplate(string projectId, UInt160 manufacturer, string templateId) => RW(nameof(SetManufacturerPreferredTemplate), projectId, manufacturer, templateId);
    public static string GetManufacturerPreferredTemplate(string projectId, UInt160 manufacturer) => (string)RO(nameof(GetManufacturerPreferredTemplate), projectId, manufacturer);

    public static Map<string, BigInteger> GetMilestonePerformanceAnalytics(string projectId, UInt160 manufacturer) => (Map<string, BigInteger>)RO(nameof(GetMilestonePerformanceAnalytics), projectId, manufacturer);
    public static void SetDailyParticipationStats(string projectId, ulong timestamp, BigInteger participantsCount) => RW(nameof(SetDailyParticipationStats), projectId, timestamp, participantsCount);
    public static BigInteger GetDailyParticipationStats(string projectId, ulong timestamp) => (BigInteger)RO(nameof(GetDailyParticipationStats), projectId, timestamp);
    public static void SetTotalRefundsProcessed(string projectId, BigInteger amount) => RW(nameof(SetTotalRefundsProcessed), projectId, amount);
    public static BigInteger GetTotalRefundsProcessed(string projectId) => (BigInteger)RO(nameof(GetTotalRefundsProcessed), projectId);
    public static void SetRefundHistory(string projectId, UInt160 participant, BigInteger amount) => RW(nameof(SetRefundHistory), projectId, participant, amount);
    public static BigInteger GetRefundHistory(string projectId, UInt160 participant) => (BigInteger)RO(nameof(GetRefundHistory), projectId, participant);

    public static void SetNotificationPreference(string projectId, UInt160 participant, bool enabled) => RW(nameof(SetNotificationPreference), projectId, participant, enabled);
    public static bool GetNotificationPreference(string projectId, UInt160 participant) => (bool)RO(nameof(GetNotificationPreference), projectId, participant);
    public static void SetVotingReminderTimestamp(string projectId, int voteType, ulong timestamp) => RW(nameof(SetVotingReminderTimestamp), projectId, voteType, timestamp);
    public static ulong GetVotingReminderTimestamp(string projectId, int voteType) => (ulong)(BigInteger)RO(nameof(GetVotingReminderTimestamp), projectId, voteType);
    public static void SetDeadlineNotificationSent(string projectId, UInt160 participant, bool sent) => RW(nameof(SetDeadlineNotificationSent), projectId, participant, sent);
    public static bool GetDeadlineNotificationSent(string projectId, UInt160 participant) => (bool)RO(nameof(GetDeadlineNotificationSent), projectId, participant);

    public static void SetReferrer(string projectId, UInt160 backer, UInt160 referrer) => RW(nameof(SetReferrer), projectId, backer, referrer);
    public static UInt160 GetReferrer(string projectId, UInt160 backer) => (UInt160)RO(nameof(GetReferrer), projectId, backer);
    public static void SetReferralReward(string projectId, UInt160 referrer, BigInteger amount) => RW(nameof(SetReferralReward), projectId, referrer, amount);
    public static BigInteger GetReferralReward(string projectId, UInt160 referrer) => (BigInteger)RO(nameof(GetReferralReward), projectId, referrer);

    public static void SetConditionalVotingRule(string projectId, string ruleId, bool isActive) => RW(nameof(SetConditionalVotingRule), projectId, ruleId, isActive);
    public static bool GetConditionalVotingRule(string projectId, string ruleId) => (bool)RO(nameof(GetConditionalVotingRule), projectId, ruleId);
    public static void SetConditionalThreshold(string projectId, string ruleId, BigInteger threshold) => RW(nameof(SetConditionalThreshold), projectId, ruleId, threshold);
    public static BigInteger GetConditionalThreshold(string projectId, string ruleId) => (BigInteger)RO(nameof(GetConditionalThreshold), projectId, ruleId);
    public static void SetMultiTierVoting(string projectId, string voteId, UInt160 voter, byte tierLevel) => RW(nameof(SetMultiTierVoting), projectId, voteId, voter, tierLevel);
    public static byte GetMultiTierVoting(string projectId, string voteId, UInt160 voter) => (byte)(BigInteger)RO(nameof(GetMultiTierVoting), projectId, voteId, voter);
    public static void SetVoteWeightByTier(string projectId, string tierId, BigInteger weight) => RW(nameof(SetVoteWeightByTier), projectId, tierId, weight);
    public static BigInteger GetVoteWeightByTier(string projectId, string tierId) => (BigInteger)RO(nameof(GetVoteWeightByTier), projectId, tierId);
    public static void RemoveVoteWeightByTier(string projectId, string tierId) => RW(nameof(RemoveVoteWeightByTier), projectId, tierId);
    public static string[] GetVotingTierWeightsKeys(string projectId) => (string[])RO(nameof(GetVotingTierWeightsKeys), projectId);
    public static void ClearVotingTierWeights(string projectId) => RW(nameof(ClearVotingTierWeights), projectId);

    public static void SetBackerTokenReward(string projectId, UInt160 backer, BigInteger tokenAmount) => RW(nameof(SetBackerTokenReward), projectId, backer, tokenAmount);
    public static BigInteger GetBackerTokenReward(string projectId, UInt160 backer) => (BigInteger)RO(nameof(GetBackerTokenReward), projectId, backer);

    public static void SetManufacturerPenalty(string projectId, UInt160 manufacturer, BigInteger penaltyAmount) => RW(nameof(SetManufacturerPenalty), projectId, manufacturer, penaltyAmount);
    public static BigInteger GetManufacturerPenalty(string projectId, UInt160 manufacturer) => (BigInteger)RO(nameof(GetManufacturerPenalty), projectId, manufacturer);
    public static void SetPenaltyTimestamp(string projectId, UInt160 manufacturer, ulong timestamp) => RW(nameof(SetPenaltyTimestamp), projectId, manufacturer, timestamp);
    public static ulong GetPenaltyTimestamp(string projectId, UInt160 manufacturer) => (ulong)(BigInteger)RO(nameof(GetPenaltyTimestamp), projectId, manufacturer);

    public static void SetProjectUpdateVotingStatus(string projectId, string updateId, bool isActive, bool isFinalized) => RW(nameof(SetProjectUpdateVotingStatus), projectId, updateId, isActive, isFinalized);
    public static bool IsProjectUpdateVotingActive(string projectId, string updateId) => (bool)RO(nameof(IsProjectUpdateVotingActive), projectId, updateId);
    public static bool IsProjectUpdateVotingFinalized(string projectId, string updateId) => (bool)RO(nameof(IsProjectUpdateVotingFinalized), projectId, updateId);
    public static void SetProjectUpdateVotingResults(string projectId, string updateId, BigInteger positiveVotes, BigInteger negativeVotes, BigInteger abstainedVotes, BigInteger totalVotes) => RW(nameof(SetProjectUpdateVotingResults), projectId, updateId, positiveVotes, negativeVotes, abstainedVotes, totalVotes);
    public static object[] GetProjectUpdateVotingResults(string projectId, string updateId) => (object[])RO(nameof(GetProjectUpdateVotingResults), projectId, updateId);
    public static void SetApprovedUpdate(string projectId, string updateId, bool approved) => RW(nameof(SetApprovedUpdate), projectId, updateId, approved);
    public static bool IsUpdateApproved(string projectId, string updateId) => (bool)RO(nameof(IsUpdateApproved), projectId, updateId);
    public static void SetProjectUpdateVote(string projectId, string updateId, UInt160 backer, int vote) => RW(nameof(SetProjectUpdateVote), projectId, updateId, backer, vote);
    public static int GetProjectUpdateVote(string projectId, string updateId, UInt160 backer) => (int)(BigInteger)RO(nameof(GetProjectUpdateVote), projectId, updateId, backer);
    public static void SetProjectUpdateVotingDeadline(string projectId, string updateId, ulong deadline) => RW(nameof(SetProjectUpdateVotingDeadline), projectId, updateId, deadline);
    public static ulong GetProjectUpdateVotingDeadline(string projectId, string updateId) => (ulong)(BigInteger)RO(nameof(GetProjectUpdateVotingDeadline), projectId, updateId);

    public static void SetProjectVotingDeadlines(string projectId, ulong launchDeadline, ulong fundraisingDeadline, ulong manufacturerSelectionDeadline) => RW(nameof(SetProjectVotingDeadlines), projectId, launchDeadline, fundraisingDeadline, manufacturerSelectionDeadline);
    public static object[] GetProjectVotingDeadlines(string projectId) => (object[])RO(nameof(GetProjectVotingDeadlines), projectId);

    public static void SetAutoSelectWinner(string projectId, UInt160 backer, UInt160 manufacturer) => RW(nameof(SetAutoSelectWinner), projectId, backer, manufacturer);
    public static UInt160 GetAutoSelectWinner(string projectId, UInt160 backer) => (UInt160)RO(nameof(GetAutoSelectWinner), projectId, backer);
    public static void ClearAutoSelections(string projectId) => RW(nameof(ClearAutoSelections), projectId);

    public static void SetVotingConfiguration(string projectId, BigInteger minParticipation, BigInteger minApproval, bool autoAssignVoiceless, bool abstainAsSupport) => RW(nameof(SetVotingConfiguration), projectId, minParticipation, minApproval, autoAssignVoiceless, abstainAsSupport);
    public static object GetVotingConfiguration(string projectId) => RO(nameof(GetVotingConfiguration), projectId);

    public static void SetVoteDelegation(string projectId, string votingType, UInt160 delegator, UInt160 delegateAddr) => RW(nameof(SetVoteDelegation), projectId, votingType, delegator, delegateAddr);
    public static void RemoveVoteDelegation(string projectId, string votingType, UInt160 delegator) => RW(nameof(RemoveVoteDelegation), projectId, votingType, delegator);

    public static void SetProjectActivityScore(string projectId, BigInteger score) => RW(nameof(SetProjectActivityScore), projectId, score);
    public static BigInteger GetProjectActivityScore(string projectId) => (BigInteger)RO(nameof(GetProjectActivityScore), projectId);
    public static void SetLastActivityTime(string projectId, ulong timestamp) => RW(nameof(SetLastActivityTime), projectId, timestamp);
    public static ulong GetLastActivityTime(string projectId) => (ulong)(BigInteger)RO(nameof(GetLastActivityTime), projectId);

    public static void SetProjectStatus(string projectId, int status) => RW(nameof(SetProjectStatus), projectId, status);
    public static int GetProjectStatus(string projectId) => (int)(BigInteger)RO(nameof(GetProjectStatus), projectId);
    public static void SetProjectFlags(string projectId, bool isArchived, bool isPaused, bool isClosed, bool hasWinner) => RW(nameof(SetProjectFlags), projectId, isArchived, isPaused, isClosed, hasWinner);
    public static object GetProjectFlags(string projectId) => RO(nameof(GetProjectFlags), projectId);

    public static void SetLockedFunds(string projectId, BigInteger amount) => RW(nameof(SetLockedFunds), projectId, amount);
    public static BigInteger GetLockedFunds(string projectId) => (BigInteger)RO(nameof(GetLockedFunds), projectId);
    public static void UpdateLockedFunds(string projectId, BigInteger deltaAmount) => RW(nameof(UpdateLockedFunds), projectId, deltaAmount);

    public static bool ValidateDelegationIntegrity(string projectId)
    {
        return (bool)RO_L(nameof(ValidateDelegationIntegrity), projectId);
    }

    // NEW: Milestone backer votes and fraud flags
    public static void SetMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer, int vote)
        => RW(nameof(SetMilestoneBackerVote), projectId, manufacturer, stepNumber, backer, vote);

    public static int GetMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        => (int)(BigInteger)RO(nameof(GetMilestoneBackerVote), projectId, manufacturer, stepNumber, backer);

    public static void RemoveMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        => RW(nameof(RemoveMilestoneBackerVote), projectId, manufacturer, stepNumber, backer);

    public static void ClearMilestoneVotes(string projectId, UInt160 manufacturer, byte stepNumber)
        => RW(nameof(ClearMilestoneVotes), projectId, manufacturer, stepNumber);

    public static void SetMilestoneFraudFlag(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer, bool detected)
        => RW(nameof(SetMilestoneFraudFlag), projectId, manufacturer, stepNumber, backer, detected);

    public static bool GetMilestoneFraudFlag(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        => (bool)RO(nameof(GetMilestoneFraudFlag), projectId, manufacturer, stepNumber, backer);

    public static void ClearMilestoneFraudFlags(string projectId, UInt160 manufacturer, byte stepNumber)
        => RW(nameof(ClearMilestoneFraudFlags), projectId, manufacturer, stepNumber);

    // NEW: Winner vote fraud flags
    public static void SetWinnerVoteFraudFlag(string projectId, UInt160 manufacturer, UInt160 backer, bool detected)
        => RW(nameof(SetWinnerVoteFraudFlag), projectId, manufacturer, backer, detected);

    public static bool GetWinnerVoteFraudFlag(string projectId, UInt160 manufacturer, UInt160 backer)
        => (bool)RO(nameof(GetWinnerVoteFraudFlag), projectId, manufacturer, backer);

    public static void ClearWinnerVoteFraudFlags(string projectId, UInt160 manufacturer)
        => RW(nameof(ClearWinnerVoteFraudFlags), projectId, manufacturer);

    // NEW: Milestone template custom parameters CRUD
    public static void SetMilestoneTemplateParam(string projectId, string templateId, string paramKey, string paramValue)
        => RW(nameof(SetMilestoneTemplateParam), projectId, templateId, paramKey, paramValue);

    public static string GetMilestoneTemplateParam(string projectId, string templateId, string paramKey)
        => (string)RO(nameof(GetMilestoneTemplateParam), projectId, templateId, paramKey);

    public static void RemoveMilestoneTemplateParam(string projectId, string templateId, string paramKey)
        => RW(nameof(RemoveMilestoneTemplateParam), projectId, templateId, paramKey);

    public static void ClearMilestoneTemplateParams(string projectId, string templateId)
        => RW(nameof(ClearMilestoneTemplateParams), projectId, templateId);

    public static bool HasMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
        => (bool)RO(nameof(HasMilestoneBackerVote), projectId, manufacturer, stepNumber, backer);

    public static void SyncVotingDeadline(string projectId, string votingType, ulong deadline)
    {
        if (deadline > 0)
            SetVotingDeadline(projectId, votingType, deadline);
    }

    public static BigInteger GetInvestorToManufacturerReservation(string projectId, UInt160 investorAddress, UInt160 man)
    {
        return 0;
    }

    public static void SetInvestorToManufacturerReservation(string projectId, UInt160 investorAddress, UInt160 man, int v)
    {
    }
}






