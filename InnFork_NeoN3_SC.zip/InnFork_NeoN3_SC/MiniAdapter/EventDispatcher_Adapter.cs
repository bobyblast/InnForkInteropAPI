using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using System.Numerics;

namespace InnFork.NeoN3.Adapters
{
    /// <summary>
    /// ���������������� ������� ��� emit ������� ����� StorageLogic ��������.
    /// ���� ������� �� ������������� � manifest ���������� ����������,
    /// ������������ ������ ��� ����������� ������ ��� �������.
    /// </summary>
    public static class EventDispatcherAdapter
    {
        // ===== CONFIGURATION =====

        private static readonly byte[] StorageLogicHashKey = "if_storage_logic_hash".ToByteArray();

        /// <summary>
        /// �������� ����� StorageLogic ��������� �� ���������
        /// </summary>
        private static UInt160 GetStorageLogicContract()
        {
            UInt160 hash = (UInt160)Storage.Get(Storage.CurrentContext, StorageLogicHashKey);
            ExecutionEngine.Assert(hash != null && hash.IsValid && !hash.IsZero,
            "StorageLogic contract not configured");
            return hash;
        }

        /// <summary>
        /// ������������� ����� StorageLogic ��������� (������ ��� ���������)
        /// </summary>
        public static void SetStorageLogicContract(UInt160 storageLogicHash)
        {
            ExecutionEngine.Assert(storageLogicHash.IsValid && !storageLogicHash.IsZero,
                "Invalid StorageLogic address");
            Storage.Put(Storage.CurrentContext, StorageLogicHashKey, storageLogicHash);
        }

        // ===== INVESTMENT AGREEMENTS =====

        public static void EmitAgreementCreated(byte[] agreementId, UInt160 investor, UInt160 manufacturer, BigInteger amount)
     => Contract.Call(GetStorageLogicContract(), "EmitAgreementCreated", CallFlags.All, agreementId, investor, manufacturer, amount);

        public static void EmitAgreementConfirmed(byte[] agreementId)
         => Contract.Call(GetStorageLogicContract(), "EmitAgreementConfirmed", CallFlags.All, agreementId);

        public static void EmitAgreementCompleted(byte[] agreementId)
            => Contract.Call(GetStorageLogicContract(), "EmitAgreementCompleted", CallFlags.All, agreementId);

        public static void EmitAgreementDefaulted(byte[] agreementId)
         => Contract.Call(GetStorageLogicContract(), "EmitAgreementDefaulted", CallFlags.All, agreementId);

        public static void EmitRepaymentMade(byte[] agreementId, BigInteger amount)
            => Contract.Call(GetStorageLogicContract(), "EmitRepaymentMade", CallFlags.All, agreementId, amount);

        public static void EmitInvestmentPaymentMade(byte[] agreementId, BigInteger amount)
       => Contract.Call(GetStorageLogicContract(), "EmitInvestmentPaymentMade", CallFlags.All, agreementId, amount);

        // ===== VOTING SYSTEM =====

        public static void EmitProjectLaunchApproved(string projectId, bool approved)
       => Contract.Call(GetStorageLogicContract(), "EmitProjectLaunchApproved", CallFlags.All, projectId, approved);

        public static void EmitFundraisingCompletionApproved(string projectId, bool approved)
            => Contract.Call(GetStorageLogicContract(), "EmitFundraisingCompletionApproved", CallFlags.All, projectId, approved);

        public static void EmitProjectUpdatesApproved(string projectId, bool approved)
    => Contract.Call(GetStorageLogicContract(), "EmitProjectUpdatesApproved", CallFlags.All, projectId, approved);

        public static void EmitManufacturerWinnerSelectionApproved(string projectId, UInt160 manufacturerAddress, bool approved)
      => Contract.Call(GetStorageLogicContract(), "EmitManufacturerWinnerSelectionApproved", CallFlags.All, projectId, manufacturerAddress, approved);

        public static void EmitMilestoneCompletionApproved(string projectId, string milestoneId, bool approved)
            => Contract.Call(GetStorageLogicContract(), "EmitMilestoneCompletionApproved", CallFlags.All, projectId, milestoneId, approved);

        public static void EmitProjectPauseResumeVoted(string projectId, bool isPause, bool approved)
                    => Contract.Call(GetStorageLogicContract(), "EmitProjectPauseResumeVoted", CallFlags.All, projectId, isPause, approved);

        public static void EmitSuccessfulClosureApproved(string projectId, bool approved)
       => Contract.Call(GetStorageLogicContract(), "EmitSuccessfulClosureApproved", CallFlags.All, projectId, approved);

        public static void EmitTerminationWithRefundApproved(string projectId, bool approved)
     => Contract.Call(GetStorageLogicContract(), "EmitTerminationWithRefundApproved", CallFlags.All, projectId, approved);

        public static void EmitVoteAbstained(string projectId, string voteType, UInt160 voterAddress)
                    => Contract.Call(GetStorageLogicContract(), "EmitVoteAbstained", CallFlags.All, projectId, voteType, voterAddress);

        public static void EmitVoteCasted(string projectId, UInt160 voterAddress, int voteValue)
           => Contract.Call(GetStorageLogicContract(), "EmitVoteCasted", CallFlags.All, projectId, voterAddress, voteValue);

        public static void EmitVotingStarted(string projectId, string voteType)
               => Contract.Call(GetStorageLogicContract(), "EmitVotingStarted", CallFlags.All, projectId, voteType);

        public static void EmitVotingCompleted(string projectId, string voteType, BackerVotesEnum result)
    => Contract.Call(GetStorageLogicContract(), "EmitVotingCompleted", CallFlags.All, projectId, voteType, result);

        public static void EmitVotingFinalized(string projectId, int voteType)
 => Contract.Call(GetStorageLogicContract(), "EmitVotingFinalized", CallFlags.All, projectId, voteType);

        public static void EmitWinnerSelected(string projectId, string winnerId)
        => Contract.Call(GetStorageLogicContract(), "EmitWinnerSelected", CallFlags.All, projectId, winnerId);

        public static void EmitManufacturerSelected(string projectId, UInt160 manufacturerAddress)
   => Contract.Call(GetStorageLogicContract(), "EmitManufacturerSelected", CallFlags.All, projectId, manufacturerAddress);

        // ===== VOTE DELEGATION =====

        public static void EmitVoteDelegated(string projectId, string delegatorAddress, string delegateAddress, string votingType)
            => Contract.Call(GetStorageLogicContract(), "EmitVoteDelegated", CallFlags.All, projectId, delegatorAddress, delegateAddress, votingType);

        public static void EmitVoteDelegationRevoked(string projectId, string delegatorAddress, string delegateAddress, string votingType)
       => Contract.Call(GetStorageLogicContract(), "EmitVoteDelegationRevoked", CallFlags.All, projectId, delegatorAddress, delegateAddress, votingType);

        public static void EmitBulkDelegationRevoked(string projectId, string participantAddress, int revokedCount)
   => Contract.Call(GetStorageLogicContract(), "EmitBulkDelegationRevoked", CallFlags.All, projectId, participantAddress, revokedCount);

        public static void EmitDelegationIntegrityViolation(string projectId, string participantAddress, string violationType, string details)
            => Contract.Call(GetStorageLogicContract(), "EmitDelegationIntegrityViolation", CallFlags.All, projectId, participantAddress, violationType, details);

        // ===== MILESTONES =====

        public static void EmitMilestoneCompleted(string projectId, byte stepNumber, bool successful)
         => Contract.Call(GetStorageLogicContract(), "EmitMilestoneCompleted", CallFlags.All, projectId, stepNumber, successful);

        public static void EmitMilestoneFundingRolledBack(string projectId, UInt160 manufacturerAddress, byte stepNumber, string reason, BigInteger amount)
   => Contract.Call(GetStorageLogicContract(), "EmitMilestoneFundingRolledBack", CallFlags.All, projectId, manufacturerAddress, stepNumber, reason, amount);

        public static void EmitMilestoneResetForRestart(string projectId, UInt160 manufacturerAddress, byte stepNumber, string reason)
            => Contract.Call(GetStorageLogicContract(), "EmitMilestoneResetForRestart", CallFlags.All, projectId, manufacturerAddress, stepNumber, reason);

        // ===== DISPUTES =====

        public static void EmitDisputeCreated(string disputeId, UInt160 initiator, int disputeType, string description)
                  => Contract.Call(GetStorageLogicContract(), "EmitDisputeCreated", CallFlags.All, disputeId, initiator, disputeType, description);

        public static void EmitDisputeStatusChanged(string disputeId, int oldStatus, int newStatus)
       => Contract.Call(GetStorageLogicContract(), "EmitDisputeStatusChanged", CallFlags.All, disputeId, oldStatus, newStatus);

        public static void EmitDisputeStatusUpdated(string disputeId, int newStatus)
       => Contract.Call(GetStorageLogicContract(), "EmitDisputeStatusUpdated", CallFlags.All, disputeId, newStatus);

        // ===== BANS & PENALTIES =====

        public static void EmitManufacturerBanned(UInt160 manufacturerAddress, int banReason)
=> Contract.Call(GetStorageLogicContract(), "EmitManufacturerBanned", CallFlags.All, manufacturerAddress, banReason);

        public static void EmitBackerBanned(UInt160 backerAddress, int banReason)
       => Contract.Call(GetStorageLogicContract(), "EmitBackerBanned", CallFlags.All, backerAddress, banReason);

        public static void EmitManufacturerPenalized(UInt160 manufacturerAddress, BigInteger penaltyAmount)
                   => Contract.Call(GetStorageLogicContract(), "EmitManufacturerPenalized", CallFlags.All, manufacturerAddress, penaltyAmount);

        public static void EmitManufacturerPenaltyCleared(UInt160 manufacturerAddress, BigInteger clearedAmount)
       => Contract.Call(GetStorageLogicContract(), "EmitManufacturerPenaltyCleared", CallFlags.All, manufacturerAddress, clearedAmount);

        public static void EmitBackerFundsBlocked(UInt160 backerAddress, BigInteger blockedAmount, int blockReason)
              => Contract.Call(GetStorageLogicContract(), "EmitBackerFundsBlocked", CallFlags.All, backerAddress, blockedAmount, blockReason);

        public static void EmitBackerFundsUnblocked(UInt160 backerAddress, BigInteger unblockedAmount)
     => Contract.Call(GetStorageLogicContract(), "EmitBackerFundsUnblocked", CallFlags.All, backerAddress, unblockedAmount);

        // ===== SYSTEM =====

        public static void EmitProjectSaved(string projectId, UInt160 author)
  => Contract.Call(GetStorageLogicContract(), "EmitProjectSaved", CallFlags.All, projectId, author);

        public static void EmitEmergencyRefundExecuted(string projectId, BigInteger refundAmount)
              => Contract.Call(GetStorageLogicContract(), "EmitEmergencyRefundExecuted", CallFlags.All, projectId, refundAmount);
    }
}
