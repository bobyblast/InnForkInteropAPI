﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public interface IIF_MainGateway3
    {


        static abstract void AcquireLock();
        static abstract void addConditionalVotingRule(string projectId, string ruleId, BigInteger threshold);
        static abstract void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason);
        static abstract void autoSetToPause(string projectId);
        static abstract void banBacker(string projectId, UInt160 backerAddress, BanReason reason);
        static abstract void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock);
        static abstract BigInteger calculateTotalReservedForOffer(string offerId);
        static abstract BigInteger calculateVoteWeight(string projectId, UInt160 voterAddress, string voteId);
        static abstract bool checkConditionalVotingStatus(string projectId, string ruleId);
        static abstract string createBlockedFundsKey(UInt160 backerAddress, BanReason reason);
        static abstract string createDispute(string projectId, UInt160 initiator, DisputeType disputeType, string description, UInt160 manufacturerInvolved = null, byte milestoneStepInvolved = 0);
        static abstract void createMilestoneDispute(UInt160 initiatorAddress, string projectId, UInt160 manufacturerAddress, byte stepNumber, string disputeReason);
        static abstract void Destroy();
        static abstract void distributeTokenRewards(string projectId, UInt160 backerAddress, BigInteger tokenAmount);
        static abstract int getCountOfSelectedMapName(string MapName);
        static abstract int getCountOf_Sha256Offers();
        static abstract Dictionary<string, BigInteger> getMilestonePerformanceAnalytics(string projectId, UInt160 manufacturerAddress);
        static abstract UInt160 GetOwner();
        static abstract BigInteger getParticipationTrend(string projectId, ulong startTimestamp, ulong endTimestamp);
        static abstract Dictionary<string, BigInteger> getProjectAnalytics(string projectId);
        static abstract ProjectOfferPackage getProjectOfferPack(string projectOfferId);
        static abstract ProjectPackage getProjectPack(string projectId);
        static abstract ProjectPackage getProjectPackWNull(string projectId, bool AllowReturnNull);
        static abstract bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType);
        static abstract string[] getProjectStatuses(string projectId);
        static abstract BigInteger getRiskScoreForBanReason(BanReason reason);
        static abstract string[] getSerializedGlobalProjectsPackagesList();
        static abstract BigInteger getTotalReservedDonatesToOffer(string offerSha256Id);
        static abstract void ImportNewProjectSettings(string jsonSettings);
        static abstract bool IsOwner();
        static abstract bool isParticipantBanned(string projectId, UInt160 participantAddress);
        static abstract bool isProjectRegistered(string projectId);
        static abstract bool isValidStatusTransition(DisputeStatus current, DisputeStatus next);
        static abstract string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund);
        static abstract void ReleaseAcquireLock();
        static abstract void removeOffer(string offerSha256Id);
        static abstract void removeProjectFromGlobalProjectsLists(ProjectAccount Account);
        static abstract void removeProjectFromGlobalProjectsListsByProjectId(string projectId);
        static abstract bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id);
        static abstract void resolveDispute(string projectId, string disputeId, DisputeStatus newStatus, string resolutionNote);
        static abstract void resumeProject(string projectId);
        static abstract void saveProjectToProjectsAccountStore(ProjectPackage package);
        static abstract void saveToGlobalProjectsLists(ProjectAccount Account);
        static abstract void SetOwner(UInt160 newOwner);
        static abstract void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256);
        static abstract void setRewardTokenContract(string projectId, UInt160 tokenContractAddress);
        static abstract string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner);
        static abstract void Update(ByteString nefFile, string manifest, object data = null);
        static abstract void updateDailyParticipation(string projectId, ulong timestamp, BigInteger participantsCount);
        static abstract void updateProjectPackage(ProjectPackage package, byte[] projectId);
        static abstract bool validateProjectIsLiving(string projectId);
        static abstract void voteForTransferProjectManagementToInnFork(string projectId, UInt160 backer, bool votingFor);
        static abstract void voteFundraisingCompletion(string projectId, UInt160 backer, BackerVotesEnum vote);
        static abstract void voteIncreaseProjectBudget(string projectId, UInt160 backer, BackerVotesEnum vote);
        static abstract void votePauseResume(string projectId, UInt160 backer, BackerVotesEnum vote);
        static abstract void voteSuccessfulClosure(string projectId, UInt160 backer, BackerVotesEnum vote);
        static abstract void voteTerminationWithRefund(string projectId, UInt160 backer, BackerVotesEnum vote);
        static abstract void _deploy(object data, bool update);
    }
}