﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public interface IIF_MainGatewayinfra
    {

        static abstract void autoSetToPause(string projectId);
        static abstract BigInteger calculateTotalReservedForOffer(string offerId);
        static abstract void Destroy();
        static abstract int getCountOfSelectedMapName(string MapName);
        static abstract int getCountOf_Sha256Offers();
        static abstract UInt160 GetModeratorContractHash();
        static abstract UInt160 GetOwner();
        static abstract ProjectOfferPackage getProjectOfferPack(string projectOfferId);
        static abstract ProjectPackage getProjectPack(string projectId);
        static abstract ProjectPackage getProjectPackWNull(string projectId, bool AllowReturnNull);
        static abstract bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType);
        static abstract string[] getProjectStatuses(string projectId);
        static abstract string[] getSerializedGlobalProjectsPackagesList();
        static abstract UInt160 GetStateContractHash();
        static abstract BigInteger getTotalReservedDonatesToOffer(string offerSha256Id);
        static abstract void ImportNewProjectSettings(string jsonSettings);
        static abstract bool IsOwner();
        static abstract bool isProjectRegistered(string projectId);
        static abstract void OverrideModeratorContract(UInt160 newContract);
        static abstract void OverrideStateContract(UInt160 newHash);
        static abstract string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund);
        static abstract void ReleaseAcquireLock();
        static abstract void removeOffer(string offerSha256Id);
        static abstract void removeProjectFromGlobalProjectsLists(ProjectAccount Account);
        static abstract void removeProjectFromGlobalProjectsListsByProjectId(string projectId);
        static abstract bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id);
        static abstract void resumeProject(string projectId);
        static abstract void saveProjectAccountToProjectsAccountStore(string ProjectAddress, ProjectAccount project);
        static abstract void saveProjectToProjectsAccountStore(ProjectPackage package);
        static abstract void saveToGlobalProjectsLists(ProjectAccount Account);
        static abstract void SetModeratorContractHash(UInt160 newContract);
        static abstract void SetOwner(UInt160 newOwner);
        static abstract void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256);
        static abstract void SetStateContractHash(UInt160 newContract);
        static abstract string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner);
        static abstract void Update(ByteString nefFile, string manifest, object data = null);
        static abstract void updateProjectPackage(ProjectPackage package, byte[] projectId);
        static abstract bool validateProjectIsLiving(string projectId);
        static abstract void _deploy(object data, bool update);
    }
}