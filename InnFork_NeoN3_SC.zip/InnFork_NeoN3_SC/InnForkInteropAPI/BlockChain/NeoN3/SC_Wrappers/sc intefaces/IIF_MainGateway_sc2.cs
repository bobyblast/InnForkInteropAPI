﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public interface IIF_MainGateway2
    {

        static abstract void AcquireLock();
        static abstract bool analyzeAccountConnections(string projectId, UInt160 voterAddress);
        static abstract bool analyzeVotingFrequency(string projectId, UInt160 voterAddress, ulong currentVoteTime);
        static abstract void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason);
        static abstract void applyFraudPenalties(string projectId, UInt160 voterAddress);
        static abstract void applyGradedFraudPenalties(string projectId, UInt160 voterAddress, FraudType fraudType);
        static abstract void autoSetToPause(string projectId);
        static abstract void banBacker(string projectId, UInt160 backerAddress, BanReason reason);
        static abstract void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock);
        static abstract BigInteger calculateTotalReservedForOffer(string offerId);
        static abstract bool checkIdenticalVotingPatterns(string projectId, UInt160 voterAddress);
        static abstract void Destroy();
        static abstract bool detectBalanceManipulationFraud(string projectId, UInt160 voterAddress);
        static abstract bool detectCircularTransactions(string projectId, UInt160 voterAddress, BackerAccount backerAccount);
        static abstract bool detectCollusionPattern(string projectId, UInt160 voterAddress);
        static abstract bool detectRapidVotingPattern(string projectId, UInt160 voterAddress);
        static abstract bool detectSybilAttack(string projectId, UInt160 voterAddress);
        static abstract bool detectTemporalVotingAnomalies(string projectId, UInt160 voterAddress);
        static abstract bool detectUniformVotingIntervals(string projectId, UInt160 voterAddress);
        static abstract bool detectVoteSwitchingFraud(string projectId, UInt160 voterAddress, string votingType);
        static abstract bool detectVotingFraud(UInt160 voterAddress, string projectId, string votingType);
        static abstract void distributeConsentedFunds(string projectId, UInt160 manufacturer);
        static abstract void distributeManufacturerProfit(string projectId, UInt160 manufacturerAddress, BigInteger profitAmount);
        static abstract bool getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer);
        static abstract BigInteger getBackerPrizeFundDonation(string projectId, UInt160 backer);
        static abstract BigInteger getBackerReservedAmountForManufacturer(string projectId, UInt160 backer, UInt160 manufacturerCandidate);
        static abstract int getCountOfSelectedMapName(string MapName);
        static abstract int getCountOf_Sha256Offers();
        static abstract UInt160 GetOwner();
        static abstract ProjectOfferPackage getProjectOfferPack(string projectOfferId);
        static abstract ProjectPackage getProjectPack(string projectId);
        static abstract ProjectPackage getProjectPackWNull(string projectId, bool AllowReturnNull);
        static abstract bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType);
        static abstract string[] getProjectStatuses(string projectId);
        static abstract BigInteger getRiskScoreForBanReason(BanReason reason);
        static abstract string[] getSerializedGlobalProjectsPackagesList();
        static abstract BigInteger getTotalReservedDonatesToOffer(string offerSha256Id);
        static abstract void ImportNewProjectSettings(string jsonSettings);
        static abstract bool isBackerDonatedToPrizeFund(string projectId, UInt160 backer);
        static abstract bool IsOwner();
        static abstract bool isParticipantBanned(string projectId, UInt160 participantAddress);
        static abstract bool isProjectOpen(string projectId);
        static abstract bool isProjectRegistered(string projectId);
        static abstract void moneyBackFromProjectToBackerAccount(string projectId, UInt160 backerAddress, BigInteger amount);
        static abstract void processBackerPrizeFundDonation(string projectId, UInt160 backerAddress, BigInteger amount);
        static abstract void proposeProfitShare(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger profitSharePercentage);
        static abstract string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund);
        static abstract void ReleaseAcquireLock();
        static abstract void removeOffer(string offerSha256Id);
        static abstract void removeProjectFromGlobalProjectsLists(ProjectAccount Account);
        static abstract void removeProjectFromGlobalProjectsListsByProjectId(string projectId);
        static abstract bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id);
        static abstract void resumeProject(string projectId);
        static abstract void saveProjectToProjectsAccountStore(ProjectPackage package);
        static abstract void saveToGlobalProjectsLists(ProjectAccount Account);
        static abstract void setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer, bool consent);
        static abstract void setManufacturerMinInvestment(string projectId, UInt160 manufacturerId, BigInteger amount);
        static abstract void SetOwner(UInt160 newOwner);
        static abstract void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256);
        static abstract string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner);
        static abstract void Update(ByteString nefFile, string manifest, object data = null);
        static abstract void updateProjectPackage(ProjectPackage package, byte[] projectId);
        static abstract bool validateProjectIsLiving(string projectId);
        static abstract bool validateVotingIntegrity(string projectId);
        static abstract void _deploy(object data, bool update);
    }
}