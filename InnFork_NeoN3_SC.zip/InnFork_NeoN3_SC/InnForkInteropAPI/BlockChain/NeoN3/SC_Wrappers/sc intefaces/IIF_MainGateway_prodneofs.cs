﻿using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Native;
using System.Numerics;

namespace InnFork.NeoN3
{
    public interface IIF_MainGatewayprod
    {

        static abstract BigInteger CalculateFinallyProductPrice(UInt160 productId, UInt160 addonId, BigInteger Quantity);
        static abstract void cancelOrder(UInt160 orderId, UInt160 customerAddress);
        static abstract void confirmOrder(UInt160 orderId, UInt160 manufacturerAddress, UInt160 paymentTokenHash);
        static abstract void convertToFLMStableCoin();
        static abstract void createManufacturerAccount(UInt160 manufacturerAddress, string name, byte[] publicKey);
        static abstract void createOrder(UInt160 orderId, UInt160 productId, UInt160 customerId, BigInteger quantity, UInt160 customerAddress);
        static abstract void depositCustomerFunds(UInt160 customerAddress, UInt160 token, BigInteger amount);
        static abstract void doRequest();
        static abstract ManufacturerAccount getManufacturerAccount(UInt160 manufacturerAddress);
        static abstract Dictionary<string, BigInteger> getManufacturerSalesAnalytics(UInt160 manufacturerAddress);
        static abstract Order getOrder(UInt160 orderId);
        static abstract ProductSalesStats getProductStatistics(UInt160 productId);
        static abstract string GetResponse();
        static abstract BigInteger getSwapRate(UInt160 fromToken, UInt160 toToken);
        static abstract BigInteger getTotalBackerRewards(string projectId, UInt160 backerAddress);
        static abstract void onOracleFlamingoPriceResponse(string requestedUrl, object userData, OracleResponseCode oracleResponse, string jsonString);
        static abstract void OracleCallback(ByteString userKey, ByteString result);
        static abstract UInt160 owner();
        static abstract UInt160 purchaseProduct(UInt160 productId, UInt160 customerAddress, BigInteger quantity, UInt160 paymentToken);
        static abstract ByteString Query(string key);
        static abstract void registerCustomer(UInt160 customerAddress);
        static abstract UInt160 registerProduct(UInt160 manufacturerAddress, string projectId, string name, string description, string neoFSContainerId, string neoFSObjectId, BigInteger price, UInt160 priceToken, BigInteger quantity);
        static abstract void RequestObject(string containerId, string objectId, string userKey);
        static abstract void setProductDiscount(UInt160 productId, bool isActive, BigInteger discountPercent);
        static abstract void setSwapRate(UInt160 fromToken, UInt160 toToken, BigInteger rate);
        static abstract BigInteger swapTokenToFUSD(UInt160 userAddress, UInt160 fromToken, BigInteger amount);
        static abstract void updateProductStock(UInt160 productId, BigInteger newQuantity);
    }
}