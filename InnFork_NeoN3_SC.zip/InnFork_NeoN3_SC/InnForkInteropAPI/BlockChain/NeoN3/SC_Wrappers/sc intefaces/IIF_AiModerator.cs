﻿using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Native;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public interface IIF_AiModerator
    {
        static abstract event Action<string, string, bool, BigInteger> OnModerationCompleted;
        static abstract event Action<string, string, string> OnModerationError;
        static abstract event Action<string, string, ulong> OnModerationRequested;
        static abstract event Action<UInt160, UInt160> OnOwnerChanged;
        static abstract event Action<bool> OnPaused;

        static abstract void ConfigureOracle(string url, string jsonPath);
        static abstract BigInteger GetConfidenceScore(string requestId);
        static abstract Map<string, BigInteger> GetEnhancedModerationStats(string requestId, string projectId);
        static abstract string[] GetModerationHistory(UInt160 address);
        static abstract object[] GetModerationHistoryWithContext(UInt160 address, string projectId);
        static abstract ModerationResult GetModerationResult(string requestId);
        static abstract Map<string, BigInteger> GetModerationStats(string requestId);
        static abstract bool HasViolationFlag(string requestId, ViolationFlag flag);
        static abstract void Initialize(UInt160 owner);
        static abstract bool IsModerationApproved(string requestId);
        static abstract void ManuallyApplySanctions(string requestId, string projectId, UInt160 admin);
        static abstract string ModerateDisputeEvidence(string projectId, string disputeId, string evidenceJson, UInt160 requester, bool autoEnforce = true);
        static abstract string ModerateManufacturerProfile(string projectId, UInt160 manufacturerAddress, string profileJson, UInt160 requester, bool autoEnforce = true);
        static abstract string ModerateProductDescription(string productId, string productJson, UInt160 requester, bool autoEnforce = false);
        static abstract string ModerateProjectDescription(string projectId, string descriptionJson, UInt160 requester, bool autoEnforce = false);
        static abstract string ModerateProjectOffer(string offerId, string offerJson, UInt160 requester, bool autoEnforce = false);
        static abstract string ModerateProjectUpdate(string projectId, string updateId, string updateJson, UInt160 requester, bool autoEnforce = false);
        static abstract string ModerateRefundRequest(string projectId, string refundId, string refundJson, UInt160 requester, bool autoEnforce = true);
        static abstract string ModerateUserComment(string projectId, string commentId, string commentJson, UInt160 author, bool autoEnforce = false);
        static abstract void OnOracleModerationResponse(string requestedUrl, object userData, OracleResponseCode code, string jsonResponse);
        static abstract void RehabilitateParticipant(string projectId, UInt160 participant, UInt160 admin);
        static abstract void SetMainGatewayContract(UInt160 newAddress);
        static abstract void SetPaused(bool paused);
        static abstract void SetStateStorageContract(UInt160 newAddress);
        static abstract void TransferOwnership(UInt160 newOwner);
    }
}