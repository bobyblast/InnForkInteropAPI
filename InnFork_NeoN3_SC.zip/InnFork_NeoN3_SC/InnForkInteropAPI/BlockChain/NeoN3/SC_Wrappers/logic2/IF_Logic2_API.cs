﻿using InnFork.NeoN3;

using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using Neo;
using Neo.SmartContract;

using InnFork.NeoN3.Enums;
using Neo.VM.Types;
using System.Threading.Tasks;


namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{

    public partial class IFPlatform
    {
        public partial class SCPlatform_Logic2
        {

            public static UInt160 Address = UInt160.Parse("0xb3ac61163fdd41871f2c6abbb33b007fbf6b2d61");
            public static bool TestNet = true;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; } = "";




            public static bool analyzeAccountConnections(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(analyzeAccountConnections),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> analyzeAccountConnectionsAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(analyzeAccountConnections), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool analyzeVotingFrequency(string projectId, UInt160 voterAddress, ulong currentVoteTime)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(analyzeVotingFrequency),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress, currentVoteTime));
            }
            public static Task<bool> analyzeVotingFrequencyAsync(string projectId, UInt160 voterAddress, ulong currentVoteTime)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(analyzeVotingFrequency), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress, currentVoteTime));


            public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(applyBackerBanSanctions),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, reason));
            }
            public static Task applyBackerBanSanctionsAsync(string projectId, UInt160 backerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(applyBackerBanSanctions), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, reason));


            public static void applyFraudPenalties(string projectId, UInt160 voterAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(applyFraudPenalties),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voterAddress));
            }
            public static Task applyFraudPenaltiesAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(applyFraudPenalties), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static void applyGradedFraudPenalties(string projectId, UInt160 voterAddress, FraudType fraudType)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(applyGradedFraudPenalties),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voterAddress, fraudType));
            }
            public static Task applyGradedFraudPenaltiesAsync(string projectId, UInt160 voterAddress, FraudType fraudType)
 => ExecuteContractWithoutResultAsync(Address, nameof(applyGradedFraudPenalties), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress, fraudType));


            public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(banBacker),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, reason));
            }
            public static Task banBackerAsync(string projectId, UInt160 backerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(banBacker), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, reason));


            public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(blockBackerFinance),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, banReason, amountToBlock));
            }
            public static Task blockBackerFinanceAsync(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
 => ExecuteContractWithoutResultAsync(Address, nameof(blockBackerFinance), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, banReason, amountToBlock));


            public static bool checkIdenticalVotingPatterns(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(checkIdenticalVotingPatterns),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> checkIdenticalVotingPatternsAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(checkIdenticalVotingPatterns), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool detectBalanceManipulationFraud(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectBalanceManipulationFraud),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> detectBalanceManipulationFraudAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectBalanceManipulationFraud), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool detectCircularTransactions(string projectId, UInt160 voterAddress, BackerAccount backerAccount)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectCircularTransactions),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress, backerAccount));
            }
            public static Task<bool> detectCircularTransactionsAsync(string projectId, UInt160 voterAddress, BackerAccount backerAccount)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectCircularTransactions), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress, backerAccount));


            public static bool detectCollusionPattern(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectCollusionPattern),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> detectCollusionPatternAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectCollusionPattern), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool detectRapidVotingPattern(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectRapidVotingPattern),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> detectRapidVotingPatternAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectRapidVotingPattern), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool detectSybilAttack(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectSybilAttack),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> detectSybilAttackAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectSybilAttack), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool detectTemporalVotingAnomalies(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectTemporalVotingAnomalies),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> detectTemporalVotingAnomaliesAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectTemporalVotingAnomalies), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool detectUniformVotingIntervals(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectUniformVotingIntervals),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }
            public static Task<bool> detectUniformVotingIntervalsAsync(string projectId, UInt160 voterAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectUniformVotingIntervals), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress));


            public static bool detectVoteSwitchingFraud(string projectId, UInt160 voterAddress, string votingType)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectVoteSwitchingFraud),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress, votingType));
            }
            public static Task<bool> detectVoteSwitchingFraudAsync(string projectId, UInt160 voterAddress, string votingType)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectVoteSwitchingFraud), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress, votingType));


            public static bool detectVotingFraud(UInt160 voterAddress, string projectId, string votingType)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectVotingFraud),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(voterAddress, projectId, votingType));
            }
            public static Task<bool> detectVotingFraudAsync(UInt160 voterAddress, string projectId, string votingType)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(detectVotingFraud), TestNet, TestInvoke, DefaultUserWif, BuildParameters(voterAddress, projectId, votingType));


            public static void distributeConsentedFunds(string projectId, UInt160 manufacturer)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(distributeConsentedFunds),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturer));
            }
            public static Task distributeConsentedFundsAsync(string projectId, UInt160 manufacturer)
 => ExecuteContractWithoutResultAsync(Address, nameof(distributeConsentedFunds), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer));


            public static void distributeManufacturerProfit(string projectId, UInt160 manufacturerAddress, BigInteger profitAmount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(distributeManufacturerProfit),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturerAddress, profitAmount));
            }
            public static Task distributeManufacturerProfitAsync(string projectId, UInt160 manufacturerAddress, BigInteger profitAmount)
 => ExecuteContractWithoutResultAsync(Address, nameof(distributeManufacturerProfit), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, profitAmount));


            public static bool getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }
            public static Task<bool> getBackerAutoConsent_ToUsePrizeFundToMilestoneFundingAsync(string projectId, UInt160 backer)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer));


            public static BigInteger getBackerPrizeFundDonation(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getBackerPrizeFundDonation),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }
            public static Task<BigInteger> getBackerPrizeFundDonationAsync(string projectId, UInt160 backer)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getBackerPrizeFundDonation), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer));


            public static BigInteger getBackerReservedAmountForManufacturer(string projectId, UInt160 backer, UInt160 manufacturerCandidate)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getBackerReservedAmountForManufacturer),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer, manufacturerCandidate));
            }
            public static Task<BigInteger> getBackerReservedAmountForManufacturerAsync(string projectId, UInt160 backer, UInt160 manufacturerCandidate)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getBackerReservedAmountForManufacturer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, manufacturerCandidate));



            public static ProjectAccount getProjectAccount(string projectId)
            {
                return ExecuteContractWithResult<ProjectAccount>(Address,
                                                         nameof(getProjectAccount),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId)) ?? new ProjectAccount();
            }
            public static async Task<ProjectAccount> getProjectAccountAsync(string projectId)
 => await ExecuteContractWithResultAsync<ProjectAccount>(Address, nameof(getProjectAccount), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId)) ?? new ProjectAccount();


            public static BigInteger getRiskScoreForBanReason(BanReason reason)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getRiskScoreForBanReason),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(reason));
            }
            public static Task<BigInteger> getRiskScoreForBanReasonAsync(BanReason reason)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getRiskScoreForBanReason), TestNet, TestInvoke, DefaultUserWif, BuildParameters(reason));


            public static bool isBackerDonatedToPrizeFund(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isBackerDonatedToPrizeFund),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }
            public static Task<bool> isBackerDonatedToPrizeFundAsync(string projectId, UInt160 backer)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isBackerDonatedToPrizeFund), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer));


            public static bool isParticipantBanned(string projectId, UInt160 participantAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isParticipantBanned),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, participantAddress));
            }
            public static Task<bool> isParticipantBannedAsync(string projectId, UInt160 participantAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isParticipantBanned), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, participantAddress));


            public static bool isProjectOpen(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isProjectOpen),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }
            public static Task<bool> isProjectOpenAsync(string projectId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isProjectOpen), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static void moneyBackFromProjectToBackerAccount(string projectId, UInt160 backerAddress, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(moneyBackFromProjectToBackerAccount),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, amount));
            }
            public static Task moneyBackFromProjectToBackerAccountAsync(string projectId, UInt160 backerAddress, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(moneyBackFromProjectToBackerAccount), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, amount));


            public static void processBackerPrizeFundDonation(string projectId, UInt160 backerAddress, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(processBackerPrizeFundDonation),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, amount));
            }
            public static Task processBackerPrizeFundDonationAsync(string projectId, UInt160 backerAddress, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(processBackerPrizeFundDonation), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, amount));


            public static void proposeProfitShare(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger profitSharePercentage)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(proposeProfitShare),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, investorAddress, manufacturerAddress, profitSharePercentage));
            }
            public static Task proposeProfitShareAsync(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger profitSharePercentage)
 => ExecuteContractWithoutResultAsync(Address, nameof(proposeProfitShare), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, investorAddress, manufacturerAddress, profitSharePercentage));



            public static void setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer, bool consent)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, consent));
            }
            public static Task setBackerAutoConsent_ToUsePrizeFundToMilestoneFundingAsync(string projectId, UInt160 backer, bool consent)
 => ExecuteContractWithoutResultAsync(Address, nameof(setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, consent));


            public static void setManufacturerMinInvestment(string projectId, UInt160 manufacturerId, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setManufacturerMinInvestment),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturerId, amount));
            }
            public static Task setManufacturerMinInvestmentAsync(string projectId, UInt160 manufacturerId, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(setManufacturerMinInvestment), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerId, amount));


            public static bool validateVotingIntegrity(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(validateVotingIntegrity),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }
            public static Task<bool> validateVotingIntegrityAsync(string projectId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(validateVotingIntegrity), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));




























            public static void autoSetToPause(string projectId)
            {
                throw new NotImplementedException();
            }
            public static Task autoSetToPauseAsync(string projectId)
 => throw new NotImplementedException();

            public static BigInteger calculateTotalReservedForOffer(string offerId)
            {
                throw new NotImplementedException();
            }
            public static Task<BigInteger> calculateTotalReservedForOfferAsync(string offerId)
 => throw new NotImplementedException();


            public static bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType)
            {
                throw new NotImplementedException();
            }
            public static Task<bool> getProjectStatusAsBooleanAsync(string ProjectId, ProjectStateRequest statusType)
 => throw new NotImplementedException();

            public static string[] getProjectStatuses(string projectId)
            {
                throw new NotImplementedException();
            }
            public static Task<string[]> getProjectStatusesAsync(string projectId)
 => throw new NotImplementedException();

            public static string[] getSerializedGlobalProjectsPackagesList()
            {
                throw new NotImplementedException();
            }
            public static Task<string[]> getSerializedGlobalProjectsPackagesListAsync()
 => throw new NotImplementedException();

            public static BigInteger getTotalReservedDonatesToOffer(string offerSha256Id)
            {
                throw new NotImplementedException();
            }
            public static Task<BigInteger> getTotalReservedDonatesToOfferAsync(string offerSha256Id)
 => throw new NotImplementedException();

            public static void ImportNewProjectSettings(string jsonSettings)
            {
                throw new NotImplementedException();
            }
            public static Task ImportNewProjectSettingsAsync(string jsonSettings)
 => throw new NotImplementedException();


            public static bool isProjectRegistered(string projectId)
            {
                throw new NotImplementedException();
            }
            public static Task<bool> isProjectRegisteredAsync(string projectId)
 => throw new NotImplementedException();

            public static string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
            {
                throw new NotImplementedException();
            }
            public static Task<string> registerProjectExAsync(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
 => throw new NotImplementedException();


            public static bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id)
            {
                throw new NotImplementedException();
            }
            public static Task<bool> removeProjectOfferByTimeLineAsync(UInt160 projectCreatorAddress, string offerSha256Id)
 => throw new NotImplementedException();

            public static void resumeProject(string projectId)
            {
                throw new NotImplementedException();
            }
            public static Task resumeProjectAsync(string projectId)
 => throw new NotImplementedException();



            public static bool validateProjectIsLiving(string projectId)
            {
                throw new NotImplementedException();
            }
            public static Task<bool> validateProjectIsLivingAsync(string projectId)
 => throw new NotImplementedException();



        }
    }
}