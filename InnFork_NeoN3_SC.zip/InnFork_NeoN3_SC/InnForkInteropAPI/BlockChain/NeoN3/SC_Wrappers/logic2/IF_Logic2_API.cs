﻿using InnFork.NeoN3;

using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using Neo;
using Neo.SmartContract;

using InnFork.NeoN3.Enums;
using Neo.VM.Types;


namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{

    public partial class IFPlatform
    {
        public partial class SCPlatform_Logic2_new
        {
            public static UInt160 Address = "";
            public static bool testnet = false;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; }

            public static void AcquireLock()
            {
                throw new NotImplementedException();
            }

            public static bool analyzeAccountConnections(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static bool analyzeVotingFrequency(string projectId, UInt160 voterAddress, ulong currentVoteTime)
            {
                throw new NotImplementedException();
            }

            public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
            {
                throw new NotImplementedException();
            }

            public static void applyFraudPenalties(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static void applyGradedFraudPenalties(string projectId, UInt160 voterAddress, FraudType fraudType)
            {
                throw new NotImplementedException();
            }

            public static void autoSetToPause(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
            {
                throw new NotImplementedException();
            }

            public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
            {
                throw new NotImplementedException();
            }

            public static BigInteger calculateTotalReservedForOffer(string offerId)
            {
                throw new NotImplementedException();
            }

            public static bool checkIdenticalVotingPatterns(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static void Destroy()
            {
                throw new NotImplementedException();
            }

            public static bool detectBalanceManipulationFraud(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static bool detectCircularTransactions(string projectId, UInt160 voterAddress, BackerAccount backerAccount)
            {
                throw new NotImplementedException();
            }

            public static bool detectCollusionPattern(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static bool detectRapidVotingPattern(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static bool detectSybilAttack(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static bool detectTemporalVotingAnomalies(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static bool detectUniformVotingIntervals(string projectId, UInt160 voterAddress)
            {
                throw new NotImplementedException();
            }

            public static bool detectVoteSwitchingFraud(string projectId, UInt160 voterAddress, string votingType)
            {
                throw new NotImplementedException();
            }

            public static bool detectVotingFraud(UInt160 voterAddress, string projectId, string votingType)
            {
                throw new NotImplementedException();
            }

            public static void distributeConsentedFunds(string projectId, UInt160 manufacturer)
            {
                throw new NotImplementedException();
            }

            public static void distributeManufacturerProfit(string projectId, UInt160 manufacturerAddress, BigInteger profitAmount)
            {
                throw new NotImplementedException();
            }

            public static bool getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer)
            {
                throw new NotImplementedException();
            }

            public static BigInteger getBackerPrizeFundDonation(string projectId, UInt160 backer)
            {
                throw new NotImplementedException();
            }

            public static BigInteger getBackerReservedAmountForManufacturer(string projectId, UInt160 backer, UInt160 manufacturerCandidate)
            {
                throw new NotImplementedException();
            }

            public static int getCountOfSelectedMapName(string MapName)
            {
                throw new NotImplementedException();
            }

            public static int getCountOf_Sha256Offers()
            {
                throw new NotImplementedException();
            }

            public static UInt160 GetOwner()
            {
                throw new NotImplementedException();
            }

            public static ProjectOfferPackage getProjectOfferPack(string projectOfferId)
            {
                throw new NotImplementedException();
            }

            public static ProjectPackage getProjectPack(string projectId)
            {
                throw new NotImplementedException();
            }

            public static ProjectPackage getProjectPackWNull(string projectId, bool AllowReturnNull)
            {
                throw new NotImplementedException();
            }

            public static bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType)
            {
                throw new NotImplementedException();
            }

            public static string[] getProjectStatuses(string projectId)
            {
                throw new NotImplementedException();
            }

            public static BigInteger getRiskScoreForBanReason(BanReason reason)
            {
                throw new NotImplementedException();
            }

            public static string[] getSerializedGlobalProjectsPackagesList()
            {
                throw new NotImplementedException();
            }

            public static BigInteger getTotalReservedDonatesToOffer(string offerSha256Id)
            {
                throw new NotImplementedException();
            }

            public static void ImportNewProjectSettings(string jsonSettings)
            {
                throw new NotImplementedException();
            }

            public static bool isBackerDonatedToPrizeFund(string projectId, UInt160 backer)
            {
                throw new NotImplementedException();
            }

            public static bool IsOwner()
            {
                throw new NotImplementedException();
            }

            public static bool isParticipantBanned(string projectId, UInt160 participantAddress)
            {
                throw new NotImplementedException();
            }

            public static bool isProjectOpen(string projectId)
            {
                throw new NotImplementedException();
            }

            public static bool isProjectRegistered(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void moneyBackFromProjectToBackerAccount(string projectId, UInt160 backerAddress, BigInteger amount)
            {
                throw new NotImplementedException();
            }

            public static void processBackerPrizeFundDonation(string projectId, UInt160 backerAddress, BigInteger amount)
            {
                throw new NotImplementedException();
            }

            public static void proposeProfitShare(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger profitSharePercentage)
            {
                throw new NotImplementedException();
            }

            public static string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
            {
                throw new NotImplementedException();
            }

            public static void ReleaseAcquireLock()
            {
                throw new NotImplementedException();
            }

            public static void removeOffer(string offerSha256Id)
            {
                throw new NotImplementedException();
            }

            public static void removeProjectFromGlobalProjectsLists(ProjectAccount Account)
            {
                throw new NotImplementedException();
            }

            public static void removeProjectFromGlobalProjectsListsByProjectId(string projectId)
            {
                throw new NotImplementedException();
            }

            public static bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id)
            {
                throw new NotImplementedException();
            }

            public static void resumeProject(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void saveProjectToProjectsAccountStore(ProjectPackage package)
            {
                throw new NotImplementedException();
            }

            public static void saveToGlobalProjectsLists(ProjectAccount Account)
            {
                throw new NotImplementedException();
            }

            public static void setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer, bool consent)
            {
                throw new NotImplementedException();
            }

            public static void setManufacturerMinInvestment(string projectId, UInt160 manufacturerId, BigInteger amount)
            {
                throw new NotImplementedException();
            }

            public static void SetOwner(UInt160 newOwner)
            {
                throw new NotImplementedException();
            }

            public static void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256)
            {
                throw new NotImplementedException();
            }

            public static string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner)
            {
                throw new NotImplementedException();
            }

            public static void Update(ByteString nefFile, string manifest, object data = null)
            {
                throw new NotImplementedException();
            }

            public static void updateProjectPackage(ProjectPackage package, byte[] projectId)
            {
                throw new NotImplementedException();
            }

            public static bool validateProjectIsLiving(string projectId)
            {
                throw new NotImplementedException();
            }

            public static bool validateVotingIntegrity(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void _deploy(object data, bool update)
            {
                throw new NotImplementedException();
            }
        }


        public partial class SCPlatform_Logic2
        {
            public static UInt160 Address = "";
            public static bool testnet = false;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; }

            public static bool analyzeAccountConnections(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(analyzeAccountConnections),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool analyzeVotingFrequency(string projectId, UInt160 voterAddress, ulong currentVoteTime)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(analyzeVotingFrequency),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress, currentVoteTime));
            }


            public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(applyBackerBanSanctions),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, reason));
            }


            public static void applyFraudPenalties(string projectId, UInt160 voterAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(applyFraudPenalties),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voterAddress));
            }


            public static void applyGradedFraudPenalties(string projectId, UInt160 voterAddress, FraudType fraudType)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(applyGradedFraudPenalties),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voterAddress, fraudType));
            }


            public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(banBacker),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, reason));
            }


            public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(blockBackerFinance),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, banReason, amountToBlock));
            }


            public static bool checkIdenticalVotingPatterns(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(checkIdenticalVotingPatterns),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool detectBalanceManipulationFraud(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectBalanceManipulationFraud),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool detectCircularTransactions(string projectId, UInt160 voterAddress, BackerAccount backerAccount)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectCircularTransactions),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress, backerAccount));
            }


            public static bool detectCollusionPattern(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectCollusionPattern),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool detectRapidVotingPattern(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectRapidVotingPattern),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool detectSybilAttack(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectSybilAttack),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool detectTemporalVotingAnomalies(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectTemporalVotingAnomalies),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool detectUniformVotingIntervals(string projectId, UInt160 voterAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectUniformVotingIntervals),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress));
            }


            public static bool detectVoteSwitchingFraud(string projectId, UInt160 voterAddress, string votingType)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectVoteSwitchingFraud),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress, votingType));
            }


            public static bool detectVotingFraud(UInt160 voterAddress, string projectId, string votingType)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(detectVotingFraud),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(voterAddress, projectId, votingType));
            }


            public static void distributeConsentedFunds(string projectId, UInt160 manufacturer)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(distributeConsentedFunds),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturer));
            }


            public static void distributeManufacturerProfit(string projectId, UInt160 manufacturerAddress, BigInteger profitAmount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(distributeManufacturerProfit),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturerAddress, profitAmount));
            }


            public static bool getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }


            public static BigInteger getBackerPrizeFundDonation(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getBackerPrizeFundDonation),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }


            public static BigInteger getBackerReservedAmountForManufacturer(string projectId, UInt160 backer, UInt160 manufacturerCandidate)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getBackerReservedAmountForManufacturer),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer, manufacturerCandidate));
            }



            public static ProjectAccount getProjectAccount(string projectId)
            {
                return ExecuteContractWithResult<ProjectAccount>(Address,
                                                         nameof(getProjectAccount),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId)) ?? new ProjectAccount();
            }


            public static BigInteger getRiskScoreForBanReason(BanReason reason)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getRiskScoreForBanReason),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(reason));
            }


            public static bool isBackerDonatedToPrizeFund(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isBackerDonatedToPrizeFund),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }


            public static bool isParticipantBanned(string projectId, UInt160 participantAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isParticipantBanned),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, participantAddress));
            }


            public static bool isProjectOpen(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isProjectOpen),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }


            public static void moneyBackFromProjectToBackerAccount(string projectId, UInt160 backerAddress, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(moneyBackFromProjectToBackerAccount),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, amount));
            }


            public static void processBackerPrizeFundDonation(string projectId, UInt160 backerAddress, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(processBackerPrizeFundDonation),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, amount));
            }


            public static void proposeProfitShare(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger profitSharePercentage)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(proposeProfitShare),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, investorAddress, manufacturerAddress, profitSharePercentage));
            }


            public static void saveProjectAccountToProjectsAccountStore(string projectId, ProjectAccount project)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(saveProjectAccountToProjectsAccountStore),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, project));
            }


            public static void setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer, bool consent)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, consent));
            }


            public static void setManufacturerMinInvestment(string projectId, UInt160 manufacturerId, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setManufacturerMinInvestment),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturerId, amount));
            }


            public static void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setProjectOfferShortJsonToExistingProject),
                                                 testnet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(offerShortJson, ProjectOfferId_Sha256, projectIdSha256));
            }



            public static bool validateVotingIntegrity(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(validateVotingIntegrity),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }

        }
    }
}