﻿using InnFork.NeoN3;

using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using Neo;
using Neo.SmartContract;
using InnFork.NeoN3.Enums;
using Neo.VM.Types;


namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{
















    public partial class IFPlatform
    {



        public partial class SCPlatform_Logic4_new
        {
            public static UInt160 Address = "";
            public static bool TestNet = false;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; }

            public static void AcquireLock()
            {
                throw new NotImplementedException();
            }

            public static void allocateFunds(string projectId, UInt160 backer, byte prizeFundPartAllocation)
            {
                throw new NotImplementedException();
            }

            public static void archiveProject(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void autoSetToPause(string projectId)
            {
                throw new NotImplementedException();
            }

            public static byte calculateReliabilityTier(string projectId, UInt160 manufacturer)
            {
                throw new NotImplementedException();
            }

            public static BigInteger calculateTotalReservedForOffer(string offerId)
            {
                throw new NotImplementedException();
            }

            public static void calculateWinners(UInt160 FromAddress)
            {
                throw new NotImplementedException();
            }

            public static bool canSelectWinner(string projectId)
            {
                throw new NotImplementedException();
            }

            public static bool canWithdrawFromProject(string projectId, UInt160 backer)
            {
                throw new NotImplementedException();
            }

            public static void ClearMilestoneFraudFlags(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public static void ClearMilestoneTemplateParams(string projectId, string templateId)
            {
                throw new NotImplementedException();
            }

            public static void ClearMilestoneVotes(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public static void collectFeeForProjectAuthor(string projectId, UInt160 ProjectCreatorAddressParam)
            {
                throw new NotImplementedException();
            }

            public static void configureVotingSystem(string projectId, BigInteger minRequiredParticipationPercent, BigInteger minApprovalPercent)
            {
                throw new NotImplementedException();
            }

            public static void Destroy()
            {
                throw new NotImplementedException();
            }

            public static void distributeReferralReward(string projectId, UInt160 referrerAddress, BigInteger amount)
            {
                throw new NotImplementedException();
            }

            public static void finalizeWinnerSelectionVoting(string projectId)
            {
                throw new NotImplementedException();
            }

            public static int getCountOfSelectedMapName(string MapName)
            {
                throw new NotImplementedException();
            }

            public static int getCountOf_Sha256Offers()
            {
                throw new NotImplementedException();
            }

            public static UInt160 getFinalDelegateForVoting(string projectId, Dictionary<UInt160, UInt160> delegationMap, UInt160 backerAddress)
            {
                throw new NotImplementedException();
            }

            public static BackerVotesEnum GetMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public static bool GetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public static string GetMilestoneTemplateParam(string projectId, string templateId, string key)
            {
                throw new NotImplementedException();
            }

            public static UInt160 GetOwner()
            {
                throw new NotImplementedException();
            }

            public static ProjectOfferPackage getProjectOfferPack(string projectOfferId)
            {
                throw new NotImplementedException();
            }

            public static ProjectPackage getProjectPack(string projectId)
            {
                throw new NotImplementedException();
            }

            public static ProjectPackage getProjectPackWNull(string projectId, bool AllowReturnNull)
            {
                throw new NotImplementedException();
            }

            public static bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType)
            {
                throw new NotImplementedException();
            }

            public static string[] getProjectStatuses(string projectId)
            {
                throw new NotImplementedException();
            }

            public static string[] getSerializedGlobalProjectsPackagesList()
            {
                throw new NotImplementedException();
            }

            public static BigInteger getTotalReservedDonatesToOffer(string offerSha256Id)
            {
                throw new NotImplementedException();
            }

            public static void ImportNewProjectSettings(string jsonSettings)
            {
                throw new NotImplementedException();
            }

            public static bool isFundingGoalReached(string projectId)
            {
                throw new NotImplementedException();
            }

            public static bool isManufacturerCandidateRegistered(string projectId, UInt160 manufacturerId)
            {
                throw new NotImplementedException();
            }

            public static bool IsOwner()
            {
                throw new NotImplementedException();
            }

            public static bool isProjectRegistered(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void paymentPrizeFundToManufacturer(string projectId, UInt160 winnerAddress)
            {
                throw new NotImplementedException();
            }

            public static void processProjectsWinner(string projectId, UInt160 FromAddress)
            {
                throw new NotImplementedException();
            }

            public static string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
            {
                throw new NotImplementedException();
            }

            public static void registerReferrer(string projectId, UInt160 backerAddress, UInt160 referrerAddress)
            {
                throw new NotImplementedException();
            }

            public static void ReleaseAcquireLock()
            {
                throw new NotImplementedException();
            }

            public static void RemoveMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public static void RemoveMilestoneTemplateParam(string projectId, string templateId, string key)
            {
                throw new NotImplementedException();
            }

            public static void removeOffer(string offerSha256Id)
            {
                throw new NotImplementedException();
            }

            public static void removeProjectFromGlobalProjectsLists(ProjectAccount Account)
            {
                throw new NotImplementedException();
            }

            public static void removeProjectFromGlobalProjectsListsByProjectId(string projectId)
            {
                throw new NotImplementedException();
            }

            public static bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id)
            {
                throw new NotImplementedException();
            }

            public static void reserveBackerFundsForManufacturer(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount)
            {
                throw new NotImplementedException();
            }

            public static void resumeProject(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void safeRefundAllDonations(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void saveProjectToProjectsAccountStore(ProjectPackage package)
            {
                throw new NotImplementedException();
            }

            public static void saveToGlobalProjectsLists(ProjectAccount Account)
            {
                throw new NotImplementedException();
            }

            public static UInt160 selectWinnerManufacturer(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void sendDeadlineNotifications(string projectId, int voteType)
            {
                throw new NotImplementedException();
            }

            public static void setBillingProductBuyContractCallbackAddressOwner(string projectId, UInt160 manufacturerAddress, UInt160 callbackAddress)
            {
                throw new NotImplementedException();
            }

            public static void SetMilestoneBackerVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public static void SetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, bool detected, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public static void SetMilestoneTemplateParam(string projectId, string templateId, string key, string value)
            {
                throw new NotImplementedException();
            }

            public static void SetOwner(UInt160 newOwner)
            {
                throw new NotImplementedException();
            }

            public static void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256)
            {
                throw new NotImplementedException();
            }

            public static void setVoterTier(string projectId, string voteId, UInt160 voterAddress, byte tierLevel)
            {
                throw new NotImplementedException();
            }

            public static void setVotingReminder(string projectId, int voteType, ulong reminderTimestamp)
            {
                throw new NotImplementedException();
            }

            public static string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner)
            {
                throw new NotImplementedException();
            }

            public static void Update(ByteString nefFile, string manifest, object data = null)
            {
                throw new NotImplementedException();
            }

            public static void updateManufacturerKPI(string projectId, UInt160 manufacturer, BigInteger deliveryScore, BigInteger qualityScore)
            {
                throw new NotImplementedException();
            }

            public static void updateProjectActivityScore(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void updateProjectPackage(ProjectPackage package, byte[] projectId)
            {
                throw new NotImplementedException();
            }

            public static void updateVotingTimeParameters(string projectId, string votingTypeAsString, ulong newDeadline)
            {
                throw new NotImplementedException();
            }

            public static bool validateProjectIsLiving(string projectId)
            {
                throw new NotImplementedException();
            }

            public static void voteLaunchProject(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                throw new NotImplementedException();
            }

            public static void _deploy(object data, bool update)
            {
                throw new NotImplementedException();
            }

            public void ClearWinnerVoteFraudFlags(string projectId, UInt160 ManufacturerCandidate)
            {
                throw new NotImplementedException();
            }

            public BackerVotesEnum GetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
            {
                throw new NotImplementedException();
            }

            public bool GetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
            {
                throw new NotImplementedException();
            }

            public bool IsMilestoneStepCompletedSuccessfully(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public bool isMilestoneStepStillRunning(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                throw new NotImplementedException();
            }

            public void SetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote)
            {
                throw new NotImplementedException();
            }

            public void SetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, bool detected)
            {
                throw new NotImplementedException();
            }










        }


























        public partial class SCPlatform_Logic4
        {
            public static UInt160 Address = "";
            public static bool TestNet = false;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; }
            public static void allocateFunds(string projectId, UInt160 backer, byte prizeFundPartAllocation)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(allocateFunds),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, prizeFundPartAllocation));
            }


            public static void archiveProject(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(archiveProject),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }


            public static byte calculateReliabilityTier(string projectId, UInt160 manufacturer)
            {
                return ExecuteContractWithResult<byte>(Address,
                                                         nameof(calculateReliabilityTier),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, manufacturer));
            }


            public static void calculateWinners(UInt160 FromAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(calculateWinners),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(FromAddress));
            }


            public static bool canSelectWinner(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(canSelectWinner),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }


            public static bool canWithdrawFromProject(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(canWithdrawFromProject),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }


            public static void ClearMilestoneFraudFlags(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(ClearMilestoneFraudFlags),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }


            public static void ClearMilestoneTemplateParams(string projectId, string templateId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(ClearMilestoneTemplateParams),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, templateId));
            }


            public static void ClearMilestoneVotes(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(ClearMilestoneVotes),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }


            public static void collectFeeForProjectAuthor(string projectId, UInt160 ProjectCreatorAddressParam)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(collectFeeForProjectAuthor),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ProjectCreatorAddressParam));
            }


            public static void configureVotingSystem(string projectId, BigInteger minRequiredParticipationPercent, BigInteger minApprovalPercent)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(configureVotingSystem),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, minRequiredParticipationPercent, minApprovalPercent));
            }


            public static void distributeReferralReward(string projectId, UInt160 referrerAddress, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(distributeReferralReward),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, referrerAddress, amount));
            }


            public static void finalizeWinnerSelectionVoting(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(finalizeWinnerSelectionVoting),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }


            public static UInt160 getFinalDelegateForVoting(string projectId, Dictionary<UInt160, UInt160> delegationMap, UInt160 backerAddress)
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(getFinalDelegateForVoting),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, delegationMap, backerAddress)) ?? UInt160.Zero;
            }


            public static BackerVotesEnum GetMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                return ExecuteContractWithResult<BackerVotesEnum>(Address,
                                                         nameof(GetMilestoneBackerVote),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));
            }


            public static bool GetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(GetMilestoneFraudFlag),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));
            }


            public static string GetMilestoneTemplateParam(string projectId, string templateId, string key)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(GetMilestoneTemplateParam),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, templateId, key)) ?? string.Empty;
            }


            public static ProjectAccount getProjectAccount(string projectId)
            {
                return ExecuteContractWithResult<ProjectAccount>(Address,
                                                         nameof(getProjectAccount),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId)) ?? new ProjectAccount();
            }


            public static bool isFundingGoalReached(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isFundingGoalReached),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }


            public static bool isManufacturerCandidateRegistered(string projectId, UInt160 manufacturerId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isManufacturerCandidateRegistered),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, manufacturerId));
            }


            public static void paymentPrizeFundToManufacturer(string projectId, UInt160 winnerAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(paymentPrizeFundToManufacturer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, winnerAddress));
            }


            public static void processProjectsWinner(string projectId, UInt160 FromAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(processProjectsWinner),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, FromAddress));
            }


            public static void registerReferrer(string projectId, UInt160 backerAddress, UInt160 referrerAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(registerReferrer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, referrerAddress));
            }


            public static void RemoveMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(RemoveMilestoneBackerVote),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));
            }


            public static void RemoveMilestoneTemplateParam(string projectId, string templateId, string key)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(RemoveMilestoneTemplateParam),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, templateId, key));
            }


            public static void reserveBackerFundsForManufacturer(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(reserveBackerFundsForManufacturer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, manufacturer, amount));
            }


            public static void safeRefundAllDonations(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(safeRefundAllDonations),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }


            public static void saveProjectAccountToProjectsAccountStore(string projectId, ProjectAccount project)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(saveProjectAccountToProjectsAccountStore),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, project));
            }


            public static UInt160 selectWinnerManufacturer(string projectId)
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(selectWinnerManufacturer),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId)) ?? UInt160.Zero;
            }


            public static void sendDeadlineNotifications(string projectId, int voteType)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(sendDeadlineNotifications),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voteType));
            }


            public static void setBillingProductBuyContractCallbackAddressOwner(string projectId, UInt160 manufacturerAddress, UInt160 callbackAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setBillingProductBuyContractCallbackAddressOwner),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturerAddress, callbackAddress));
            }


            public static void SetMilestoneBackerVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetMilestoneBackerVote),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, ManufacturerCandidate, vote, StepNumber));
            }


            public static void SetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, bool detected, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetMilestoneFraudFlag),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, backer, detected, StepNumber));
            }


            public static void SetMilestoneTemplateParam(string projectId, string templateId, string key, string value)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetMilestoneTemplateParam),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, templateId, key, value));
            }


            public static void setVoterTier(string projectId, string voteId, UInt160 voterAddress, byte tierLevel)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setVoterTier),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voteId, voterAddress, tierLevel));
            }


            public static void setVotingReminder(string projectId, int voteType, ulong reminderTimestamp)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setVotingReminder),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voteType, reminderTimestamp));
            }




            public static void updateManufacturerKPI(string projectId, UInt160 manufacturer, BigInteger deliveryScore, BigInteger qualityScore)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateManufacturerKPI),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturer, deliveryScore, qualityScore));
            }


            public static void updateProjectActivityScore(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateProjectActivityScore),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }


            public static void updateVotingTimeParameters(string projectId, string votingTypeAsString, ulong newDeadline)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateVotingTimeParameters),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, votingTypeAsString, newDeadline));
            }


            public static void voteLaunchProject(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(voteLaunchProject),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, vote));
            }


            public void ClearWinnerVoteFraudFlags(string projectId, UInt160 ManufacturerCandidate)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(ClearWinnerVoteFraudFlags),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, ManufacturerCandidate));
            }

            public BackerVotesEnum GetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
            {
                return ExecuteContractWithResult<BackerVotesEnum>(Address,
                                                                  nameof(GetWinnerSelectionVote),
                                                                  TestNet,
                                                                  TestInvoke,
                                                                  DefaultUserWif,
                                                                  BuildParameters(projectId, backer, ManufacturerCandidate));
            }

            public bool GetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(GetWinnerVoteFraudFlag),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(projectId, backer, ManufacturerCandidate));
            }

            public bool IsMilestoneStepCompletedSuccessfully(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(IsMilestoneStepCompletedSuccessfully),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }

            public bool isMilestoneStepStillRunning(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(isMilestoneStepStillRunning),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }

            public void SetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetWinnerSelectionVote),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backer, ManufacturerCandidate, vote));
            }

            public void SetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, bool detected)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetWinnerVoteFraudFlag),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backer, ManufacturerCandidate, detected));
            }
        }
    }
}