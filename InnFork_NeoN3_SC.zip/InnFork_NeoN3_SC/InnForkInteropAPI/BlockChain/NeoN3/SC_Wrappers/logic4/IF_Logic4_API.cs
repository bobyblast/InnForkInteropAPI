﻿using InnFork.NeoN3;
using System.Numerics;
using Neo;
using InnFork.NeoN3.Enums;
using System.Threading.Tasks;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{




    public partial class IFPlatform
    {




        public partial class SCPlatform_Logic4
        {

            public static UInt160 Address = UInt160.Parse("0xc435482820d745c01e9753d4b3101404f1e14002");
            public static bool TestNet = true;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; } = ""; public static void allocateFunds(string projectId, UInt160 backer, byte prizeFundPartAllocation)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(allocateFunds),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, prizeFundPartAllocation));
            }
            public static Task allocateFundsAsync(string projectId, UInt160 backer, byte prizeFundPartAllocation)
 => ExecuteContractWithoutResultAsync(Address, nameof(allocateFunds), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, prizeFundPartAllocation));


            public static void archiveProject(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(archiveProject),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }
            public static Task archiveProjectAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(archiveProject), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static byte calculateReliabilityTier(string projectId, UInt160 manufacturer)
            {
                return ExecuteContractWithResult<byte>(Address,
                                                         nameof(calculateReliabilityTier),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, manufacturer));
            }
            public static Task<byte> calculateReliabilityTierAsync(string projectId, UInt160 manufacturer)
 => ExecuteContractWithResultAsync<byte>(Address, nameof(calculateReliabilityTier), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer));


            public static void calculateWinners(UInt160 FromAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(calculateWinners),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(FromAddress));
            }
            public static Task calculateWinnersAsync(UInt160 FromAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(calculateWinners), TestNet, TestInvoke, DefaultUserWif, BuildParameters(FromAddress));


            public static bool canSelectWinner(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(canSelectWinner),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }
            public static Task<bool> canSelectWinnerAsync(string projectId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(canSelectWinner), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static bool canWithdrawFromProject(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(canWithdrawFromProject),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backer));
            }
            public static Task<bool> canWithdrawFromProjectAsync(string projectId, UInt160 backer)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(canWithdrawFromProject), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer));


            public static void ClearMilestoneFraudFlags(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(ClearMilestoneFraudFlags),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }
            public static Task ClearMilestoneFraudFlagsAsync(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(ClearMilestoneFraudFlags), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, StepNumber));


            public static void ClearMilestoneTemplateParams(string projectId, string templateId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(ClearMilestoneTemplateParams),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, templateId));
            }
            public static Task ClearMilestoneTemplateParamsAsync(string projectId, string templateId)
 => ExecuteContractWithoutResultAsync(Address, nameof(ClearMilestoneTemplateParams), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, templateId));


            public static void ClearMilestoneVotes(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(ClearMilestoneVotes),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }
            public static Task ClearMilestoneVotesAsync(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(ClearMilestoneVotes), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, StepNumber));


            public static void collectFeeForProjectAuthor(string projectId, UInt160 ProjectCreatorAddressParam)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(collectFeeForProjectAuthor),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ProjectCreatorAddressParam));
            }
            public static Task collectFeeForProjectAuthorAsync(string projectId, UInt160 ProjectCreatorAddressParam)
 => ExecuteContractWithoutResultAsync(Address, nameof(collectFeeForProjectAuthor), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ProjectCreatorAddressParam));


            public static void configureVotingSystem(string projectId, BigInteger minRequiredParticipationPercent, BigInteger minApprovalPercent)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(configureVotingSystem),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, minRequiredParticipationPercent, minApprovalPercent));
            }
            public static Task configureVotingSystemAsync(string projectId, BigInteger minRequiredParticipationPercent, BigInteger minApprovalPercent)
 => ExecuteContractWithoutResultAsync(Address, nameof(configureVotingSystem), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, minRequiredParticipationPercent, minApprovalPercent));


            public static void distributeReferralReward(string projectId, UInt160 referrerAddress, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(distributeReferralReward),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, referrerAddress, amount));
            }
            public static Task distributeReferralRewardAsync(string projectId, UInt160 referrerAddress, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(distributeReferralReward), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, referrerAddress, amount));


            public static void finalizeWinnerSelectionVoting(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(finalizeWinnerSelectionVoting),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }
            public static Task finalizeWinnerSelectionVotingAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(finalizeWinnerSelectionVoting), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static UInt160 getFinalDelegateForVoting(string projectId, Dictionary<UInt160, UInt160> delegationMap, UInt160 backerAddress)
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(getFinalDelegateForVoting),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, delegationMap, backerAddress)) ?? UInt160.Zero;
            }
            public static async Task<UInt160> getFinalDelegateForVotingAsync(string projectId, Dictionary<UInt160, UInt160> delegationMap, UInt160 backerAddress)
 => await ExecuteContractWithResultAsync<UInt160>(Address, nameof(getFinalDelegateForVoting), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, delegationMap, backerAddress)) ?? UInt160.Zero;


            public static BackerVotesEnum GetMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                return ExecuteContractWithResult<BackerVotesEnum>(Address,
                                                         nameof(GetMilestoneBackerVote),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));
            }
            public static Task<BackerVotesEnum> GetMilestoneBackerVoteAsync(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
 => ExecuteContractWithResultAsync<BackerVotesEnum>(Address, nameof(GetMilestoneBackerVote), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));


            public static bool GetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(GetMilestoneFraudFlag),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));
            }
            public static Task<bool> GetMilestoneFraudFlagAsync(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(GetMilestoneFraudFlag), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));


            public static string GetMilestoneTemplateParam(string projectId, string templateId, string key)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(GetMilestoneTemplateParam),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, templateId, key)) ?? string.Empty;
            }
            public static async Task<string> GetMilestoneTemplateParamAsync(string projectId, string templateId, string key)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(GetMilestoneTemplateParam), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, templateId, key)) ?? string.Empty;


            public static ProjectAccount getProjectAccount(string projectId)
            {
                return ExecuteContractWithResult<ProjectAccount>(Address,
                                                         nameof(getProjectAccount),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId)) ?? new ProjectAccount();
            }
            public static async Task<ProjectAccount> getProjectAccountAsync(string projectId)
 => await ExecuteContractWithResultAsync<ProjectAccount>(Address, nameof(getProjectAccount), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId)) ?? new ProjectAccount();


            public static bool isFundingGoalReached(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isFundingGoalReached),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }
            public static Task<bool> isFundingGoalReachedAsync(string projectId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isFundingGoalReached), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static bool isManufacturerCandidateRegistered(string projectId, UInt160 manufacturerId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isManufacturerCandidateRegistered),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, manufacturerId));
            }
            public static Task<bool> isManufacturerCandidateRegisteredAsync(string projectId, UInt160 manufacturerId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isManufacturerCandidateRegistered), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerId));


            public static void paymentPrizeFundToManufacturer(string projectId, UInt160 winnerAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(paymentPrizeFundToManufacturer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, winnerAddress));
            }
            public static Task paymentPrizeFundToManufacturerAsync(string projectId, UInt160 winnerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(paymentPrizeFundToManufacturer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, winnerAddress));


            public static void processProjectsWinner(string projectId, UInt160 FromAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(processProjectsWinner),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, FromAddress));
            }
            public static Task processProjectsWinnerAsync(string projectId, UInt160 FromAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(processProjectsWinner), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, FromAddress));


            public static void registerReferrer(string projectId, UInt160 backerAddress, UInt160 referrerAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(registerReferrer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, referrerAddress));
            }
            public static Task registerReferrerAsync(string projectId, UInt160 backerAddress, UInt160 referrerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(registerReferrer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, referrerAddress));


            public static void RemoveMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(RemoveMilestoneBackerVote),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));
            }
            public static Task RemoveMilestoneBackerVoteAsync(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(RemoveMilestoneBackerVote), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, backer, StepNumber));


            public static void RemoveMilestoneTemplateParam(string projectId, string templateId, string key)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(RemoveMilestoneTemplateParam),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, templateId, key));
            }
            public static Task RemoveMilestoneTemplateParamAsync(string projectId, string templateId, string key)
 => ExecuteContractWithoutResultAsync(Address, nameof(RemoveMilestoneTemplateParam), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, templateId, key));


            public static void reserveBackerFundsForManufacturer(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(reserveBackerFundsForManufacturer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, manufacturer, amount));
            }
            public static Task reserveBackerFundsForManufacturerAsync(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(reserveBackerFundsForManufacturer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, manufacturer, amount));


            public static void safeRefundAllDonations(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(safeRefundAllDonations),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }
            public static Task safeRefundAllDonationsAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(safeRefundAllDonations), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static UInt160 selectWinnerManufacturer(string projectId)
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(selectWinnerManufacturer),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId)) ?? UInt160.Zero;
            }
            public static async Task<UInt160> selectWinnerManufacturerAsync(string projectId)
 => await ExecuteContractWithResultAsync<UInt160>(Address, nameof(selectWinnerManufacturer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId)) ?? UInt160.Zero;


            public static void sendDeadlineNotifications(string projectId, int voteType)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(sendDeadlineNotifications),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voteType));
            }
            public static Task sendDeadlineNotificationsAsync(string projectId, int voteType)
 => ExecuteContractWithoutResultAsync(Address, nameof(sendDeadlineNotifications), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voteType));


            public static void setBillingProductBuyContractCallbackAddressOwner(string projectId, UInt160 manufacturerAddress, UInt160 callbackAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setBillingProductBuyContractCallbackAddressOwner),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturerAddress, callbackAddress));
            }
            public static Task setBillingProductBuyContractCallbackAddressOwnerAsync(string projectId, UInt160 manufacturerAddress, UInt160 callbackAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(setBillingProductBuyContractCallbackAddressOwner), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, callbackAddress));


            public static void SetMilestoneBackerVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetMilestoneBackerVote),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, ManufacturerCandidate, vote, StepNumber));
            }
            public static Task SetMilestoneBackerVoteAsync(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote, byte StepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetMilestoneBackerVote), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, ManufacturerCandidate, vote, StepNumber));


            public static void SetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, bool detected, byte StepNumber)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetMilestoneFraudFlag),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ManufacturerCandidate, backer, detected, StepNumber));
            }
            public static Task SetMilestoneFraudFlagAsync(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, bool detected, byte StepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetMilestoneFraudFlag), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, backer, detected, StepNumber));


            public static void SetMilestoneTemplateParam(string projectId, string templateId, string key, string value)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetMilestoneTemplateParam),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, templateId, key, value));
            }
            public static Task SetMilestoneTemplateParamAsync(string projectId, string templateId, string key, string value)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetMilestoneTemplateParam), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, templateId, key, value));


            public static void setVoterTier(string projectId, string voteId, UInt160 voterAddress, byte tierLevel)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setVoterTier),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voteId, voterAddress, tierLevel));
            }
            public static Task setVoterTierAsync(string projectId, string voteId, UInt160 voterAddress, byte tierLevel)
 => ExecuteContractWithoutResultAsync(Address, nameof(setVoterTier), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voteId, voterAddress, tierLevel));


            public static void setVotingReminder(string projectId, int voteType, ulong reminderTimestamp)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setVotingReminder),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, voteType, reminderTimestamp));
            }
            public static Task setVotingReminderAsync(string projectId, int voteType, ulong reminderTimestamp)
 => ExecuteContractWithoutResultAsync(Address, nameof(setVotingReminder), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voteType, reminderTimestamp));





            public static void updateManufacturerKPI(string projectId, UInt160 manufacturer, BigInteger deliveryScore, BigInteger qualityScore)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateManufacturerKPI),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, manufacturer, deliveryScore, qualityScore));
            }
            public static Task updateManufacturerKPIAsync(string projectId, UInt160 manufacturer, BigInteger deliveryScore, BigInteger qualityScore)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateManufacturerKPI), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer, deliveryScore, qualityScore));


            public static void updateProjectActivityScore(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateProjectActivityScore),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }
            public static Task updateProjectActivityScoreAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateProjectActivityScore), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static void updateVotingTimeParameters(string projectId, string votingTypeAsString, ulong newDeadline)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateVotingTimeParameters),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, votingTypeAsString, newDeadline));
            }
            public static Task updateVotingTimeParametersAsync(string projectId, string votingTypeAsString, ulong newDeadline)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateVotingTimeParameters), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, votingTypeAsString, newDeadline));


            public static void voteLaunchProject(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(voteLaunchProject),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, vote));
            }
            public static Task voteLaunchProjectAsync(string projectId, UInt160 backer, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteLaunchProject), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, vote));


            public void ClearWinnerVoteFraudFlags(string projectId, UInt160 ManufacturerCandidate)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(ClearWinnerVoteFraudFlags),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, ManufacturerCandidate));
            }
            public Task ClearWinnerVoteFraudFlagsAsync(string projectId, UInt160 ManufacturerCandidate)
 => ExecuteContractWithoutResultAsync(Address, nameof(ClearWinnerVoteFraudFlags), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate));

            public BackerVotesEnum GetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
            {
                return ExecuteContractWithResult<BackerVotesEnum>(Address,
                                                                  nameof(GetWinnerSelectionVote),
                                                                  TestNet,
                                                                  TestInvoke,
                                                                  DefaultUserWif,
                                                                  BuildParameters(projectId, backer, ManufacturerCandidate));
            }
            public Task<BackerVotesEnum> GetWinnerSelectionVoteAsync(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
 => ExecuteContractWithResultAsync<BackerVotesEnum>(Address, nameof(GetWinnerSelectionVote), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, ManufacturerCandidate));

            public bool GetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(GetWinnerVoteFraudFlag),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(projectId, backer, ManufacturerCandidate));
            }
            public Task<bool> GetWinnerVoteFraudFlagAsync(string projectId, UInt160 backer, UInt160 ManufacturerCandidate)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(GetWinnerVoteFraudFlag), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, ManufacturerCandidate));

            public bool IsMilestoneStepCompletedSuccessfully(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(IsMilestoneStepCompletedSuccessfully),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }
            public Task<bool> IsMilestoneStepCompletedSuccessfullyAsync(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(IsMilestoneStepCompletedSuccessfully), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, StepNumber));

            public bool isMilestoneStepStillRunning(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(isMilestoneStepStillRunning),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(projectId, ManufacturerCandidate, StepNumber));
            }
            public Task<bool> isMilestoneStepStillRunningAsync(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isMilestoneStepStillRunning), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerCandidate, StepNumber));

            public void SetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetWinnerSelectionVote),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backer, ManufacturerCandidate, vote));
            }
            public Task SetWinnerSelectionVoteAsync(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetWinnerSelectionVote), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, ManufacturerCandidate, vote));

            public void SetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, bool detected)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetWinnerVoteFraudFlag),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backer, ManufacturerCandidate, detected));
            }
            public Task SetWinnerVoteFraudFlagAsync(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, bool detected)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetWinnerVoteFraudFlag), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, ManufacturerCandidate, detected));


        }
    }
}