namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;



public partial class IFPlatform
{


    public partial class SCPlatform_Investing
    {
        // Strongly-typed operation names without enum numbering risks
        public readonly record struct BackerFacadeMethod(string Name)
        {
            public override string ToString() => Name;
            public static implicit operator string(BackerFacadeMethod m) => m.Name;
            public static implicit operator BackerFacadeMethod(string s) => new(s);

            public static BackerFacadeMethod createBackerAccount => new("createBackerAccount");
            public static BackerFacadeMethod updateExistingBackerAccount => new("updateExistingBackerAccount");
            public static BackerFacadeMethod getBackerAccount => new("getBackerAccount");
            public static BackerFacadeMethod getTotalBalanceOfBackerAccount => new("getTotalBalanceOfBackerAccount");
            public static BackerFacadeMethod getFreeBalanceOfBackerAccount => new("getFreeBalanceOfBackerAccount");
            public static BackerFacadeMethod withdrawFromMainBalance => new("withdrawFromMainBalance");
        }

        public readonly record struct InvestorFacadeMethod(string Name)
        {
            public override string ToString() => Name;
            public static implicit operator string(InvestorFacadeMethod m) => m.Name;
            public static implicit operator InvestorFacadeMethod(string s) => new(s);

            // InvestorAccount
            public static InvestorFacadeMethod getInvestorAccount => new("getInvestorAccount");
            public static InvestorFacadeMethod updateExistingInvestorAccount => new("updateExistingInvestorAccount");
            public static InvestorFacadeMethod withdrawInvestment => new("withdrawInvestment");
            public static InvestorFacadeMethod investAsInvestorToManufacturerCandidate => new("investAsInvestorToManufacturerCandidate");
            public static InvestorFacadeMethod createInvestorAccount => new("createInvestorAccount");
            public static InvestorFacadeMethod moveFromInvestorBalanceToInnFork => new("moveFromInvestorBalanceToInnFork");
            public static InvestorFacadeMethod withdrawFromMainBalance => new("withdrawFromMainBalance");
            public static InvestorFacadeMethod getTotalBalanceOfInvestorAccount => new("getTotalBalanceOfInvestorAccount");
            public static InvestorFacadeMethod getFreeBalanceOfInvestorAccount => new("getFreeBalanceOfInvestorAccount");
            public static InvestorFacadeMethod removeInvestorAccount => new("removeInvestorAccount");
            // FinancialOperations
            public static InvestorFacadeMethod RecordInvestment => new("RecordInvestment");
            public static InvestorFacadeMethod GetInvestmentAmount => new("GetInvestmentAmount");
            // InvestmentAgreement
            public static InvestorFacadeMethod trackAgreementParties => new("trackAgreementParties");
            public static InvestorFacadeMethod handleRepayment => new("handleRepayment");
            public static InvestorFacadeMethod scheduledAgreementMaintenance => new("scheduledAgreementMaintenance");
            public static InvestorFacadeMethod processLimitedExpiredAgreements => new("processLimitedExpiredAgreements");
            public static InvestorFacadeMethod processAgreementsList => new("processAgreementsList");
            public static InvestorFacadeMethod checkSingleAgreementStatus => new("checkSingleAgreementStatus");
            public static InvestorFacadeMethod generateAgreementId => new("generateAgreementId");
            public static InvestorFacadeMethod checkAgreementStatus => new("checkAgreementStatus");
            public static InvestorFacadeMethod createAgreement => new("createAgreement");
            public static InvestorFacadeMethod createAgreementForProjectInvestment => new("createAgreementForProjectInvestment");
            public static InvestorFacadeMethod confirmAgreement => new("confirmAgreement");
            public static InvestorFacadeMethod checkAllExpiredAgreements => new("checkAllExpiredAgreements");
            public static InvestorFacadeMethod handleInvestmentPayment => new("handleInvestmentPayment");
            public static InvestorFacadeMethod checkExpiredAgreementsForParticipant => new("checkExpiredAgreementsForParticipant");
            public static InvestorFacadeMethod processAllExpiredAgreements => new("processAllExpiredAgreements");
            public static InvestorFacadeMethod safeTransfer => new("safeTransfer");
        }

        public readonly record struct ManufacturerFacadeMethod(string Name)
        {
            public override string ToString() => Name;
            public static implicit operator string(ManufacturerFacadeMethod m) => m.Name;
            public static implicit operator ManufacturerFacadeMethod(string s) => new(s);

            // Instance methods (first arg: caller)
            public static ManufacturerFacadeMethod payProfitToInvestor => new("payProfitToInvestor");
            public static ManufacturerFacadeMethod canRefundInvestment => new("canRefundInvestment");
            public static ManufacturerFacadeMethod refundInvestment => new("refundInvestment");
            public static ManufacturerFacadeMethod canPayProfit => new("canPayProfit");
            public static ManufacturerFacadeMethod processInvestorInvestments => new("processInvestorInvestments");
            public static ManufacturerFacadeMethod processRepayment => new("processRepayment");
            public static ManufacturerFacadeMethod processManufacturerRepayment => new("processManufacturerRepayment");
            public static ManufacturerFacadeMethod processInvestorWithdraw => new("processInvestorWithdraw");
            // Static methods
            public static ManufacturerFacadeMethod getManufacturerAccount => new("getManufacturerAccount");
            public static ManufacturerFacadeMethod createManufacturerAccount => new("createManufacturerAccount");
            public static ManufacturerFacadeMethod updateExistingManufacturerAccount => new("updateExistingManufacturerAccount");
            public static ManufacturerFacadeMethod getTotalBalanceOfManufacturerAccount => new("getTotalBalanceOfManufacturerAccount");
            public static ManufacturerFacadeMethod getFreeBalanceOfManufacturerAccount => new("getFreeBalanceOfManufacturerAccount");
            public static ManufacturerFacadeMethod removeManufacturerAccount => new("removeManufacturerAccount");
            public static ManufacturerFacadeMethod withdrawFromMainBalance => new("withdrawFromMainBalance");
        }

        public readonly record struct ProjectCreatorFacadeMethod(string Name)
        {
            public override string ToString() => Name;
            public static implicit operator string(ProjectCreatorFacadeMethod m) => m.Name;
            public static implicit operator ProjectCreatorFacadeMethod(string s) => new(s);

            public static ProjectCreatorFacadeMethod createProjectCreatorAccount => new("createProjectCreatorAccount");
            public static ProjectCreatorFacadeMethod withdrawFromMainBalance => new("withdrawFromMainBalance");
            public static ProjectCreatorFacadeMethod updateExistingProjectCreatorAccount => new("updateExistingProjectCreatorAccount");
            public static ProjectCreatorFacadeMethod getProjectCreatorAccount => new("getProjectCreatorAccount");
            public static ProjectCreatorFacadeMethod getTotalBalanceOfProjectCreatorAccount => new("getTotalBalanceOfProjectCreatorAccount");
            public static ProjectCreatorFacadeMethod getFreeBalanceOfProjectCreatorAccount => new("getFreeBalanceOfProjectCreatorAccount");
            public static ProjectCreatorFacadeMethod getProjectCreatorAccountByProjectId => new("getProjectCreatorAccountByProjectId");
            public static ProjectCreatorFacadeMethod setPublicKey => new("setPublicKey");
            public static ProjectCreatorFacadeMethod setPublicKeyBytes => new("setPublicKeyBytes");
            public static ProjectCreatorFacadeMethod executeProjectCreatorRefund => new("executeProjectCreatorRefund");
        }


        // Overloads using strongly-typed operation holders
        public static string callBackerAccountFacade(BackerFacadeMethod operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callBackerAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callBackerAccountFacadeAsync(BackerFacadeMethod operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callBackerAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;

        public static string callInvestorAccountFacade(InvestorFacadeMethod operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callInvestorAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callInvestorAccountFacadeAsync(InvestorFacadeMethod operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callInvestorAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;

        public static string callManufacturerAccountFacade(ManufacturerFacadeMethod operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callManufacturerAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callManufacturerAccountFacadeAsync(ManufacturerFacadeMethod operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callManufacturerAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;

        public static string callProjectCreatorAccountFacade(ProjectCreatorFacadeMethod operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callProjectCreatorAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callProjectCreatorAccountFacadeAsync(ProjectCreatorFacadeMethod operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callProjectCreatorAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters((string)operation, args ?? System.Array.Empty<object>())) ?? string.Empty;


        // Backward-compatible string overloads remain below

        public static string callBackerAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callBackerAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callBackerAccountFacadeAsync(string operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callBackerAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;

        public static string callInvestorAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callInvestorAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callInvestorAccountFacadeAsync(string operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callInvestorAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;

        public static string callManufacturerAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callManufacturerAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callManufacturerAccountFacadeAsync(string operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callManufacturerAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;

        public static string callProjectCreatorAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callProjectCreatorAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }
        public static async Task<string> callProjectCreatorAccountFacadeAsync(string operation, object[] args)
        => await ExecuteContractWithResultAsync<string>(Address, nameof(callProjectCreatorAccountFacade), TestNet, TestInvoke, DefaultUserWif, BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;



    }
}