using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using InnFork.NeoN3;
using InnFork.NeoN3.Enums;
using Neo;
using Neo.SmartContract;
using Neo.VM.Types;


namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;



public partial class IFPlatform
{
    public class SCPlatform_Investing_new
    {
        public static UInt160 Address = "";
        public int version;

        public static bool testnet = false;
        public static bool TestInvoke = false;

        public static string? DefaultUserWif { get; set; }

        public static void AcquireLock()
        {
            throw new NotImplementedException();
        }

        public static void autoFinalizeAllExpiredVotings(string projectId)
        {
            throw new NotImplementedException();
        }

        public static void autoSetToPause(string projectId)
        {
            throw new NotImplementedException();
        }

        public static BigInteger calculateTotalReservedForOffer(string offerId)
        {
            throw new NotImplementedException();
        }

        public static void CallAgreementCompleted(byte[] agreementId)
        {
            throw new NotImplementedException();
        }

        public static void CallAgreementConfirmed(byte[] agreementId)
        {
            throw new NotImplementedException();
        }

        public static void CallAgreementCreated(byte[] agreementId, UInt160 investor, UInt160 manufacturer, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void CallAgreementDefaulted(byte[] agreementId)
        {
            throw new NotImplementedException();
        }

        public static string callBackerAccountFacade(string operation, object[] args)
        {
            throw new NotImplementedException();
        }

        public static void CallInvestmentPaymentMade(byte[] agreementId, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static string callInvestorAccountFacade(string operation, object[] args)
        {
            throw new NotImplementedException();
        }

        public static string callManufacturerAccountFacade(string operation, object[] args)
        {
            throw new NotImplementedException();
        }

        public static string callProjectCreatorAccountFacade(string operation, object[] args)
        {
            throw new NotImplementedException();
        }

        public static void CallRepaymentMade(byte[] agreementId, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static bool canWithdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            throw new NotImplementedException();
        }

        public static void Destroy()
        {
            throw new NotImplementedException();
        }

        public static void donateToProjectManufacturerAsInvestor(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void finalizeVoting(string projectId, string votingType)
        {
            throw new NotImplementedException();
        }

        public static int getCountOfSelectedMapName(string MapName)
        {
            throw new NotImplementedException();
        }

        public static int getCountOf_Sha256Offers()
        {
            throw new NotImplementedException();
        }

        public static UInt160 GetOwner()
        {
            throw new NotImplementedException();
        }

        public static ProjectOfferPackage getProjectOfferPack(string projectOfferId)
        {
            throw new NotImplementedException();
        }

        public static ProjectPackage getProjectPack(string projectId)
        {
            throw new NotImplementedException();
        }

        public static ProjectPackage getProjectPackWNull(string projectId, bool AllowReturnNull)
        {
            throw new NotImplementedException();
        }

        public static bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType)
        {
            throw new NotImplementedException();
        }

        public static string[] getProjectStatuses(string projectId)
        {
            throw new NotImplementedException();
        }

        public static string[] getSerializedGlobalProjectsPackagesList()
        {
            throw new NotImplementedException();
        }

        public static BigInteger getTotalReservedDonatesToOffer(string offerSha256Id)
        {
            throw new NotImplementedException();
        }

        public static void ImportNewProjectSettings(string jsonSettings)
        {
            throw new NotImplementedException();
        }

        public static void investToManufacturer(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static bool isMilestoneVotingCompleteSuccess(UInt160 manufacturer, string projectId, byte stepNumber)
        {
            throw new NotImplementedException();
        }

        public static bool IsOwner()
        {
            throw new NotImplementedException();
        }

        public static bool isProjectOpen(string projectId)
        {
            throw new NotImplementedException();
        }

        public static bool isProjectRegistered(string projectId)
        {
            throw new NotImplementedException();
        }

        public static void refundOfferDonate(UInt160 backer, string offerSha256Id, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void registerNewManufacturerCandidate(UInt160 ManufacturerAddress, string projectId)
        {
            throw new NotImplementedException();
        }

        public static string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
        {
            throw new NotImplementedException();
        }

        public static void ReleaseAcquireLock()
        {
            throw new NotImplementedException();
        }

        public static void removeOffer(string offerSha256Id)
        {
            throw new NotImplementedException();
        }

        public static void removeProjectFromGlobalProjectsLists(ProjectAccount Account)
        {
            throw new NotImplementedException();
        }

        public static void removeProjectFromGlobalProjectsListsByProjectId(string projectId)
        {
            throw new NotImplementedException();
        }

        public static bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id)
        {
            throw new NotImplementedException();
        }

        public static void resumeProject(string projectId)
        {
            throw new NotImplementedException();
        }

        public static void saveProjectToProjectsAccountStore(ProjectPackage package)
        {
            throw new NotImplementedException();
        }

        public static void saveToGlobalProjectsLists(ProjectAccount Account)
        {
            throw new NotImplementedException();
        }

        public static void SetOwner(UInt160 newOwner)
        {
            throw new NotImplementedException();
        }

        public static void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256)
        {
            throw new NotImplementedException();
        }

        public static string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner)
        {
            throw new NotImplementedException();
        }

        public static void Update(ByteString nefFile, string manifest, object data = null)
        {
            throw new NotImplementedException();
        }

        public static void updateProjectPackage(ProjectPackage package, byte[] projectId)
        {
            throw new NotImplementedException();
        }

        public static bool validateProjectIsLiving(string projectId)
        {
            throw new NotImplementedException();
        }

        public static void withdrawBackerBalance(UInt160 backerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void withdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            throw new NotImplementedException();
        }

        public static void withdrawInvestorBalance(UInt160 investorAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void withdrawInvestorProfit(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            throw new NotImplementedException();
        }

        public static void withdrawManufacturerBalance(UInt160 manufacturerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void withdrawProjectCreatorBalance(UInt160 projectCreatorAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void _deploy(object data, bool update)
        {
            throw new NotImplementedException();
        }

        public static void CallAgreementCreated(byte[] agreementId, Neo.SmartContract.Framework.UInt160 investor, Neo.SmartContract.Framework.UInt160 manufacturer, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static bool canWithdrawInvestment(string projectId, Neo.SmartContract.Framework.UInt160 investorAddress, Neo.SmartContract.Framework.UInt160 manufacturerAddress)
        {
            throw new NotImplementedException();
        }

        public static void donateToProjectManufacturerAsInvestor(string projectId, Neo.SmartContract.Framework.UInt160 investorAddress, Neo.SmartContract.Framework.UInt160 manufacturerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }



        public static void investToManufacturer(string projectId, Neo.SmartContract.Framework.UInt160 investorAddress, Neo.SmartContract.Framework.UInt160 manufacturerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static bool isMilestoneVotingCompleteSuccess(Neo.SmartContract.Framework.UInt160 manufacturer, string projectId, byte stepNumber)
        {
            throw new NotImplementedException();
        }

        public static void refundOfferDonate(Neo.SmartContract.Framework.UInt160 backer, string offerSha256Id, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void registerNewManufacturerCandidate(Neo.SmartContract.Framework.UInt160 ManufacturerAddress, string projectId)
        {
            throw new NotImplementedException();
        }

        public static string registerProjectEx(Neo.SmartContract.Framework.UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
        {
            throw new NotImplementedException();
        }

        public static bool removeProjectOfferByTimeLine(Neo.SmartContract.Framework.UInt160 projectCreatorAddress, string offerSha256Id)
        {
            throw new NotImplementedException();
        }

        public static void SetOwner(Neo.SmartContract.Framework.UInt160 newOwner)
        {
            throw new NotImplementedException();
        }

        public static string storeProjectOfferMetaData(Neo.SmartContract.Framework.UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner)
        {
            throw new NotImplementedException();
        }

        public static void Update(Neo.SmartContract.Framework.ByteString nefFile, string manifest, object data = null)
        {
            throw new NotImplementedException();
        }

        public static void withdrawBackerBalance(Neo.SmartContract.Framework.UInt160 backerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void withdrawInvestment(string projectId, Neo.SmartContract.Framework.UInt160 investorAddress, Neo.SmartContract.Framework.UInt160 manufacturerAddress)
        {
            throw new NotImplementedException();
        }

        public static void withdrawInvestorBalance(Neo.SmartContract.Framework.UInt160 investorAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void withdrawInvestorProfit(string projectId, Neo.SmartContract.Framework.UInt160 investorAddress, Neo.SmartContract.Framework.UInt160 manufacturerAddress)
        {
            throw new NotImplementedException();
        }

        public static void withdrawManufacturerBalance(Neo.SmartContract.Framework.UInt160 manufacturerAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }

        public static void withdrawProjectCreatorBalance(Neo.SmartContract.Framework.UInt160 projectCreatorAddress, BigInteger amount)
        {
            throw new NotImplementedException();
        }
    }


    public class SCPlatform_Investing
    {
        public static UInt160 Address = "";
        public int version;

        public static bool testnet = false;
        public static bool TestInvoke = false;
        public static string? DefaultUserWif { get; set; }

        public static void collectFeeForProjectAuthor(string projectId, UInt160 ProjectCreatorAddressParam)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(collectFeeForProjectAuthor),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, ProjectCreatorAddressParam));
        }



        public static void autoFinalizeAllExpiredVotings(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(autoFinalizeAllExpiredVotings),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static string callBackerAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callBackerAccountFacade),
                                                     testnet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }

        public static string callInvestorAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callInvestorAccountFacade),
                                                     testnet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }

        public static string callManufacturerAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callManufacturerAccountFacade),
                                                     testnet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }

        public static string callProjectCreatorAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callProjectCreatorAccountFacade),
                                                     testnet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }

        public static bool canWithdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(canWithdrawInvestment),
                                                   testnet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(projectId, investorAddress, manufacturerAddress));
        }

        public static void checkAllMilestoneVotings(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(checkAllMilestoneVotings),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static bool checkAndFinalizeMilestoneVoting(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(checkAndFinalizeMilestoneVoting),
                                                   testnet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(projectId, manufacturer, stepNumber));
        }


        public static void donateToProjectManufacturerAsInvestor(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(donateToProjectManufacturerAsInvestor),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress, amount));
        }

        public static void finalizeFundraisingIncreaseVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeFundraisingIncreaseVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void finalizeFundraisingVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeFundraisingVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void finalizeLaunchVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeLaunchVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void finalizeManagementTransferVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeManagementTransferVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void finalizePauseVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizePauseVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void finalizeSuccessfulClosureVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeSuccessfulClosureVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void finalizeTerminationWithRefundVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeTerminationWithRefundVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void finalizeWinnerSelectionVoting(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeWinnerSelectionVoting),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static string[] getAllProjectsIds()
        {
            return ExecuteContractWithResult<string[]>(Address,
                                                        nameof(getAllProjectsIds),
                                                        testnet,
                                                        TestInvoke,
                                                        DefaultUserWif,
                                                        BuildParameters()) ?? System.Array.Empty<string>();
        }

        public static UInt160 GetOwner()
        {
            return ExecuteContractWithResult<UInt160>(Address,
                                                      nameof(GetOwner),
                                                      testnet,
                                                      TestInvoke,
                                                      DefaultUserWif,
                                                      BuildParameters()) ?? UInt160.Zero;
        }

        public static void investToManufacturer(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(investToManufacturer),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress, amount));
        }

        public static bool isFundingGoalReached(string projectId)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(isFundingGoalReached),
                                                   testnet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(projectId));
        }

        public static bool isMilestoneVotingCompleteSuccess(UInt160 manufacturer, string projectId, byte stepNumber)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(isMilestoneVotingCompleteSuccess),
                                                   testnet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(manufacturer, projectId, stepNumber));
        }

        public static bool isProjectOpen(string projectId)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(isProjectOpen),
                                                   testnet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(projectId));
        }

        public static void paymentPrizeFundToManufacturer(string projectId, UInt160 winnerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(paymentPrizeFundToManufacturer),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, winnerAddress));
        }

        public static void refundOfferDonate(UInt160 backer, string offerSha256Id, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(refundOfferDonate),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(backer, offerSha256Id, amount));
        }

        public static void registerNewManufacturerCandidate(UInt160 ManufacturerAddress, string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(registerNewManufacturerCandidate),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(ManufacturerAddress, projectId));
        }

        public static void safeRefundAllDonations(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(safeRefundAllDonations),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }

        public static void withdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawInvestment),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress));
        }

        public static void withdrawInvestorProfit(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawInvestorProfit),
                                         testnet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress));
        }
    }

}