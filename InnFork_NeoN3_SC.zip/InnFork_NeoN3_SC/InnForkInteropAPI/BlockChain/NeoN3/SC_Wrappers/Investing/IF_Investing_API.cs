using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using InnFork.NeoN3;
using InnFork.NeoN3.Enums;
using Neo;
using Neo.SmartContract;
using Neo.VM.Types;


namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;



public partial class IFPlatform
{


    public class SCPlatform_Investing
    {




        public static string callBackerAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callBackerAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }

        public static string callInvestorAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callInvestorAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }

        public static string callManufacturerAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callManufacturerAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }

        public static string callProjectCreatorAccountFacade(string operation, object[] args)
        {
            return ExecuteContractWithResult<string>(Address,
                                                     nameof(callProjectCreatorAccountFacade),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(operation, args ?? System.Array.Empty<object>())) ?? string.Empty;
        }



        public static UInt160 Address = UInt160.Parse("0x6758ffa179253a04d7eadd4f7763e08431768cd2");

        public static bool TestNet = true;
        public static bool TestInvoke = false;

        public static string? DefaultUserWif { get; set; } = "";


        public static void collectFeeForProjectAuthor(string projectId, UInt160 ProjectCreatorAddressParam)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(collectFeeForProjectAuthor),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, ProjectCreatorAddressParam));
        }



        public static void autoFinalizeAllExpiredVotings(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(autoFinalizeAllExpiredVotings),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId));
        }




        public static bool canWithdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(canWithdrawInvestment),
                                                   TestNet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(projectId, investorAddress, manufacturerAddress));
        }


        public static void donateToProjectManufacturerAsInvestor(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(donateToProjectManufacturerAsInvestor),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress, amount));
        }

        public static void investToManufacturer(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(investToManufacturer),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress, amount));
        }

        public static bool isMilestoneVotingCompleteSuccess(UInt160 manufacturer, string projectId, byte stepNumber)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(isMilestoneVotingCompleteSuccess),
                                                   TestNet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(manufacturer, projectId, stepNumber));
        }

        public static bool isProjectOpen(string projectId)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                   nameof(isProjectOpen),
                                                   TestNet,
                                                   TestInvoke,
                                                   DefaultUserWif,
                                                   BuildParameters(projectId));
        }

        public static void refundOfferDonate(UInt160 backer, string offerSha256Id, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(refundOfferDonate),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(backer, offerSha256Id, amount));
        }

        public static void registerNewManufacturerCandidate(UInt160 ManufacturerAddress, string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(registerNewManufacturerCandidate),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(ManufacturerAddress, projectId));
        }


        public static void withdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawInvestment),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress));
        }

        public static void withdrawInvestorProfit(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawInvestorProfit),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, investorAddress, manufacturerAddress));
        }


        public static void CallAgreementCompleted(byte[] agreementId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(CallAgreementCompleted),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(agreementId));
        }

        public static void CallAgreementConfirmed(byte[] agreementId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(CallAgreementConfirmed),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(agreementId));
        }

        public static void CallAgreementCreated(byte[] agreementId, UInt160 investor, UInt160 manufacturer, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(CallAgreementCreated),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(agreementId, investor, manufacturer, amount));
        }

        public static void CallAgreementDefaulted(byte[] agreementId)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(CallAgreementDefaulted),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(agreementId));
        }

        public static void CallInvestmentPaymentMade(byte[] agreementId, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(CallInvestmentPaymentMade),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(agreementId, amount));
        }

        public static void CallRepaymentMade(byte[] agreementId, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(CallRepaymentMade),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(agreementId, amount));
        }


        public static void finalizeVoting(string projectId, string votingType)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(finalizeVoting),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectId, votingType));
        }

        public static void withdrawBackerBalance(UInt160 backerAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawBackerBalance),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(backerAddress, amount));
        }

        public static void withdrawInvestorBalance(UInt160 investorAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawInvestorBalance),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(investorAddress, amount));
        }

        public static void withdrawManufacturerBalance(UInt160 manufacturerAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawManufacturerBalance),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(manufacturerAddress, amount));
        }

        public static void withdrawProjectCreatorBalance(UInt160 projectCreatorAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                         nameof(withdrawProjectCreatorBalance),
                                         TestNet,
                                         TestInvoke,
                                         DefaultUserWif,
                                         BuildParameters(projectCreatorAddress, amount));
        }
    }
}