﻿using InnFork.NeoN3;

using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using Neo;
using Neo.SmartContract;
using Neo.VM;

using InnFork.NeoN3.Enums;
using Neo.VM.Types;
using System.Threading.Tasks;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{
    public partial class IFPlatform
    {

        public partial class SCPlatform_Logic3
        {

            public static UInt160 Address = UInt160.Parse("0x482a39813ad1db98f946583c7f87f48f2fb72c73");
            public static bool TestNet = true;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; } = "";



            public static void addConditionalVotingRule(string projectId, string ruleId, BigInteger threshold)
            {

                ExecuteContractWithoutResult(Address,
                                                 nameof(addConditionalVotingRule),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, ruleId, threshold));
            }
            public static Task addConditionalVotingRuleAsync(string projectId, string ruleId, BigInteger threshold)
 => ExecuteContractWithoutResultAsync(Address, nameof(addConditionalVotingRule), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ruleId, threshold));


            public static BigInteger calculateVoteWeight(string projectId, UInt160 voterAddress, string voteId)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(calculateVoteWeight),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, voterAddress, voteId));
            }
            public static Task<BigInteger> calculateVoteWeightAsync(string projectId, UInt160 voterAddress, string voteId)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(calculateVoteWeight), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress, voteId));


            public static bool checkConditionalVotingStatus(string projectId, string ruleId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(checkConditionalVotingStatus),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, ruleId));
            }
            public static Task<bool> checkConditionalVotingStatusAsync(string projectId, string ruleId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(checkConditionalVotingStatus), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ruleId));


            public static string createBlockedFundsKey(UInt160 backerAddress, BanReason reason)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(createBlockedFundsKey),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(backerAddress, reason)) ?? string.Empty;
            }
            public static async Task<string> createBlockedFundsKeyAsync(UInt160 backerAddress, BanReason reason)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(createBlockedFundsKey), TestNet, TestInvoke, DefaultUserWif, BuildParameters(backerAddress, reason)) ?? string.Empty;


            public static string createDispute(string projectId, UInt160 initiator, DisputeType disputeType, string description, UInt160 manufacturerInvolved = null, byte milestoneStepInvolved = 0)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(createDispute),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, initiator, disputeType, description, manufacturerInvolved, milestoneStepInvolved)) ?? string.Empty;
            }
            public static async Task<string> createDisputeAsync(string projectId, UInt160 initiator, DisputeType disputeType, string description, UInt160 manufacturerInvolved = null, byte milestoneStepInvolved = 0)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(createDispute), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, initiator, disputeType, description, manufacturerInvolved, milestoneStepInvolved)) ?? string.Empty;


            public static void createMilestoneDispute(UInt160 initiatorAddress, string projectId, UInt160 manufacturerAddress, byte stepNumber, string disputeReason)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(createMilestoneDispute),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(initiatorAddress, projectId, manufacturerAddress, stepNumber, disputeReason));
            }
            public static Task createMilestoneDisputeAsync(UInt160 initiatorAddress, string projectId, UInt160 manufacturerAddress, byte stepNumber, string disputeReason)
 => ExecuteContractWithoutResultAsync(Address, nameof(createMilestoneDispute), TestNet, TestInvoke, DefaultUserWif, BuildParameters(initiatorAddress, projectId, manufacturerAddress, stepNumber, disputeReason));


            public static void distributeTokenRewards(string projectId, UInt160 backerAddress, BigInteger tokenAmount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(distributeTokenRewards),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, tokenAmount));
            }
            public static Task distributeTokenRewardsAsync(string projectId, UInt160 backerAddress, BigInteger tokenAmount)
 => ExecuteContractWithoutResultAsync(Address, nameof(distributeTokenRewards), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, tokenAmount));


            public static Dictionary<string, BigInteger> getMilestonePerformanceAnalytics(string projectId, UInt160 manufacturerAddress)
            {
                return ExecuteContractWithResult<Dictionary<string, BigInteger>>(Address,
                                                                         nameof(getMilestonePerformanceAnalytics),
                                                                         TestNet,
                                                                         TestInvoke,
                                                                         DefaultUserWif,
                                                                         BuildParameters(projectId, manufacturerAddress));
            }
            public static Task<Dictionary<string, BigInteger>> getMilestonePerformanceAnalyticsAsync(string projectId, UInt160 manufacturerAddress)
 => ExecuteContractWithResultAsync<Dictionary<string, BigInteger>>(Address, nameof(getMilestonePerformanceAnalytics), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress));


            public static BigInteger getParticipationTrend(string projectId, ulong startTimestamp, ulong endTimestamp)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getParticipationTrend),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, startTimestamp, endTimestamp));
            }
            public static Task<BigInteger> getParticipationTrendAsync(string projectId, ulong startTimestamp, ulong endTimestamp)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getParticipationTrend), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, startTimestamp, endTimestamp));


            public static Dictionary<string, BigInteger> getProjectAnalytics(string projectId)
            {
                return ExecuteContractWithResult<Dictionary<string, BigInteger>>(Address,
                                                                         nameof(getProjectAnalytics),
                                                                         TestNet,
                                                                         TestInvoke,
                                                                         DefaultUserWif,
                                                                         BuildParameters(projectId));
            }
            public static Task<Dictionary<string, BigInteger>> getProjectAnalyticsAsync(string projectId)
 => ExecuteContractWithResultAsync<Dictionary<string, BigInteger>>(Address, nameof(getProjectAnalytics), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));

            public static bool isValidStatusTransition(DisputeStatus current, DisputeStatus next)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isValidStatusTransition),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(current, next));
            }
            public static Task<bool> isValidStatusTransitionAsync(DisputeStatus current, DisputeStatus next)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isValidStatusTransition), TestNet, TestInvoke, DefaultUserWif, BuildParameters(current, next));


            public static void resolveDispute(string projectId, string disputeId, DisputeStatus newStatus, string resolutionNote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(resolveDispute),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, disputeId, newStatus, resolutionNote));
            }
            public static Task resolveDisputeAsync(string projectId, string disputeId, DisputeStatus newStatus, string resolutionNote)
 => ExecuteContractWithoutResultAsync(Address, nameof(resolveDispute), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, disputeId, newStatus, resolutionNote));



            public static void setRewardTokenContract(string projectId, UInt160 tokenContractAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setRewardTokenContract),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, tokenContractAddress));
            }
            public static Task setRewardTokenContractAsync(string projectId, UInt160 tokenContractAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(setRewardTokenContract), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, tokenContractAddress));

            public static void updateDailyParticipation(string projectId, ulong timestamp, BigInteger participantsCount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateDailyParticipation),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, timestamp, participantsCount));
            }
            public static Task updateDailyParticipationAsync(string projectId, ulong timestamp, BigInteger participantsCount)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateDailyParticipation), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, timestamp, participantsCount));


            public static void voteForTransferProjectManagementToInnFork(string projectId, UInt160 backer, bool votingFor)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(voteForTransferProjectManagementToInnFork),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, votingFor));
            }
            public static Task voteForTransferProjectManagementToInnForkAsync(string projectId, UInt160 backer, bool votingFor)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteForTransferProjectManagementToInnFork), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, votingFor));


            public static void voteFundraisingCompletion(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(voteFundraisingCompletion),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, vote));
            }
            public static Task voteFundraisingCompletionAsync(string projectId, UInt160 backer, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteFundraisingCompletion), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, vote));


            public static void voteIncreaseProjectBudget(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(voteIncreaseProjectBudget),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, vote));
            }
            public static Task voteIncreaseProjectBudgetAsync(string projectId, UInt160 backer, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteIncreaseProjectBudget), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, vote));


            public static void votePauseResume(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(votePauseResume),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, vote));
            }
            public static Task votePauseResumeAsync(string projectId, UInt160 backer, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(votePauseResume), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, vote));


            public static void voteSuccessfulClosure(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(voteSuccessfulClosure),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, vote));
            }
            public static Task voteSuccessfulClosureAsync(string projectId, UInt160 backer, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteSuccessfulClosure), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, vote));


            public static void voteTerminationWithRefund(string projectId, UInt160 backer, BackerVotesEnum vote)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(voteTerminationWithRefund),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backer, vote));
            }
            public static Task voteTerminationWithRefundAsync(string projectId, UInt160 backer, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteTerminationWithRefund), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, vote));




            public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(applyBackerBanSanctions),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, reason));
            }
            public static Task applyBackerBanSanctionsAsync(string projectId, UInt160 backerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(applyBackerBanSanctions), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, reason));

            public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(banBacker),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, reason));
            }
            public static Task banBackerAsync(string projectId, UInt160 backerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(banBacker), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, reason));

            public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(blockBackerFinance),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId, backerAddress, banReason, amountToBlock));
            }
            public static Task blockBackerFinanceAsync(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
 => ExecuteContractWithoutResultAsync(Address, nameof(blockBackerFinance), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, banReason, amountToBlock));


            public static BigInteger getRiskScoreForBanReason(BanReason reason)
            {

                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getRiskScoreForBanReason),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(reason));
            }
            public static Task<BigInteger> getRiskScoreForBanReasonAsync(BanReason reason)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getRiskScoreForBanReason), TestNet, TestInvoke, DefaultUserWif, BuildParameters(reason));


            public static bool isParticipantBanned(string projectId, UInt160 participantAddress)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                            nameof(isParticipantBanned),
                                                            TestNet,
                                                            TestInvoke,
                                                            DefaultUserWif,
                                                            BuildParameters(projectId, participantAddress));
            }
            public static Task<bool> isParticipantBannedAsync(string projectId, UInt160 participantAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isParticipantBanned), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, participantAddress));


        }
    }
}