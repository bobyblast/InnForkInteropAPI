﻿using InnFork.NeoN3;

using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using Neo;
using Neo.SmartContract;


using InnFork.NeoN3.Enums;
using Neo.VM.Types;
using System.Threading.Tasks;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;

public partial class IFPlatform
{
    public partial class SCPlatform_Logic1
    {
        public static UInt160 Address = UInt160.Parse("0x201dcf53b7798b551cde4c4dedb929f624ba9917");
        public static bool TestNet = true;
        public static bool TestInvoke = false;
        public static string? DefaultUserWif { get; set; } = "";



        public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(applyBackerBanSanctions),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backerAddress, reason));
        }
        public static Task applyBackerBanSanctionsAsync(string projectId, UInt160 backerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(applyBackerBanSanctions), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, reason));


        public static void applyManufacturerBanSanctions(string projectId, UInt160 manufacturerAddress, BanReason reason)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(applyManufacturerBanSanctions),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress, reason));
        }
        public static Task applyManufacturerBanSanctionsAsync(string projectId, UInt160 manufacturerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(applyManufacturerBanSanctions), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, reason));


        public static void applyRejectionPenalty(string projectId, UInt160 initiator, DisputeType disputeType)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(applyRejectionPenalty),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, initiator, disputeType));
        }
        public static Task applyRejectionPenaltyAsync(string projectId, UInt160 initiator, DisputeType disputeType)
 => ExecuteContractWithoutResultAsync(Address, nameof(applyRejectionPenalty), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, initiator, disputeType));


        public static void autoProgressMilestones(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(autoProgressMilestones),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId));
        }
        public static Task autoProgressMilestonesAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(autoProgressMilestones), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


        public static void autoRollbackOnDisputeResolution(string projectId, string disputeId, UInt160 manufacturerAddress, byte stepNumber)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(autoRollbackOnDisputeResolution),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, disputeId, manufacturerAddress, stepNumber));
        }
        public static Task autoRollbackOnDisputeResolutionAsync(string projectId, string disputeId, UInt160 manufacturerAddress, byte stepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(autoRollbackOnDisputeResolution), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, disputeId, manufacturerAddress, stepNumber));


        public static void autoStartNextMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(autoStartNextMilestone),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturer, stepNumber));
        }
        public static Task autoStartNextMilestoneAsync(string projectId, UInt160 manufacturer, byte stepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(autoStartNextMilestone), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer, stepNumber));


        public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(banBacker),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backerAddress, reason));
        }
        public static Task banBackerAsync(string projectId, UInt160 backerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(banBacker), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, reason));


        public static void banManufacturer(string projectId, UInt160 manufacturerAddress, BanReason reason)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(banManufacturer),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress, reason));
        }
        public static Task banManufacturerAsync(string projectId, UInt160 manufacturerAddress, BanReason reason)
 => ExecuteContractWithoutResultAsync(Address, nameof(banManufacturer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, reason));


        public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(blockBackerFinance),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backerAddress, banReason, amountToBlock));
        }
        public static Task blockBackerFinanceAsync(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
 => ExecuteContractWithoutResultAsync(Address, nameof(blockBackerFinance), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, banReason, amountToBlock));


        public static ProjectAccount.CalculatedVoteOutcome calculateInternalVoteOutcome(string projectId, Dictionary<UInt160, BackerVotesEnum> votesMap, string votingType, BigInteger explicitPositiveRaw, BigInteger explicitNegativeRaw, BigInteger explicitAbstainedRaw, BigInteger totalCastedRaw)
        {
            return ExecuteContractWithResult<ProjectAccount.CalculatedVoteOutcome>(Address,
                                                     nameof(calculateInternalVoteOutcome),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, votesMap, votingType, explicitPositiveRaw, explicitNegativeRaw, explicitAbstainedRaw, totalCastedRaw)) ?? new ProjectAccount.CalculatedVoteOutcome();
        }
        public static async Task<ProjectAccount.CalculatedVoteOutcome> calculateInternalVoteOutcomeAsync(string projectId, Dictionary<UInt160, BackerVotesEnum> votesMap, string votingType, BigInteger explicitPositiveRaw, BigInteger explicitNegativeRaw, BigInteger explicitAbstainedRaw, BigInteger totalCastedRaw)
 => await ExecuteContractWithResultAsync<ProjectAccount.CalculatedVoteOutcome>(Address, nameof(calculateInternalVoteOutcome), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, votesMap, votingType, explicitPositiveRaw, explicitNegativeRaw, explicitAbstainedRaw, totalCastedRaw)) ?? new ProjectAccount.CalculatedVoteOutcome();


        public static bool canBackerVote(string projectId, UInt160 backer, bool ignoreAlreadyVoted = false)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(canBackerVote),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, backer, ignoreAlreadyVoted));
        }
        public static Task<bool> canBackerVoteAsync(string projectId, UInt160 backer, bool ignoreAlreadyVoted = false)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(canBackerVote), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, ignoreAlreadyVoted));


        public static bool canWithdrawReservedForManufacturerFunds(string projectId, UInt160 backer, UInt160 manufacturer)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(canWithdrawReservedForManufacturerFunds),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, backer, manufacturer));
        }
        public static Task<bool> canWithdrawReservedForManufacturerFundsAsync(string projectId, UInt160 backer, UInt160 manufacturer)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(canWithdrawReservedForManufacturerFunds), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, manufacturer));


        public static void checkAndRollbackExpiredMilestones(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(checkAndRollbackExpiredMilestones),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId));
        }
        public static Task checkAndRollbackExpiredMilestonesAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(checkAndRollbackExpiredMilestones), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


        public static bool checkMilestoneExpired(string projectId, UInt160 manufacturer, byte checkMilestoneStep)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(checkMilestoneExpired),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, manufacturer, checkMilestoneStep));
        }
        public static Task<bool> checkMilestoneExpiredAsync(string projectId, UInt160 manufacturer, byte checkMilestoneStep)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(checkMilestoneExpired), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer, checkMilestoneStep));


        public static void clearPenalty(string projectId, UInt160 manufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(clearPenalty),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress));
        }
        public static Task clearPenaltyAsync(string projectId, UInt160 manufacturerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(clearPenalty), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress));


        public static MilestoneTemplate createDefaultTemplate(byte stepNumber, ProjectAccount project)
        {
            return ExecuteContractWithResult<MilestoneTemplate>(Address,
                                                     nameof(createDefaultTemplate),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(stepNumber, project)) ?? new MilestoneTemplate();
        }
        public static async Task<MilestoneTemplate> createDefaultTemplateAsync(byte stepNumber, ProjectAccount project)
 => await ExecuteContractWithResultAsync<MilestoneTemplate>(Address, nameof(createDefaultTemplate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(stepNumber, project)) ?? new MilestoneTemplate();


        public static MilestoneTemplate createDevelopmentTemplate(byte stepNumber)
        {
            return ExecuteContractWithResult<MilestoneTemplate>(Address,
                                                     nameof(createDevelopmentTemplate),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(stepNumber)) ?? new MilestoneTemplate();
        }
        public static async Task<MilestoneTemplate> createDevelopmentTemplateAsync(byte stepNumber)
 => await ExecuteContractWithResultAsync<MilestoneTemplate>(Address, nameof(createDevelopmentTemplate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(stepNumber)) ?? new MilestoneTemplate();


        public static MilestoneTemplate createManufacturingTemplate(byte stepNumber)
        {
            return ExecuteContractWithResult<MilestoneTemplate>(Address,
                                                     nameof(createManufacturingTemplate),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(stepNumber)) ?? new MilestoneTemplate();
        }
        public static async Task<MilestoneTemplate> createManufacturingTemplateAsync(byte stepNumber)
 => await ExecuteContractWithResultAsync<MilestoneTemplate>(Address, nameof(createManufacturingTemplate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(stepNumber)) ?? new MilestoneTemplate();


        public static void createMilestoneRequest(string projectId, UInt160 manufacturer, byte stepNumber, string name, string description, BigInteger requestedAmount, ulong deadline, ulong votingDuration, BigInteger minimumVotes)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(createMilestoneRequest),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturer, stepNumber, name, description, requestedAmount, deadline, votingDuration, minimumVotes));
        }
        public static Task createMilestoneRequestAsync(string projectId, UInt160 manufacturer, byte stepNumber, string name, string description, BigInteger requestedAmount, ulong deadline, ulong votingDuration, BigInteger minimumVotes)
 => ExecuteContractWithoutResultAsync(Address, nameof(createMilestoneRequest), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer, stepNumber, name, description, requestedAmount, deadline, votingDuration, minimumVotes));


        public static MilestoneTemplate createResearchTemplate(byte stepNumber)
        {
            return ExecuteContractWithResult<MilestoneTemplate>(Address,
                                                     nameof(createResearchTemplate),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(stepNumber)) ?? new MilestoneTemplate();
        }
        public static async Task<MilestoneTemplate> createResearchTemplateAsync(byte stepNumber)
 => await ExecuteContractWithResultAsync<MilestoneTemplate>(Address, nameof(createResearchTemplate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(stepNumber)) ?? new MilestoneTemplate();


        public static MilestoneTemplate createTestingTemplate(byte stepNumber)
        {
            return ExecuteContractWithResult<MilestoneTemplate>(Address,
                                                     nameof(createTestingTemplate),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(stepNumber)) ?? new MilestoneTemplate();
        }
        public static async Task<MilestoneTemplate> createTestingTemplateAsync(byte stepNumber)
 => await ExecuteContractWithResultAsync<MilestoneTemplate>(Address, nameof(createTestingTemplate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(stepNumber)) ?? new MilestoneTemplate();



        public static void finalizeProjectUpdateVoting(string projectId, string updateId)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(finalizeProjectUpdateVoting),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, updateId));
        }
        public static Task finalizeProjectUpdateVotingAsync(string projectId, string updateId)
 => ExecuteContractWithoutResultAsync(Address, nameof(finalizeProjectUpdateVoting), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, updateId));


        public static bool getBackerVoteStatusByComplexKey_BackerAddress_UpdateHash(string projectId, string UpdateHash, UInt160 backerAddress)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(getBackerVoteStatusByComplexKey_BackerAddress_UpdateHash),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, UpdateHash, backerAddress));
        }
        public static Task<bool> getBackerVoteStatusByComplexKey_BackerAddress_UpdateHashAsync(string projectId, string UpdateHash, UInt160 backerAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(getBackerVoteStatusByComplexKey_BackerAddress_UpdateHash), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, UpdateHash, backerAddress));


        public static BigInteger getBackerVoteWeight(string projectId, UInt160 backer)
        {
            return ExecuteContractWithResult<BigInteger>(Address,
                                                     nameof(getBackerVoteWeight),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, backer));
        }
        public static Task<BigInteger> getBackerVoteWeightAsync(string projectId, UInt160 backer)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getBackerVoteWeight), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer));


        public static UInt160 getFinalDelegateForVoting(string projectId, Dictionary<Dictionary<string, UInt160>, UInt160> delegationMap, UInt160 backerAddress)
        {
            return ExecuteContractWithResult<UInt160>(Address,
                                                     nameof(getFinalDelegateForVoting),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, delegationMap, backerAddress)) ?? UInt160.Zero;
        }
        public static async Task<UInt160> getFinalDelegateForVotingAsync(string projectId, Dictionary<Dictionary<string, UInt160>, UInt160> delegationMap, UInt160 backerAddress)
 => await ExecuteContractWithResultAsync<UInt160>(Address, nameof(getFinalDelegateForVoting), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, delegationMap, backerAddress)) ?? UInt160.Zero;


        public static byte getLatestMilestoneStepByManufacturer(string projectId, UInt160 manufacturer)
        {
            return ExecuteContractWithResult<byte>(Address,
                                                     nameof(getLatestMilestoneStepByManufacturer),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, manufacturer));
        }
        public static Task<byte> getLatestMilestoneStepByManufacturerAsync(string projectId, UInt160 manufacturer)
 => ExecuteContractWithResultAsync<byte>(Address, nameof(getLatestMilestoneStepByManufacturer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer));


        public static ulong getManufacturerLastPenaltyTime(string projectId, UInt160 manufacturerAddress)
        {
            return ExecuteContractWithResult<ulong>(Address,
                                                     nameof(getManufacturerLastPenaltyTime),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, manufacturerAddress));
        }
        public static Task<ulong> getManufacturerLastPenaltyTimeAsync(string projectId, UInt160 manufacturerAddress)
 => ExecuteContractWithResultAsync<ulong>(Address, nameof(getManufacturerLastPenaltyTime), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress));


        public static BigInteger getManufacturerTotalPenalties(string projectId, UInt160 manufacturerAddress)
        {
            return ExecuteContractWithResult<BigInteger>(Address,
                                                     nameof(getManufacturerTotalPenalties),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, manufacturerAddress));
        }
        public static Task<BigInteger> getManufacturerTotalPenaltiesAsync(string projectId, UInt160 manufacturerAddress)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getManufacturerTotalPenalties), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress));


        public static bool getMilestoneCompletionVotingStatus(string projectId, UInt160 manufacturerAddress, byte milestoneStep)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(getMilestoneCompletionVotingStatus),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, manufacturerAddress, milestoneStep));
        }
        public static Task<bool> getMilestoneCompletionVotingStatusAsync(string projectId, UInt160 manufacturerAddress, byte milestoneStep)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(getMilestoneCompletionVotingStatus), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, milestoneStep));


        public static MilestoneTemplate getMilestoneTemplate(ProjectAccount project, UInt160 manufacturer, byte stepNumber, string templateType = "default")
        {
            return ExecuteContractWithResult<MilestoneTemplate>(Address,
                                                     nameof(getMilestoneTemplate),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(project, manufacturer, stepNumber, templateType)) ?? new MilestoneTemplate();
        }
        public static async Task<MilestoneTemplate> getMilestoneTemplateAsync(ProjectAccount project, UInt160 manufacturer, byte stepNumber, string templateType = "default")
 => await ExecuteContractWithResultAsync<MilestoneTemplate>(Address, nameof(getMilestoneTemplate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(project, manufacturer, stepNumber, templateType)) ?? new MilestoneTemplate();




        public static BanReason getParticipantBanReason(string projectId, UInt160 participantAddress)
        {
            return ExecuteContractWithResult<BanReason>(Address,
                                                     nameof(getParticipantBanReason),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, participantAddress));
        }
        public static Task<BanReason> getParticipantBanReasonAsync(string projectId, UInt160 participantAddress)
 => ExecuteContractWithResultAsync<BanReason>(Address, nameof(getParticipantBanReason), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, participantAddress));


        public static ProjectAccount getProjectAccount(string projectId)
        {
            return ExecuteContractWithResult<ProjectAccount>(Address,
                                                     nameof(getProjectAccount),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId)) ?? new ProjectAccount();
        }
        public static async Task<ProjectAccount> getProjectAccountAsync(string projectId)
 => await ExecuteContractWithResultAsync<ProjectAccount>(Address, nameof(getProjectAccount), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId)) ?? new ProjectAccount();


        public static BigInteger getRiskScoreForBanReason(BanReason reason)
        {
            return ExecuteContractWithResult<BigInteger>(Address,
                                                     nameof(getRiskScoreForBanReason),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(reason));
        }
        public static Task<BigInteger> getRiskScoreForBanReasonAsync(BanReason reason)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getRiskScoreForBanReason), TestNet, TestInvoke, DefaultUserWif, BuildParameters(reason));


        public static string[] getSerializedGlobalProjectsAccountsList()
        {
            return ExecuteContractWithResult<string[]>(Address,
                                                     nameof(getSerializedGlobalProjectsAccountsList),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters()) ?? System.Array.Empty<string>();
        }
        public static async Task<string[]> getSerializedGlobalProjectsAccountsListAsync()
 => await ExecuteContractWithResultAsync<string[]>(Address, nameof(getSerializedGlobalProjectsAccountsList), TestNet, TestInvoke, DefaultUserWif, BuildParameters()) ?? System.Array.Empty<string>();


        public static void handleGeneralEscalation(string projectId, string disputeId)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(handleGeneralEscalation),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, disputeId));
        }
        public static Task handleGeneralEscalationAsync(string projectId, string disputeId)
 => ExecuteContractWithoutResultAsync(Address, nameof(handleGeneralEscalation), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, disputeId));


        public static void handleInvestorRollback(string projectId, UInt160 manufacturerAddress, BigInteger rolledBackAmount)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(handleInvestorRollback),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress, rolledBackAmount));
        }
        public static Task handleInvestorRollbackAsync(string projectId, UInt160 manufacturerAddress, BigInteger rolledBackAmount)
 => ExecuteContractWithoutResultAsync(Address, nameof(handleInvestorRollback), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, rolledBackAmount));


        public static void imposePenalty(string projectId, UInt160 manufacturerAddress, BigInteger penaltyAmount)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(imposePenalty),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress, penaltyAmount));
        }
        public static Task imposePenaltyAsync(string projectId, UInt160 manufacturerAddress, BigInteger penaltyAmount)
 => ExecuteContractWithoutResultAsync(Address, nameof(imposePenalty), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, penaltyAmount));


        public static bool isEligibleToVote(string projectId, UInt160 backerAddress)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(isEligibleToVote),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, backerAddress));
        }
        public static Task<bool> isEligibleToVoteAsync(string projectId, UInt160 backerAddress)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isEligibleToVote), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress));


        public static bool isProjectOpen(string projectId)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(isProjectOpen),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId));
        }
        public static Task<bool> isProjectOpenAsync(string projectId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isProjectOpen), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


        public static void lockFunds(string projectId, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(lockFunds),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, amount));
        }
        public static Task lockFundsAsync(string projectId, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(lockFunds), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, amount));


        public static void processAutomaticUnbans(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(processAutomaticUnbans),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId));
        }
        public static Task processAutomaticUnbansAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(processAutomaticUnbans), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


        public static void processMilestoneConditionalFunding(UInt160 manufacturerAddress, string projectId, byte stepNumber, BigInteger conditionalAmount)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(processMilestoneConditionalFunding),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(manufacturerAddress, projectId, stepNumber, conditionalAmount));
        }
        public static Task processMilestoneConditionalFundingAsync(UInt160 manufacturerAddress, string projectId, byte stepNumber, BigInteger conditionalAmount)
 => ExecuteContractWithoutResultAsync(Address, nameof(processMilestoneConditionalFunding), TestNet, TestInvoke, DefaultUserWif, BuildParameters(manufacturerAddress, projectId, stepNumber, conditionalAmount));


        public static void processMilestoneFunding(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(processMilestoneFunding),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturer, stepNumber));
        }
        public static Task processMilestoneFundingAsync(string projectId, UInt160 manufacturer, byte stepNumber)
 => ExecuteContractWithoutResultAsync(Address, nameof(processMilestoneFunding), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer, stepNumber));



        public static void removeManufacturerCandidate(string projectId, UInt160 ManufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(removeManufacturerCandidate),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, ManufacturerAddress));
        }
        public static Task removeManufacturerCandidateAsync(string projectId, UInt160 ManufacturerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(removeManufacturerCandidate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, ManufacturerAddress));


        public static void removeManufacturerCandidateFromAllProjects(UInt160 manufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(removeManufacturerCandidateFromAllProjects),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(manufacturerAddress));
        }
        public static Task removeManufacturerCandidateFromAllProjectsAsync(UInt160 manufacturerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(removeManufacturerCandidateFromAllProjects), TestNet, TestInvoke, DefaultUserWif, BuildParameters(manufacturerAddress));


        public static void requestMilestoneCompletion(UInt160 manufacturerAddress, string projectId, byte stepNumber, string completionProof, byte[] verificationData)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(requestMilestoneCompletion),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(manufacturerAddress, projectId, stepNumber, completionProof, verificationData));
        }
        public static Task requestMilestoneCompletionAsync(UInt160 manufacturerAddress, string projectId, byte stepNumber, string completionProof, byte[] verificationData)
 => ExecuteContractWithoutResultAsync(Address, nameof(requestMilestoneCompletion), TestNet, TestInvoke, DefaultUserWif, BuildParameters(manufacturerAddress, projectId, stepNumber, completionProof, verificationData));


        public static void requireMilestoneVerification(string projectId, string milestoneId, bool required)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(requireMilestoneVerification),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, milestoneId, required));
        }
        public static Task requireMilestoneVerificationAsync(string projectId, string milestoneId, bool required)
 => ExecuteContractWithoutResultAsync(Address, nameof(requireMilestoneVerification), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, milestoneId, required));


        public static void resetProjectWinnerStatus(string projectId)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(resetProjectWinnerStatus),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId));
        }
        public static Task resetProjectWinnerStatusAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(resetProjectWinnerStatus), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


        public static void returnAllReservedInvestmentsFromCandidate(string projectId, UInt160 manufacturerAddress)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(returnAllReservedInvestmentsFromCandidate),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress));
        }
        public static Task returnAllReservedInvestmentsFromCandidateAsync(string projectId, UInt160 manufacturerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(returnAllReservedInvestmentsFromCandidate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress));


        public static void returnInvestmentToInvestor(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(returnInvestmentToInvestor),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, investorAddress, manufacturerAddress, amount));
        }
        public static Task returnInvestmentToInvestorAsync(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(returnInvestmentToInvestor), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, investorAddress, manufacturerAddress, amount));


        public static void rollbackMilestoneFunding(string projectId, UInt160 manufacturerAddress, byte stepNumber, string rollbackReason)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(rollbackMilestoneFunding),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress, stepNumber, rollbackReason));
        }
        public static Task rollbackMilestoneFundingAsync(string projectId, UInt160 manufacturerAddress, byte stepNumber, string rollbackReason)
 => ExecuteContractWithoutResultAsync(Address, nameof(rollbackMilestoneFunding), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, stepNumber, rollbackReason));


        public static void setBackerVoteStatusByComplexKey_BackerAddress_UpdateHash(string projectId, string UpdateHash, UInt160 backerAddress, BackerVotesEnum BackerVote)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(setBackerVoteStatusByComplexKey_BackerAddress_UpdateHash),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, UpdateHash, backerAddress, BackerVote));
        }
        public static Task setBackerVoteStatusByComplexKey_BackerAddress_UpdateHashAsync(string projectId, string UpdateHash, UInt160 backerAddress, BackerVotesEnum BackerVote)
 => ExecuteContractWithoutResultAsync(Address, nameof(setBackerVoteStatusByComplexKey_BackerAddress_UpdateHash), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, UpdateHash, backerAddress, BackerVote));


        public static bool shouldAutoStartNextMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
        {
            return ExecuteContractWithResult<bool>(Address,
                                                     nameof(shouldAutoStartNextMilestone),
                                                     TestNet,
                                                     TestInvoke,
                                                     DefaultUserWif,
                                                     BuildParameters(projectId, manufacturer, stepNumber));
        }
        public static Task<bool> shouldAutoStartNextMilestoneAsync(string projectId, UInt160 manufacturer, byte stepNumber)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(shouldAutoStartNextMilestone), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer, stepNumber));


        public static void startMilestoneVoting(string projectId, UInt160 manufacturer, byte stepNumber, ulong duration, BigInteger minimumVotes)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(startMilestoneVoting),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturer, stepNumber, duration, minimumVotes));
        }
        public static Task startMilestoneVotingAsync(string projectId, UInt160 manufacturer, byte stepNumber, ulong duration, BigInteger minimumVotes)
 => ExecuteContractWithoutResultAsync(Address, nameof(startMilestoneVoting), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturer, stepNumber, duration, minimumVotes));


        public static void submitMilestoneVerification(UInt160 validatorAddress, string projectId, UInt160 manufacturerAddress, byte stepNumber, bool isVerified, string verificationReport)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(submitMilestoneVerification),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(validatorAddress, projectId, manufacturerAddress, stepNumber, isVerified, verificationReport));
        }
        public static Task submitMilestoneVerificationAsync(UInt160 validatorAddress, string projectId, UInt160 manufacturerAddress, byte stepNumber, bool isVerified, string verificationReport)
 => ExecuteContractWithoutResultAsync(Address, nameof(submitMilestoneVerification), TestNet, TestInvoke, DefaultUserWif, BuildParameters(validatorAddress, projectId, manufacturerAddress, stepNumber, isVerified, verificationReport));


        public static void unBlockBackerFinance(string projectId, UInt160 backerAddress, BigInteger amountToRestore)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(unBlockBackerFinance),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backerAddress, amountToRestore));
        }
        public static Task unBlockBackerFinanceAsync(string projectId, UInt160 backerAddress, BigInteger amountToRestore)
 => ExecuteContractWithoutResultAsync(Address, nameof(unBlockBackerFinance), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress, amountToRestore));


        public static void unlockFunds(string projectId, BigInteger amount)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(unlockFunds),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, amount));
        }
        public static Task unlockFundsAsync(string projectId, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(unlockFunds), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, amount));



        public static void updateManufacturerReputationAfterPenalty(string projectId, UInt160 manufacturerAddress, BigInteger penaltyAmount)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(updateManufacturerReputationAfterPenalty),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, manufacturerAddress, penaltyAmount));
        }
        public static Task updateManufacturerReputationAfterPenaltyAsync(string projectId, UInt160 manufacturerAddress, BigInteger penaltyAmount)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateManufacturerReputationAfterPenalty), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, penaltyAmount));


        public static void verifyMilestone(string projectId, string milestoneId, bool verified)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(verifyMilestone),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, milestoneId, verified));
        }
        public static Task verifyMilestoneAsync(string projectId, string milestoneId, bool verified)
 => ExecuteContractWithoutResultAsync(Address, nameof(verifyMilestone), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, milestoneId, verified));


        public static void voteAbstain(string projectId, UInt160 voterAddress, int voteType, string updateHash)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(voteAbstain),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, voterAddress, voteType, updateHash));
        }
        public static Task voteAbstainAsync(string projectId, UInt160 voterAddress, int voteType, string updateHash)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteAbstain), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, voterAddress, voteType, updateHash));


        public static void voteForManufacturerWinner(string projectId, UInt160 backer, UInt160 manufacturer, BackerVotesEnum vote)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(voteForManufacturerWinner),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backer, manufacturer, vote));
        }
        public static Task voteForManufacturerWinnerAsync(string projectId, UInt160 backer, UInt160 manufacturer, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteForManufacturerWinner), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, manufacturer, vote));


        public static void voteProjectUpdate(string projectId, UInt160 backer, string updateId, BackerVotesEnum vote)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(voteProjectUpdate),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backer, updateId, vote));
        }
        public static Task voteProjectUpdateAsync(string projectId, UInt160 backer, string updateId, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteProjectUpdate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, updateId, vote));


        public static void voteToMilestoneCompletionStep(string projectId, UInt160 backer, UInt160 manufacturerCandidate, byte stepNumber, BackerVotesEnum vote)
        {
            ExecuteContractWithoutResult(Address,
                                             nameof(voteToMilestoneCompletionStep),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, backer, manufacturerCandidate, stepNumber, vote));
        }
        public static Task voteToMilestoneCompletionStepAsync(string projectId, UInt160 backer, UInt160 manufacturerCandidate, byte stepNumber, BackerVotesEnum vote)
 => ExecuteContractWithoutResultAsync(Address, nameof(voteToMilestoneCompletionStep), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backer, manufacturerCandidate, stepNumber, vote));


    }
}