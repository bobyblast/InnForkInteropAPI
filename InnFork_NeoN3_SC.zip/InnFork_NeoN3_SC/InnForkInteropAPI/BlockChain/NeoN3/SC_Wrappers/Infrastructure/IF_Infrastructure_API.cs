﻿using InnFork.Blockchain.NEO3;
using InnFork.NeoN3;
using InnFork.NeoN3.Enums;
using Neo;
using Neo.SmartContract;
using Neo.VM.Types;
using System;
using System.IO.Packaging;
using System.Numerics;
using System.Threading.Tasks;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{

    public partial class IFPlatform
    {

        public partial class SCPlatform_Infrastructure
        {
            public static UInt160 Address = UInt160.Parse("0xf2d67848ff0416f32ac0d4147524c5ee0de722c9");



            public static bool TestNet = true;
            public static bool TestInvoke = false;

            public static string? DefaultUserWif { get; set; } = "";


            public static void autoSetToPause(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(autoSetToPause),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }
            public static Task autoSetToPauseAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(autoSetToPause), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static BigInteger calculateTotalReservedForOffer(string offerId)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(calculateTotalReservedForOffer),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(offerId));
            }
            public static Task<BigInteger> calculateTotalReservedForOfferAsync(string offerId)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(calculateTotalReservedForOffer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(offerId));


            public static int getContractVersion()
            {
                return ExecuteContractWithResult<int>(Address,
                                                         nameof(getContractVersion),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters());
            }
            public static Task<int> getContractVersionAsync()
 => ExecuteContractWithResultAsync<int>(Address, nameof(getContractVersion), TestNet, TestInvoke, DefaultUserWif, BuildParameters());


            public static string getContractVersionChangelog()
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(getContractVersionChangelog),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters()) ?? string.Empty;
            }
            public static async Task<string> getContractVersionChangelogAsync()
 => await ExecuteContractWithResultAsync<string>(Address, nameof(getContractVersionChangelog), TestNet, TestInvoke, DefaultUserWif, BuildParameters()) ?? string.Empty;


            public static int getCountOfSelectedMapName(string MapName)
            {
                return ExecuteContractWithResult<int>(Address,
                                                         nameof(getCountOfSelectedMapName),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(MapName));
            }
            public static Task<int> getCountOfSelectedMapNameAsync(string MapName)
 => ExecuteContractWithResultAsync<int>(Address, nameof(getCountOfSelectedMapName), TestNet, TestInvoke, DefaultUserWif, BuildParameters(MapName));


            public static int getCountOf_Sha256Offers()
            {
                return ExecuteContractWithResult<int>(Address,
                                                         nameof(getCountOf_Sha256Offers),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters());
            }
            public static Task<int> getCountOf_Sha256OffersAsync()
 => ExecuteContractWithResultAsync<int>(Address, nameof(getCountOf_Sha256Offers), TestNet, TestInvoke, DefaultUserWif, BuildParameters());


            public static UInt160 GetModeratorContractHash()
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(GetModeratorContractHash),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters()) ?? UInt160.Zero;
            }
            public static async Task<UInt160> GetModeratorContractHashAsync()
 => await ExecuteContractWithResultAsync<UInt160>(Address, nameof(GetModeratorContractHash), TestNet, TestInvoke, DefaultUserWif, BuildParameters()) ?? UInt160.Zero;


            public static bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(getProjectStatusAsBoolean),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(ProjectId, statusType));
            }
            public static Task<bool> getProjectStatusAsBooleanAsync(string ProjectId, ProjectStateRequest statusType)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(getProjectStatusAsBoolean), TestNet, TestInvoke, DefaultUserWif, BuildParameters(ProjectId, statusType));


            public static string[] getProjectStatuses(string projectId)
            {
                return ExecuteContractWithResult<string[]>(Address,
                                                         nameof(getProjectStatuses),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId)) ?? System.Array.Empty<string>();
            }
            public static async Task<string[]> getProjectStatusesAsync(string projectId)
 => await ExecuteContractWithResultAsync<string[]>(Address, nameof(getProjectStatuses), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId)) ?? System.Array.Empty<string>();


            public static string[] getSerializedGlobalProjectsPackagesList()
            {
                return ExecuteContractWithResult<string[]>(Address,
                                                         nameof(getSerializedGlobalProjectsPackagesList),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters()) ?? System.Array.Empty<string>();
            }
            public static async Task<string[]> getSerializedGlobalProjectsPackagesListAsync()
 => await ExecuteContractWithResultAsync<string[]>(Address, nameof(getSerializedGlobalProjectsPackagesList), TestNet, TestInvoke, DefaultUserWif, BuildParameters()) ?? System.Array.Empty<string>();


            public static UInt160 GetStateContractHash()
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(GetStateContractHash),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters()) ?? UInt160.Zero;
            }
            public static async Task<UInt160> GetStateContractHashAsync()
 => await ExecuteContractWithResultAsync<UInt160>(Address, nameof(GetStateContractHash), TestNet, TestInvoke, DefaultUserWif, BuildParameters()) ?? UInt160.Zero;


            public static BigInteger getTotalReservedDonatesToOffer(string offerSha256Id)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getTotalReservedDonatesToOffer),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(offerSha256Id));
            }
            public static Task<BigInteger> getTotalReservedDonatesToOfferAsync(string offerSha256Id)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getTotalReservedDonatesToOffer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(offerSha256Id));


            public static void ImportNewProjectSettings(string jsonSettings)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(ImportNewProjectSettings),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(jsonSettings));
            }
            public static Task ImportNewProjectSettingsAsync(string jsonSettings)
 => ExecuteContractWithoutResultAsync(Address, nameof(ImportNewProjectSettings), TestNet, TestInvoke, DefaultUserWif, BuildParameters(jsonSettings));


            public static bool isProjectRegistered(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(isProjectRegistered),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }
            public static Task<bool> isProjectRegisteredAsync(string projectId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(isProjectRegistered), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static void OverrideModeratorContract(UInt160 newContract)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(OverrideModeratorContract),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(newContract));
            }
            public static Task OverrideModeratorContractAsync(UInt160 newContract)
 => ExecuteContractWithoutResultAsync(Address, nameof(OverrideModeratorContract), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newContract));


            public static void OverrideStateContract(UInt160 newHash)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(OverrideStateContract),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(newHash));
            }
            public static Task OverrideStateContractAsync(UInt160 newHash)
 => ExecuteContractWithoutResultAsync(Address, nameof(OverrideStateContract), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newHash));


            public static string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(registerProjectEx),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(ProjectCreatorId, AuthorPubKey, ProjectJson, signatureOfJson, pubKeyOfJsonSigner, ProjectOfferId_Sha256, bool_StoreOffer, projectOfferJson, WinnerDollars_GoalFund)) ?? string.Empty;
            }
            public static async Task<string> registerProjectExAsync(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner, string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson, BigInteger WinnerDollars_GoalFund)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(registerProjectEx), TestNet, TestInvoke, DefaultUserWif, BuildParameters(ProjectCreatorId, AuthorPubKey, ProjectJson, signatureOfJson, pubKeyOfJsonSigner, ProjectOfferId_Sha256, bool_StoreOffer, projectOfferJson, WinnerDollars_GoalFund)) ?? string.Empty;



            public static void removeOffer(string offerSha256Id)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(removeOffer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(offerSha256Id));
            }
            public static Task removeOfferAsync(string offerSha256Id)
 => ExecuteContractWithoutResultAsync(Address, nameof(removeOffer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(offerSha256Id));


            /* public static void removeProjectFromGlobalProjectsLists(ProjectAccount Account)
 {
 ExecuteContractWithoutResult(Address,
 nameof(removeProjectFromGlobalProjectsLists),
 TestNet,
 TestInvoke,
 DefaultUserWif,
 BuildParameters(Account));
 }
*/

            public static void removeProjectFromGlobalProjectsListsByProjectId(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(removeProjectFromGlobalProjectsListsByProjectId),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }
            public static Task removeProjectFromGlobalProjectsListsByProjectIdAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(removeProjectFromGlobalProjectsListsByProjectId), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(removeProjectOfferByTimeLine),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectCreatorAddress, offerSha256Id));
            }
            public static Task<bool> removeProjectOfferByTimeLineAsync(UInt160 projectCreatorAddress, string offerSha256Id)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(removeProjectOfferByTimeLine), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectCreatorAddress, offerSha256Id));


            public static void resumeProject(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(resumeProject),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(projectId));
            }
            public static Task resumeProjectAsync(string projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(resumeProject), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));

            public static void SetModeratorContractHash(UInt160 newContract)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetModeratorContractHash),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(newContract));
            }
            public static Task SetModeratorContractHashAsync(UInt160 newContract)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetModeratorContractHash), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newContract));


            public static void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setProjectOfferShortJsonToExistingProject),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(offerShortJson, ProjectOfferId_Sha256, projectIdSha256));
            }
            public static Task setProjectOfferShortJsonToExistingProjectAsync(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256)
 => ExecuteContractWithoutResultAsync(Address, nameof(setProjectOfferShortJsonToExistingProject), TestNet, TestInvoke, DefaultUserWif, BuildParameters(offerShortJson, ProjectOfferId_Sha256, projectIdSha256));


            public static void SetStateContractHash(UInt160 newContract)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(SetStateContractHash),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(newContract));
            }
            public static Task SetStateContractHashAsync(UInt160 newContract)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetStateContractHash), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newContract));


            public static string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(storeProjectOfferMetaData),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectCreatorAddress, AuthorPubKey, JsonOfferDoc, signatureOfJson, pubKeyOfJsonSigner)) ?? string.Empty;
            }
            public static async Task<string> storeProjectOfferMetaDataAsync(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(storeProjectOfferMetaData), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectCreatorAddress, AuthorPubKey, JsonOfferDoc, signatureOfJson, pubKeyOfJsonSigner)) ?? string.Empty;


            public static void updateContractVersion(int newVersion, string changelogHash)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateContractVersion),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(newVersion, changelogHash));
            }
            public static Task updateContractVersionAsync(int newVersion, string changelogHash)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateContractVersion), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newVersion, changelogHash));


            /* public static void updateProjectPackage(ProjectPackage package, byte[] projectId)
 {
 ExecuteContractWithoutResult(Address,
 nameof(updateProjectPackage),
 TestNet,
 TestInvoke,
 DefaultUserWif,
 BuildParameters(package, projectId));
 }
*/

            public static bool validateProjectIsLiving(string projectId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                         nameof(validateProjectIsLiving),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId));
            }
            public static Task<bool> validateProjectIsLivingAsync(string projectId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(validateProjectIsLiving), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));


            public static ProjectOfferPackage getProjectOfferPack(string projectOfferId)
            {
                return ExecuteContractWithResult<ProjectOfferPackage>(Address,
                                               nameof(getProjectOfferPack),
                                               TestNet,
                                               TestInvoke,
                                               DefaultUserWif,
                                               BuildParameters(projectOfferId));
            }
            public static Task<ProjectOfferPackage> getProjectOfferPackAsync(string projectOfferId)
 => ExecuteContractWithResultAsync<ProjectOfferPackage>(Address, nameof(getProjectOfferPack), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectOfferId));

            public static ProjectPackage getProjectPack(string projectId)
            {
                return ExecuteContractWithResult<ProjectPackage>(Address,
                                               nameof(getProjectPack),
                                               TestNet,
                                               TestInvoke,
                                               DefaultUserWif,
                                               BuildParameters(projectId));

            }
            public static Task<ProjectPackage> getProjectPackAsync(string projectId)
 => ExecuteContractWithResultAsync<ProjectPackage>(Address, nameof(getProjectPack), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId));



            public static void removeProjectFromGlobalProjectsLists(ProjectAccount Account)
            {


            }


            public static void saveProjectToProjectsAccountStore(ProjectPackage package)
            {

            }

            public static void saveToGlobalProjectsLists(ProjectAccount Account)
            {


            }





            public static void updateProjectPackage(ProjectPackage package, byte[] projectId)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateProjectPackage),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(package, projectId));
            }
            public static Task updateProjectPackageAsync(ProjectPackage package, byte[] projectId)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateProjectPackage), TestNet, TestInvoke, DefaultUserWif, BuildParameters(package, projectId));



        }
    }
}