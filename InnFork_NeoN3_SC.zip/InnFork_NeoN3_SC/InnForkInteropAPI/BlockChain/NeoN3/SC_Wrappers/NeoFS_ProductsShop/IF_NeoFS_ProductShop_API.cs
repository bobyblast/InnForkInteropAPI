﻿using InnFork.NeoN3;

using Neo.SmartContract.Native;
using System;
using System.Numerics;
using InnFork.Blockchain.NEO3;
using Neo;
using Neo.SmartContract;
using Neo.VM.Types;
using Neo.SmartContract.Framework.Native;
using System.Threading.Tasks;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{

    public partial class IFPlatform
    {






        public class SCPlatform_ProductShop
        {
            public static UInt160 Address = UInt160.Parse("0xb0dddaf4d735be91e74c24aa7db58139fcb63971");
            public static bool TestNet = true;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; } = "";

            public static BigInteger CalculateFinallyProductPrice(UInt160 productId, UInt160 addonId, BigInteger Quantity)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(CalculateFinallyProductPrice),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(productId, addonId, Quantity));
            }
            public static Task<BigInteger> CalculateFinallyProductPriceAsync(UInt160 productId, UInt160 addonId, BigInteger Quantity)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(CalculateFinallyProductPrice), TestNet, TestInvoke, DefaultUserWif, BuildParameters(productId, addonId, Quantity));


            public static void cancelOrder(UInt160 orderId, UInt160 customerAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(cancelOrder),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(orderId, customerAddress));
            }
            public static Task cancelOrderAsync(UInt160 orderId, UInt160 customerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(cancelOrder), TestNet, TestInvoke, DefaultUserWif, BuildParameters(orderId, customerAddress));


            public static void confirmOrder(UInt160 orderId, UInt160 manufacturerAddress, UInt160 paymentTokenHash)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(confirmOrder),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(orderId, manufacturerAddress, paymentTokenHash));
            }
            public static Task confirmOrderAsync(UInt160 orderId, UInt160 manufacturerAddress, UInt160 paymentTokenHash)
 => ExecuteContractWithoutResultAsync(Address, nameof(confirmOrder), TestNet, TestInvoke, DefaultUserWif, BuildParameters(orderId, manufacturerAddress, paymentTokenHash));


            public static void convertToFLMStableCoin()
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(convertToFLMStableCoin),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters());
            }
            public static Task convertToFLMStableCoinAsync()
 => ExecuteContractWithoutResultAsync(Address, nameof(convertToFLMStableCoin), TestNet, TestInvoke, DefaultUserWif, BuildParameters());


            public static void createManufacturerAccount(UInt160 manufacturerAddress, string name, byte[] publicKey)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(createManufacturerAccount),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(manufacturerAddress, name, publicKey));
            }
            public static Task createManufacturerAccountAsync(UInt160 manufacturerAddress, string name, byte[] publicKey)
 => ExecuteContractWithoutResultAsync(Address, nameof(createManufacturerAccount), TestNet, TestInvoke, DefaultUserWif, BuildParameters(manufacturerAddress, name, publicKey));


            public static void createOrder(UInt160 orderId, UInt160 productId, UInt160 customerId, BigInteger quantity, UInt160 customerAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(createOrder),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(orderId, productId, customerId, quantity, customerAddress));
            }
            public static Task createOrderAsync(UInt160 orderId, UInt160 productId, UInt160 customerId, BigInteger quantity, UInt160 customerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(createOrder), TestNet, TestInvoke, DefaultUserWif, BuildParameters(orderId, productId, customerId, quantity, customerAddress));


            public static void depositCustomerFunds(UInt160 customerAddress, UInt160 token, BigInteger amount)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(depositCustomerFunds),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(customerAddress, token, amount));
            }
            public static Task depositCustomerFundsAsync(UInt160 customerAddress, UInt160 token, BigInteger amount)
 => ExecuteContractWithoutResultAsync(Address, nameof(depositCustomerFunds), TestNet, TestInvoke, DefaultUserWif, BuildParameters(customerAddress, token, amount));


            public static void doRequest()
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(doRequest),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters());
            }
            public static Task doRequestAsync()
 => ExecuteContractWithoutResultAsync(Address, nameof(doRequest), TestNet, TestInvoke, DefaultUserWif, BuildParameters());


            public static ManufacturerAccount getManufacturerAccount(UInt160 manufacturerAddress)
            {
                return ExecuteContractWithResult<ManufacturerAccount>(Address,
                                                         nameof(getManufacturerAccount),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(manufacturerAddress));
            }
            public static Task<ManufacturerAccount> getManufacturerAccountAsync(UInt160 manufacturerAddress)
 => ExecuteContractWithResultAsync<ManufacturerAccount>(Address, nameof(getManufacturerAccount), TestNet, TestInvoke, DefaultUserWif, BuildParameters(manufacturerAddress));


            public static Dictionary<string, BigInteger> getManufacturerSalesAnalytics(UInt160 manufacturerAddress)
            {
                return ExecuteContractWithResult<Dictionary<string, BigInteger>>(Address,
                                                                          nameof(getManufacturerSalesAnalytics),
                                                                          TestNet,
                                                                          TestInvoke,
                                                                          DefaultUserWif,
                                                                          BuildParameters(manufacturerAddress));
            }
            public static Task<Dictionary<string, BigInteger>> getManufacturerSalesAnalyticsAsync(UInt160 manufacturerAddress)
 => ExecuteContractWithResultAsync<Dictionary<string, BigInteger>>(Address, nameof(getManufacturerSalesAnalytics), TestNet, TestInvoke, DefaultUserWif, BuildParameters(manufacturerAddress));

            public static Order getOrder(UInt160 orderId)
            {
                return ExecuteContractWithResult<Order>(Address,
                                                         nameof(getOrder),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(orderId));
            }
            public static Task<Order> getOrderAsync(UInt160 orderId)
 => ExecuteContractWithResultAsync<Order>(Address, nameof(getOrder), TestNet, TestInvoke, DefaultUserWif, BuildParameters(orderId));


            public static ProductSalesStats getProductStatistics(UInt160 productId)
            {
                return ExecuteContractWithResult<ProductSalesStats>(Address,
                                                         nameof(getProductStatistics),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(productId));
            }
            public static Task<ProductSalesStats> getProductStatisticsAsync(UInt160 productId)
 => ExecuteContractWithResultAsync<ProductSalesStats>(Address, nameof(getProductStatistics), TestNet, TestInvoke, DefaultUserWif, BuildParameters(productId));


            public static string GetResponse()
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(GetResponse),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters()) ?? string.Empty;
            }
            public static async Task<string> GetResponseAsync()
 => await ExecuteContractWithResultAsync<string>(Address, nameof(GetResponse), TestNet, TestInvoke, DefaultUserWif, BuildParameters()) ?? string.Empty;


            public static BigInteger getSwapRate(UInt160 fromToken, UInt160 toToken)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getSwapRate),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(fromToken, toToken));
            }
            public static Task<BigInteger> getSwapRateAsync(UInt160 fromToken, UInt160 toToken)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getSwapRate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(fromToken, toToken));


            public static BigInteger getTotalBackerRewards(string projectId, UInt160 backerAddress)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(getTotalBackerRewards),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, backerAddress));
            }
            public static Task<BigInteger> getTotalBackerRewardsAsync(string projectId, UInt160 backerAddress)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(getTotalBackerRewards), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, backerAddress));


            public static void onOracleFlamingoPriceResponse(string requestedUrl, object userData, OracleResponseCode oracleResponse, string jsonString)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(onOracleFlamingoPriceResponse),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(requestedUrl, userData, oracleResponse, jsonString));
            }
            public static Task onOracleFlamingoPriceResponseAsync(string requestedUrl, object userData, OracleResponseCode oracleResponse, string jsonString)
 => ExecuteContractWithoutResultAsync(Address, nameof(onOracleFlamingoPriceResponse), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestedUrl, userData, oracleResponse, jsonString));


            public static void OracleCallback(ByteString userKey, ByteString result)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(OracleCallback),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(userKey, result));
            }
            public static Task OracleCallbackAsync(ByteString userKey, ByteString result)
 => ExecuteContractWithoutResultAsync(Address, nameof(OracleCallback), TestNet, TestInvoke, DefaultUserWif, BuildParameters(userKey, result));



            public static UInt160 purchaseProduct(UInt160 productId, UInt160 customerAddress, BigInteger quantity, UInt160 paymentToken)
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(purchaseProduct),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(productId, customerAddress, quantity, paymentToken)) ?? UInt160.Zero;
            }
            public static async Task<UInt160> purchaseProductAsync(UInt160 productId, UInt160 customerAddress, BigInteger quantity, UInt160 paymentToken)
 => await ExecuteContractWithResultAsync<UInt160>(Address, nameof(purchaseProduct), TestNet, TestInvoke, DefaultUserWif, BuildParameters(productId, customerAddress, quantity, paymentToken)) ?? UInt160.Zero;


            public static ByteString Query(string key)
            {
                return ExecuteContractWithResult<ByteString>(Address,
                                                         nameof(Query),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(key));
            }
            public static Task<ByteString> QueryAsync(string key)
 => ExecuteContractWithResultAsync<ByteString>(Address, nameof(Query), TestNet, TestInvoke, DefaultUserWif, BuildParameters(key));


            public static void registerCustomer(UInt160 customerAddress)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(registerCustomer),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(customerAddress));
            }
            public static Task registerCustomerAsync(UInt160 customerAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(registerCustomer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(customerAddress));


            public static UInt160 registerProduct(UInt160 manufacturerAddress, string projectId, string name, string description, string neoFSContainerId, string neoFSObjectId, BigInteger price, UInt160 priceToken, BigInteger quantity)
            {
                return ExecuteContractWithResult<UInt160>(Address,
                                                         nameof(registerProduct),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(manufacturerAddress, projectId, name, description, neoFSContainerId, neoFSObjectId, price, priceToken, quantity)) ?? UInt160.Zero;
            }
            public static async Task<UInt160> registerProductAsync(UInt160 manufacturerAddress, string projectId, string name, string description, string neoFSContainerId, string neoFSObjectId, BigInteger price, UInt160 priceToken, BigInteger quantity)
 => await ExecuteContractWithResultAsync<UInt160>(Address, nameof(registerProduct), TestNet, TestInvoke, DefaultUserWif, BuildParameters(manufacturerAddress, projectId, name, description, neoFSContainerId, neoFSObjectId, price, priceToken, quantity)) ?? UInt160.Zero;


            public static void RequestObject(string containerId, string objectId, string userKey)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(RequestObject),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(containerId, objectId, userKey));
            }
            public static Task RequestObjectAsync(string containerId, string objectId, string userKey)
 => ExecuteContractWithoutResultAsync(Address, nameof(RequestObject), TestNet, TestInvoke, DefaultUserWif, BuildParameters(containerId, objectId, userKey));


            public static void setProductDiscount(UInt160 productId, bool isActive, BigInteger discountPercent)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setProductDiscount),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(productId, isActive, discountPercent));
            }
            public static Task setProductDiscountAsync(UInt160 productId, bool isActive, BigInteger discountPercent)
 => ExecuteContractWithoutResultAsync(Address, nameof(setProductDiscount), TestNet, TestInvoke, DefaultUserWif, BuildParameters(productId, isActive, discountPercent));


            public static void setSwapRate(UInt160 fromToken, UInt160 toToken, BigInteger rate)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(setSwapRate),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(fromToken, toToken, rate));
            }
            public static Task setSwapRateAsync(UInt160 fromToken, UInt160 toToken, BigInteger rate)
 => ExecuteContractWithoutResultAsync(Address, nameof(setSwapRate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(fromToken, toToken, rate));


            public static BigInteger swapTokenToFUSD(UInt160 userAddress, UInt160 fromToken, BigInteger amount)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                         nameof(swapTokenToFUSD),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(userAddress, fromToken, amount));
            }
            public static Task<BigInteger> swapTokenToFUSDAsync(UInt160 userAddress, UInt160 fromToken, BigInteger amount)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(swapTokenToFUSD), TestNet, TestInvoke, DefaultUserWif, BuildParameters(userAddress, fromToken, amount));


            public static void updateProductStock(UInt160 productId, BigInteger newQuantity)
            {
                ExecuteContractWithoutResult(Address,
                                                 nameof(updateProductStock),
                                                 TestNet,
                                                 TestInvoke,
                                                 DefaultUserWif,
                                                 BuildParameters(productId, newQuantity));
            }
            public static Task updateProductStockAsync(UInt160 productId, BigInteger newQuantity)
 => ExecuteContractWithoutResultAsync(Address, nameof(updateProductStock), TestNet, TestInvoke, DefaultUserWif, BuildParameters(productId, newQuantity));




 }
 }
}
