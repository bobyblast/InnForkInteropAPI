﻿using System;
using System.Numerics;
using System.Threading.Tasks;
using InnFork.Blockchain.NEO3;
using InnFork.NeoN3;
using InnFork.NeoN3.Enums;
using Neo;
using Neo.SmartContract;
using Neo.VM.Types;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{

    public partial class IFPlatform
    {
        public partial class SCPlatform_Logic5
        {
            public static UInt160 Address = UInt160.Parse("0x032845e538aa090c467fb41ca7446eb96142cb0a");
            public static bool TestNet = true;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; } = "";

            public static BigInteger calculateManufacturerFinalScore(string projectId, UInt160 manufacturer)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                nameof(calculateManufacturerFinalScore),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, manufacturer));
            }
            public static Task<BigInteger> calculateManufacturerFinalScoreAsync(string projectId, UInt160 manufacturer)
            => ExecuteContractWithResultAsync<BigInteger>(Address,
            nameof(calculateManufacturerFinalScore),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, manufacturer))!;

            public static BigInteger calculateManufacturerWeightedVoteResult(string projectId, UInt160 manufacturer)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                nameof(calculateManufacturerWeightedVoteResult),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, manufacturer));
            }
            public static Task<BigInteger> calculateManufacturerWeightedVoteResultAsync(string projectId, UInt160 manufacturer)
            => ExecuteContractWithResultAsync<BigInteger>(Address,
            nameof(calculateManufacturerWeightedVoteResult),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, manufacturer))!;

            public static bool canActivateManufacturer(string projectId, UInt160 manufacturer)
            {
                return ExecuteContractWithResult<bool>(Address,
                nameof(canActivateManufacturer),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, manufacturer));
            }
            public static Task<bool> canActivateManufacturerAsync(string projectId, UInt160 manufacturer)
            => ExecuteContractWithResultAsync<bool>(Address,
            nameof(canActivateManufacturer),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, manufacturer))!;

            public static bool canBackerVote(string projectId, UInt160 backer, bool ignoreAlreadyVoted = false)
            {
                return ExecuteContractWithResult<bool>(Address,
                nameof(canBackerVote),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, backer, ignoreAlreadyVoted));
            }
            public static Task<bool> canBackerVoteAsync(string projectId, UInt160 backer, bool ignoreAlreadyVoted = false)
            => ExecuteContractWithResultAsync<bool>(Address,
            nameof(canBackerVote),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, backer, ignoreAlreadyVoted))!;

            public static void ClearVotingTierWeightsAll(string projectId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(ClearVotingTierWeightsAll),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId));
            }
            public static Task ClearVotingTierWeightsAllAsync(string projectId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(ClearVotingTierWeightsAll),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId));

            public static BigInteger getBackerVoteWeight(string projectId, UInt160 backer)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                nameof(getBackerVoteWeight),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, backer));
            }
            public static Task<BigInteger> getBackerVoteWeightAsync(string projectId, UInt160 backer)
            => ExecuteContractWithResultAsync<BigInteger>(Address,
            nameof(getBackerVoteWeight),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, backer))!;

            public static BigInteger getExternalRating(string projectId, UInt160 manufacturer)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                nameof(getExternalRating),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, manufacturer));
            }
            public static Task<BigInteger> getExternalRatingAsync(string projectId, UInt160 manufacturer)
            => ExecuteContractWithResultAsync<BigInteger>(Address,
            nameof(getExternalRating),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, manufacturer))!;

            public static byte GetVoterTier(string projectId, string voteId, UInt160 voter)
            {
                return ExecuteContractWithResult<byte>(Address,
                nameof(GetVoterTier),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, voteId, voter));
            }
            public static Task<byte> GetVoterTierAsync(string projectId, string voteId, UInt160 voter)
            => ExecuteContractWithResultAsync<byte>(Address,
            nameof(GetVoterTier),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, voteId, voter))!;

            public static string[] GetVotingTierIds(string projectId)
            {
                return ExecuteContractWithResult<string[]>(Address,
                nameof(GetVotingTierIds),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId)) ?? System.Array.Empty<string>();
            }
            public static async Task<string[]> GetVotingTierIdsAsync(string projectId)
            {
                var res = await ExecuteContractWithResultAsync<string[]>(Address,
                nameof(GetVotingTierIds),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId)).ConfigureAwait(false);
                return res ?? System.Array.Empty<string>();
            }

            public static BigInteger GetVotingTierWeight(string projectId, string tierId)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                nameof(GetVotingTierWeight),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, tierId));
            }
            public static Task<BigInteger> GetVotingTierWeightAsync(string projectId, string tierId)
            => ExecuteContractWithResultAsync<BigInteger>(Address,
            nameof(GetVotingTierWeight),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, tierId))!;

            public static void handleContractBreachResolution(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleContractBreachResolution),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleContractBreachResolutionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleContractBreachResolution),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleDisputeEscalation(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleDisputeEscalation),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleDisputeEscalationAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleDisputeEscalation),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleDisputeRejection(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleDisputeRejection),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleDisputeRejectionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleDisputeRejection),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleDisputeResolution(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleDisputeResolution),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleDisputeResolutionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleDisputeResolution),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleFraudDisputeResolution(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleFraudDisputeResolution),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleFraudDisputeResolutionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleFraudDisputeResolution),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleFraudEscalation(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleFraudEscalation),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleFraudEscalationAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleFraudEscalation),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleGeneralDisputeResolution(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleGeneralDisputeResolution),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleGeneralDisputeResolutionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleGeneralDisputeResolution),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleMilestoneDisputeResolution(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleMilestoneDisputeResolution),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleMilestoneDisputeResolutionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleMilestoneDisputeResolution),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleMilestoneEscalation(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleMilestoneEscalation),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleMilestoneEscalationAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleMilestoneEscalation),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handlePaymentDisputeResolution(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handlePaymentDisputeResolution),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handlePaymentDisputeResolutionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handlePaymentDisputeResolution),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handlePaymentEscalation(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handlePaymentEscalation),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handlePaymentEscalationAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handlePaymentEscalation),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static void handleQualityDisputeResolution(string projectId, string disputeId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(handleQualityDisputeResolution),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, disputeId));
            }
            public static Task handleQualityDisputeResolutionAsync(string projectId, string disputeId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(handleQualityDisputeResolution),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, disputeId));

            public static bool hasManufacturerUsedMilestoneFunding(string projectId, UInt160 manufacturerId)
            {
                return ExecuteContractWithResult<bool>(Address,
                nameof(hasManufacturerUsedMilestoneFunding),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, manufacturerId));
            }
            public static Task<bool> hasManufacturerUsedMilestoneFundingAsync(string projectId, UInt160 manufacturerId)
            => ExecuteContractWithResultAsync<bool>(Address,
            nameof(hasManufacturerUsedMilestoneFunding),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, manufacturerId))!;

            public static void RemoveVotingTierWeight(string projectId, string tierId)
            {
                ExecuteContractWithoutResult(Address,
                nameof(RemoveVotingTierWeight),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, tierId));
            }
            public static Task RemoveVotingTierWeightAsync(string projectId, string tierId)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(RemoveVotingTierWeight),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, tierId));

            public static void setAutoSelectWinner(string projectId, UInt160 backer, UInt160 manufacturer)
            {
                ExecuteContractWithoutResult(Address,
                nameof(setAutoSelectWinner),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, backer, manufacturer));
            }
            public static Task setAutoSelectWinnerAsync(string projectId, UInt160 backer, UInt160 manufacturer)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(setAutoSelectWinner),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, backer, manufacturer));

            public static void SetVoterTier(string projectId, string voteId, UInt160 voter, byte tier)
            {
                ExecuteContractWithoutResult(Address,
                nameof(SetVoterTier),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, voteId, voter, tier));
            }
            public static Task SetVoterTierAsync(string projectId, string voteId, UInt160 voter, byte tier)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(SetVoterTier),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, voteId, voter, tier));

            public static void SetVotingTierWeight(string projectId, string tierId, BigInteger weight)
            {
                ExecuteContractWithoutResult(Address,
                nameof(SetVotingTierWeight),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, tierId, weight));
            }
            public static Task SetVotingTierWeightAsync(string projectId, string tierId, BigInteger weight)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(SetVotingTierWeight),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, tierId, weight));

            public static void validateManufacturer(string projectId, UInt160 manufacturer)
            {
                ExecuteContractWithoutResult(Address,
                nameof(validateManufacturer),
                TestNet,
                TestInvoke,
                DefaultUserWif,
                BuildParameters(projectId, manufacturer));
            }
            public static Task validateManufacturerAsync(string projectId, UInt160 manufacturer)
            => ExecuteContractWithoutResultAsync(Address,
            nameof(validateManufacturer),
            TestNet,
            TestInvoke,
            DefaultUserWif,
            BuildParameters(projectId, manufacturer));
        }
    }
}