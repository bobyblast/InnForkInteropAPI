﻿using InnFork.Blockchain.NEO3;
using InnFork.NeoN3;
using Neo;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Native;
using System;
using System.Numerics;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{
    public enum ViolationFlag : int
    {
        None = 0,
        Spam = 1 << 0,              // Спам -> BanReason.SpamVoting
        Scam = 1 << 1,              // Мошенничество -> BanReason.FraudulentActivity
        OffensiveLanguage = 1 << 2, // Оскорбительные выражения -> BanReason.InappropriateBehavior
        FalseInformation = 1 << 3,  // Ложная информация -> BanReason.FalseDispute
        Copyright = 1 << 4,         // Нарушение авторских прав -> BanReason.IntellectualPropertyTheft
        AdultContent = 1 << 5,      // Контент для взрослых -> BanReason.ViolationOfTerms
        Violence = 1 << 6,          // Насилие -> BanReason.InappropriateBehavior
        IllegalContent = 1 << 7,    // Незаконный контент -> BanReason.RegulatoryViolation
        Plagiarism = 1 << 8,        // Плагиат -> BanReason.IntellectualPropertyTheft
        LowQuality = 1 << 9,        // Низкое качество -> BanReason.QualityIssues
        Unrealistic = 1 << 10,      // Нереалистичные обещания -> BanReason.FraudSuspicion
        MissingInfo = 1 << 11,      // Недостаточно информации -> BanReason.ViolationOfTerms
        SuspiciousActivity = 1 << 12 // Подозрительная активность -> BanReason.SystemAbuse
    }

    public partial class IFPlatform
    {





        public class Ai_Moderator_new
        {
            // Локальная конфигурация вызова смарт-контракта (не используем SCPlatform_AiModerator)
            public static UInt160 Address { get; set; }
            public static bool testnet { get; set; }
            public static bool TestInvoke { get; set; }
            public static string? DefaultUserWif { get; set; }


            public static void ConfigureOracle(string url, string jsonPath)
            {
                throw new NotImplementedException();
            }

            public static BigInteger GetConfidenceScore(string requestId)
            {
                throw new NotImplementedException();
            }

            public static Dictionary<string, BigInteger> GetEnhancedModerationStats(string requestId, string projectId)
            {
                throw new NotImplementedException();
            }

            public static string[] GetModerationHistory(UInt160 address)
            {
                throw new NotImplementedException();
            }

            public static object[] GetModerationHistoryWithContext(UInt160 address, string projectId)
            {
                throw new NotImplementedException();
            }

            public static ModerationResult GetModerationResult(string requestId)
            {
                throw new NotImplementedException();
            }

            public static Dictionary<string, BigInteger> GetModerationStats(string requestId)
            {
                throw new NotImplementedException();
            }

            public static bool HasViolationFlag(string requestId, InnFork.NeoN3.ViolationFlag flag)
            {
                throw new NotImplementedException();
            }

            public static void Initialize(UInt160 owner)
            {
                throw new NotImplementedException();
            }

            public static bool IsModerationApproved(string requestId)
            {
                throw new NotImplementedException();
            }

            public static void ManuallyApplySanctions(string requestId, string projectId, UInt160 admin)
            {
                throw new NotImplementedException();
            }

            public static string ModerateDisputeEvidence(string projectId, string disputeId, string evidenceJson, UInt160 requester, bool autoEnforce = true)
            {
                throw new NotImplementedException();
            }

            public static string ModerateManufacturerProfile(string projectId, UInt160 manufacturerAddress, string profileJson, UInt160 requester, bool autoEnforce = true)
            {
                throw new NotImplementedException();
            }

            public static string ModerateProductDescription(string productId, string productJson, UInt160 requester, bool autoEnforce = false)
            {
                throw new NotImplementedException();
            }

            public static string ModerateProjectDescription(string projectId, string descriptionJson, UInt160 requester, bool autoEnforce = false)
            {
                throw new NotImplementedException();
            }

            public static string ModerateProjectOffer(string offerId, string offerJson, UInt160 requester, bool autoEnforce = false)
            {
                throw new NotImplementedException();
            }

            public static string ModerateProjectUpdate(string projectId, string updateId, string updateJson, UInt160 requester, bool autoEnforce = false)
            {
                throw new NotImplementedException();
            }

            public static string ModerateRefundRequest(string projectId, string refundId, string refundJson, UInt160 requester, bool autoEnforce = true)
            {
                throw new NotImplementedException();
            }

            public static string ModerateUserComment(string projectId, string commentId, string commentJson, UInt160 author, bool autoEnforce = false)
            {
                throw new NotImplementedException();
            }

            public static void OnOracleModerationResponse(string requestedUrl, object userData, OracleResponseCode code, string jsonResponse)
            {
                throw new NotImplementedException();
            }

            public static void RehabilitateParticipant(string projectId, UInt160 participant, UInt160 admin)
            {
                throw new NotImplementedException();
            }

            public static void SetMainGatewayContract(UInt160 newAddress)
            {
                throw new NotImplementedException();
            }

            public static void SetPaused(bool paused)
            {
                throw new NotImplementedException();
            }

            public static void SetStateStorageContract(UInt160 newAddress)
            {
                throw new NotImplementedException();
            }

            public static void TransferOwnership(UInt160 newOwner)
            {
                throw new NotImplementedException();
            }
        }























        public class Ai_Moderator_API
        {
            // Локальная конфигурация вызова смарт-контракта (не используем SCPlatform_AiModerator)
            public static UInt160 Address { get; set; }
            public static bool testnet { get; set; }
            public static bool TestInvoke { get; set; }
            public static string? DefaultUserWif { get; set; }

            public static void ConfigureOracle(string url, string jsonPath)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(ConfigureOracle),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(url, jsonPath));
            }

            public static BigInteger GetConfidenceScore(string requestId)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                            nameof(GetConfidenceScore),
                                                            testnet,
                                                            TestInvoke,
                                                            DefaultUserWif,
                                                            BuildParameters(requestId));
            }

            // Исправление неоднозначности Dictionary<<TKey, TValue>:
            // Явно указываем пространство имён Neo.SmartContract.Framework для Dictionary<

            public static Dictionary<string, BigInteger> GetEnhancedModerationStats(string requestId, string projectId)
            {
                return ExecuteContractWithResult<Dictionary<string, BigInteger>>(Address,
                                                                                                      nameof(GetEnhancedModerationStats),
                                                                                                      testnet,
                                                                                                      TestInvoke,
                                                                                                      DefaultUserWif,
                                                                                                      BuildParameters(requestId, projectId));
            }

            public static string[] GetModerationHistory(UInt160 address)
            {
                return ExecuteContractWithResult<string[]>(Address,
                                                           nameof(GetModerationHistory),
                                                           testnet,
                                                           TestInvoke,
                                                           DefaultUserWif,
                                                           BuildParameters(address)) ?? Array.Empty<string>();
            }

            public static object[] GetModerationHistoryWithContext(UInt160 address, string projectId)
            {
                return ExecuteContractWithResult<object[]>(Address,
                                                           nameof(GetModerationHistoryWithContext),
                                                           testnet,
                                                           TestInvoke,
                                                           DefaultUserWif,
                                                           BuildParameters(address, projectId)) ?? Array.Empty<object>();
            }

            public static ModerationResult GetModerationResult(string requestId)
            {
                return ExecuteContractWithResult<ModerationResult>(Address,
                                                                                  nameof(GetModerationResult),
                                                                                  testnet,
                                                                                  TestInvoke,
                                                                                  DefaultUserWif,
                                                                                  BuildParameters(requestId));
            }

            public static Dictionary<string, BigInteger> GetModerationStats(string requestId)
            {
                return ExecuteContractWithResult<Dictionary<string, BigInteger>>(Address,
                                                                                                      nameof(GetModerationStats),
                                                                                                      testnet,
                                                                                                      TestInvoke,
                                                                                                      DefaultUserWif,
                                                                                                      BuildParameters(requestId));
            }

            public static bool HasViolationFlag(string requestId, ViolationFlag flag)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(HasViolationFlag),
                                                       testnet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(requestId, flag));
            }

            public static void Initialize(UInt160 owner)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(Initialize),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(owner));
            }

            public static bool IsModerationApproved(string requestId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(IsModerationApproved),
                                                       testnet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(requestId));
            }

            public static void ManuallyApplySanctions(string requestId, string projectId, UInt160 admin)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(ManuallyApplySanctions),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(requestId, projectId, admin));
            }

            public static string ModerateDisputeEvidence(string projectId, string disputeId, string evidenceJson, UInt160 requester, bool autoEnforce = true)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateDisputeEvidence),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, disputeId, evidenceJson, requester, autoEnforce)) ?? string.Empty;
            }

            public static string ModerateManufacturerProfile(string projectId, UInt160 manufacturerAddress, string profileJson, UInt160 requester, bool autoEnforce = true)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateManufacturerProfile),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, manufacturerAddress, profileJson, requester, autoEnforce)) ?? string.Empty;
            }

            public static string ModerateProductDescription(string productId, string productJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProductDescription),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(productId, productJson, requester, autoEnforce)) ?? string.Empty;
            }

            public static string ModerateProjectDescription(string projectId, string descriptionJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProjectDescription),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, descriptionJson, requester, autoEnforce)) ?? string.Empty;
            }

            public static string ModerateProjectOffer(string offerId, string offerJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProjectOffer),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(offerId, offerJson, requester, autoEnforce)) ?? string.Empty;
            }

            public static string ModerateProjectUpdate(string projectId, string updateId, string updateJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProjectUpdate),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, updateId, updateJson, requester, autoEnforce)) ?? string.Empty;
            }

            public static string ModerateRefundRequest(string projectId, string refundId, string refundJson, UInt160 requester, bool autoEnforce = true)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateRefundRequest),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, refundId, refundJson, requester, autoEnforce)) ?? string.Empty;
            }

            public static string ModerateUserComment(string projectId, string commentId, string commentJson, UInt160 author, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateUserComment),
                                                         testnet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, commentId, commentJson, author, autoEnforce)) ?? string.Empty;
            }

            public static void OnOracleModerationResponse(string requestedUrl, object userData, OracleResponseCode code, string jsonResponse)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(OnOracleModerationResponse),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(requestedUrl, userData, code, jsonResponse));
            }

            public static void RehabilitateParticipant(string projectId, UInt160 participant, UInt160 admin)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(RehabilitateParticipant),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, participant, admin));
            }

            public static void SetMainGatewayContract(UInt160 newAddress)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetMainGatewayContract),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(newAddress));
            }

            public static void SetPaused(bool paused)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetPaused),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(paused));
            }

            public static void SetStateStorageContract(UInt160 newAddress)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetStateStorageContract),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(newAddress));
            }

            public static void TransferOwnership(UInt160 newOwner)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(TransferOwnership),
                                             testnet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(newOwner));
            }
        }

        enum Network { TestNet, MainNet }
    }
}