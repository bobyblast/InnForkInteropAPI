﻿using InnFork.Blockchain.NEO3;
using InnFork.NeoN3;
using Neo;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Native;
using System;
using System.Numerics;
using System.Threading.Tasks;

namespace InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers
{


    public partial class IFPlatform
    {


        public class Ai_Moderator_API
        {
            // Локальная конфигурация вызова смарт-контракта (не используем SCPlatform_AiModerator)
            public static UInt160 Address = UInt160.Parse("0x0973c8585d176cfcae93456b5d215bb7783a3e1b");
            public static bool TestNet = true;
            public static bool TestInvoke = false;
            public static string? DefaultUserWif { get; set; } = "";


            public static void ConfigureOracle(string url, string jsonPath)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(ConfigureOracle),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(url, jsonPath));
            }
            public static Task ConfigureOracleAsync(string url, string jsonPath)
            => ExecuteContractWithoutResultAsync(Address, nameof(ConfigureOracle), TestNet, TestInvoke, DefaultUserWif, BuildParameters(url, jsonPath));


            public static BigInteger GetConfidenceScore(string requestId)
            {
                return ExecuteContractWithResult<BigInteger>(Address,
                                                            nameof(GetConfidenceScore),
                                                            TestNet,
                                                            TestInvoke,
                                                            DefaultUserWif,
                                                            BuildParameters(requestId));
            }
            public static Task<BigInteger> GetConfidenceScoreAsync(string requestId)
 => ExecuteContractWithResultAsync<BigInteger>(Address, nameof(GetConfidenceScore), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestId));

            // Исправление неоднозначности Dictionary<<TKey, TValue>:
            // Явно указываем пространство имён Neo.SmartContract.Framework для Dictionary<

            public static Dictionary<string, BigInteger> GetEnhancedModerationStats(string requestId, string projectId)
            {
                return ExecuteContractWithResult<Dictionary<string, BigInteger>>(Address,
                                                                                                      nameof(GetEnhancedModerationStats),
                                                                                                      TestNet,
                                                                                                      TestInvoke,
                                                                                                      DefaultUserWif,
                                                                                                      BuildParameters(requestId, projectId));
            }
            public static Task<Dictionary<string, BigInteger>> GetEnhancedModerationStatsAsync(string requestId, string projectId)
 => ExecuteContractWithResultAsync<Dictionary<string, BigInteger>>(Address, nameof(GetEnhancedModerationStats), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestId, projectId));

            public static string[] GetModerationHistory(UInt160 address)
            {
                return ExecuteContractWithResult<string[]>(Address,
                                                           nameof(GetModerationHistory),
                                                           TestNet,
                                                           TestInvoke,
                                                           DefaultUserWif,
                                                           BuildParameters(address)) ?? Array.Empty<string>();
            }
            public static async Task<string[]> GetModerationHistoryAsync(UInt160 address)
 => await ExecuteContractWithResultAsync<string[]>(Address, nameof(GetModerationHistory), TestNet, TestInvoke, DefaultUserWif, BuildParameters(address)) ?? Array.Empty<string>();

            public static object[] GetModerationHistoryWithContext(UInt160 address, string projectId)
            {
                return ExecuteContractWithResult<object[]>(Address,
                                                           nameof(GetModerationHistoryWithContext),
                                                           TestNet,
                                                           TestInvoke,
                                                           DefaultUserWif,
                                                           BuildParameters(address, projectId)) ?? Array.Empty<object>();
            }
            public static async Task<object[]> GetModerationHistoryWithContextAsync(UInt160 address, string projectId)
 => await ExecuteContractWithResultAsync<object[]>(Address, nameof(GetModerationHistoryWithContext), TestNet, TestInvoke, DefaultUserWif, BuildParameters(address, projectId)) ?? Array.Empty<object>();

            public static ModerationResult GetModerationResult(string requestId)
            {
                return ExecuteContractWithResult<ModerationResult>(Address,
                                                                                  nameof(GetModerationResult),
                                                                                  TestNet,
                                                                                  TestInvoke,
                                                                                  DefaultUserWif,
                                                                                  BuildParameters(requestId));
            }
            public static Task<ModerationResult> GetModerationResultAsync(string requestId)
 => ExecuteContractWithResultAsync<ModerationResult>(Address, nameof(GetModerationResult), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestId));

            public static Dictionary<string, BigInteger> GetModerationStats(string requestId)
            {
                return ExecuteContractWithResult<Dictionary<string, BigInteger>>(Address,
                                                                                                      nameof(GetModerationStats),
                                                                                                      TestNet,
                                                                                                      TestInvoke,
                                                                                                      DefaultUserWif,
                                                                                                      BuildParameters(requestId));
            }
            public static Task<Dictionary<string, BigInteger>> GetModerationStatsAsync(string requestId)
 => ExecuteContractWithResultAsync<Dictionary<string, BigInteger>>(Address, nameof(GetModerationStats), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestId));



            public static bool HasViolationFlag(string requestId, ViolationFlag flag)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(HasViolationFlag),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(requestId, flag));
            }
            public static Task<bool> HasViolationFlagAsync(string requestId, ViolationFlag flag)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(HasViolationFlag), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestId, flag));

            public static void Initialize(UInt160 owner)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(Initialize),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(owner));
            }
            public static Task InitializeAsync(UInt160 owner)
 => ExecuteContractWithoutResultAsync(Address, nameof(Initialize), TestNet, TestInvoke, DefaultUserWif, BuildParameters(owner));

            public static bool IsModerationApproved(string requestId)
            {
                return ExecuteContractWithResult<bool>(Address,
                                                       nameof(IsModerationApproved),
                                                       TestNet,
                                                       TestInvoke,
                                                       DefaultUserWif,
                                                       BuildParameters(requestId));
            }
            public static Task<bool> IsModerationApprovedAsync(string requestId)
 => ExecuteContractWithResultAsync<bool>(Address, nameof(IsModerationApproved), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestId));



            public static void ManuallyApplySanctions(string requestId, string projectId, UInt160 admin)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(ManuallyApplySanctions),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(requestId, projectId, admin));
            }
            public static Task ManuallyApplySanctionsAsync(string requestId, string projectId, UInt160 admin)
 => ExecuteContractWithoutResultAsync(Address, nameof(ManuallyApplySanctions), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestId, projectId, admin));

            public static string ModerateDisputeEvidence(string projectId, string disputeId, string evidenceJson, UInt160 requester, bool autoEnforce = true)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateDisputeEvidence),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, disputeId, evidenceJson, requester, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateDisputeEvidenceAsync(string projectId, string disputeId, string evidenceJson, UInt160 requester, bool autoEnforce = true)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateDisputeEvidence), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, disputeId, evidenceJson, requester, autoEnforce)) ?? string.Empty;

            public static string ModerateManufacturerProfile(string projectId, UInt160 manufacturerAddress, string profileJson, UInt160 requester, bool autoEnforce = true)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateManufacturerProfile),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, manufacturerAddress, profileJson, requester, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateManufacturerProfileAsync(string projectId, UInt160 manufacturerAddress, string profileJson, UInt160 requester, bool autoEnforce = true)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateManufacturerProfile), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, manufacturerAddress, profileJson, requester, autoEnforce)) ?? string.Empty;

            public static string ModerateProductDescription(string productId, string productJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProductDescription),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(productId, productJson, requester, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateProductDescriptionAsync(string productId, string productJson, UInt160 requester, bool autoEnforce = false)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateProductDescription), TestNet, TestInvoke, DefaultUserWif, BuildParameters(productId, productJson, requester, autoEnforce)) ?? string.Empty;

            public static string ModerateProjectDescription(string projectId, string descriptionJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProjectDescription),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, descriptionJson, requester, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateProjectDescriptionAsync(string projectId, string descriptionJson, UInt160 requester, bool autoEnforce = false)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateProjectDescription), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, descriptionJson, requester, autoEnforce)) ?? string.Empty;

            public static string ModerateProjectOffer(string offerId, string offerJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProjectOffer),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(offerId, offerJson, requester, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateProjectOfferAsync(string offerId, string offerJson, UInt160 requester, bool autoEnforce = false)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateProjectOffer), TestNet, TestInvoke, DefaultUserWif, BuildParameters(offerId, offerJson, requester, autoEnforce)) ?? string.Empty;

            public static string ModerateProjectUpdate(string projectId, string updateId, string updateJson, UInt160 requester, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateProjectUpdate),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, updateId, updateJson, requester, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateProjectUpdateAsync(string projectId, string updateId, string updateJson, UInt160 requester, bool autoEnforce = false)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateProjectUpdate), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, updateId, updateJson, requester, autoEnforce)) ?? string.Empty;

            public static string ModerateRefundRequest(string projectId, string refundId, string refundJson, UInt160 requester, bool autoEnforce = true)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateRefundRequest),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, refundId, refundJson, requester, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateRefundRequestAsync(string projectId, string refundId, string refundJson, UInt160 requester, bool autoEnforce = true)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateRefundRequest), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, refundId, refundJson, requester, autoEnforce)) ?? string.Empty;

            public static string ModerateUserComment(string projectId, string commentId, string commentJson, UInt160 author, bool autoEnforce = false)
            {
                return ExecuteContractWithResult<string>(Address,
                                                         nameof(ModerateUserComment),
                                                         TestNet,
                                                         TestInvoke,
                                                         DefaultUserWif,
                                                         BuildParameters(projectId, commentId, commentJson, author, autoEnforce)) ?? string.Empty;
            }
            public static async Task<string> ModerateUserCommentAsync(string projectId, string commentId, string commentJson, UInt160 author, bool autoEnforce = false)
 => await ExecuteContractWithResultAsync<string>(Address, nameof(ModerateUserComment), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, commentId, commentJson, author, autoEnforce)) ?? string.Empty;

            public static void OnOracleModerationResponse(string requestedUrl, object userData, OracleResponseCode code, string jsonResponse)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(OnOracleModerationResponse),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(requestedUrl, userData, code, jsonResponse));
            }
            public static Task OnOracleModerationResponseAsync(string requestedUrl, object userData, OracleResponseCode code, string jsonResponse)
 => ExecuteContractWithoutResultAsync(Address, nameof(OnOracleModerationResponse), TestNet, TestInvoke, DefaultUserWif, BuildParameters(requestedUrl, userData, code, jsonResponse));

            public static void RehabilitateParticipant(string projectId, UInt160 participant, UInt160 admin)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(RehabilitateParticipant),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(projectId, participant, admin));
            }
            public static Task RehabilitateParticipantAsync(string projectId, UInt160 participant, UInt160 admin)
 => ExecuteContractWithoutResultAsync(Address, nameof(RehabilitateParticipant), TestNet, TestInvoke, DefaultUserWif, BuildParameters(projectId, participant, admin));



            public static void SetMainGatewayContract(UInt160 newAddress)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetMainGatewayContract),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(newAddress));
            }
            public static Task SetMainGatewayContractAsync(UInt160 newAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetMainGatewayContract), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newAddress));

            public static void SetPaused(bool paused)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetPaused),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(paused));
            }
            public static Task SetPausedAsync(bool paused)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetPaused), TestNet, TestInvoke, DefaultUserWif, BuildParameters(paused));

            public static void SetStateStorageContract(UInt160 newAddress)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(SetStateStorageContract),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(newAddress));
            }
            public static Task SetStateStorageContractAsync(UInt160 newAddress)
 => ExecuteContractWithoutResultAsync(Address, nameof(SetStateStorageContract), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newAddress));

            public static void TransferOwnership(UInt160 newOwner)
            {
                ExecuteContractWithoutResult(Address,
                                             nameof(TransferOwnership),
                                             TestNet,
                                             TestInvoke,
                                             DefaultUserWif,
                                             BuildParameters(newOwner));
            }
            public static Task TransferOwnershipAsync(UInt160 newOwner)
 => ExecuteContractWithoutResultAsync(Address, nameof(TransferOwnership), TestNet, TestInvoke, DefaultUserWif, BuildParameters(newOwner));





        }























        enum Network { TestNet, MainNet }
    }
}