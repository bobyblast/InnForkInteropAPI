
using Neo.SmartContract.Framework;

using System.Numerics;

namespace InnFork.NeoN3;



public struct Order
{
    public UInt160 Id { get; set; }
    public UInt160 ProductId { get; set; }
    public UInt160 CustomerId { get; set; }
    public UInt160 CustomerNeoN3Address { get; set; }
    public ulong OrderDate { get; set; }
    public string ProductName { get; set; }
    public BigInteger Price { get; set; }
    public BigInteger Amount { get; set; }
    public BigInteger Quantity { get; set; }
    public string shipping_FirstName { get; set; }
    public string shipping_LastName { get; set; }
    public string shipping_Address { get; set; }
    public string shipping_City { get; set; }
    public string shipping_ZipCode { get; set; }
    public bool IsConfirmed { get; set; }

}
