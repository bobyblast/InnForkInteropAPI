
using Neo.SmartContract.Framework;
using System.Numerics;

namespace InnFork.NeoN3;

public struct Customer
{
    public UInt160 CustomerAddress;
    public BigInteger Balance;
    public ulong RegisteredAt;
    public BigInteger TotalPurchases;
}

