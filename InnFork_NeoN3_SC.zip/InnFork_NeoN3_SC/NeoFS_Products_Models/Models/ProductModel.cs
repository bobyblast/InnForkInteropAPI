
using Neo.SmartContract.Framework;

using System.Numerics;

namespace InnFork.NeoN3;



public struct Product
{
    public UInt160 ProductId { get; set; }
    public UInt160 ManufacturerAddress { get; set; }
    public string ProjectId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public string NeoFSContainerId { get; set; }
    public string NeoFSObjectId { get; set; }
    public BigInteger Price { get; set; }
    public UInt160 PriceToken { get; set; }
    public BigInteger Quantity { get; set; }
    public ulong CreatedAt { get; set; }
    public bool IsActive { get; set; }
    public bool IsDiscountActive { get; set; }
    public BigInteger DiscountAmount { get; set; }

}
