
using Neo.SmartContract.Framework;

using System.Numerics;

namespace InnFork.NeoN3;



public struct SaleRecord
{
    public UInt160 SaleId;
    public UInt160 ProductId;
    public UInt160 ManufacturerAddress;
    public UInt160 CustomerAddress;
    public BigInteger Quantity;
    public BigInteger TotalPrice;
    public UInt160 PaymentToken;
    public ulong SaleTimestamp;
    public string ProjectId;
    public bool RewardsDistributed;
}

