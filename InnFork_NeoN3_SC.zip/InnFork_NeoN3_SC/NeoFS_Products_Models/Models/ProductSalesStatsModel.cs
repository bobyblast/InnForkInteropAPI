
using Neo.SmartContract.Framework;

using System.Numerics;

namespace InnFork.NeoN3;


public struct ProductSalesStats
{
    public UInt160 ProductId;
    public BigInteger TotalSales;
    public BigInteger TotalRevenue;
    public BigInteger TotalQuantitySold;
    public ulong LastSaleTimestamp;
}