
using Neo.SmartContract.Framework;

using System.Numerics;

namespace InnFork.NeoN3;

public struct SwapRecord
{
    public UInt160 SwapId;
    public UInt160 UserAddress;
    public UInt160 FromToken;
    public UInt160 ToToken;
    public BigInteger FromAmount;
    public BigInteger ToAmount;
    public BigInteger FeeAmount;
    public BigInteger Rate;
    public ulong Timestamp;
}

