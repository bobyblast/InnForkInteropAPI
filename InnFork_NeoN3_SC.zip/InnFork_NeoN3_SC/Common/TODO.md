# Common TODO Checklist

## ✅ Completed
- [x] Wired critical dispute and withdrawal events into application logic to surface activity through `IF_EventsDelegates` (see dispute resolution updates in `sc logic three/Project/IFProjectAccounts_AppMethods.cs` and facade withdrawals in `cs investing/Project/IF_ActorsAccountsFacade.cs`).
- [x] Implemented contract version storage and update workflow within `IF_MainGateway` infrastructure, including changelog persistence and a `ContractVersionUpdated` event (`cs infrastructure/Project/IFProjectAccounts_CoreMethods.cs`).
- [x] Added configurable storage-state contract routing with owner-governed setters and related events (`MiniAdapter/IFMiniAdapter.cs`, `cs infrastructure/IF_MainGateway.cs`).
- [x] Removed temporary test balances from all `BackerAccount` models to ensure production-safe defaults (multiple `Shared Models/Accounts/Backer/IFBackerAccount.cs`).
- [x] Replaced unsupported `DateTime.AddSeconds` usage with a deterministic Unix timestamp formatter compatible with Neo N3 (`Common/IF_Helpers.cs`).
- [x] Exposed withdraw flows for backers, investors, manufacturers, and project creators through the actors facade and account APIs (`cs investing/Project/IF_ActorsAccountsFacade.cs`, `cs infrastructure/Accounts/Creator/IFProjectCreatorAccount.cs`).
- [x] Delivered a fully functional dispute-resolution pipeline leveraging the storage contract API and broadcasting status events (`sc logic three/Project/IFProjectAccounts_AppMethods.cs`).
- [x] Migrated the AI moderator adapter to a managed contract pointer with MCP-style configurability and update events (`MiniAdapter/AIModerator_Adapter.cs`, `cs infrastructure/IF_MainGateway.cs`).

## 🚧 In Progress / Deferred
- [ ] Perform a full authorization audit to verify `Runtime.CheckWitness` coverage for every externally callable method (scope too large for this iteration; tracked for dedicated security review).
- [ ] Refactor voting storage interactions (`SetWinnerSelectionVote`, `SetReservedFunds`) to resolve architectural issues highlighted in logic-two modules.
- [ ] Extend the storage contract models with BalanceManager APIs and related helpers (`sc IF Storage/StateStorgageContract_Models.cs`).
- [ ] Implement delegation-cycle detection utilities and comprehensive API tests for the storage contract (`sc IF Storage` TODOs).
- [ ] Finalize manufacturer reservation helpers inside `MiniAdapter/IFMiniAdapter.cs` (getter/setter stubs remain to be completed).

Each completed item references the code updates from this branch; deferred items carry explanatory notes for future planning.
