
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;

namespace InnFork.NeoN3;



public partial class IFHelper
{
    private static readonly int[] DaysInMonthsCommon = new[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    private static readonly int[] DaysInMonthsLeap = new[] { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };


    public static bool validateAddress(UInt160 address)
    {
        return address.IsValid && !address.IsZero;
    }

    public static byte[] safeHexToBytes(string input)
    {
        // If the string is already in hex format (64 characters)
        if (input.Length == 64)
        {
            ExecutionEngine.Assert(isValidHex(input), "Invalid hex characters");
            return hexToBytes(input);
        }

        // If the string is binary data (32 bytes in UTF-8)
        if (input.Length == 32)
        {
            return input.ToByteArray();
        }

        ExecutionEngine.Assert(false, "Unsupported input format");
        return new byte[0];
    }

    public static bool isValidHex(string hex)
    {
        foreach (char c in hex)
        {
            if (!(c >= '0' && c <= '9') &&
                !(c >= 'A' && c <= 'F') &&
                !(c >= 'a' && c <= 'f'))
                return false;
        }
        return true;
    }

    public static byte[] hexToBytes(string hex)
    {
        ExecutionEngine.Assert(hex.Length == 64, "hexToBytes method: Invalid hex length. Param Length is: " + hex.Length.ToString()); // Reason: hexToBytes method: Invalid hex length. Param Lenght is: 32'

        byte[] bytes = new byte[32];
        for (int i = 0; i < 64; i += 2)
        {
            bytes[i / 2] = (byte)((getHexValue(hex[i]) << 4 | getHexValue(hex[i + 1])));
        }
        return bytes;
    }

    public static byte getHexValue(char c)
    {
        if (c >= '0' && c <= '9') return (byte)(c - '0');
        if (c >= 'A' && c <= 'F') return (byte)(c - 'A' + 10);
        if (c >= 'a' && c <= 'f') return (byte)(c - 'a' + 10);
        ExecutionEngine.Assert(false, "getHexValue Invalid hex character");
        return 0;
    }

    public static bool verifySignatureSHA256(byte[] publicKeyBytes, byte[] message, byte[] signature)
    {
        if (publicKeyBytes == null || message == null || signature == null)
            return false;

        if (publicKeyBytes.Length != 33 || signature.Length != 64)
            return false;

        try
        {
            ECPoint publicKey = (ECPoint)publicKeyBytes;
            return CryptoLib.VerifyWithECDsa((ByteString)message, publicKey, (ByteString)signature, NamedCurveHash.secp256r1SHA256);
        }
        catch
        {
            return false;
        }
    }

    public static UInt160 pubKeyToAddress(byte[] pubKey)
    {
        if (pubKey == null || pubKey.Length != 33)
            return UInt160.Zero; // Return a null address instead of an exception

        try
        {
            return Contract.CreateStandardAccount((ECPoint)pubKey);
        }
        catch
        {
            return UInt160.Zero;
        }
    }


    public static string get_Sha256SubKey_FromComplexValue(string complexKey_value)
    {
        if (complexKey_value.Length != 52) // 32 bytes for sha256 + 20 bytes for UInt160
            throw new Exception("Invalid complex key length");

        string Sha256value = complexKey_value.Substring(0, 32);// 20 bytes for UInt160

        return Sha256value;
    }

    public static byte extractStepNumberFromComplexKey(string complexKey)
    {
        // We assume that the stage number is the last byte in the key
        byte[] keyBytes = complexKey.ToByteArray();
        return keyBytes[keyBytes.Length - 1];
    }

    public static UInt160 getSecondParamUInt160FromComplexKey_Sha256_UInt160(string complexKey_value)
    {
        if (complexKey_value.Length != 52) // 32 bytes for sha256 + 20 bytes for UInt160
            throw new Exception("Invalid complex key length");

        UInt160 uint160_value = complexKey_value.Substring(31);// 20 bytes for UInt160

        return uint160_value;
    }


    public static UInt160 getFirst_UInt160_FromComplexValue(string complexKey_value)
    {
        if (complexKey_value.Length != 40) // 32 bytes for sha256 + 20 bytes for UInt160
            throw new Exception("Invalid complex key length");

        UInt160 uint160_value = complexKey_value.Substring(19);// 20 bytes for UInt160

        return uint160_value;
    }
    public static UInt160 getSecond_Unt160_FromComplexValue(string complexKey_value)
    {
        if (complexKey_value.Length != 40) // 32 bytes for sha256 + 20 bytes for UInt160
            throw new Exception("Invalid complex key length");

        UInt160 uint160_value = complexKey_value.Substring(0, 20);// 20 bytes for UInt160

        return uint160_value;
    }

    public static string createComplexKey(UInt160 uint160_value1, UInt160 uint160_value2)
    {
        return (string)uint160_value1 + (string)uint160_value2;
    }
    public static string createComplexKey(UInt160 valueUint160, byte valueByte)
    {
        return (string)valueUint160 + valueByte.ToString();
    }

    public static string createComplexKey(UInt160 uint160_value, string sha256_value)
    {
        return sha256_value + (string)uint160_value;
    }
    private static bool IsLeapYear(int year)
    {
        if (year % 4 != 0) return false;
        if (year % 100 == 0 && year % 400 != 0) return false;
        return true;
    }

    private static int DaysInMonth(int year, int month)
    {
        return IsLeapYear(year) ? DaysInMonthsLeap[month - 1] : DaysInMonthsCommon[month - 1];
    }

    public static string getDateTimeFromUnixTimeStampToString(ulong unixTime)
    {
        const ulong SecondsPerMinute = 60;
        const ulong SecondsPerHour = 60 * SecondsPerMinute;
        const ulong SecondsPerDay = 24 * SecondsPerHour;

        ulong remainingSeconds = unixTime;
        ulong daysSinceEpoch = remainingSeconds / SecondsPerDay;
        remainingSeconds %= SecondsPerDay;

        int hours = (int)(remainingSeconds / SecondsPerHour);
        remainingSeconds %= SecondsPerHour;
        int minutes = (int)(remainingSeconds / SecondsPerMinute);
        int seconds = (int)(remainingSeconds % SecondsPerMinute);

        int year = 1970;
        while (true)
        {
            int daysInYear = IsLeapYear(year) ? 366 : 365;
            if (daysSinceEpoch < (ulong)daysInYear)
                break;

            daysSinceEpoch -= (ulong)daysInYear;
            year++;
        }

        int month = 1;
        while (month <= 12)
        {
            int dim = DaysInMonth(year, month);
            if (daysSinceEpoch < (ulong)dim)
                break;

            daysSinceEpoch -= (ulong)dim;
            month++;
        }

        int day = (int)daysSinceEpoch + 1;

        string yearPart = year.ToString();
        string monthPart = month < 10 ? "0" + month : month.ToString();
        string dayPart = day < 10 ? "0" + day : day.ToString();
        string hourPart = hours < 10 ? "0" + hours : hours.ToString();
        string minutePart = minutes < 10 ? "0" + minutes : minutes.ToString();
        string secondPart = seconds < 10 ? "0" + seconds : seconds.ToString();

        return yearPart + "-" + monthPart + "-" + dayPart + " " + hourPart + ":" + minutePart + ":" + secondPart;
    }
}
