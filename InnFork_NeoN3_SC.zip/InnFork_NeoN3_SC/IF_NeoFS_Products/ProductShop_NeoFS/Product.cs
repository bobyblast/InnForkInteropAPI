using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{
    private static StorageMap ProductStore = new StorageMap(Storage.CurrentContext, "Products");
    private static StorageMap ManufacturerProductsStore = new StorageMap(Storage.CurrentContext, "ManufacturerProducts");
    private static StorageMap BackerRewardsMap = new StorageMap(Storage.CurrentContext, "BackerRewards");
    private static StorageMap CustomerMap = new StorageMap(Storage.CurrentContext, "Customers");
    private static StorageMap SalesStatisticsMap = new StorageMap(Storage.CurrentContext, "SalesStatistics");
    private static StorageMap ProductSalesMap = new StorageMap(Storage.CurrentContext, "ProductSales");
}