
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Linq;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.ComponentModel;
using System.Numerics;
using System.Reflection;
using System.Security.Cryptography;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{

    private static readonly string ManufacturerProductsMap_Prefix = "ManufacturerProductsMap_";

    // �������� ��� ���� � ����� IF_MainGateway ��� �������� ������������ manufacturer+productId -> productId
    private static readonly StorageMap ManufacturerProductsMap = new(Storage.CurrentContext, ManufacturerProductsMap_Prefix);

    public static UInt160 registerProduct(
        UInt160 manufacturerAddress,
        string projectId,
        string name,
        string description,
        string neoFSContainerId,
        string neoFSObjectId,
        BigInteger price,
        UInt160 priceToken,
        BigInteger quantity)
    {
        if (!Runtime.CheckWitness(manufacturerAddress))
            throw new Exception("Manufacturer authorization failed");

        if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(neoFSContainerId))
            throw new Exception("Invalid product data");

        if (price <= 0 || quantity <= 0)
            throw new Exception("Price and quantity must be positive");

        UInt160 productId = generateProductId(manufacturerAddress, name);

        Product product = new Product
        {
            ProductId = productId,
            ManufacturerAddress = manufacturerAddress,
            ProjectId = projectId,
            Name = name,
            Description = description,
            NeoFSContainerId = neoFSContainerId,
            NeoFSObjectId = neoFSObjectId,
            Price = price,
            PriceToken = priceToken,
            Quantity = quantity,
            CreatedAt = Runtime.Time,
            IsActive = true,
            IsDiscountActive = false,
            DiscountAmount = 0
        };

        // Persist product into dedicated product store
        ProductStore.Put((ByteString)productId, StdLib.Serialize(product));

        string manuKey = StdLib.Base64Encode((ByteString)manufacturerAddress) + "_" + StdLib.Base64Encode((ByteString)productId);
        ManufacturerProductsMap.Put(manuKey, productId);

        OnProductRegistered(productId, manufacturerAddress, projectId, name);

        return productId;
    }

    private static UInt160 generateProductId(UInt160 manufacturerAddress, string name)
    {
        // ��������� ������������������ �������������� �������� �� ������ ������ ������������� � �����
        byte[] addressBytes = (byte[])manufacturerAddress;
        byte[] nameBytes = (byte[])name.ToByteArray();
        byte[] combined = Helper.Concat(addressBytes, nameBytes);

        // productId = RIPEMD160(SHA256(manufacturer || name))
        ByteString sha = CryptoLib.Sha256((ByteString)combined);
        return (UInt160)CryptoLib.Ripemd160(sha);
    }

    public static void updateProductStock(UInt160 productId, BigInteger newQuantity)
    {
        ByteString data = ProductStore.Get(productId);
        if (data == null)
            throw new Exception("Product not found");

        Product product = (Product)StdLib.Deserialize(data);

        if (!Runtime.CheckWitness(product.ManufacturerAddress))
            throw new Exception("Only manufacturer can update stock");

        if (newQuantity < 0)
            throw new Exception("Quantity cannot be negative");

        product.Quantity = newQuantity;
        ProductStore.Put((ByteString)productId, StdLib.Serialize(product));

        OnProductStockUpdated(productId, newQuantity);
    }

    public static void setProductDiscount(UInt160 productId, bool isActive, BigInteger discountPercent)
    {
        ByteString data = ProductStore.Get(productId);
        if (data == null)
            throw new Exception("Product not found");

        Product product = (Product)StdLib.Deserialize(data);

        if (!Runtime.CheckWitness(product.ManufacturerAddress))
            throw new Exception("Only manufacturer can set discount");

        if (discountPercent < 0 || discountPercent > 100)
            throw new Exception("Discount must be between 0 and 100");

        product.IsDiscountActive = isActive;
        product.DiscountAmount = discountPercent;
        ProductStore.Put((ByteString)productId, StdLib.Serialize(product));

        OnProductDiscountSet(productId, isActive, discountPercent);
    }


    public delegate void OnProductRegisteredDelegate(UInt160 productId, UInt160 manufacturer, string projectId, string name);
    [DisplayName("ProductRegistered")]
    public static event OnProductRegisteredDelegate OnProductRegistered;

    public delegate void OnProductStockUpdatedDelegate(UInt160 productId, BigInteger newQuantity);
    [DisplayName("ProductStockUpdated")]
    public static event OnProductStockUpdatedDelegate OnProductStockUpdated;

    public delegate void OnProductDiscountSetDelegate(UInt160 productId, bool isActive, BigInteger discountPercent);
    [DisplayName("ProductDiscountSet")]
    public static event OnProductDiscountSetDelegate OnProductDiscountSet;
}