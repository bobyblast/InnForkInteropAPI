using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.ComponentModel;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{
    [InitialValue("0xef4073a0f2b305a38ec4050e4d3d28bc40ea63f5", ContractParameterType.Hash160)]
    private static readonly UInt160 NeoToken = default;
    [InitialValue("0xd2a4cff31913016155e38e474a2c06d08be276cf", ContractParameterType.Hash160)]
    private static readonly UInt160 GasToken = default;
    // Placeholder FUSD token hash, replace with actual deployed fUSDT/fUSD script hash on target network
    [InitialValue("0xcd48b160c1bbc9d74997b803b9a7ad50a4bef020", ContractParameterType.Hash160)]
    private static readonly UInt160 FUSDToken = default;

    private const int SWAP_FEE_PERCENT = 1;
    private const int MIN_SWAP_AMOUNT = 100000;

    private static StorageMap SwapHistoryStore = new StorageMap(Storage.CurrentContext, "SwapHistory");
    private static StorageMap SwapRatesStore = new StorageMap(Storage.CurrentContext, "SwapRates");

    public static BigInteger swapTokenToFUSD(UInt160 userAddress, UInt160 fromToken, BigInteger amount)
    {
        if (!Runtime.CheckWitness(userAddress))
            throw new Exception("User authorization failed");

        if (amount < MIN_SWAP_AMOUNT)
            throw new Exception("Amount below minimum swap threshold");

        if (fromToken != NeoToken && fromToken != GasToken)
            throw new Exception("Only NEO and GAS tokens supported");

        BigInteger rate = getSwapRate(fromToken, FUSDToken);
        if (rate <= 0)
            throw new Exception("Invalid swap rate");

        BigInteger feeAmount = (amount * SWAP_FEE_PERCENT) / 100;
        BigInteger amountAfterFee = amount - feeAmount;
        BigInteger fusdAmount = (amountAfterFee * rate) / 100000000;

        if (fusdAmount <= 0)
            throw new Exception("Resulting FUSD amount too small");

        bool transferSuccess = (bool)Contract.Call(fromToken, "transfer",
            CallFlags.All, new object[] { userAddress, Runtime.ExecutingScriptHash, amount, null });

        if (!transferSuccess)
            throw new Exception("Token transfer failed");

        bool fusdTransferSuccess = (bool)Contract.Call(FUSDToken, "transfer",
            CallFlags.All, new object[] { Runtime.ExecutingScriptHash, userAddress, fusdAmount, null });

        if (!fusdTransferSuccess)
        {
            Contract.Call(fromToken, "transfer", CallFlags.All,
                new object[] { Runtime.ExecutingScriptHash, userAddress, amount, null });
            throw new Exception("FUSD transfer failed");
        }

        UInt160 swapId = generateSwapId(userAddress, fromToken);
        SwapRecord record = new SwapRecord
        {
            SwapId = swapId,
            UserAddress = userAddress,
            FromToken = fromToken,
            ToToken = FUSDToken,
            FromAmount = amount,
            ToAmount = fusdAmount,
            FeeAmount = feeAmount,
            Rate = rate,
            Timestamp = Runtime.Time
        };

        SwapHistoryStore.Put((ByteString)swapId, StdLib.Serialize(record));

        OnTokenSwapped(userAddress, fromToken, FUSDToken, amount, fusdAmount);

        return fusdAmount;
    }

    public static void setSwapRate(UInt160 fromToken, UInt160 toToken, BigInteger rate)
    {
        if (rate <= 0)
            throw new Exception("Rate must be positive");

        string key = fromToken + "_" + toToken;
        SwapRatesStore.Put(key, rate);

        OnSwapRateUpdated(fromToken, toToken, rate);
    }

    public static BigInteger getSwapRate(UInt160 fromToken, UInt160 toToken)
    {
        string key = fromToken + "_" + toToken;
        ByteString result = SwapRatesStore.Get(key);

        if (result == null)
            return 100000000;

        return (BigInteger)result;
    }

    private static UInt160 generateSwapId(UInt160 userAddress, UInt160 token)
    {
        byte[] timeBytes = ((BigInteger)Runtime.Time).ToByteArray();
        byte[] data = Helper.Concat((byte[])userAddress, Helper.Concat((byte[])token, timeBytes));
        return (UInt160)CryptoLib.Ripemd160(data.ToByteString());
    }

    public delegate void OnTokenSwappedDelegate(UInt160 user, UInt160 fromToken, UInt160 toToken, BigInteger fromAmount, BigInteger toAmount);
    [DisplayName("TokenSwapped")]
    public static event OnTokenSwappedDelegate OnTokenSwapped;

    public delegate void OnSwapRateUpdatedDelegate(UInt160 fromToken, UInt160 toToken, BigInteger rate);
    [DisplayName("SwapRateUpdated")]
    public static event OnSwapRateUpdatedDelegate OnSwapRateUpdated;
}