﻿using Neo;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.ComponentModel;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{
    public delegate void OnRequestSuccessfulDelegate(string requestedUrl, object jsonValue);

    [DisplayName("FlamingoPriceRequestSuccessful")]
    public static event OnRequestSuccessfulDelegate OnFlamingoPriceRequestSuccessful;

    public static void doRequest()
    {
        var requestUrl = "https://cdn.flamingo.finance/token-info/prices";
        Oracle.Request(requestUrl, "$..*", "onOracleFlamingoPriceResponse", null, Oracle.MinimumResponseFee);
    }

    public static void convertToFLMStableCoin()
    {
        UInt160 sender = (UInt160)Runtime.CallingScriptHash;
        int neoAmount = 10_00000000; // 10 NEO
        int minFUSDTAmount = 1_00000000; // Minimum 1 fUSDT
        FlamingoSwap.SwapNEOForFUSDT(sender, neoAmount, minFUSDTAmount);
    }


    public static void onOracleFlamingoPriceResponse(string requestedUrl, object userData, OracleResponseCode oracleResponse, string jsonString)
    {
        if (Runtime.CallingScriptHash != Oracle.Hash) throw new InvalidOperationException("No Authorization!");

        if (oracleResponse != OracleResponseCode.Success) throw new Exception("Oracle response failure with code " + (byte)oracleResponse);

        var jsonArrayValues = (string[])StdLib.JsonDeserialize(jsonString);

        var jsonFirstValue = jsonArrayValues[0];

        OnFlamingoPriceRequestSuccessful(requestedUrl, jsonFirstValue);
    }

    public class FlamingoSwap
    {
        // Адрес контракта пула ликвидности NEO/fUSDT (замените на реальный скрипт-хэш)
        [InitialValue("0xca2d20610d7982ebe0bed124ee7e9b2d580a6efc", ContractParameterType.Hash160)]
        private static readonly UInt160 PoolContractHash = default;

        // Адрес контракта токена NEO
        [InitialValue("0xef4073a0f2b305a38ec4050e4d3d28bc40ea63f5", ContractParameterType.Hash160)]
        private static readonly UInt160 NEOTokenHash = default;

        // Адрес контракта токена fUSDT
        [InitialValue("0xcd48b160c1bbc9d74997b803b9a7ad50a4bef020", ContractParameterType.Hash160)]
        private static readonly UInt160 FUSDTTokenHash = default;

        // Метод для обмена NEO на fUSDT через AMM
        public static bool SwapNEOForFUSDT(UInt160 sender, BigInteger neoAmount, BigInteger minFUSDTAmount)
        {
            // Проверка, что отправитель авторизован
            if (!Runtime.CheckWitness(sender))
                throw new Exception("Unauthorized");

            // Передача NEO от отправителя в контракт пула
            var transferNEO = (bool)Contract.Call(NEOTokenHash, "transfer", CallFlags.All, sender, PoolContractHash, neoAmount, null);
            if (!transferNEO)
                throw new Exception("NEO transfer failed");

            // Вызов метода `swap` в контракте пула ликвидности
            var swapResult = (bool)Contract.Call(PoolContractHash, "swap", CallFlags.All, sender, NEOTokenHash, FUSDTTokenHash, neoAmount, minFUSDTAmount);
            if (!swapResult)
                throw new Exception("Swap failed");

            return true;
        }
    }
}



