using Neo;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System.ComponentModel;
using static InnFork.NeoN3.IF_MainGateway;

namespace InnFork.NeoN3
{
    [DisplayName("InnFork_Market")]
    [ContractAuthor("InnFork", "info@innfork.com")]
    [ContractDescription("InnFork crowdfunding platform")]
    [ContractVersion("<1>")]
    [ContractSourceCode("https://github.com/InnFork")]
    [ContractPermission(Permission.Any, Method.Any)]
    public partial class IF_MainGateway
    {
        // Storage Maps
        public static StorageMap ProductIdToPriceStore = new StorageMap(Storage.CurrentContext, "ProductIdToPriceStore");
        public static StorageMap ProductAddonIdToPriceStore = new StorageMap(Storage.CurrentContext, "ProductAddonIdToPriceStore");
        public static StorageMap OrderIdKeyToOrderHashMap = new StorageMap(Storage.CurrentContext, "OrderIdKeyToOrderHashMap");
        public static StorageMap ManufacturerAccountStore = new StorageMap(Storage.CurrentContext, "ManufacturerAccountStore");



        // Get Manufacturer Account
        public static ManufacturerAccount? getManufacturerAccount(UInt160 manufacturerAddress)
        {
            var raw = ManufacturerAccountStore.Get(manufacturerAddress);
            if (raw == null || raw.Length == 0) return null;
            return (ManufacturerAccount)StdLib.Deserialize(raw);
        }

        // Create Manufacturer Account
        public static void createManufacturerAccount(UInt160 manufacturerAddress, string name, byte[] publicKey)
        {
            if (manufacturerAddress.Length != 20)
                throw new System.Exception("Invalid manufacturer address");

            if (!Runtime.CheckWitness(manufacturerAddress))
                throw new System.Exception("Only manufacturer can create their account");

            if (ManufacturerAccountStore.Get(manufacturerAddress) != null)
                throw new System.Exception("Manufacturer already registered");

            ManufacturerAccount account = new ManufacturerAccount(manufacturerAddress, publicKey);

            ManufacturerAccountStore.Put(manufacturerAddress, StdLib.Serialize(account));
        }

        [Safe]
        public static string GetResponse()
        {
            return Storage.Get(Storage.CurrentContext, "Response");
        }

        // example entry
        public static void RequestObject(string containerId, string objectId, string userKey)
        {
            // ��������� URI � neofs ������
            string uri = "neofs://" + containerId + "/" + objectId;
            // �����������: ��������� �������, JSONPath � �.�.
            Oracle.Request(uri, "", "OracleCallback", userKey, Oracle.MinimumResponseFee);
        }

        public static void OracleCallback(ByteString userKey, ByteString result)
        {
            if (Runtime.CallingScriptHash != Oracle.Hash)
                throw new System.Exception("Unauthorized");

            if (result is null || result.Length == 0)
            {
                // ��� ������
                return;
            }
            // ��������, result � JSON-������ ��� ������ ������, ��������:
            // { "price": 123, "name": "ItemA" }
            // ����� ���������� JSON ������� (� ������������ ������) ��� ������� ������� ������

            var jsonArrayValues = (object[])StdLib.JsonDeserialize(result);
            var jsonFirstValue = (string)jsonArrayValues[0];

            Storage.Put(Storage.CurrentContext, "Response", jsonFirstValue);

            // ������: ������� ���� JSON ��� ���� userKey
            Storage.Put(Storage.CurrentContext, userKey, result);
        }

        [Safe]
        public static ByteString Query(string key)
        {
            return Storage.Get(Storage.CurrentContext, key);
        }

        [Safe]
        public static UInt160 owner()
        {
            // For now, set the deployer/owner to this contract hash, can be adjusted to a stored admin
            // In a real deployment, you may want to store and manage owner in storage during deploy
            return (UInt160)Runtime.ExecutingScriptHash;
        }
    }
}
