namespace InnFork.NeoN3
{

    public enum ModerationType : byte
    {
        ProjectOffer = 1,
        ProjectDescription = 2,
        ManufacturerProfile = 3,
        ProductDescription = 4,
        DisputeEvidence = 5,
        UserComment = 6,
        ProjectUpdate = 7,
        RefundRequest = 8
    }
}

