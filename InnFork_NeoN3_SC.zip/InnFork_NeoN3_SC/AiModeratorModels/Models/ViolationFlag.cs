namespace InnFork.NeoN3
{

    public enum ViolationFlag : int
    {
        None = 0,
        Spam = 1 << 0,
        Scam = 1 << 1,
        OffensiveLanguage = 1 << 2,
        FalseInformation = 1 << 3,
        Copyright = 1 << 4,
        AdultContent = 1 << 5,
        Violence = 1 << 6,
        IllegalContent = 1 << 7,
        Plagiarism = 1 << 8,
        LowQuality = 1 << 9,
        Unrealistic = 1 << 10,
        MissingInfo = 1 << 11,
        SuspiciousActivity = 1 << 12
    }
}
