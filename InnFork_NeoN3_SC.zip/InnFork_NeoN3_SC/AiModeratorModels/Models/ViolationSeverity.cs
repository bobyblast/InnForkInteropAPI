namespace InnFork.NeoN3
{

    public enum ViolationSeverity : byte
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }
}

