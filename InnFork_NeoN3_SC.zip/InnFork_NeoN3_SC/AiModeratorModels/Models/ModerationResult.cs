using Neo.SmartContract.Framework;

using System.Numerics;

namespace InnFork.NeoN3
{

    public class ModerationResult
    {
        public string RequestId; // unique id
        public byte ModerationType; // see enum
        public bool IsApproved; // decision
        public BigInteger ConfidenceScore; //0..100
        public BigInteger ViolationFlags; // bitmask
        public string ViolationCategory; // string label
        public string Explanation; // short reason
        public ulong Timestamp; // Runtime.Time
        public UInt160 Requester; // who initiated
    }
}

