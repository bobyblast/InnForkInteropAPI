﻿using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Attributes;
using System;
using System.ComponentModel;
using System.Numerics;
using InnFork.NeoN3.Enums;


namespace InnFork.NeoN3;




public partial class ProjectAccount // часть класса с переменными и методами подсистемы голосования по проекту
{

    private static readonly byte[] ContractVersionKey = "if:contract:version".ToByteArray();
    private static readonly byte[] ContractVersionChangelogKey = "if:contract:version:changelog".ToByteArray();

    [DisplayName("ContractVersionUpdated")]
    public static event Action<int, int, string> ContractVersionUpdated;

    public static int ContractVersion
    {
        get
        {
            ByteString value = Storage.Get(Storage.CurrentContext, ContractVersionKey);
            return value is null || value.Length == 0 ? 1 : (int)(BigInteger)value;
        }
        private set => Storage.Put(Storage.CurrentContext, ContractVersionKey, (BigInteger)value);
    }

    [Safe]
    public static int getContractVersion()
    {
        return ContractVersion;
    }

    [Safe]
    public static string getContractVersionChangelog()
    {
        ByteString value = Storage.Get(Storage.CurrentContext, ContractVersionChangelogKey);
        return value is null ? string.Empty : (string)value;
    }

    public static void updateContractVersion(int newVersion, string changelogHash)
    {
        if (!IF_MainGateway.IsOwner())
            throw new Exception("Only owner can update contract version");

        if (newVersion <= ContractVersion)
            throw new Exception("New version must be greater than current version");

        if (changelogHash is null || changelogHash.Length == 0)
            throw new Exception("Changelog hash is required");

        int previousVersion = ContractVersion;
        ContractVersion = newVersion;
        Storage.Put(Storage.CurrentContext, ContractVersionChangelogKey, changelogHash);

        ContractVersionUpdated(previousVersion, newVersion, changelogHash);
    }



    public static void saveProjectAccountToProjectsAccountStore(string projectId, ProjectAccount project)
    {
        if (project == null) throw new Exception("Project param is null: " + projectId);
        if (string.IsNullOrEmpty(projectId) || (projectId.Length != 32 && projectId.Length != 64))
            throw new Exception("saveProjectAccountToProjectsAccountStore: Invalid projectId format. Length is: " + (projectId == null ? 0 : projectId.Length));

        project.LastActivityTime = Runtime.Time;
        var coreDto = ToCoreDto(projectId, project);
        var coreBytes = StdLib.Serialize(coreDto);

        ProjectState.SetProjectCore(projectId, coreBytes);

        try { ProjectState.SetLastActivityTime(projectId, project.LastActivityTime); } catch { }
        try { ProjectState.SetProjectTotalBalance(projectId, project.FLMUSD_TotalProjectBalance); } catch { }
        try { ProjectState.SetLockedFunds(projectId, project.totalFundsLocked); } catch { }
        try { ProjectState.SetTotalRefundsProcessed(projectId, project.TotalRefundsProcessed); } catch { }
        try { ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, project.IsProjectHasWinner); } catch { }
        try { ProjectState.SetProjectStatus(projectId, (int)project.CurrentProjectStatus); } catch { }
        try { ProjectState.SetVotingConfiguration(projectId, project.MinRequiredVotingParticipation, project.MinApprovalPercentage, project.AutoAssignVoicelessToAbstain, project.AutoAbstainVoteAsSupport); } catch { }

        try
        {
            if (project.LaunchVotingDeadline > 0 || project.FundraisingDeadline > 0 || project.ManufacturerSelectionVotingDeadline > 0)
                ProjectState.SetProjectVotingDeadlines(projectId, project.LaunchVotingDeadline, project.FundraisingDeadline, project.ManufacturerSelectionVotingDeadline);

            ProjectState.SyncVotingDeadline(projectId, "LaunchApproval", project.LaunchVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "FundraisingCompletion", project.FundraisingCompletionVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "SuccessfulClosure", project.SuccessfulClosureVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "PauseResume", project.PauseResumeVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "ManufacturerSelection", project.ManufacturerSelectionVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "TerminationWithRefund", project.TerminationWithRefundVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "FundraisingIncrease", project.FundraisingIncreaseVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "ManagementTransfer", project.ManagementTransferVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "MilestoneCompletion", project.MilestoneCompletionVotingDeadline);
        }
        catch { }
    }



    //TOSO: разобраться с загрузкой settings во всех проектах

    public ProjectSettings projectSettings { get; set; } = new ProjectSettings(); // <--- настройки проекта

    public string getProjectSettingsJson()
    {
        return StdLib.Serialize(this.projectSettings);
    }

    public void setProjectSettingsJson(string projectSettingsJson)
    {
        if (Runtime.CheckWitness(ProjectCreatorAddress) == false && DirectInnForkProjectManagement == false)
            throw new Exception("Only project creator can set project settings.");
        else
            if (DirectInnForkProjectManagement == true && IF_MainGateway.IsOwner() == false)
            throw new Exception("Only InnFork Gateway can set project settings.");


        // проверяем дедлайн по записи настроек от projectCreator. Если больше месяца с начала проекта - выходим

        projectSettings = (ProjectSettings)StdLib.Deserialize(projectSettingsJson);

        AutoAssignVoicelessToAbstain = projectSettings.AutoAssignVoicelessToAbstain;// <--- Флаг для автоматического учета безголосых как воздержавшихся
        AutoAbstainVoteAsSupport = projectSettings.AutoAbstainVoteAsSupport; // <--- Флаг для автоматического учета воздержавшихся голосов как поддерживающих

        // Настройки голосования
        MinimumVotesRequired = projectSettings.MinimumVotesRequired; // Минимальное количество голосов
        MinRequiredVotingParticipation = projectSettings.MinRequiredVotingParticipation; // Минимальная требуемая доля голосования
        MinApprovalPercentage = projectSettings.MinApprovalPercentage; // Минимальный процент одобрения

        // Настройки этапов финансирования
        DefaultFundingType = (MilestoneFundingType)projectSettings.DefaultFundingType; // Тип финансирования по умолчанию
        DefaultVotingDuration = projectSettings.DefaultVotingDuration; // Длительность голосования по умолчанию
        AllowSteppedFinancing = projectSettings.AllowSteppedFinancing; // Разрешить поэтапное финансирование
        MaxMilestoneSteps = projectSettings.MaxMilestoneSteps; // Максимальное количество этапов финансирования

        // Настройки производителей
        MaxManufacturers = projectSettings.MaxManufacturers;
        //   project.MinManufacturerInvestment = projectSettings.MinManufacturerInvestment; // Минимальная инвестиция от производителя
        DefaultPrizeFundAllocation = projectSettings.DefaultPrizeFundAllocation; // Доля призового фонда по умолчанию

        // Финансовые настройки
        CreatorFeePercentage = projectSettings.CreatorFeePercentage; // Процент комиссии создателя проекта
        CreatorFixedReward = projectSettings.CreatorFixedReward; // Фиксированная награда для создателя проекта
        FLMUSD_PrizeFundGoal = projectSettings.FLMUSD_PrizeFundGoal; // Целевая сумма в долларах для сбора средств

        // Настройки безопасности и мониторинга
        WithdrawalTimeout = projectSettings.WithdrawalTimeout; // Таймаут на вывод средств
        EnableFraudDetection = projectSettings.EnableFraudDetection; // Включить обнаружение мошенничества

        // Настройки автоматизации
        AutoDistributeConsentedFunds = projectSettings.AutoDistributeConsentedFunds; // Автоматически распределять согласованные средства
        AutoPauseEnabled = projectSettings.AutoPauseEnabled; // Автоматически приостанавливать проект при недостаточном финансировании
        AutoFinishExpiredVotings = projectSettings.AutoFinishExpiredVotings; // Автоматически завершать истекшие голосования

        // Настройки временных параметров

        FundraisingDeadline = projectSettings.FundraisingDeadline; // время окончания сбора средств
        ManufacturerSelectionDeadline = projectSettings.ManufacturerSelectionDeadline; // Дедлайн выбора производителей
        LaunchVotingDeadline = projectSettings.LaunchVotingDeadline; // Дедлайн запуска голосования
        FundraisingVotingDeadline = projectSettings.FundraisingVotingDeadline; // Дедлайн голосования по сбору средств


        // Базовые настройки проекта
        /*        if (projectSettings.ProjectName != null && projectSettings.ProjectName.Length > 0)
                    project.ProjectName = projectSettings.ProjectName;*/

        if (projectSettings.ProjectDescription_NeoFS_Address != null && projectSettings.ProjectDescription_NeoFS_Address.Length > 0)
            ProjectDescription_NeoFS_Address = projectSettings.ProjectDescription_NeoFS_Address;

        saveProjectAccountToProjectsAccountStore(projectId, this);
    }



    internal class ProjectCoreStateDto
    {
        public string ProjectId;
        public UInt160 ProjectCreatorAddress;
        public BigInteger FLMUSD_TotalProjectBalance;
        public BigInteger FLMUSD_PrizeFundBalance;
        public BigInteger TotalRefundsProcessed;
        public BigInteger TotalFundsLocked;
        public bool IsArchived;
        public bool IsProjectPaused;
        public bool IsProjectClosed;
        public bool IsProjectHasWinner;
        public int CurrentProjectStatus;
        public BigInteger MinRequiredVotingParticipation;
        public BigInteger MinApprovalPercentage;
        public bool AutoAssignVoicelessToAbstain;
        public bool AutoAbstainVoteAsSupport;
        public ulong LaunchVotingDeadline;
        public ulong FundraisingDeadline;
        public ulong FundraisingCompletionVotingDeadline;
        public ulong SuccessfulClosureVotingDeadline;
        public ulong PauseResumeVotingDeadline;
        public ulong ManufacturerSelectionVotingDeadline;
        public ulong TerminationWithRefundVotingDeadline;
        public ulong MilestoneCompletionVotingDeadline;
        public ulong ManagementTransferVotingDeadline;
        public ulong RegistrationTime;
        public ulong LastActivityTime;
        public string ProjectOfferId_Sha256;
    }

    private static ProjectCoreStateDto ToCoreDto(string projectId, ProjectAccount account)
    {
        return new ProjectCoreStateDto
        {
            ProjectId = projectId,
            ProjectCreatorAddress = account.ProjectCreatorAddress,
            FLMUSD_TotalProjectBalance = account.FLMUSD_TotalProjectBalance,
            FLMUSD_PrizeFundBalance = account.FLMUSD_PrizeFundBalance,
            TotalRefundsProcessed = account.TotalRefundsProcessed,
            TotalFundsLocked = account.totalFundsLocked,
            IsArchived = account.IsArchived,
            IsProjectPaused = account.IsProjectPaused,
            IsProjectClosed = account.IsProjectClosed,
            IsProjectHasWinner = account.IsProjectHasWinner,
            CurrentProjectStatus = (int)account.CurrentProjectStatus,
            MinRequiredVotingParticipation = account.MinRequiredVotingParticipation,
            MinApprovalPercentage = account.MinApprovalPercentage,
            AutoAssignVoicelessToAbstain = account.AutoAssignVoicelessToAbstain,
            AutoAbstainVoteAsSupport = account.AutoAbstainVoteAsSupport,
            LaunchVotingDeadline = account.LaunchVotingDeadline,
            FundraisingDeadline = account.FundraisingDeadline,
            FundraisingCompletionVotingDeadline = account.FundraisingCompletionVotingDeadline,
            SuccessfulClosureVotingDeadline = account.SuccessfulClosureVotingDeadline,
            PauseResumeVotingDeadline = account.PauseResumeVotingDeadline,
            ManufacturerSelectionVotingDeadline = account.ManufacturerSelectionVotingDeadline,
            TerminationWithRefundVotingDeadline = account.TerminationWithRefundVotingDeadline,
            MilestoneCompletionVotingDeadline = account.MilestoneCompletionVotingDeadline,
            ManagementTransferVotingDeadline = account.ManagementTransferVotingDeadline,
            RegistrationTime = account.RegistrationTime,
            LastActivityTime = account.LastActivityTime,
            ProjectOfferId_Sha256 = account.ProjectOfferId_Sha256
        };
    }

    private static void ApplyCoreDto(ProjectAccount account, ProjectCoreStateDto dto)
    {
        account.ProjectCreatorAddress = dto.ProjectCreatorAddress;
        account.FLMUSD_TotalProjectBalance = dto.FLMUSD_TotalProjectBalance;
        account.FLMUSD_PrizeFundBalance = dto.FLMUSD_PrizeFundBalance;
        account.TotalRefundsProcessed = dto.TotalRefundsProcessed;
        account.totalFundsLocked = dto.TotalFundsLocked;
        account.IsArchived = dto.IsArchived;
        account.IsProjectPaused = dto.IsProjectPaused;
        account.IsProjectClosed = dto.IsProjectClosed;
        account.IsProjectHasWinner = dto.IsProjectHasWinner;
        account.CurrentProjectStatus = (ProjectStatus)dto.CurrentProjectStatus;
        account.MinRequiredVotingParticipation = dto.MinRequiredVotingParticipation;
        account.MinApprovalPercentage = dto.MinApprovalPercentage;
        account.AutoAssignVoicelessToAbstain = dto.AutoAssignVoicelessToAbstain;
        account.AutoAbstainVoteAsSupport = dto.AutoAbstainVoteAsSupport;
        account.LaunchVotingDeadline = dto.LaunchVotingDeadline;
        account.FundraisingDeadline = dto.FundraisingDeadline;
        account.FundraisingCompletionVotingDeadline = dto.FundraisingCompletionVotingDeadline;
        account.SuccessfulClosureVotingDeadline = dto.SuccessfulClosureVotingDeadline;
        account.PauseResumeVotingDeadline = dto.PauseResumeVotingDeadline;
        account.ManufacturerSelectionVotingDeadline = dto.ManufacturerSelectionVotingDeadline;
        account.TerminationWithRefundVotingDeadline = dto.TerminationWithRefundVotingDeadline;
        account.MilestoneCompletionVotingDeadline = dto.MilestoneCompletionVotingDeadline;
        account.ManagementTransferVotingDeadline = dto.ManagementTransferVotingDeadline;
        account.RegistrationTime = dto.RegistrationTime;
        account.LastActivityTime = dto.LastActivityTime;
        account.ProjectOfferId_Sha256 = dto.ProjectOfferId_Sha256;
    }


    public static ProjectAccount getProjectAccount(string projectId)
    {
        if (projectId.Length != 32 && projectId.Length != 64)
            throw new Exception("getProjectAccount: Invalid projectId format. Lenght is: " + projectId.Length.ToString());

        var coreBytes = ProjectState.GetProjectCoreBytes(projectId);
        if (coreBytes is null) throw new Exception("getProjectAccount: Project not found");

        var dto = (ProjectCoreStateDto)StdLib.Deserialize(coreBytes);
        var p = new ProjectAccount();
        ApplyCoreDto(p, dto);
        p.projectId = projectId;
        return p;
    }

}

