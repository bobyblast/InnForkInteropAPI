using System;
using System.Numerics;
using Xunit;
using Neo;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3.Enums;


namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
    public class ComplianceSanctionsTests
    {
        private readonly string _testProjectId = "test_project_123";
        private readonly UInt160 _testBacker = UInt160.Parse("0x1234567890123456789012345678901234567890");
        private readonly UInt160 _testManufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

        [Fact]
        public void ApplyBackerBan_WithValidReason_ExecutesSuccessfully()
        {
            // Arrange
            var reason = BanReason.ReviewManipulation;

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Compliance.Sanctions.ApplyBackerBan(
                    _testProjectId, _testBacker, reason));

            Assert.Null(exception);
        }

        [Fact]
        public void ApplyManufacturerBan_WithValidReason_ExecutesSuccessfully()
        {
            // Arrange
            var reason = BanReason.FalseDispute;

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Compliance.Sanctions.ApplyManufacturerBan(
                    _testProjectId, _testManufacturer, reason));

            Assert.Null(exception);
        }

        [Fact]
        public void BanBacker_WithValidReason_ExecutesSuccessfully()
        {
            // Arrange
            var reason = BanReason.ReviewManipulation;

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Compliance.Sanctions.BanBacker(
                    _testProjectId, _testBacker, reason));

            Assert.Null(exception);
        }

        [Fact]
        public void ClearPenalty_WithValidManufacturer_ExecutesSuccessfully()
        {
            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Compliance.Sanctions.ClearPenalty(
                    _testProjectId, _testManufacturer));

            Assert.Null(exception);
        }

        [Fact]
        public void ProcessAutomaticUnbans_WithValidProjectId_ExecutesSuccessfully()
        {
            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Compliance.Sanctions.ProcessAutomaticUnbans(_testProjectId));

            Assert.Null(exception);
        }
    }

    public class ComplianceInsightsTests
    {
        private readonly string _testProjectId = "test_project_123";
        private readonly UInt160 _testParticipant = UInt160.Parse("0x1234567890123456789012345678901234567890");

        [Fact]
        public void GetParticipantBanReason_WithValidParticipant_ReturnsBanReason()
        {
            // Act
            var result = InnFork_DDD_Wrapper.Compliance.Insights.GetParticipantBanReason(
                _testProjectId, _testParticipant);

            // Assert
            Assert.IsType<BanReason>(result);
        }

        [Fact]
        public void GetManufacturerTotalPenalties_WithValidManufacturer_ReturnsBigInteger()
        {
            // Act
            var result = InnFork_DDD_Wrapper.Compliance.Insights.GetManufacturerTotalPenalties(
                _testProjectId, _testParticipant);

            // Assert
            Assert.IsType<BigInteger>(result);
        }

        [Fact]
        public void IsParticipantBanned_WithValidParticipant_ReturnsBool()
        {
            // Act
            var result = InnFork_DDD_Wrapper.Compliance.Insights.IsParticipantBanned(
                _testProjectId, _testParticipant);

            // Assert
            Assert.IsType<bool>(result);
        }

        [Fact]
        public void GetRiskScore_WithValidReason_ReturnsBigInteger()
        {
            // Arrange
            var reason = BanReason.ReviewManipulation;

            // Act
            var result = InnFork_DDD_Wrapper.Compliance.Insights.GetRiskScore(reason);

            // Assert
            Assert.IsType<BigInteger>(result);
        }
    }
}