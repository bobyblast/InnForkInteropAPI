using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class FinancePrizeFundTests_2
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void GetBackerDonation_ReturnsBI()
 {
 var res = InnFork_DDD_Wrapper.Finance.PrizeFund.GetBackerDonation(_projectId, _backer);
 Assert.IsType<BigInteger>(res);
 }

 [Fact]
 public void HasBackerDonated_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.Finance.PrizeFund.HasBackerDonated(_projectId, _backer);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void ProcessDonation_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.PrizeFund.ProcessDonation(_projectId, _backer, new BigInteger(42)));
 Assert.Null(ex);
 }

 [Fact]
 public void SetBackerAutoConsent_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.PrizeFund.SetBackerAutoConsent(_projectId, _backer, true));
 Assert.Null(ex);
 }
 }
}
