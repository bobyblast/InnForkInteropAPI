using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class FinanceTreasuryCoreTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void BlockUnblockFunds_DoesNotThrow()
 {
 var ex1 = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.BlockBackerFunds(_projectId, _backer, InnFork.NeoN3.Enums.BanReason.SecurityBreach, new BigInteger(10)));
 var ex2 = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.UnblockBackerFunds(_projectId, _backer, new BigInteger(10)));
 Assert.Null(ex1);
 Assert.Null(ex2);
 }

 [Fact]
 public void LockUnlockFunds_DoesNotThrow()
 {
 var ex1 = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.LockFunds(_projectId, new BigInteger(100)));
 var ex2 = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.UnlockFunds(_projectId, new BigInteger(50)));
 Assert.Null(ex1);
 Assert.Null(ex2);
 }
 }
}
