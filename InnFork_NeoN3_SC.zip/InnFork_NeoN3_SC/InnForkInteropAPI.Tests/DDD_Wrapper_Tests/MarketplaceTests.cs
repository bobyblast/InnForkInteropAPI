using System.Collections.Generic;
using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class MarketplaceManufacturersTests
 {
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void CreateManufacturerAccount_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Manufacturers.CreateManufacturerAccount(_manufacturer, "name", new byte[] {1,2,3}));
 Assert.Null(ex);
 }

 [Fact]
 public void GetManufacturerAccount_ReturnsModel()
 {
 var res = InnFork_DDD_Wrapper.Marketplace.Manufacturers.GetManufacturerAccount(_manufacturer);
 Assert.IsType<ManufacturerAccount>(res);
 }

 [Fact]
 public void GetManufacturerSalesAnalytics_ReturnsDict()
 {
 var res = InnFork_DDD_Wrapper.Marketplace.Manufacturers.GetManufacturerSalesAnalytics(_manufacturer);
 Assert.IsAssignableFrom<Dictionary<string, System.Numerics.BigInteger>>(res);
 }
 }

 public class MarketplaceCatalogTests
 {
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");
 private readonly UInt160 _token = UInt160.Parse("0x1234567890123456789012345678901234567890");

 [Fact]
 public void RegisterProduct_ReturnsProductId()
 {
 var id = InnFork_DDD_Wrapper.Marketplace.Catalog.RegisterProduct(_manufacturer, "p", "name", "descr", "cont","obj", new System.Numerics.BigInteger(10), _token, new System.Numerics.BigInteger(1));
 Assert.IsType<UInt160>(id);
 }

 [Fact]
 public void UpdateProductStock_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Catalog.UpdateProductStock(UInt160.Zero, new System.Numerics.BigInteger(5)));
 Assert.Null(ex);
 }

 [Fact]
 public void SetProductDiscount_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Catalog.SetProductDiscount(UInt160.Zero, true, new System.Numerics.BigInteger(10)));
 Assert.Null(ex);
 }

 [Fact]
 public void GetProductStatistics_ReturnsStats()
 {
 var stats = InnFork_DDD_Wrapper.Marketplace.Catalog.GetProductStatistics(UInt160.Zero);
 Assert.IsType<ProductSalesStats>(stats);
 }
 }

 public class MarketplaceOrdersTests
 {
 private readonly UInt160 _customer = UInt160.Parse("0x1111111111111111111111111111111111111111");

 [Fact]
 public void RegisterCustomer_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Orders.RegisterCustomer(_customer));
 Assert.Null(ex);
 }

 [Fact]
 public void CreateCancelConfirmOrder_DoesNotThrow()
 {
 var ex1 = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Orders.CreateOrder(UInt160.Zero, UInt160.Zero, _customer, new System.Numerics.BigInteger(1), _customer));
 var ex2 = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Orders.CancelOrder(UInt160.Zero, _customer));
 var ex3 = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Orders.ConfirmOrder(UInt160.Zero, _customer, UInt160.Zero));
 Assert.Null(ex1);
 Assert.Null(ex2);
 Assert.Null(ex3);
 }

 [Fact]
 public void GetOrder_ReturnsOrder()
 {
 var order = InnFork_DDD_Wrapper.Marketplace.Orders.GetOrder(UInt160.Zero);
 Assert.IsType<Order>(order);
 }

 [Fact]
 public void PurchaseProduct_ReturnsId()
 {
 var id = InnFork_DDD_Wrapper.Marketplace.Orders.PurchaseProduct(UInt160.Zero, _customer, new System.Numerics.BigInteger(1), UInt160.Zero);
 Assert.IsType<UInt160>(id);
 }
 }

 public class MarketplacePricingTests
 {
 private readonly UInt160 _product = UInt160.Zero;

 [Fact]
 public void CalculateFinalPrice_ReturnsBI()
 {
 var price = InnFork_DDD_Wrapper.Marketplace.Pricing.CalculateFinalPrice(_product, UInt160.Zero, new System.Numerics.BigInteger(1));
 Assert.IsType<System.Numerics.BigInteger>(price);
 }

 [Fact]
 public void ConvertToStableCoin_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Pricing.ConvertToStableCoin());
 Assert.Null(ex);
 }

 [Fact]
 public void DepositCustomerFunds_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Pricing.DepositCustomerFunds(UInt160.Zero, UInt160.Zero, new System.Numerics.BigInteger(10)));
 Assert.Null(ex);
 }

 [Fact]
 public void SwapRates_Flow()
 {
 var rate = InnFork_DDD_Wrapper.Marketplace.Pricing.GetSwapRate(UInt160.Zero, UInt160.Zero);
 Assert.IsType<System.Numerics.BigInteger>(rate);
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Pricing.SetSwapRate(UInt160.Zero, UInt160.Zero, new System.Numerics.BigInteger(2)));
 Assert.Null(ex);
 }

 [Fact]
 public void SwapTokenToFusd_ReturnsBI()
 {
 var res = InnFork_DDD_Wrapper.Marketplace.Pricing.SwapTokenToFusd(UInt160.Zero, UInt160.Zero, new System.Numerics.BigInteger(1));
 Assert.IsType<System.Numerics.BigInteger>(res);
 }

 [Fact]
 public void GetTotalBackerRewards_ReturnsBI()
 {
 var res = InnFork_DDD_Wrapper.Marketplace.Pricing.GetTotalBackerRewards("p", UInt160.Zero);
 Assert.IsType<System.Numerics.BigInteger>(res);
 }
 }

 public class MarketplaceIntegrationTests
 {
 [Fact]
 public void DoRequest_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Integration.DoRequest());
 Assert.Null(ex);
 }

 [Fact]
 public void RequestAndOracleCallbacks_DoesNotThrow()
 {
 var ex1 = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Integration.RequestObject("c","o","k"));
 var ex2 = Record.Exception(() => InnFork_DDD_Wrapper.Marketplace.Integration.OnOracleFlamingoPriceResponse("url", new { }, default, "{}"));
 // Skip direct ByteString construction to avoid VM type conflicts in unit tests.
 Assert.Null(ex1);
 Assert.Null(ex2);
 }

 [Fact]
 public void QueryAndGetResponse_Returns()
 {
 var bs = InnFork_DDD_Wrapper.Marketplace.Integration.Query("key");
 Assert.NotNull(bs);
 var resp = InnFork_DDD_Wrapper.Marketplace.Integration.GetResponse();
 Assert.IsType<string>(resp);
 }
 }
}
