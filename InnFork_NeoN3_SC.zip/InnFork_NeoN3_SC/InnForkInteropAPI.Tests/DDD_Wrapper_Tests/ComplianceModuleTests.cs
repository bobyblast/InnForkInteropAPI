using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3.Enums;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class ComplianceSanctionsModuleTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact] public void ApplyBackerBan_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.ApplyBackerBan(_projectId, _backer, BanReason.FraudulentActivity)));
 [Fact] public void ApplyManufacturerBan_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.ApplyManufacturerBan(_projectId, _manufacturer, BanReason.SecurityBreach)));
 [Fact] public void BanBacker_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.BanBacker(_projectId, _backer, BanReason.SystemAbuse)));
 [Fact] public void BanManufacturer_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.BanManufacturer(_projectId, _manufacturer, BanReason.QualityIssues)));
 [Fact] public void ApplyGradedFraudPenalty_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.ApplyGradedFraudPenalty(_projectId, _backer, FraudType.SybilAttack)));
 [Fact] public void ApplyFraudPenalty_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.ApplyFraudPenalty(_projectId, _backer)));
 [Fact] public void ApplyRejectionPenalty_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.ApplyRejectionPenalty(_projectId, _backer, DisputeType.Refund)));
 [Fact] public void ClearPenalty_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.ClearPenalty(_projectId, _manufacturer)));
 [Fact] public void ProcessAutomaticUnbans_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.ProcessAutomaticUnbans(_projectId)));
 [Fact] public void UpdateReputationAfterPenalty_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Compliance.Sanctions.UpdateReputationAfterPenalty(_projectId, _manufacturer, new BigInteger(10))));
 }

 public class ComplianceInsightsModuleTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _addr = UInt160.Parse("0x1234567890123456789012345678901234567890");

 [Fact] public void GetParticipantBanReason_ReturnsEnum() => Assert.IsType<BanReason>(InnFork_DDD_Wrapper.Compliance.Insights.GetParticipantBanReason(_projectId, _addr));
 [Fact] public void GetManufacturerTotalPenalties_ReturnsBI() => Assert.IsType<BigInteger>(InnFork_DDD_Wrapper.Compliance.Insights.GetManufacturerTotalPenalties(_projectId, _addr));
 [Fact] public void GetManufacturerLastPenaltyTime_ReturnsULong() => Assert.IsType<ulong>(InnFork_DDD_Wrapper.Compliance.Insights.GetManufacturerLastPenaltyTime(_projectId, _addr));
 [Fact] public void GetRiskScore_ReturnsBI() => Assert.IsType<BigInteger>(InnFork_DDD_Wrapper.Compliance.Insights.GetRiskScore(BanReason.PaymentIssues));
 [Fact] public void IsParticipantBanned_ReturnsBool() => Assert.IsType<bool>(InnFork_DDD_Wrapper.Compliance.Insights.IsParticipantBanned(_projectId, _addr));
 [Fact] public void CreateBlockedFundsKey_ReturnsString() => Assert.IsType<string>(InnFork_DDD_Wrapper.Compliance.Insights.CreateBlockedFundsKey(_addr, BanReason.SecurityBreach));
 }
}
