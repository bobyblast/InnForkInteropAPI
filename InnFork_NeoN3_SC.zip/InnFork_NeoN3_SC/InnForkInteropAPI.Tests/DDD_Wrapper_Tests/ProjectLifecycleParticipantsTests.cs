using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class ProjectLifecycleParticipantsTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void RemoveManufacturerCandidate_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Participants.RemoveManufacturerCandidate(_projectId, _manufacturer));
 Assert.Null(ex);
 }

 [Fact]
 public void RemoveManufacturerCandidateFromAllProjects_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Participants.RemoveManufacturerCandidateFromAllProjects(_manufacturer));
 Assert.Null(ex);
 }

 [Fact]
 public void ValidateManufacturer_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Participants.ValidateManufacturer(_projectId, _manufacturer));
 Assert.Null(ex);
 }
 }
}
