using System;
using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3;
using InnFork.NeoN3.Enums;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class ProjectLifecycleMilestonesTests_2
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _validator = UInt160.Parse("0x1111111111111111111111111111111111111111");

 [Fact]
 public void AutoProgress_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.AutoProgress(_projectId));
 Assert.Null(ex);
 }

 [Fact]
 public void AutoRollbackAfterDispute_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.AutoRollbackAfterDispute(_projectId, "dispute1", _manufacturer, (byte)1));
 Assert.Null(ex);
 }

 [Fact]
 public void AutoStartNext_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.AutoStartNext(_projectId, _manufacturer, (byte)1));
 Assert.Null(ex);
 }

 [Fact]
 public void CheckAndRollbackExpired_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.CheckAndRollbackExpired(_projectId));
 Assert.Null(ex);
 }

 [Fact]
 public void IsExpired_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.IsExpired(_projectId, _manufacturer, (byte)1);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void CreateRequest_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.CreateRequest(
 _projectId, _manufacturer, (byte)1, "name", "descr", new BigInteger(100),1700000000UL,3600UL, new BigInteger(10)));
 Assert.Null(ex);
 }

 [Fact]
 public void RequestCompletion_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.RequestCompletion(_manufacturer, _projectId, (byte)1, "proof", Array.Empty<byte>()));
 Assert.Null(ex);
 }

 [Fact]
 public void SetVerificationRequirement_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.SetVerificationRequirement(_projectId, "templ1", true));
 Assert.Null(ex);
 }

 [Fact]
 public void SubmitVerification_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.SubmitVerification(_validator, _projectId, _manufacturer, (byte)1, true, "ok"));
 Assert.Null(ex);
 }

 [Fact]
 public void Verify_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.Verify(_projectId, "m1", true));
 Assert.Null(ex);
 }

 [Fact]
 public void ShouldAutoStartNext_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.ShouldAutoStartNext(_projectId, _manufacturer, (byte)1);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void GetLatestStep_ReturnsByte()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.GetLatestStep(_projectId, _manufacturer);
 Assert.IsType<byte>(res);
 }

 [Fact]
 public void GetMilestoneCompletionVotingStatus_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.GetMilestoneCompletionVotingStatus(_projectId, _manufacturer, (byte)1);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void ClearMilestoneFraudFlags_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.ClearMilestoneFraudFlags(_projectId, _manufacturer, (byte)1));
 Assert.Null(ex);
 }

 [Fact]
 public void ClearMilestoneTemplateParams_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.ClearMilestoneTemplateParams(_projectId, "t1"));
 Assert.Null(ex);
 }

 [Fact]
 public void ClearMilestoneVotes_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.ClearMilestoneVotes(_projectId, _manufacturer, (byte)1));
 Assert.Null(ex);
 }

 [Fact]
 public void GetMilestoneBackerVote_ReturnsEnum()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.GetMilestoneBackerVote(_projectId, _manufacturer, _backer, (byte)1);
 Assert.IsType<BackerVotesEnum>(res);
 }

 [Fact]
 public void GetMilestoneFraudFlag_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.GetMilestoneFraudFlag(_projectId, _manufacturer, _backer, (byte)1);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void GetMilestoneTemplateParam_ReturnsString()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.GetMilestoneTemplateParam(_projectId, "t1", "k");
 Assert.IsType<string>(res);
 }

 [Fact]
 public void RemoveMilestoneBackerVote_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.RemoveMilestoneBackerVote(_projectId, _manufacturer, _backer, (byte)1));
 Assert.Null(ex);
 }

 [Fact]
 public void RemoveMilestoneTemplateParam_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.RemoveMilestoneTemplateParam(_projectId, "t1", "k"));
 Assert.Null(ex);
 }

 [Fact]
 public void SetMilestoneBackerVote_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.SetMilestoneBackerVote(_projectId, _backer, _manufacturer, BackerVotesEnum.Positive, (byte)1));
 Assert.Null(ex);
 }

 [Fact]
 public void SetMilestoneFraudFlag_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.SetMilestoneFraudFlag(_projectId, _manufacturer, _backer, true, (byte)1));
 Assert.Null(ex);
 }

 [Fact]
 public void SetMilestoneTemplateParam_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.SetMilestoneTemplateParam(_projectId, "t1", "k", "v"));
 Assert.Null(ex);
 }
 }
}
