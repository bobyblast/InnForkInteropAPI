using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class ProjectLifecycleWorkflowTests_2
 {
 private readonly string _projectId = "test_project_123";

 [Fact]
 public void Archive_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.Archive(_projectId));
 Assert.Null(ex);
 }

 [Fact]
 public void IsOpen_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.IsOpen(_projectId);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void RefreshActivityScore_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.RefreshActivityScore(_projectId));
 Assert.Null(ex);
 }

 [Fact]
 public void AutoPause_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.AutoPause(_projectId));
 Assert.Null(ex);
 }
 }
}
