using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using System.Numerics;
using Xunit;
using InnFork.NeoN3;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
    public class ProjectLifecycleMilestonesTests
    {
        private readonly string _testProjectId = "test_project_123";
        private readonly UInt160 _testManufacturer = UInt160.Parse("0x1234567890123456789012345678901234567890");
        private readonly byte _testStepNumber = 1;

        //    private readonly Neo.SmartContract.Framework.UInt160 calletAddress = Neo.SmartContract.Framework.UInt160.Parse("NQdq7Ud4q2VSjtPFW43cns3aP5SZtRL5pE");


        [Fact]
        public void AutoProgress_CallsUnderlyingLogic1Method()
        {
            // Arrange
            var projectId = _testProjectId;

            // Act & Assert - ��������� ��� ����� �� ����������� ����������
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.AutoProgress(projectId));

            Assert.Null(exception);
        }

        [Fact]
        public void AutoRollbackAfterDispute_WithValidParameters_ExecutesSuccessfully()
        {
            // Arrange
            var disputeId = "dispute_001";

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.AutoRollbackAfterDispute(
                    _testProjectId, disputeId, _testManufacturer, _testStepNumber));

            Assert.Null(exception);
        }

        [Fact]
        public void AutoStartNext_WithValidParameters_ExecutesSuccessfully()
        {
            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.AutoStartNext(
                    _testProjectId, _testManufacturer, _testStepNumber));

            Assert.Null(exception);
        }

        [Fact]
        public void CheckAndRollbackExpired_WithValidProjectId_ExecutesSuccessfully()
        {
            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.CheckAndRollbackExpired(_testProjectId));

            Assert.Null(exception);
        }

        [Fact]
        public void IsExpired_WithValidParameters_ReturnsBool()
        {
            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.IsExpired(
                _testProjectId, _testManufacturer, _testStepNumber);

            // Assert
            Assert.IsType<bool>(result);
        }

        [Fact]
        public void CreateRequest_WithAllParameters_ExecutesSuccessfully()
        {
            // Arrange
            var name = "Test Milestone";
            var description = "Test Description";
            var requestedAmount = BigInteger.Parse("1000000");
            var deadline = 1700000000ul;
            var votingDuration = 86400ul;
            var minimumVotes = BigInteger.Parse("100");

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.CreateRequest(
                    _testProjectId, _testManufacturer, _testStepNumber,
                    name, description, requestedAmount, deadline, votingDuration, minimumVotes));

            Assert.Null(exception);
        }

        [Fact]
        public void RequestCompletion_WithVerificationData_ExecutesSuccessfully()
        {
            // Arrange
            var completionProof = "Proof of completion";
            var verificationData = new byte[] { 0x01, 0x02, 0x03 };

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.RequestCompletion(
                    _testManufacturer, _testProjectId, _testStepNumber,
                    completionProof, verificationData));

            Assert.Null(exception);
        }

        [Fact]
        public void GetLatestStep_WithValidParameters_ReturnsByte()
        {
            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Milestones.GetLatestStep(
                _testProjectId, _testManufacturer);

            // Assert
            Assert.IsType<byte>(result);
        }
    }

    public class ProjectLifecycleTemplatesTests
    {
        private readonly byte _testStepNumber = 1;

        [Fact]
        public void CreateDefault_WithValidParameters_ReturnsTemplate()
        {
            // Arrange
            var project = new ProjectAccount();

            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateDefault(
                _testStepNumber, project);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<MilestoneTemplate>(result);
        }

        [Fact]
        public void CreateResearch_ReturnsValidTemplate()
        {
            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateResearch(_testStepNumber);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<MilestoneTemplate>(result);
        }

        [Fact]
        public void CreateDevelopment_ReturnsValidTemplate()
        {
            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateDevelopment(_testStepNumber);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<MilestoneTemplate>(result);
        }

        [Fact]
        public void CreateManufacturing_ReturnsValidTemplate()
        {
            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateManufacturing(_testStepNumber);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<MilestoneTemplate>(result);
        }

        [Fact]
        public void CreateTesting_ReturnsValidTemplate()
        {
            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateTesting(_testStepNumber);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<MilestoneTemplate>(result);
        }
    }

    public class ProjectLifecycleWorkflowTests
    {
        private readonly string _testProjectId = "test_project_123";

        [Fact]
        public void Archive_WithValidProjectId_ExecutesSuccessfully()
        {
            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.Archive(_testProjectId));

            Assert.Null(exception);
        }

        [Fact]
        public void IsOpen_WithValidProjectId_ReturnsBool()
        {
            // Act
            var result = InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.IsOpen(_testProjectId);

            // Assert
            Assert.IsType<bool>(result);
        }

        [Fact]
        public void RefreshActivityScore_WithValidProjectId_ExecutesSuccessfully()
        {
            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.RefreshActivityScore(_testProjectId));

            Assert.Null(exception);
        }

        [Fact]
        public void AutoPause_WithValidProjectId_ExecutesSuccessfully()
        {
            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.ProjectLifecycle.Workflow.AutoPause(_testProjectId));

            Assert.Null(exception);
        }
    }
}