using System.Collections.Generic;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class GovernanceVoteWeightingAdvancedTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");

 [Fact]
 public void ResolveFinalDelegate_ComplexMap_ReturnsUInt160()
 {
 var inner = new Dictionary<string, UInt160>{{"k", _backer}};
 var map = new Dictionary<Dictionary<string, UInt160>, UInt160>{{inner, _backer}};
 var res = InnFork_DDD_Wrapper.Governance.VoteWeighting.ResolveFinalDelegate(_projectId, map, _backer);
 Assert.IsType<UInt160>(res);
 }
 }
}
