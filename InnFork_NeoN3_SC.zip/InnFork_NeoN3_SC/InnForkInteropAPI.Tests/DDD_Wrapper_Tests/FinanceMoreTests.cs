using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class FinanceTreasuryMoreTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void CanWithdrawReservedForManufacturer_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.Finance.Treasury.CanWithdrawReservedForManufacturer(_projectId, _backer, _manufacturer);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void UnlockFunds_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.UnlockFunds(_projectId, new BigInteger(100)));
 Assert.Null(ex);
 }

 [Fact]
 public void ProcessConditionalMilestoneFunding_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.ProcessConditionalMilestoneFunding(_manufacturer, _projectId, (byte)1, new BigInteger(100)));
 Assert.Null(ex);
 }

 [Fact]
 public void RollbackMilestoneFunding_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.RollbackMilestoneFunding(_projectId, _manufacturer, (byte)1, "reason"));
 Assert.Null(ex);
 }

 [Fact]
 public void ReserveBackerFunds_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.ReserveBackerFunds(_projectId, _backer, _manufacturer, new BigInteger(100)));
 Assert.Null(ex);
 }

 [Fact]
 public void CanWithdrawFromProject_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.Finance.Treasury.CanWithdrawFromProject(_projectId, _backer);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void AllocateFunds_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.AllocateFunds(_projectId, _backer, (byte)10));
 Assert.Null(ex);
 }

 [Fact]
 public void PayPrizeFundToManufacturer_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.PayPrizeFundToManufacturer(_projectId, _manufacturer));
 Assert.Null(ex);
 }

 [Fact]
 public void DistributeReferralReward_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.DistributeReferralReward(_projectId, _backer, new BigInteger(50)));
 Assert.Null(ex);
 }

 [Fact]
 public void CollectProjectAuthorFee_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.CollectProjectAuthorFee(_projectId, _backer));
 Assert.Null(ex);
 }

 [Fact]
 public void DistributeTokenRewards_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.DistributeTokenRewards(_projectId, _backer, new BigInteger(5)));
 Assert.Null(ex);
 }

 [Fact]
 public void SetRewardTokenContract_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.SetRewardTokenContract(_projectId, _backer));
 Assert.Null(ex);
 }

 [Fact]
 public void RegisterReferrer_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.RegisterReferrer(_projectId, _backer, _manufacturer));
 Assert.Null(ex);
 }

 [Fact]
 public void ProcessProjectWinner_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.ProcessProjectWinner(_projectId, _backer));
 Assert.Null(ex);
 }

 [Fact]
 public void SetBillingCallbackOwner_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.SetBillingCallbackOwner(_projectId, _manufacturer, _backer));
 Assert.Null(ex);
 }

 [Fact]
 public void SafeRefundAllDonations_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.SafeRefundAllDonations(_projectId));
 Assert.Null(ex);
 }

 [Fact]
 public void ReturnAllReservedInvestments_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.ReturnAllReservedInvestments(_projectId, _manufacturer));
 Assert.Null(ex);
 }

 [Fact]
 public void ReturnInvestmentToInvestor_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.ReturnInvestmentToInvestor(_projectId, _backer, _manufacturer, new BigInteger(10)));
 Assert.Null(ex);
 }

 [Fact]
 public void ImposePenalty_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.ImposePenalty(_projectId, _manufacturer, new BigInteger(1)));
 Assert.Null(ex);
 }

 [Fact]
 public void DistributeConsentedFunds_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.DistributeConsentedFunds(_projectId, _manufacturer));
 Assert.Null(ex);
 }

 [Fact]
 public void DistributeManufacturerProfit_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.DistributeManufacturerProfit(_projectId, _manufacturer, new BigInteger(1)));
 Assert.Null(ex);
 }

 [Fact]
 public void ResetProjectWinnerStatus_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Treasury.ResetProjectWinnerStatus(_projectId));
 Assert.Null(ex);
 }
 }

 public class FinancePrizeFundMoreTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void GetReservedAmountForManufacturer_ReturnsBigInteger()
 {
 var res = InnFork_DDD_Wrapper.Finance.PrizeFund.GetReservedAmountForManufacturer(_projectId, _backer, _manufacturer);
 Assert.IsType<BigInteger>(res);
 }

 [Fact]
 public void GetBackerAutoConsent_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.Finance.PrizeFund.GetBackerAutoConsent(_projectId, _backer);
 Assert.IsType<bool>(res);
 }
 }

 public class FinanceInvestingTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _backer = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void DonateToManufacturer_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Investing.DonateToManufacturer(_projectId, _backer, _manufacturer, new BigInteger(100)));
 Assert.Null(ex);
 }

 [Fact]
 public void CanWithdrawInvestment_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.Finance.Investing.CanWithdrawInvestment(_projectId, _backer, _manufacturer);
 Assert.IsType<bool>(res);
 }

 [Fact]
 public void MoneyBackToBacker_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Investing.MoneyBackToBacker(_projectId, _backer, new BigInteger(10)));
 Assert.Null(ex);
 }

 [Fact]
 public void ProposeProfitShare_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Investing.ProposeProfitShare(_projectId, _backer, _manufacturer, new BigInteger(50)));
 Assert.Null(ex);
 }

 [Fact]
 public void SetManufacturerMinimumInvestment_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Investing.SetManufacturerMinimumInvestment(_projectId, _manufacturer, new BigInteger(1000)));
 Assert.Null(ex);
 }

 [Fact]
 public void CollectProjectAuthorFeeViaInvesting_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Finance.Investing.CollectProjectAuthorFeeViaInvesting(_projectId, _backer));
 Assert.Null(ex);
 }

 [Fact]
 public void CallBackerAccountFacade_ReturnsString()
 {
 var res = InnFork_DDD_Wrapper.Finance.Investing.CallBackerAccountFacade("operation", "a",1);
 Assert.IsType<string>(res);
 }

 [Fact]
 public void CallInvestorAccountFacade_ReturnsString()
 {
 var res = InnFork_DDD_Wrapper.Finance.Investing.CallInvestorAccountFacade("operation", "a",1);
 Assert.IsType<string>(res);
 }

 [Fact]
 public void CallManufacturerAccountFacade_ReturnsString()
 {
 var res = InnFork_DDD_Wrapper.Finance.Investing.CallManufacturerAccountFacade("operation", "a",1);
 Assert.IsType<string>(res);
 }

 [Fact]
 public void CallProjectCreatorAccountFacade_ReturnsString()
 {
 var res = InnFork_DDD_Wrapper.Finance.Investing.CallProjectCreatorAccountFacade("operation", "a",1);
 Assert.IsType<string>(res);
 }
 }
}
