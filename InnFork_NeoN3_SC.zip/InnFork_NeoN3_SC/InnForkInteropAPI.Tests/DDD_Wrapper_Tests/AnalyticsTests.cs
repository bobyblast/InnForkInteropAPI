using System.Collections.Generic;
using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class AnalyticsProjectsTests
 {
 [Fact]
 public void GetFromLogic1_ReturnsProjectAccount()
 {
 var acc = InnFork_DDD_Wrapper.Analytics.Projects.GetFromLogic1("p");
 Assert.IsType<ProjectAccount>(acc);
 }

 [Fact]
 public void GetProjectAnalytics_ReturnsDict()
 {
 var dict = InnFork_DDD_Wrapper.Analytics.Projects.GetProjectAnalytics("p");
 Assert.IsType<Dictionary<string, BigInteger>>(dict);
 }
 }

 public class AnalyticsParticipationTests
 {
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void GetMilestonePerformanceAnalytics_ReturnsDict()
 {
 var dict = InnFork_DDD_Wrapper.Analytics.Participation.GetMilestonePerformanceAnalytics("p", _manufacturer);
 Assert.IsType<Dictionary<string, BigInteger>>(dict);
 }

 [Fact]
 public void GetParticipationTrend_ReturnsBI()
 {
 var res = InnFork_DDD_Wrapper.Analytics.Participation.GetParticipationTrend("p",1,2);
 Assert.IsType<BigInteger>(res);
 }

 [Fact]
 public void UpdateDailyParticipation_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Analytics.Participation.UpdateDailyParticipation("p",1, new BigInteger(10)));
 Assert.Null(ex);
 }

 [Fact]
 public void UpdateManufacturerKpi_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Analytics.Participation.UpdateManufacturerKpi("p", _manufacturer, new BigInteger(1), new BigInteger(2)));
 Assert.Null(ex);
 }
 }

 public class AnalyticsManufacturersTests
 {
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void CalculateReliabilityTier_ReturnsByte()
 {
 var res = InnFork_DDD_Wrapper.Analytics.Manufacturers.CalculateReliabilityTier("p", _manufacturer);
 Assert.IsType<byte>(res);
 }

 [Fact]
 public void GetExternalRating_ReturnsBI()
 {
 var res = InnFork_DDD_Wrapper.Analytics.Manufacturers.GetExternalRating("p", _manufacturer);
 Assert.IsType<BigInteger>(res);
 }
 }
}
