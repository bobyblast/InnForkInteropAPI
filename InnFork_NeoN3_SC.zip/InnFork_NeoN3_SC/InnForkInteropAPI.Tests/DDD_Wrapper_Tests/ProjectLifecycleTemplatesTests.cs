using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3;
using Xunit;
using Neo;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
    public class ProjectLifecycleTemplatesTests_2
    {
        private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

        [Fact]
        public void CreateDefault_ReturnsTemplate()
        {
            var project = InnFork_DDD_Wrapper.Analytics.Projects.GetFromLogic1("p");
            var t = InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateDefault(1, project);
            Assert.IsType<MilestoneTemplate>(t);
        }

        [Fact]
        public void CreatePhaseTemplates_ReturnTemplates()
        {
            Assert.IsType<MilestoneTemplate>(InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateResearch(1));
            Assert.IsType<MilestoneTemplate>(InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateDevelopment(1));
            Assert.IsType<MilestoneTemplate>(InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateManufacturing(1));
            Assert.IsType<MilestoneTemplate>(InnFork_DDD_Wrapper.ProjectLifecycle.Templates.CreateTesting(1));
        }

        [Fact]
        public void GetTemplate_ReturnsTemplate()
        {
            var project = InnFork_DDD_Wrapper.Analytics.Projects.GetFromLogic1("p");
            var t = InnFork_DDD_Wrapper.ProjectLifecycle.Templates.GetTemplate(project, _manufacturer, 1, "default");
            Assert.IsType<MilestoneTemplate>(t);
        }
    }
}
