using System.Collections.Generic;
using System.Numerics;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3;
using Neo;
using Neo.SmartContract;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
    public class AiModerationConfigurationTests
    {
        private readonly UInt160 _addr = UInt160.Parse("0x1234567890123456789012345678901234567890");

        [Fact] public void Initialize_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Configuration.Initialize(_addr)));
        [Fact] public void ConfigureOracle_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Configuration.ConfigureOracle("url", "$.path")));
        [Fact] public void SetMainGatewayContract_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Configuration.SetMainGatewayContract(_addr)));
        [Fact] public void SetStateStorageContract_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Configuration.SetStateStorageContract(_addr)));
        [Fact] public void SetPaused_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Configuration.SetPaused(true)));
        [Fact] public void TransferOwnership_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Configuration.TransferOwnership(_addr)));
    }

    public class AiModerationRequestsTests
    {
        private readonly UInt160 _addr = UInt160.Parse("0x1234567890123456789012345678901234567890");

        [Fact]
        public void RequestModerations_ReturnsIds()
        {
            var r1 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateDisputeEvidence("p", "d", "{}", _addr, true);
            var r2 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateManufacturerProfile("p", _addr, "{}", _addr, true);
            var r3 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateProductDescription("pr", "{}", _addr, false);
            var r4 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateProjectDescription("p", "{}", _addr, false);
            var r5 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateProjectOffer("o", "{}", _addr, false);
            var r6 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateProjectUpdate("p", "u", "{}", _addr, false);
            var r7 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateRefundRequest("p", "r", "{}", _addr, true);
            var r8 = InnFork_DDD_Wrapper.AiModeration.Requests.ModerateUserComment("p", "c", "{}", _addr, false);
            Assert.All(new[] { r1, r2, r3, r4, r5, r6, r7, r8 }, v => Assert.IsType<string>(v));
        }
    }

    public class AiModerationInsightsTests
    {
        private readonly UInt160 _addr = UInt160.Parse("0x1234567890123456789012345678901234567890");

        [Fact]
        public void Insights_Readers_ReturnTypes()
        {
            var approved = InnFork_DDD_Wrapper.AiModeration.Insights.IsModerationApproved("req");
            Assert.IsType<bool>(approved);
            var score = InnFork_DDD_Wrapper.AiModeration.Insights.GetConfidenceScore("req");
            Assert.IsType<BigInteger>(score);
            var stats = InnFork_DDD_Wrapper.AiModeration.Insights.GetModerationStats("req");
            Assert.IsAssignableFrom<Dictionary<string, BigInteger>>(stats);
            var estats = InnFork_DDD_Wrapper.AiModeration.Insights.GetEnhancedModerationStats("req", "p");
            Assert.IsAssignableFrom<Dictionary<string, BigInteger>>(estats);
            var result = InnFork_DDD_Wrapper.AiModeration.Insights.GetModerationResult("req");
            Assert.IsType<ModerationResult>(result);
            var hasFlag = InnFork_DDD_Wrapper.AiModeration.Insights.HasViolationFlag("req", ViolationFlag.Spam);
            Assert.IsType<bool>(hasFlag);
            var hist = InnFork_DDD_Wrapper.AiModeration.Insights.GetModerationHistory(_addr);
            Assert.NotNull(hist);
            var hist2 = InnFork_DDD_Wrapper.AiModeration.Insights.GetModerationHistoryWithContext(_addr, "p");
            Assert.NotNull(hist2);
            var simple = InnFork_DDD_Wrapper.AiModeration.Insights.AnalyzeParticipantViolations(_addr, "p");
            Assert.NotNull(simple);
        }
    }

    public class AiModerationSanctionsTests
    {
        private readonly UInt160 _addr = UInt160.Parse("0x1234567890123456789012345678901234567890");
        [Fact] public void ManuallyApplySanctions_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Sanctions.ManuallyApplySanctions("req", "p", _addr)));
        [Fact] public void RehabilitateParticipant_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Sanctions.RehabilitateParticipant("p", _addr, _addr)));
    }

    public class AiModerationOracleTests
    {
        [Fact]
        public void OnOracleModerationResponse_DoesNotThrow()
        {
            var ex = Record.Exception(() => InnFork_DDD_Wrapper.AiModeration.Oracle.OnOracleModerationResponse("url", new { }, default, "{}"));
            Assert.Null(ex);
        }
    }
}
