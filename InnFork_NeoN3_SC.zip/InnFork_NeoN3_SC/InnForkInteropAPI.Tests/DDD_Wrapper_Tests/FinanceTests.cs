using System;
using System.Numerics;
using Xunit;
using Neo;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using InnFork.NeoN3.Enums;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
    public class FinanceTreasuryTests
    {
        private readonly string _testProjectId = "test_project_123";
        private readonly UInt160 _testBacker = UInt160.Parse("0x1234567890123456789012345678901234567890");
        private readonly UInt160 _testManufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

        [Fact]
        public void BlockBackerFunds_WithValidAmount_ExecutesSuccessfully()
        {
            // Arrange
            var reason = BanReason.ReviewManipulation;
            var amount = BigInteger.Parse("1000000");

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Finance.Treasury.BlockBackerFunds(
                    _testProjectId, _testBacker, reason, amount));

            Assert.Null(exception);
        }

        [Fact]
        public void UnblockBackerFunds_WithValidAmount_ExecutesSuccessfully()
        {
            // Arrange
            var amount = BigInteger.Parse("1000000");

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Finance.Treasury.UnblockBackerFunds(
                    _testProjectId, _testBacker, amount));

            Assert.Null(exception);
        }

        [Fact]
        public void LockFunds_WithValidAmount_ExecutesSuccessfully()
        {
            // Arrange
            var amount = BigInteger.Parse("5000000");

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Finance.Treasury.LockFunds(_testProjectId, amount));

            Assert.Null(exception);
        }

        [Fact]
        public void ProcessMilestoneFunding_WithValidParameters_ExecutesSuccessfully()
        {
            // Arrange
            byte stepNumber = 1;

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Finance.Treasury.ProcessMilestoneFunding(
                    _testProjectId, _testManufacturer, stepNumber));

            Assert.Null(exception);
        }

        [Fact]
        public void IsFundingGoalReached_WithValidProjectId_ReturnsBool()
        {
            // Act
            var result = InnFork_DDD_Wrapper.Finance.Treasury.IsFundingGoalReached(_testProjectId);

            // Assert
            Assert.IsType<bool>(result);
        }
    }

    public class FinancePrizeFundTests
    {
        private readonly string _testProjectId = "test_project_123";
        private readonly UInt160 _testBacker = UInt160.Parse("0x1234567890123456789012345678901234567890");

        [Fact]
        public void GetBackerDonation_WithValidBacker_ReturnsBigInteger()
        {
            // Act
            var result = InnFork_DDD_Wrapper.Finance.PrizeFund.GetBackerDonation(
                _testProjectId, _testBacker);

            // Assert
            Assert.IsType<BigInteger>(result);
        }

        [Fact]
        public void HasBackerDonated_WithValidBacker_ReturnsBool()
        {
            // Act
            var result = InnFork_DDD_Wrapper.Finance.PrizeFund.HasBackerDonated(
                _testProjectId, _testBacker);

            // Assert
            Assert.IsType<bool>(result);
        }

        [Fact]
        public void ProcessDonation_WithValidAmount_ExecutesSuccessfully()
        {
            // Arrange
            var amount = BigInteger.Parse("500000");

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Finance.PrizeFund.ProcessDonation(
                    _testProjectId, _testBacker, amount));

            Assert.Null(exception);
        }

        [Fact]
        public void SetBackerAutoConsent_WithValidConsent_ExecutesSuccessfully()
        {
            // Arrange
            bool consent = true;

            // Act & Assert
            var exception = Record.Exception(() =>
                InnFork_DDD_Wrapper.Finance.PrizeFund.SetBackerAutoConsent(
                    _testProjectId, _testBacker, consent));

            Assert.Null(exception);
        }
    }
}