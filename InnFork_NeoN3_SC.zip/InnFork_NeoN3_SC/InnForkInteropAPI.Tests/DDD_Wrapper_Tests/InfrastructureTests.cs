using System.Collections.Generic;
using System.Numerics;
using InnFork.NeoN3.Enums;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class InfrastructureConfigurationTests
 {
 [Fact] public void GetContractVersion_ReturnsInt() => Assert.IsType<int>(InnFork_DDD_Wrapper.Infrastructure.Configuration.GetContractVersion());
 [Fact] public void GetContractVersionChangelog_ReturnsString() => Assert.IsType<string>(InnFork_DDD_Wrapper.Infrastructure.Configuration.GetContractVersionChangelog());
 [Fact] public void UpdateContractVersion_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Configuration.UpdateContractVersion(2, "hash")));
 [Fact] public void ModeratorStateHash_RW_DoesNotThrow()
 {
 var m = InnFork_DDD_Wrapper.Infrastructure.Configuration.GetModeratorContractHash();
 Assert.IsType<UInt160>(m);
 var s = InnFork_DDD_Wrapper.Infrastructure.Configuration.GetStateContractHash();
 Assert.IsType<UInt160>(s);
 Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Configuration.OverrideModeratorContract(UInt160.Zero)));
 Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Configuration.OverrideStateContract(UInt160.Zero)));
 Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Configuration.SetModeratorContractHash(UInt160.Zero)));
 Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Configuration.SetStateContractHash(UInt160.Zero)));
 }
 }

 public class InfrastructureProjectsTests
 {
 private readonly UInt160 _creator = UInt160.Parse("0x1234567890123456789012345678901234567890");

 [Fact]
 public void ImportNewProjectSettings_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Projects.ImportNewProjectSettings("{}"));
 Assert.Null(ex);
 }

 [Fact]
 public void RegisterProjectEx_ReturnsId()
 {
 var id = InnFork_DDD_Wrapper.Infrastructure.Projects.RegisterProjectEx(_creator, "key","{}", new byte[]{1}, new byte[]{2},"offer", false, "{}", new BigInteger(100));
 Assert.IsType<string>(id);
 }

 [Fact]
 public void StoreProjectOfferMetadata_ReturnsId()
 {
 var id = InnFork_DDD_Wrapper.Infrastructure.Projects.StoreProjectOfferMetadata(_creator, "key", "{}", new byte[]{1}, new byte[]{2});
 Assert.IsType<string>(id);
 }

 [Fact]
 public void SetProjectOfferShortJson_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Projects.SetProjectOfferShortJson("{short}", "offer", new byte[]{1,2}));
 Assert.Null(ex);
 }

 [Fact]
 public void RemoveOfferAndTimeline_DoesNotThrow()
 {
 var ex1 = Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Projects.RemoveOffer("offer"));
 var res2 = InnFork_DDD_Wrapper.Infrastructure.Projects.RemoveProjectOfferByTimeline(_creator, "offer");
 Assert.Null(ex1);
 Assert.IsType<bool>(res2);
 }

 [Fact]
 public void ProjectListsAndStatus_Work()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Projects.RemoveProjectFromGlobalLists("p"));
 Assert.Null(ex);
 var pkgs = InnFork_DDD_Wrapper.Infrastructure.Projects.GetSerializedProjectPackages();
 Assert.NotNull(pkgs);
 var accs = InnFork_DDD_Wrapper.Infrastructure.Projects.GetSerializedProjectAccounts();
 Assert.NotNull(accs);
 var isLive = InnFork_DDD_Wrapper.Infrastructure.Projects.ValidateProjectIsLiving("p");
 Assert.IsType<bool>(isLive);
 Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Projects.ResumeProject("p")));
 Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Infrastructure.Projects.AutoSetToPause("p")));
 }
 }

 public class InfrastructureOffersTests
 {
 [Fact] public void GetTotalReservedDonations_ReturnsBI() => Assert.IsType<BigInteger>(InnFork_DDD_Wrapper.Infrastructure.Offers.GetTotalReservedDonations("offer"));
 [Fact] public void CalculateTotalReservedForOffer_ReturnsBI() => Assert.IsType<BigInteger>(InnFork_DDD_Wrapper.Infrastructure.Offers.CalculateTotalReservedForOffer("offer"));
 [Fact] public void GetCountOfSelectedMapName_ReturnsInt() => Assert.IsType<int>(InnFork_DDD_Wrapper.Infrastructure.Offers.GetCountOfSelectedMapName("map"));
 [Fact] public void GetOffersCount_ReturnsInt() => Assert.IsType<int>(InnFork_DDD_Wrapper.Infrastructure.Offers.GetOffersCount());
 }

 public class InfrastructureDiagnosticsTests
 {
 [Fact]
 public void GetProjectStatuses_ReturnTypes()
 {
 // Use any defined enum value to validate the call; we don't rely on a specific member being present
 var b = InnFork_DDD_Wrapper.Infrastructure.Diagnostics.GetProjectStatusAsBoolean("p", (ProjectStateRequest)0);
 Assert.IsType<bool>(b);
 var arr = InnFork_DDD_Wrapper.Infrastructure.Diagnostics.GetProjectStatuses("p");
 Assert.NotNull(arr);
 }
 }
}
