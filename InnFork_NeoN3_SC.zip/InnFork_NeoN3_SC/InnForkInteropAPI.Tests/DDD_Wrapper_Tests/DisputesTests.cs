using System.Numerics;
using InnFork.NeoN3.Enums;
using InnForkInteropAPI.BlockChain.NeoN3.SC_Wrappers;
using Neo;
using Xunit;

namespace InnForkInteropAPI.Tests.DDD_Wrapper
{
 public class DisputesLifecycleTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _initiator = UInt160.Parse("0x1234567890123456789012345678901234567890");
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact]
 public void CreateDispute_ReturnsId()
 {
 var id = InnFork_DDD_Wrapper.Disputes.Lifecycle.CreateDispute(_projectId, _initiator, DisputeType.PaymentDispute, "desc", _manufacturer, (byte)1);
 Assert.IsType<string>(id);
 }

 [Fact]
 public void CreateMilestoneDispute_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Lifecycle.CreateMilestoneDispute(_initiator, _projectId, _manufacturer, (byte)1, "bad quality"));
 Assert.Null(ex);
 }

 [Fact]
 public void ResolveDispute_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Lifecycle.ResolveDispute(_projectId, "dispute_1", DisputeStatus.Resolved, "ok"));
 Assert.Null(ex);
 }

 [Fact]
 public void IsValidTransition_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.Disputes.Lifecycle.IsValidTransition(DisputeStatus.Created, DisputeStatus.UnderReview);
 Assert.IsType<bool>(res);
 }
 }

 public class DisputesEscalationTests
 {
 private readonly string _projectId = "test_project_123";

 [Fact] public void HandleGeneralEscalation_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Escalation.HandleGeneralEscalation(_projectId, "dispute_1")));
 [Fact] public void HandleMilestoneEscalation_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Escalation.HandleMilestoneEscalation(_projectId, "dispute_1")));
 [Fact] public void HandleFraudEscalation_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Escalation.HandleFraudEscalation(_projectId, "dispute_1")));
 [Fact] public void HandlePaymentEscalation_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Escalation.HandlePaymentEscalation(_projectId, "dispute_1")));
 [Fact] public void HandleDisputeEscalation_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Escalation.HandleDisputeEscalation(_projectId, "dispute_1")));
 }

 public class DisputesResolutionTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");

 [Fact] public void HandleContractBreach_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleContractBreach(_projectId, "dispute_1")));
 [Fact] public void HandleRejection_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleRejection(_projectId, "dispute_1")));
 [Fact] public void HandleResolution_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleResolution(_projectId, "dispute_1")));
 [Fact] public void HandleGeneralResolution_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleGeneralResolution(_projectId, "dispute_1")));
 [Fact] public void HandleMilestoneResolution_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleMilestoneResolution(_projectId, "dispute_1")));
 [Fact] public void HandlePaymentResolution_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandlePaymentResolution(_projectId, "dispute_1")));
 [Fact] public void HandleFraudResolution_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleFraudResolution(_projectId, "dispute_1")));
 [Fact] public void HandleQualityResolution_DoesNotThrow() => Assert.Null(Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleQualityResolution(_projectId, "dispute_1")));
 [Fact]
 public void HandleInvestorRollback_DoesNotThrow()
 {
 var ex = Record.Exception(() => InnFork_DDD_Wrapper.Disputes.Resolution.HandleInvestorRollback(_projectId, _manufacturer, new BigInteger(100)));
 Assert.Null(ex);
 }
 }

 public class DisputesInsightsTests
 {
 private readonly string _projectId = "test_project_123";
 private readonly UInt160 _manufacturer = UInt160.Parse("0x0987654321098765432109876543210987654321");
 [Fact]
 public void HasManufacturerUsedMilestoneFunding_ReturnsBool()
 {
 var res = InnFork_DDD_Wrapper.Disputes.Insights.HasManufacturerUsedMilestoneFunding(_projectId, _manufacturer);
 Assert.IsType<bool>(res);
 }
 }
}
