using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;


public partial class BackerAccount
{

    public static void WithdrawFromMainBalance(UInt160 backerAddress, BigInteger amount)
    {
        if (backerAddress is null || backerAddress.IsZero)
            throw new Exception("Invalid backer address");

        if (!Runtime.CheckWitness(backerAddress))
            throw new Exception("WithdrawFromMainBalance: sender is not authorised");

        if (amount <= 0)
            throw new Exception("WithdrawFromMainBalance: amount must be positive");

        // Retrieve the backer account; throw if not found
        BackerAccount account = getBackerAccount(backerAddress, true);

        if (account.FreeBalance < amount)
            throw new Exception("WithdrawFromMainBalance: insufficient free balance");

        // Perform the token transfer from the contract to the backer
        // NEP?17 Transfer signature: Transfer(from, to, amount, data)
        bool transferOk = (bool)GAS.Transfer(Runtime.ExecutingScriptHash, backerAddress, amount, null);
        if (!transferOk)
            throw new Exception("WithdrawFromMainBalance: GAS transfer failed");

        // Update the account balances
        account.FreeBalance -= amount;
        account.TotalBalance -= amount;

        // Persist the updated account to storage
        updateExistingBackerAccount(account);
    }




    public bool setPublicKey(UInt160 backerAddress, string publicKeyBytes, string message, string signature)
    {
        if (!Runtime.CheckWitness(backerAddress)) throw new Exception("Authorization failed");

        BackerAccount account = getBackerAccount(backerAddress, false);

        if (account != null)
        {
            return account.verifyAndSetPublicKey(backerAddress, publicKeyBytes.ToByteArray(), message.ToByteArray(), signature.ToByteArray());
        }
        else
        {
            throw new Exception("Account not found");
        }
    }
    public bool setPublicKeyBytes(UInt160 backerAddress, byte[] publicKeyBytes, byte[] message, byte[] signature)
    {
        if (!Runtime.CheckWitness(backerAddress))
            throw new Exception("Authorization failed");

        BackerAccount account = getBackerAccount(backerAddress, false);

        if (account != null)
        {
            return account.verifyAndSetPublicKey(backerAddress, publicKeyBytes, message, signature);
        }
        else
        {
            throw new Exception("Account not found");
        }
    }

    public bool verifyAndSetPublicKey(UInt160 backerAddress, byte[] publicKeyBytes, byte[] message, byte[] signature)
    {
        if (!Runtime.CheckWitness(backerAddress))
            throw new Exception("Authorization failed");

        if (!IFHelper.verifySignatureSHA256(publicKeyBytes, message, signature))
            throw new Exception("Invalid signature");

        BackerAccount account = getBackerAccount(backerAddress, false);

        if (account != null)
        {
            account.PublicKey = publicKeyBytes;

            updateExistingBackerAccount(account);

            return true;
        }
        else
        {
            throw new Exception("Account not found");
        }
    }

    public BackerAccount()
    {
    }



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static BackerAccount createBackerAccount(UInt160 backerAddress, byte[] publicKeyBytes)
    {
        if (backerAddress.Length != 20) throw new Exception("Invalid BackerAccount address format");

        if (!Runtime.CheckWitness(backerAddress)) throw new Exception("Authorization failed");

        if (ProjectState.GetRawBackerAccount(backerAddress) != null) throw new Exception("Backer Account already exists");

        if (IFHelper.pubKeyToAddress(publicKeyBytes) != backerAddress) throw new Exception("Backer Public key and address are missmatch");

        BackerAccount newBackerAccount = new BackerAccount
        {
            BackerWalletAddress = backerAddress,
            TotalBalance = 0,
            FreeBalance = 0,
            PublicKey = publicKeyBytes,
            AllowAutoPaymentByInnForkGateway = false
        };

        ProjectState.SetRawBackerAccount(backerAddress, StdLib.Serialize(newBackerAccount));

        return newBackerAccount;
    }
    public static BackerAccount createBackerAccount(UInt160 backerAddress)
    {
        if (backerAddress.Length != 20) throw new Exception("Invalid BackerAccount address format");

        if (!Runtime.CheckWitness(backerAddress)) throw new Exception("Authorization failed");

        if (ProjectState.GetRawBackerAccount(backerAddress) != null) throw new Exception("This Backer Address is already registered at InnFork Gateway");

        BackerAccount newBackerAccount = new BackerAccount
        {
            BackerWalletAddress = backerAddress,
            TotalBalance = 0,
            FreeBalance = 0,
            AllowAutoPaymentByInnForkGateway = false
        };

        ProjectState.SetRawBackerAccount(backerAddress, StdLib.Serialize(newBackerAccount));

        return newBackerAccount;
    }

    internal static void updateExistingBackerAccount(BackerAccount account)
    {
        var exists = ProjectState.GetRawBackerAccount(account.BackerWalletAddress);
        if (exists == null)
        {
            throw new Exception("BackerAccount not found");
        }
        else
        {
            ProjectState.SetRawBackerAccount(account.BackerWalletAddress, StdLib.Serialize(account));
        }
    }

    public static BackerAccount getBackerAccount(UInt160 backerAddress, bool ExceptionIfNull)
    {
        var raw = ProjectState.GetRawBackerAccount(backerAddress);
        if (raw is null)
        {
            if (ExceptionIfNull) throw new Exception("BackerAccount not found");
            return null;
        }
        return (BackerAccount)StdLib.Deserialize(raw);
    }

    public static BigInteger getTotalBalanceOfBackerAccount(UInt160 backerAddress)
    {
        if (!Runtime.CheckWitness(backerAddress))
            throw new Exception("Authorization failed");

        return getBackerAccount(backerAddress, true).TotalBalance;
    }
    public static BigInteger getFreeBalanceOfBackerAccount(UInt160 backerAddress)
    {
        if (!Runtime.CheckWitness(backerAddress))
            throw new Exception("Authorization failed");

        return getBackerAccount(backerAddress, true).FreeBalance;
    }
}




