
using InnFork.NeoN3.Adapters;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;


namespace InnFork.NeoN3;


public partial class InvestorAccount
{

    /// <summary>
    /// Withdraw funds from the investor�s free balance to their own
    /// wallet.  Only the investor themselves may call this method.
    /// </summary>
    /// <param name="investorAddress">Address of the investor invoking the withdrawal.</param>
    /// <param name="amount">Amount of GAS to withdraw.</param>
    public static void WithdrawFromMainBalance(UInt160 investorAddress, BigInteger amount)
    {
        if (investorAddress is null || investorAddress.IsZero)
            throw new Exception("Invalid investor address");

        if (!Runtime.CheckWitness(investorAddress))
            throw new Exception("WithdrawFromMainBalance: sender is not authorised");

        if (amount <= 0)
            throw new Exception("WithdrawFromMainBalance: amount must be positive");

        InvestorAccount account = getInvestorAccount(investorAddress);
        if (account.FreeBalance < amount)
            throw new Exception("WithdrawFromMainBalance: insufficient free balance");

        // Transfer GAS from the contract to the investor
        bool transferOk = (bool)GAS.Transfer(Runtime.ExecutingScriptHash, investorAddress, amount, null);
        if (!transferOk)
            throw new Exception("WithdrawFromMainBalance: GAS transfer failed");

        // Deduct the withdrawn amount from the balances
        account.FreeBalance -= amount;
        account.TotalBalance -= amount;

        // Persist updated account; updateExistingInvestorAccount performs a witness check
        updateExistingInvestorAccount(investorAddress, account);
    }

    public InvestorAccount()
    {
    }

    public bool receiveProfitPayment(BigInteger amount)
    {
        if (amount <= 0)
            throw new Exception("Profit amount must be positive");

        this.FreeBalance += amount;
        this.TotalBalance += amount;
        return true;
    }

    public bool receiveInvestmentRefund(BigInteger amount)
    {
        if (amount <= 0)
            throw new Exception("Refund amount must be positive");

        this.FreeBalance += amount;
        return true;
    }

    public bool canReceiveProfit(BigInteger amount)
    {
        return amount > 0;
    }

    public bool canReceiveRefund(BigInteger amount)
    {
        return amount > 0;
    }

    public bool verifyAndSetPublicKey(UInt160 investorAddress, byte[] publicKeyBytes, byte[] message, byte[] signature)
    {
        if (!Runtime.CheckWitness(investorAddress))
            throw new Exception("Authorization failed");

        if (!IFHelper.verifySignatureSHA256(publicKeyBytes, message, signature))
            throw new Exception("Invalid signature");

        InvestorAccount account = getInvestorAccount(investorAddress);

        if (account != null)
        {
            account.PublicKey = publicKeyBytes;
            updateExistingInvestorAccount(investorAddress, account);
            return true;
        }

        throw new Exception("Account not found");
    }


    public static InvestorAccount getInvestorAccount(UInt160 investorAddress)
    {
        ByteString raw = ProjectState.GetRawInvestorAccount(investorAddress);
        InvestorAccount account = raw is null ? null : (InvestorAccount)StdLib.Deserialize(raw);
        if (account == null) throw new Exception("Investor account not found: " + investorAddress.ToString());
        return account;
    }
    public static void updateExistingInvestorAccount(UInt160 investorAddress, InvestorAccount account)
    {
        if (account == null || account.InvestorWalletAddress == null || account.InvestorWalletAddress.IsZero)
            throw new ArgumentNullException("Investor account or its address cannot be null/zero for update.");
        if (investorAddress != account.InvestorWalletAddress)
            throw new InvalidOperationException("Mismatch between provided investorAddress and account's InvestorWalletAddress.");

        if (!Runtime.CheckWitness(account.InvestorWalletAddress)) throw new Exception("Authorization failed for updating investor account");

        ProjectState.SetRawInvestorAccount(account.InvestorWalletAddress, StdLib.Serialize(account));
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    public static void withdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
    {
        if (manufacturerAddress.Length != 20) throw new Exception("The parameter ManufacturerAddress SHOULD be a 20-byte address.");
        if (investorAddress.Length != 20) throw new Exception("The parameter InvestorAddress SHOULD be a 20-byte address.");
        if (!Runtime.CheckWitness(investorAddress)) throw new Exception("Only Investor can call this method for their own investment withdrawal.");

        BigInteger investmentAmountToWithdraw = ProjectState.GetBackerReservation(projectId, investorAddress, manufacturerAddress);
        if (investmentAmountToWithdraw <= 0)
            throw new Exception("No investment found for this investor and manufacturer in this project, or investment is zero.");

        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
            throw new Exception("Manufacturer is not a candidate in this project (internal error).");

        ManufacturerAccount projectManufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
        InvestorAccount globalInvestorAccount = InvestorAccount.getInvestorAccount(investorAddress);

        if (!projectManufacturerAccount.canRefundInvestment(projectId, investorAddress, investmentAmountToWithdraw))
            throw new Exception("Cannot refund investment: insufficient manufacturer balance or invalid investment record.");

        if (!globalInvestorAccount.canReceiveRefund(investmentAmountToWithdraw))
            throw new Exception("Invalid refund amount for investor.");

        IF_MainGateway.AcquireLock();
        try
        {
            if (!projectManufacturerAccount.refundInvestment(projectId, investorAddress, investmentAmountToWithdraw))
                throw new Exception("Failed to process investment refund from manufacturer.");

            if (!globalInvestorAccount.receiveInvestmentRefund(investmentAmountToWithdraw))
                throw new Exception("Failed to process investment refund receipt by investor.");

            ProjectState.SetBackerReservation(projectId, investorAddress, manufacturerAddress, 0);

            InvestorAccount.updateExistingInvestorAccount(investorAddress, globalInvestorAccount);
            ManufacturerAccount.updateExistingManufacturerAccount(projectManufacturerAccount);
        }
        finally
        {
            IF_MainGateway.ReleaseAcquireLock();
        }
    }

    public static void investAsInvestorToManufacturerCandidate(UInt160 investorAddress, UInt160 manufacturerId, BigInteger amount)
    {
        if (!Runtime.CheckWitness(investorAddress)) throw new Exception("Authorization failed for investor.");

        InvestorAccount investor = getInvestorAccount(investorAddress);
        if (investor.FreeBalance < amount) throw new Exception("Investor has insufficient free funds.");

        ManufacturerAccount manufacturer = ManufacturerAccount.getManufacturerAccount(manufacturerId);

        IF_MainGateway.AcquireLock();
        try
        {
            investor.FreeBalance -= amount;
            updateExistingInvestorAccount(investorAddress, investor);

            manufacturer.InvestmentAmount += amount;
            manufacturer.TotalBalance += amount;
            manufacturer.FreeBalance += amount;

            // �������: ��������� ���������� �� ����� manufacturer.InvestorsInvestments � ������� �� ProjectState.

            ManufacturerAccount.updateExistingManufacturerAccount(manufacturer);
        }
        finally
        {
            IF_MainGateway.ReleaseAcquireLock();
        }
    }



    public static void createInvestorAccount(UInt160 investorAddress, byte[] PublicKey)
    {
        if (investorAddress == null || investorAddress.IsZero || investorAddress.Length != 20) throw new Exception("Invalid investor address");
        if (!Runtime.CheckWitness(investorAddress)) throw new Exception("Authorization failed for creating investor account");
        if (IFHelper.pubKeyToAddress(PublicKey) != investorAddress) throw new Exception("Public key does not match investor address");

        if (ProjectState.GetRawInvestorAccount(investorAddress) != null)
            throw new Exception("Investor account already exists.");

        InvestorAccount account = new InvestorAccount();
        account.InvestorWalletAddress = investorAddress;
        account.PublicKey = PublicKey;
        account.OwnerCreatorAddressAccount = investorAddress;
        account.TotalBalance = 0;
        account.FreeBalance = 0;
        ProjectState.SetRawInvestorAccount(investorAddress, StdLib.Serialize(account));
    }


    public static void moveFromInvestorBalanceToInnFork(string projectId, UInt160 investorAddress, BigInteger amount)
    {
        if (amount <= 0) throw new Exception("Amount must be positive");
        if (!Runtime.CheckWitness(investorAddress)) throw new Exception("Authorization failed for investor");
        InvestorAccount account = getInvestorAccount(investorAddress);
        if (account.FreeBalance < amount) throw new Exception("Insufficient free balance in investor account");
        IF_MainGateway.AcquireLock();
        try
        {
            account.FreeBalance -= amount;
            account.TotalBalance -= amount;
            updateExistingInvestorAccount(investorAddress, account);
            BigInteger currentProjectTotalBalance = ProjectState.GetProjectTotalBalance(projectId);
            ProjectState.SetProjectTotalBalance(projectId, currentProjectTotalBalance + amount);
        }
        finally
        {
            IF_MainGateway.ReleaseAcquireLock();
        }

    }
    public static BigInteger getTotalBalanceOfInvestorAccount(UInt160 investorAddress)
    {
        return getInvestorAccount(investorAddress).TotalBalance;
    }
    public static BigInteger getFreeBalanceOfInvestorAccount(UInt160 investorAddress)
    {
        return getInvestorAccount(investorAddress).FreeBalance;
    }

    public static void removeInvestorAccount(UInt160 investorAddress)
    {
        if (!Runtime.CheckWitness(investorAddress))
            throw new Exception("Authorization failed");

        if (investorAddress == null || investorAddress.IsZero || investorAddress.Length != 20)
            throw new Exception("Invalid Investor address format");

        InvestorAccount investor = null;
        try
        {
            investor = InvestorAccount.getInvestorAccount(investorAddress);
        }
        catch (Exception)
        {
            throw new Exception("Investor account not found or already removed");
        }

        if (investor.InvestorWalletAddress != investorAddress)
            throw new Exception("Authorization failed - address mismatch");

        IF_MainGateway.AcquireLock();
        try
        {
            InvestmentAgreement.checkAllExpiredAgreements(investorAddress);

            if (hasActiveInvestments(investorAddress))
                throw new Exception("Investor account has active investments and cannot be removed");

            ProjectState.LinkInvestorAgreement(investorAddress, (ByteString)new byte[0]);
            ProjectState.LinkManufacturerAgreement(investorAddress, (ByteString)new byte[0]);

            cleanupInvestorFromProjects(investorAddress);

            ProjectState.SetRawInvestorAccount(investorAddress, (ByteString)new byte[0]);
        }
        catch (Exception ex)
        {
            throw new Exception("Failed to remove investor account: " + ex.Message);
        }
        finally
        {
            IF_MainGateway.ReleaseAcquireLock();
        }
    }

    private static bool hasActiveInvestments(UInt160 investorAddress)
    {
        ByteString investorAgreementsRaw = ProjectState.GetInvestorAgreement(investorAddress);
        if (investorAgreementsRaw != null && investorAgreementsRaw.Length > 0)
        {
            return true;
        }

        ByteString manufacturerAgreementsRaw = ProjectState.GetManufacturerAgreement(investorAddress);
        if (manufacturerAgreementsRaw != null && manufacturerAgreementsRaw.Length > 0)
        {
            return true;
        }

        return false;
    }



    private static string[] cleanupInvestorFromProjects(UInt160 investorAddress)
    {
        // �������� ��� projectId ����� ProjectAccount �� ����������� ������
        string[] allProjectIds;
        try
        {
            allProjectIds = ProjectAccount.getAllProjectsIds();
        }
        catch
        {
            // ��� �������� � ������ �������
            return new string[0];
        }

        if (allProjectIds == null || allProjectIds.Length == 0)
            return new string[0];

        // ����������: �������, ��� ���� ����������� ���������
        string[] affected = new string[allProjectIds.Length];
        int affectedCount = 0;

        for (int pi = 0; pi < allProjectIds.Length; pi++)
        {
            string projectId = allProjectIds[pi];
            if (string.IsNullOrEmpty(projectId)) continue;

            bool changedInProject = false;

            // 1) ������� �� ���� ����������-��������������: ���������� � ������ ���������
            UInt160[] manufacturers = ProjectState.GetManufacturerCandidates(projectId);
            if (manufacturers != null && manufacturers.Length > 0)
            {
                for (int mi = 0; mi < manufacturers.Length; mi++)
                {
                    UInt160 man = manufacturers[mi];
                    if (man == null || man.IsZero) continue;

                    // �������� ���������� ���������� ��� ���� (investor, manufacturer)
                    BigInteger reserved = ProjectState.GetInvestorToManufacturerReservation(projectId, investorAddress, man);
                    if (reserved > 0)
                    {
                        ProjectState.SetInvestorToManufacturerReservation(projectId, investorAddress, man, 0);
                        changedInProject = true;
                    }


                }
            }

            // 2) ���� ����� ��������� ������������� ��� �����, ������� �������������
            // (�������������, �� ������� ��� ������ ������� ������ �������)
            try
            {
                BigInteger donation = ProjectState.GetBackerDonation(projectId, investorAddress);
                if (donation > 0)
                {
                    ProjectState.SetBackerDonation(projectId, investorAddress, 0);
                    changedInProject = true;
                }
            }
            catch
            {
                // ���� � ������ ����� ��� API ������������� � ����������
            }

            if (changedInProject)
            {
                affected[affectedCount] = projectId;
                affectedCount++;
            }
        }

        // ���������� ���� �� ������������ ����������
        if (affectedCount == affected.Length) return affected;

        string[] result = new string[affectedCount];
        for (int i = 0; i < affectedCount; i++)
        {
            result[i] = affected[i];
        }
        return result;
    }


}








public partial class InvestmentAgreement
{

    private static void trackInvestorAgreements(UInt160 party, byte[] agreementId)
    {
        ByteString agreementsRaw = ProjectState.GetInvestorAgreement(party);

        if (agreementsRaw == null || agreementsRaw.Length == 0)
        {
            ProjectState.LinkInvestorAgreement(party, (ByteString)agreementId);
        }
        else
        {
            byte[] separator = new byte[1] { 0xFF };
            byte[] existingData = (byte[])agreementsRaw;
            byte[] newData = new byte[existingData.Length + separator.Length + agreementId.Length];

            for (int i = 0; i < existingData.Length; i++)
            {
                newData[i] = existingData[i];
            }

            int offset = existingData.Length;
            for (int i = 0; i < separator.Length; i++)
            {
                newData[offset + i] = separator[i];
            }

            offset += separator.Length;
            for (int i = 0; i < agreementId.Length; i++)
            {
                newData[offset + i] = agreementId[i];
            }

            ProjectState.LinkInvestorAgreement(party, (ByteString)newData);
        }
    }

    private static void trackManufacturerAgreements(UInt160 party, byte[] agreementId)
    {
        ByteString agreementsRaw = ProjectState.GetManufacturerAgreement(party);

        if (agreementsRaw == null || agreementsRaw.Length == 0)
        {
            ProjectState.LinkManufacturerAgreement(party, (ByteString)agreementId);
        }
        else
        {
            byte[] separator = new byte[1] { 0xFF };
            byte[] existingData = (byte[])agreementsRaw;
            byte[] newData = new byte[existingData.Length + separator.Length + agreementId.Length];

            for (int i = 0; i < existingData.Length; i++)
            {
                newData[i] = existingData[i];
            }

            int offset = existingData.Length;
            for (int i = 0; i < separator.Length; i++)
            {
                newData[offset + i] = separator[i];
            }

            offset += separator.Length;
            for (int i = 0; i < agreementId.Length; i++)
            {
                newData[offset + i] = agreementId[i];
            }

            ProjectState.LinkManufacturerAgreement(party, (ByteString)newData);
        }
    }

    public static void trackAgreementParties(byte[] agreementId, UInt160 investor, UInt160 manufacturer)
    {
        trackInvestorAgreements(investor, agreementId);
        trackManufacturerAgreements(manufacturer, agreementId);
    }

    public static void handleRepayment(InvestmentAgreement agreement, byte[] agreementId, UInt160 from, BigInteger amount, UInt160 tokenHash)
    {
        if (from != agreement.Manufacturer) throw new Exception("Invalid manufacturer for repayment");
        if (tokenHash != (UInt160)agreement.AssetId) throw new Exception("Asset mismatch for repayment");
        if (agreement.Status != 1) throw new Exception("InvestmentAgreement is not active for repayments");
        if (amount <= 0) throw new Exception("Repayment amount must be positive");

        checkAllExpiredAgreements(agreement.Manufacturer);
        checkAllExpiredAgreements(agreement.Investor);

        BigInteger remainingDebt = agreement.RepaymentAmount - agreement.RepaidAmount;
        if (amount > remainingDebt) throw new Exception("Repayment amount exceeds remaining debt");

        agreement.RepaidAmount += amount;

        if (agreement.RepaidAmount == agreement.RepaymentAmount)
        {
            agreement.Status = 2;
            EventDispatcherAdapter.EmitAgreementCompleted(agreementId);

            ManufacturerAccount manufacturerGlobal = ManufacturerAccount.getManufacturerAccount(agreement.Manufacturer);
            if (manufacturerGlobal != null)
            {
                BigInteger reputationBonus = agreement.InvestmentAmount / 10000;
                manufacturerGlobal.ReputationScore += reputationBonus;
                ManufacturerAccount.updateExistingManufacturerAccount(manufacturerGlobal);
            }
        }

        ProjectState.SetAgreement((ByteString)agreementId, StdLib.Serialize(agreement));
        EventDispatcherAdapter.EmitRepaymentMade(agreementId, amount);

        safeTransfer(tokenHash, agreement.Investor, amount);
    }

    public static void scheduledAgreementMaintenance()
    {
        ulong currentTime = Runtime.Time;

        ByteString raw = ProjectState.GetInvestmentSystemState((ByteString)"LastAgreementCheck");
        BigInteger lastCheckValue = raw is null ? 0 : (BigInteger)raw;
        ulong lastCheck = lastCheckValue > 0 ? (ulong)lastCheckValue : 0;

        if (currentTime - lastCheck < 3600)
            throw new Exception("InvestmentAgreement maintenance can only be performed once per hour");

        ProjectState.SetInvestmentSystemState((ByteString)"LastAgreementCheck", ((BigInteger)currentTime).ToByteArray().ToByteString());

        processLimitedExpiredAgreements();
    }

    public static void processLimitedExpiredAgreements()
    {
    }

    public static void processAgreementsList(byte[] agreementsList)
    {
        if (agreementsList == null || agreementsList.Length == 0) return;

        int currentIndex = 0;
        byte separator = 0xFF;

        do
        {
            int nextSeparatorIndex = currentIndex;
            for (int i = currentIndex; i < agreementsList.Length; i++)
            {
                if (agreementsList[i] == separator)
                {
                    nextSeparatorIndex = i;
                    break;
                }
                if (i == agreementsList.Length - 1)
                {
                    nextSeparatorIndex = agreementsList.Length;
                    break;
                }
            }

            int agreementIdLength = nextSeparatorIndex - currentIndex;
            if (agreementIdLength > 0)
            {
                byte[] agreementId = new byte[agreementIdLength];
                for (int i = 0; i < agreementIdLength; i++)
                {
                    agreementId[i] = agreementsList[currentIndex + i];
                }

                ByteString rawAgreement = ProjectState.GetAgreement((ByteString)agreementId);
                if (rawAgreement != null)
                {
                    InvestmentAgreement agreement = (InvestmentAgreement)StdLib.Deserialize(rawAgreement);
                    checkSingleAgreementStatus(agreement, agreementId);
                }
            }

            currentIndex = nextSeparatorIndex + 1;
        }
        while (currentIndex < agreementsList.Length);
    }

    public static void checkSingleAgreementStatus(InvestmentAgreement agreement, byte[] agreementId)
    {
        if (agreement.Status == 1 && agreement.RepaidAmount < agreement.RepaymentAmount && Runtime.Time > agreement.DueDate)
        {
            agreement.Status = 3;
            ProjectState.SetAgreement((ByteString)agreementId, StdLib.Serialize(agreement));
            EventDispatcherAdapter.EmitAgreementDefaulted(agreementId);
        }
    }

    public static void checkExpiredAgreementsForParticipant(UInt160 participantAddress)
    {
        if (!Runtime.CheckWitness(participantAddress))
            throw new Exception("Only the participant can check their own expired agreements");

        checkAllExpiredAgreements(participantAddress);
    }

    public static void processAllExpiredAgreements()
    {
        if (!IF_MainGateway.IsOwner())
            throw new Exception("Only contract owner can process all expired agreements");
    }

    public static byte[] generateAgreementId(UInt160 investor, UInt160 manufacturer, BigInteger amount)
    {
        if (investor == null || investor.IsZero) throw new Exception("Invalid investor address for agreement ID generation");
        if (manufacturer == null || manufacturer.IsZero) throw new Exception("Invalid manufacturer address for agreement ID generation");
        if (amount <= 0) throw new Exception("Invalid amount for agreement ID generation");

        ByteString data = (ByteString)investor + (ByteString)manufacturer +
                         (ByteString)amount.ToByteArray() + (ByteString)Runtime.Time.ToString() +
                         (ByteString)Runtime.InvocationCounter.ToString();

        return ((byte[])CryptoLib.Sha256(data));
    }

    public static void checkAgreementStatus(byte[] agreementId)
    {
        ByteString rawAgreement = ProjectState.GetAgreement((ByteString)agreementId);
        if (rawAgreement == null) throw new Exception("InvestmentAgreement not found");

        InvestmentAgreement agreement = (InvestmentAgreement)StdLib.Deserialize(rawAgreement);

        if (agreement.Status == 1 && agreement.RepaidAmount < agreement.RepaymentAmount && Runtime.Time > agreement.DueDate)
        {
            agreement.Status = 3;
            ProjectState.SetAgreement((ByteString)agreementId, StdLib.Serialize(agreement));
            EventDispatcherAdapter.EmitAgreementDefaulted(agreementId);

            ManufacturerAccount manufacturerGlobal = ManufacturerAccount.getManufacturerAccount(agreement.Manufacturer);
            if (manufacturerGlobal != null)
            {
                BigInteger penaltyScore = agreement.InvestmentAmount / 1000;
                manufacturerGlobal.ReputationScore -= penaltyScore;
                if (manufacturerGlobal.ReputationScore < 0) manufacturerGlobal.ReputationScore = 0;
                ManufacturerAccount.updateExistingManufacturerAccount(manufacturerGlobal);
            }
        }
    }

    public static void safeTransfer(UInt160 token, UInt160 to, BigInteger amount)
    {
        bool result = (bool)Contract.Call(token, "transfer", CallFlags.All, Runtime.ExecutingScriptHash, to, amount, null);
        ExecutionEngine.Assert(result, "Transfer failed");
    }

    public static void createAgreement(UInt160 investor, UInt160 manufacturer, BigInteger investmentAmount, byte[] assetId, BigInteger repaymentAmount, ulong dueDate)
    {
        if (!Runtime.CheckWitness(investor)) throw new Exception("Authorization failed");
        ExecutionEngine.Assert(IFHelper.validateAddress(manufacturer), "Invalid manufacturer");
        ExecutionEngine.Assert(IFHelper.validateAddress(investor), "Invalid investor");
        ExecutionEngine.Assert(investmentAmount > 0, "Invalid amount");
        ExecutionEngine.Assert(repaymentAmount >= investmentAmount, "Invalid repayment");
        ExecutionEngine.Assert(dueDate > Runtime.Time, "Invalid date");

        byte[] agreementId = generateAgreementId(investor, manufacturer, investmentAmount);
        ExecutionEngine.Assert(ProjectState.GetAgreement((ByteString)agreementId) == null, "InvestmentAgreement exists");

        InvestmentAgreement agreement = new InvestmentAgreement
        {
            Investor = investor,
            Manufacturer = manufacturer,
            InvestmentAmount = investmentAmount,
            RepaymentAmount = repaymentAmount,
            AssetId = assetId,
            DueDate = dueDate,
            Status = 0,
            RepaidAmount = 0
        };

        ProjectState.SetAgreement((ByteString)agreementId, StdLib.Serialize(agreement));
        trackAgreementParties(agreementId, investor, manufacturer);
        EventDispatcherAdapter.EmitAgreementCreated(agreementId, investor, manufacturer, investmentAmount);
    }

    public static byte[] createAgreementForProjectInvestment(UInt160 investor, UInt160 manufacturer, BigInteger investmentAmount, byte[] assetId, BigInteger repaymentAmount, ulong dueDate)
    {
        if (!IFHelper.validateAddress(investor)) throw new Exception("Invalid investor address");
        if (!IFHelper.validateAddress(manufacturer)) throw new Exception("Invalid manufacturer address");
        if (investmentAmount <= 0) throw new Exception("Investment amount must be positive");
        if (repaymentAmount < investmentAmount) throw new Exception("Repayment amount cannot be less than investment amount");
        if (dueDate <= Runtime.Time) throw new Exception("Due date must be in the future");

        byte[] agreementId = generateAgreementId(investor, manufacturer, investmentAmount);
        if (ProjectState.GetAgreement((ByteString)agreementId) != null) throw new Exception("InvestmentAgreement already exists");

        InvestmentAgreement agreement = new InvestmentAgreement
        {
            Investor = investor,
            Manufacturer = manufacturer,
            InvestmentAmount = investmentAmount,
            RepaymentAmount = repaymentAmount,
            AssetId = assetId,
            DueDate = dueDate,
            Status = 0,
            RepaidAmount = 0
        };

        ProjectState.SetAgreement((ByteString)agreementId, StdLib.Serialize(agreement));
        trackAgreementParties(agreementId, investor, manufacturer);
        EventDispatcherAdapter.EmitAgreementCreated(agreementId, investor, manufacturer, investmentAmount);
        return agreementId;
    }

    public static void confirmAgreement(byte[] agreementId)
    {
        ByteString rawAgreement = ProjectState.GetAgreement((ByteString)agreementId);
        if (rawAgreement == null) throw new Exception("InvestmentAgreement not found");

        InvestmentAgreement agreement = (InvestmentAgreement)StdLib.Deserialize(rawAgreement);

        if (agreement.Status != 0) throw new Exception("InvestmentAgreement cannot be confirmed: invalid status");
        if (!Runtime.CheckWitness(agreement.Manufacturer)) throw new Exception("Only manufacturer can confirm agreement.");
        if (Runtime.Time > agreement.DueDate) throw new Exception("InvestmentAgreement has expired and cannot be confirmed");

        checkAllExpiredAgreements(agreement.Manufacturer);
        checkAllExpiredAgreements(agreement.Investor);

        agreement.Status = 1;
        ProjectState.SetAgreement((ByteString)agreementId, StdLib.Serialize(agreement));
        EventDispatcherAdapter.EmitAgreementConfirmed(agreementId);
    }

    public static void checkAllExpiredAgreements(UInt160 participantAddress)
    {
        if (participantAddress == null || participantAddress.IsZero) return;

        ByteString investorAgreements = ProjectState.GetInvestorAgreement(participantAddress);
        if (investorAgreements != null)
        {
            processAgreementsList((byte[])investorAgreements);
        }

        ByteString manufacturerAgreements = ProjectState.GetManufacturerAgreement(participantAddress);
        if (manufacturerAgreements != null)
        {
            processAgreementsList((byte[])manufacturerAgreements);
        }
    }

    public static void handleInvestmentPayment(InvestmentAgreement agreement, byte[] agreementId, UInt160 from, BigInteger amount, UInt160 tokenHash)
    {
        if (from != agreement.Investor) throw new Exception("Invalid investor for investment payment");
        if (!Runtime.CheckWitness(agreement.Investor)) throw new Exception("Authorization failed");
        if (tokenHash != (UInt160)agreement.AssetId) throw new Exception("Asset mismatch for investment payment");
        if (agreement.Status != 1) throw new Exception("InvestmentAgreement is not confirmed for investment payments");
        if (amount != agreement.InvestmentAmount) throw new Exception("Investment amount mismatch");

        checkAllExpiredAgreements(agreement.Investor);
        checkAllExpiredAgreements(agreement.Manufacturer);

        agreement.Status = 2;

        ProjectState.SetAgreement((ByteString)agreementId, StdLib.Serialize(agreement));

        ManufacturerAccount manufacturer = ManufacturerAccount.getManufacturerAccount(agreement.Manufacturer);
        manufacturer.processInvestorInvestments(agreement.Investor, amount, agreementId);
        ManufacturerAccount.updateExistingManufacturerAccount(manufacturer);

        EventDispatcherAdapter.EmitInvestmentPaymentMade(agreementId, amount);
    }
}


public class InvestmentRecord
{
    public BigInteger Amount;
    public ulong CreatedTime;
    public byte Status; // 0=Active, 1=Withdrawn, 2=Partial
    public byte[] AgreementId = new byte[64];
}


public class DonationRecord
{
    public BigInteger Amount;
    public byte DonationType; // 0=PrizeFund, 1=Milestone, 2=Reserved
    public ulong CreatedTime;
    public byte Status; // 0=Active, 1=Used, 2=Refunded
}

public class FinancialOperations
{
    public static void RecordInvestment(UInt160 investor, UInt160 manufacturer,
        string projectId, BigInteger amount, byte[] agreementId)
    {
        if (!Runtime.CheckWitness(investor))
            throw new Exception("Unauthorized investment record");

        ByteString key = CreateInvestmentKey(investor, manufacturer, projectId);

        InvestmentRecord record = new InvestmentRecord
        {
            Amount = amount,
            CreatedTime = Runtime.Time,
            Status = 0,
            AgreementId = agreementId
        };

        ProjectState.SetInvestmentRecord(key, StdLib.Serialize(record));
    }

    public static BigInteger GetInvestmentAmount(UInt160 investor, UInt160 manufacturer, string projectId)
    {
        ByteString key = CreateInvestmentKey(investor, manufacturer, projectId);
        ByteString raw = ProjectState.GetInvestmentRecord(key);
        if (raw is null) return 0;
        InvestmentRecord record = (InvestmentRecord)StdLib.Deserialize(raw);
        return record?.Amount ?? 0;
    }

    private static ByteString CreateInvestmentKey(UInt160 investor, UInt160 manufacturer, string projectId)
    {
        return CryptoLib.Sha256(investor.ToString() + manufacturer.ToString() + projectId);
    }
}




