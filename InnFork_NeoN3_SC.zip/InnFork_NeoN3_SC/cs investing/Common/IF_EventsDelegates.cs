using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using System;
using System.ComponentModel;
using System.Numerics;


namespace InnFork.NeoN3;

/*public partial class IF_MainGateway
{

    public static void CallAgreementCompleted(byte[] agreementId)
    {
        AgreementCompleted(agreementId);
    }
    public static void CallAgreementConfirmed(byte[] agreementId)
    {
        AgreementConfirmed(agreementId);
    }
    public static void CallAgreementCreated(byte[] agreementId, UInt160 investor, UInt160 manufacturer, BigInteger amount)
    {
        AgreementCreated(agreementId, investor, manufacturer, amount);
    }
    public static void CallAgreementDefaulted(byte[] agreementId)
    {
        AgreementDefaulted(agreementId);
    }
    public static void CallRepaymentMade(byte[] agreementId, BigInteger amount)
    {
        RepaymentMade(agreementId, amount);
    }
    public static void CallInvestmentPaymentMade(byte[] agreementId, BigInteger amount)
    {
        InvestmentPaymentMade(agreementId, amount);
    }



}
*/