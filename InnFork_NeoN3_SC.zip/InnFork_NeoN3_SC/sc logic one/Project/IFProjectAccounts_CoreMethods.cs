using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.IF_MainGateway;


namespace InnFork.NeoN3;




public partial class IF_MainGateway : Neo.SmartContract.Framework.SmartContract
{

    public static void saveProjectAccountToProjectsAccountStore(string projectId, ProjectAccount project)
    {
        if (project == null) throw new Exception("Project param is null: " + projectId);
        if (string.IsNullOrEmpty(projectId) || (projectId.Length != 32 && projectId.Length != 64))
            throw new Exception("saveProjectAccountToProjectsAccountStore: Invalid projectId format. Length is: " + (projectId == null ? 0 : projectId.Length));

        project.LastActivityTime = Runtime.Time;
        var coreDto = ToCoreDto(projectId, project);
        var coreBytes = StdLib.Serialize(coreDto);

        ProjectState.SetProjectCore(projectId, coreBytes);

        try { ProjectState.SetLastActivityTime(projectId, project.LastActivityTime); } catch { }
        try { ProjectState.SetProjectTotalBalance(projectId, project.FLMUSD_TotalProjectBalance); } catch { }
        try { ProjectState.SetLockedFunds(projectId, project.totalFundsLocked); } catch { }
        try { ProjectState.SetTotalRefundsProcessed(projectId, project.TotalRefundsProcessed); } catch { }
        try { ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, project.IsProjectHasWinner); } catch { }
        try { ProjectState.SetProjectStatus(projectId, (int)project.CurrentProjectStatus); } catch { }
        try { ProjectState.SetVotingConfiguration(projectId, project.MinRequiredVotingParticipation, project.MinApprovalPercentage, project.AutoAssignVoicelessToAbstain, project.AutoAbstainVoteAsSupport); } catch { }

        try
        {
            if (project.LaunchVotingDeadline > 0 || project.FundraisingDeadline > 0 || project.ManufacturerSelectionVotingDeadline > 0)
                ProjectState.SetProjectVotingDeadlines(projectId, project.LaunchVotingDeadline, project.FundraisingDeadline, project.ManufacturerSelectionVotingDeadline);

            ProjectState.SyncVotingDeadline(projectId, "LaunchApproval", project.LaunchVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "FundraisingCompletion", project.FundraisingCompletionVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "SuccessfulClosure", project.SuccessfulClosureVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "PauseResume", project.PauseResumeVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "ManufacturerSelection", project.ManufacturerSelectionVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "TerminationWithRefund", project.TerminationWithRefundVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "FundraisingIncrease", project.FundraisingIncreaseVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "ManagementTransfer", project.ManagementTransferVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "MilestoneCompletion", project.MilestoneCompletionVotingDeadline);
        }
        catch { }
    }
    class ProjectCoreStateDto
    {
        public string ProjectId;
        public UInt160 ProjectCreatorAddress;
        public BigInteger FLMUSD_TotalProjectBalance;
        public BigInteger FLMUSD_PrizeFundBalance;
        public BigInteger TotalRefundsProcessed;
        public BigInteger TotalFundsLocked;
        public bool IsArchived;
        public bool IsProjectPaused;
        public bool IsProjectClosed;
        public bool IsProjectHasWinner;
        public int CurrentProjectStatus;
        public BigInteger MinRequiredVotingParticipation;
        public BigInteger MinApprovalPercentage;
        public bool AutoAssignVoicelessToAbstain;
        public bool AutoAbstainVoteAsSupport;
        public ulong LaunchVotingDeadline;
        public ulong FundraisingDeadline;
        public ulong FundraisingCompletionVotingDeadline;
        public ulong SuccessfulClosureVotingDeadline;
        public ulong PauseResumeVotingDeadline;
        public ulong ManufacturerSelectionVotingDeadline;
        public ulong TerminationWithRefundVotingDeadline;
        public ulong MilestoneCompletionVotingDeadline;
        public ulong ManagementTransferVotingDeadline;
        public ulong RegistrationTime;
        public ulong LastActivityTime;
        public string ProjectOfferId_Sha256;
    }

    private static ProjectCoreStateDto ToCoreDto(string projectId, ProjectAccount p)
    {
        return new ProjectCoreStateDto
        {
            ProjectId = projectId,
            ProjectCreatorAddress = p.ProjectCreatorAddress,
            FLMUSD_TotalProjectBalance = p.FLMUSD_TotalProjectBalance,
            FLMUSD_PrizeFundBalance = p.FLMUSD_PrizeFundBalance,
            TotalRefundsProcessed = p.TotalRefundsProcessed,
            TotalFundsLocked = p.totalFundsLocked,
            IsArchived = p.IsArchived,
            IsProjectPaused = p.IsProjectPaused,
            IsProjectClosed = p.IsProjectClosed,
            IsProjectHasWinner = p.IsProjectHasWinner,
            CurrentProjectStatus = (int)p.CurrentProjectStatus,
            MinRequiredVotingParticipation = p.MinRequiredVotingParticipation,
            MinApprovalPercentage = p.MinApprovalPercentage,
            AutoAssignVoicelessToAbstain = p.AutoAssignVoicelessToAbstain,
            AutoAbstainVoteAsSupport = p.AutoAbstainVoteAsSupport,
            LaunchVotingDeadline = p.LaunchVotingDeadline,
            FundraisingDeadline = p.FundraisingDeadline,
            FundraisingCompletionVotingDeadline = p.FundraisingCompletionVotingDeadline,
            SuccessfulClosureVotingDeadline = p.SuccessfulClosureVotingDeadline,
            PauseResumeVotingDeadline = p.PauseResumeVotingDeadline,
            ManufacturerSelectionVotingDeadline = p.ManufacturerSelectionVotingDeadline,
            TerminationWithRefundVotingDeadline = p.TerminationWithRefundVotingDeadline,
            MilestoneCompletionVotingDeadline = p.MilestoneCompletionVotingDeadline,
            ManagementTransferVotingDeadline = p.ManagementTransferVotingDeadline,
            RegistrationTime = p.RegistrationTime,
            LastActivityTime = p.LastActivityTime,
            ProjectOfferId_Sha256 = p.ProjectOfferId_Sha256
        };
    }

    private static void ApplyCoreDto(ProjectAccount p, ProjectCoreStateDto d)
    {
        p.ProjectCreatorAddress = d.ProjectCreatorAddress;
        p.FLMUSD_TotalProjectBalance = d.FLMUSD_TotalProjectBalance;
        p.FLMUSD_PrizeFundBalance = d.FLMUSD_PrizeFundBalance;
        p.TotalRefundsProcessed = d.TotalRefundsProcessed;
        p.totalFundsLocked = d.TotalFundsLocked;
        p.IsArchived = d.IsArchived;
        p.IsProjectPaused = d.IsProjectPaused;
        p.IsProjectClosed = d.IsProjectClosed;
        p.IsProjectHasWinner = d.IsProjectHasWinner;
        p.CurrentProjectStatus = (ProjectStatus)d.CurrentProjectStatus;
        p.MinRequiredVotingParticipation = d.MinRequiredVotingParticipation;
        p.MinApprovalPercentage = d.MinApprovalPercentage;
        p.AutoAssignVoicelessToAbstain = d.AutoAssignVoicelessToAbstain;
        p.AutoAbstainVoteAsSupport = d.AutoAbstainVoteAsSupport;
        p.LaunchVotingDeadline = d.LaunchVotingDeadline;
        p.FundraisingDeadline = d.FundraisingDeadline;
        p.FundraisingCompletionVotingDeadline = d.FundraisingCompletionVotingDeadline;
        p.SuccessfulClosureVotingDeadline = d.SuccessfulClosureVotingDeadline;
        p.PauseResumeVotingDeadline = d.PauseResumeVotingDeadline;
        p.ManufacturerSelectionVotingDeadline = d.ManufacturerSelectionVotingDeadline;
        p.TerminationWithRefundVotingDeadline = d.TerminationWithRefundVotingDeadline;
        p.MilestoneCompletionVotingDeadline = d.MilestoneCompletionVotingDeadline;
        p.ManagementTransferVotingDeadline = d.ManagementTransferVotingDeadline;
        p.RegistrationTime = d.RegistrationTime;
        p.LastActivityTime = d.LastActivityTime;
        p.ProjectOfferId_Sha256 = d.ProjectOfferId_Sha256;
    }


    public static ProjectAccount getProjectAccount(string projectId)
    {
        if (projectId.Length != 32 && projectId.Length != 64)
            throw new Exception("getProjectAccount: Invalid projectId format. Lenght is: " + projectId.Length.ToString());

        var coreBytes = ProjectState.GetProjectCoreBytes(projectId);
        if (coreBytes is null) throw new Exception("getProjectAccount: Project not found");

        var dto = (ProjectCoreStateDto)StdLib.Deserialize(coreBytes);
        var projectAccount = new ProjectAccount();
        ApplyCoreDto(projectAccount, dto);
        projectAccount.projectId = projectId;
        return projectAccount;
    }

}

