﻿using InnFork.NeoN3.Adapters;
using InnFork.NeoN3.Enums;

using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.ProjectAccount;



namespace InnFork.NeoN3;




public partial class IF_MainGateway

// Voting and Eligibility
{

    public static bool isEligibleToVote(string projectId, UInt160 backerAddress) // for backers
    {
        if (backerAddress == null || backerAddress.IsZero) return false;
        return ProjectState.IsBackerEligible(projectId, backerAddress);
    }


    public static void resetProjectWinnerStatus(string projectId)
    {
        ProjectAccount project = getProjectAccount(projectId);
        if (project == null) throw new Exception("Project not found");

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("resetProjectWinnerStatus: Authorization failed");

        AcquireLock();
        try
        {
            project.IsProjectHasWinner = false;
            project.projectSettings.IsWinnerSelectionFinalized = false;
            project.ManufacturerWinnerAddress = UInt160.Zero;
            project.ManufacturerWinnerProductId_Sha256 = string.Empty;
            project.ManufacturerWinnerProductDescription_NeoFS_Address = string.Empty;

            if (project.CurrentProjectStatus == ProjectStatus.Manufacturing || project.CurrentProjectStatus == ProjectStatus.Completed)
            {
                project.CurrentProjectStatus = ProjectStatus.Active;
                project.IsProjectClosed = false;
            }

            UInt160[] manufacturers = ProjectState.GetManufacturerCandidates(projectId);
            if (manufacturers != null)
            {
                for (int i = 0; i < manufacturers.Length; i++)
                {
                    UInt160 manufacturer = manufacturers[i];

                    CandidateWinnerVotesStruct emptyVotes = new CandidateWinnerVotesStruct
                    {
                        ManufacturerCandidate = manufacturer,
                        PositiveVotesCount = 0,
                        NegativeVotesCount = 0,
                        AbstainedVotesCount = 0,
                        TotalVotesCount = 0,
                        IsVotingSuccessful = false
                    };

                    ProjectState.SetCandidateWinnerVotes(projectId, manufacturer, emptyVotes);
                    ProjectState.ClearWinnerVoteFraudFlags(projectId, manufacturer);
                }
            }

            ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, false);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

}



public partial class IF_MainGateway // Milestone Templates
{

    public static MilestoneTemplate getMilestoneTemplate(ProjectAccount project, UInt160 manufacturer,
        byte stepNumber, string templateType = "default")
    {
        // Template selection logic based on project type and manufacturer preferences
        switch (templateType.ToLower())
        {
            case "manufacturing":
                return createManufacturingTemplate(stepNumber);
            case "development":
                return createDevelopmentTemplate(stepNumber);
            case "research":
                return createResearchTemplate(stepNumber);
            case "testing":
                return createTestingTemplate(stepNumber);
            default:
                return createDefaultTemplate(stepNumber, project);
        }
    }

    public static MilestoneTemplate createManufacturingTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Design and Prototyping";
                template.Description = "Initial design phase and prototype development";
                template.Duration = 21 * 24 * 3600; // 21 days
                break;
            case 2:
                template.Name = "Materials Procurement";
                template.Description = "Sourcing and procurement of manufacturing materials";
                template.Duration = 14 * 24 * 3600; // 14 days
                break;
            case 3:
                template.Name = "Production Setup";
                template.Description = "Manufacturing line setup and initial production";
                template.Duration = 30 * 24 * 3600; // 30 days
                break;
            case 4:
                template.Name = "Quality Assurance";
                template.Description = "Quality testing and certification";
                template.Duration = 14 * 24 * 3600; // 14 days
                break;
            case 5:
                template.Name = "Final Delivery";
                template.Description = "Final product delivery and documentation";
                template.Duration = 7 * 24 * 3600; // 7 days
                break;
            default:
                template.Name = $"Manufacturing Step {stepNumber}";
                template.Description = $"Manufacturing milestone step {stepNumber}";
                template.Duration = 21 * 24 * 3600;
                break;
        }

        template.TemplateType = "manufacturing";
        return template;
    }

    public static MilestoneTemplate createDevelopmentTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Requirements Analysis";
                template.Description = "Requirements gathering and analysis phase";
                template.Duration = 14 * 24 * 3600;
                break;
            case 2:
                template.Name = "Technical Design";
                template.Description = "Technical architecture and design documentation";
                template.Duration = 21 * 24 * 3600;
                break;
            case 3:
                template.Name = "Core Development";
                template.Description = "Core functionality development and implementation";
                template.Duration = 45 * 24 * 3600;
                break;
            case 4:
                template.Name = "Integration Testing";
                template.Description = "System integration and comprehensive testing";
                template.Duration = 21 * 24 * 3600;
                break;
            case 5:
                template.Name = "Deployment";
                template.Description = "Production deployment and go-live support";
                template.Duration = 14 * 24 * 3600;
                break;
            default:
                template.Name = $"Development Step {stepNumber}";
                template.Description = $"Development milestone step {stepNumber}";
                template.Duration = 21 * 24 * 3600;
                break;
        }

        template.TemplateType = "development";
        return template;
    }

    public static MilestoneTemplate createResearchTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Literature Review";
                template.Description = "Comprehensive literature review and state-of-art analysis";
                template.Duration = 30 * 24 * 3600;
                break;
            case 2:
                template.Name = "Methodology Development";
                template.Description = "Research methodology design and validation";
                template.Duration = 21 * 24 * 3600;
                break;
            case 3:
                template.Name = "Experimental Phase";
                template.Description = "Experimental work and data collection";
                template.Duration = 60 * 24 * 3600;
                break;
            case 4:
                template.Name = "Analysis and Validation";
                template.Description = "Data analysis and results validation";
                template.Duration = 30 * 24 * 3600;
                break;
            case 5:
                template.Name = "Documentation";
                template.Description = "Final research documentation and reporting";
                template.Duration = 21 * 24 * 3600;
                break;
            default:
                template.Name = $"Research Step {stepNumber}";
                template.Description = $"Research milestone step {stepNumber}";
                template.Duration = 30 * 24 * 3600;
                break;
        }

        template.TemplateType = "research";
        return template;
    }

    public static MilestoneTemplate createTestingTemplate(byte stepNumber)
    {
        var template = new MilestoneTemplate();

        switch (stepNumber)
        {
            case 1:
                template.Name = "Test Planning";
                template.Description = "Test strategy and planning phase";
                template.Duration = 7 * 24 * 3600;
                break;
            case 2:
                template.Name = "Unit Testing";
                template.Description = "Component and unit testing implementation";
                template.Duration = 14 * 24 * 3600;
                break;
            case 3:
                template.Name = "Integration Testing";
                template.Description = "System integration testing and validation";
                template.Duration = 21 * 24 * 3600;
                break;
            case 4:
                template.Name = "Performance Testing";
                template.Description = "Performance and load testing execution";
                template.Duration = 14 * 24 * 3600;
                break;
            case 5:
                template.Name = "Acceptance Testing";
                template.Description = "User acceptance testing and final validation";
                template.Duration = 14 * 24 * 3600;
                break;
            default:
                template.Name = $"Testing Step {stepNumber}";
                template.Description = $"Testing milestone step {stepNumber}";
                template.Duration = 14 * 24 * 3600;
                break;
        }

        template.TemplateType = "testing";
        return template;
    }

    public static MilestoneTemplate createDefaultTemplate(byte stepNumber, ProjectAccount project)
    {
        var template = new MilestoneTemplate();
        template.Name = $"Milestone {stepNumber}";
        template.Description = $"Project milestone step {stepNumber}";
        template.Duration = 21 * 24 * 3600; // 21 days default
        template.TemplateType = "default";
        template.RequestedAmount = project.FLMUSD_PrizeFundBalance /
            (project.MaxMilestoneSteps - stepNumber + 1); // Distribute remaining funds

        return template;
    }

}





public partial class IF_MainGateway // Milestone Automation and Management
{

    public static void createMilestoneRequest(string projectId, UInt160 manufacturer, byte stepNumber, string name,
                      string description, BigInteger requestedAmount, ulong deadline,
                      ulong votingDuration, BigInteger minimumVotes) // minimumVotes - participation threshold in %
    {
        if (!Runtime.CheckWitness(manufacturer))
            throw new Exception("Authorization failed. Only the manufacturer can create a milestone request.");

        ProjectAccount project = getProjectAccount(projectId);

        // Validation
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer))
            throw new Exception("Manufacturer is not a registered candidate in this project.");

        if (project.CurrentProjectStatus != ProjectStatus.Manufacturing)
            throw new Exception("Project is not in the manufacturing state.");

        if (stepNumber == 0)
            throw new Exception("Milestone step number must be greater than 0.");

        // Вычисляем текущий максимальный шаг по данным стейт‑контракта
        byte currentMaxSteps = 0;
        for (byte s = 1; s <= project.projectSettings.MaxMilestoneSteps; s++)
        {
            var ms = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, s);
            if (ms != null) currentMaxSteps = s; else break;
        }

        if (stepNumber > currentMaxSteps + 1)
            throw new Exception("Milestone step number is out of sequence.");
        if (stepNumber > project.projectSettings.MaxMilestoneSteps)
            throw new Exception("Exceeds the maximum allowed milestone steps for the project.");

        // Убедимся, что этап не существует
        var existing = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber);
        if (existing != null)
            throw new Exception("A milestone for this step number already exists for this manufacturer.");

        if (requestedAmount <= 0)
            throw new Exception("Requested funding amount must be positive.");

        if (project.FLMUSD_PrizeFundBalance < requestedAmount)
            throw new Exception("Requested amount exceeds the project's available prize fund balance.");

        AcquireLock();
        try
        {
            string complexKey = IFHelper.createComplexKey(manufacturer, stepNumber);

            var milestone = new MilestoneCompletionVotesStruct
            {
                Name = name,
                Description = description,
                StepNumber = stepNumber,
                RequestedFinancialAmount = requestedAmount,
                FinancialAmount = requestedAmount,
                Deadline_UnixTime = deadline,
                VotingDuration = votingDuration,
                MinimumVotesRequired = minimumVotes,
                ProjectSha256_Id = projectId,
                ManufacturerCandidate = manufacturer,
                Sha256Hash_Id = CryptoLib.Sha256(complexKey),
                isManufacturerCandidateUsedSteppedFinancial = true,
                isVotingStepComplete = false,
                IsVotingSuccessful = false,
                isFundingSent = false,
                VotingStartTime = 0,
                PositiveVotesCount = 0,
                NegativeVotesCount = 0,
                AbstainedVotesCount = 0,
                TotalVotesCount = 0
            };


            // Сохраняем milestone через стейт‑контракт
            ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber, milestone);

            // Старт голосования сразу
            startMilestoneVoting(projectId, manufacturer, stepNumber, votingDuration, minimumVotes);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void startMilestoneVoting(string projectId, UInt160 manufacturer, byte stepNumber, ulong duration, BigInteger minimumVotes)
    {
        var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber);
        if (obj == null)
            throw new Exception("Cannot start voting: milestone structure not found.");

        var milestone = (MilestoneCompletionVotesStruct)obj;

        if (milestone.VotingStartTime > 0)
            throw new Exception("Voting for this milestone has already started.");

        milestone.VotingStartTime = Runtime.Time;
        milestone.VotingDuration = duration;
        milestone.Deadline_UnixTime = Runtime.Time + duration;
        milestone.MinimumVotesRequired = minimumVotes;

        ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber, milestone);

        EventDispatcherAdapter.EmitVotingStarted(projectId, "Milestone:" + manufacturer.ToString() + "_step" + stepNumber.ToString());
    }


}





public partial class IF_MainGateway // bans penalties 
{
    public static void clearPenalty(string projectId, UInt160 manufacturerAddress)
    {
        if (!IsOwner())
            throw new Exception("Only contract owner can clear penalties");

        AcquireLock();
        try
        {
            BigInteger clearedAmount = ProjectState.GetManufacturerPenalty(projectId, manufacturerAddress);
            ProjectState.SetManufacturerPenalty(projectId, manufacturerAddress, 0);
            ProjectState.SetPenaltyTimestamp(projectId, manufacturerAddress, 0);

            BigInteger currentQuality = ProjectState.GetManufacturerQualityScore(projectId, manufacturerAddress);
            BigInteger reputationBonus = clearedAmount / 200;
            ProjectState.SetManufacturerQualityScore(projectId, manufacturerAddress, currentQuality + reputationBonus);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    public static void processAutomaticUnbans(string projectId)
    {
        var project = getProjectAccount(projectId);

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Unauthorized automatic unban processing");

        throw new Exception("Automatic unban iteration is not supported via ProjectState adapter API.");
    }

    public static void unBlockBackerFinance(string projectId, UInt160 backerAddress, BigInteger amountToRestore)
    {
        if (!IsOwner())
            throw new Exception("Only contract owner can unblock finances");

        if (amountToRestore <= 0)
            throw new Exception("Amount to restore must be positive");

        AcquireLock();
        try
        {
            BigInteger locked = ProjectState.GetLockedFunds(projectId);
            if (locked < amountToRestore)
                throw new Exception("Insufficient locked funds for restoration");

            BigInteger donation = ProjectState.GetBackerDonation(projectId, backerAddress);
            ProjectState.SetBackerDonation(projectId, backerAddress, donation + amountToRestore);
            ProjectState.UpdateLockedFunds(projectId, -amountToRestore);

            BigInteger currentScore = ProjectState.GetSuspiciousActivityScore(projectId, backerAddress);
            BigInteger newScore = currentScore > 10 ? currentScore - 10 : 0;
            ProjectState.SetSuspiciousActivityScore(projectId, backerAddress, newScore);

            if (ProjectState.IsParticipantBanned(projectId, backerAddress))
            {
                BigInteger remainingBalance = ProjectState.GetBackerDonation(projectId, backerAddress);
                BigInteger originalBalance = remainingBalance + amountToRestore;
                if (originalBalance > 0 && (remainingBalance * 100 / originalBalance) >= 80)
                {
                    ProjectState.UnbanParticipant(projectId, backerAddress, false);
                }
            }
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }



    public static BanReason getParticipantBanReason(string projectId, UInt160 participantAddress)
    {
        int reason = ProjectState.GetParticipantBanReason(projectId, participantAddress);
        return (BanReason)reason;
    }

    public static BigInteger getManufacturerTotalPenalties(string projectId, UInt160 manufacturerAddress)
    {
        return ProjectState.GetManufacturerPenalty(projectId, manufacturerAddress);
    }

    public static ulong getManufacturerLastPenaltyTime(string projectId, UInt160 manufacturerAddress)
    {
        return ProjectState.GetPenaltyTimestamp(projectId, manufacturerAddress);
    }

    private static void processManufacturerUnbans(string projectId, ulong currentTime, ulong banDuration)
    {
        UInt160[] manufacturers = InnFork.NeoN3.ProjectState.GetManufacturerCandidates(projectId);
        if (manufacturers == null || manufacturers.Length == 0) return;

        for (int i = 0; i < manufacturers.Length; i++)
        {
            UInt160 m = manufacturers[i];
            if (!InnFork.NeoN3.ProjectState.IsParticipantBanned(projectId, m)) continue;

            ulong ts = InnFork.NeoN3.ProjectState.GetPenaltyTimestamp(projectId, m);
            if (ts > 0 && currentTime >= ts + banDuration)
            {
                InnFork.NeoN3.ProjectState.UnbanParticipant(projectId, m, true);
            }
        }
    }

    private static void processBackerUnbans(string projectId, ulong currentTime, ulong banDuration)
    {
        UInt160[] backers = InnFork.NeoN3.ProjectState.GetBackersWithDonations(projectId);
        if (backers == null || backers.Length == 0) return;

        for (int i = 0; i < backers.Length; i++)
        {
            UInt160 b = backers[i];
            if (!InnFork.NeoN3.ProjectState.IsParticipantBanned(projectId, b)) continue;

            ulong last = InnFork.NeoN3.ProjectState.GetLastVoteTimestamp(projectId, b);
            if (last > 0 && currentTime >= last + banDuration)
            {
                InnFork.NeoN3.ProjectState.UnbanParticipant(projectId, b, false);
            }
        }
    }

    public static void applyRejectionPenalty(string projectId, UInt160 initiator, DisputeType disputeType)
    {
        if (initiator == null || initiator.IsZero)
            throw new Exception("Invalid initiator address");

        BigInteger penaltyAmount = disputeType switch
        {
            DisputeType.MilestoneCompletion => 100,
            DisputeType.QualityDispute => 150,
            DisputeType.PaymentDispute => 200,
            DisputeType.FraudAccusation => 500,
            DisputeType.ContractBreach => 300,
            _ => 75
        };

        BackerAccount backerAccount = BackerAccount.getBackerAccount(initiator, false);
        ManufacturerAccount manufacturerAccount = null;

        if (backerAccount == null)
        {
            try
            {
                manufacturerAccount = ManufacturerAccount.getManufacturerAccount(initiator);
            }
            catch
            {
                throw new Exception("Initiator account not found");
            }
        }

        AcquireLock();
        try
        {
            if (backerAccount != null)
            {
                if (backerAccount.FreeBalance >= penaltyAmount)
                {
                    backerAccount.FreeBalance -= penaltyAmount;
                    backerAccount.TotalBalance -= penaltyAmount;
                }
                else
                {
                    banBacker(projectId, initiator, BanReason.RepeatedFraudulentDisputes);
                }
                BackerAccount.updateExistingBackerAccount(backerAccount);
            }
            else if (manufacturerAccount != null)
            {
                if (manufacturerAccount.FreeBalance >= penaltyAmount)
                {
                    manufacturerAccount.FreeBalance -= penaltyAmount;
                    manufacturerAccount.TotalBalance -= penaltyAmount;

                    BigInteger reputationPenalty = penaltyAmount / 5;
                    manufacturerAccount.ReputationScore -= reputationPenalty;
                    if (manufacturerAccount.ReputationScore < 0)
                        manufacturerAccount.ReputationScore = 0;
                }
                else
                {
                    banManufacturer(projectId, initiator, BanReason.RepeatedFraudulentDisputes);
                }
                ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);
            }

            BigInteger currentScore = ProjectState.GetSuspiciousActivityScore(projectId, initiator);
            ProjectState.SetSuspiciousActivityScore(projectId, initiator, currentScore + penaltyAmount);

            if (ProjectState.GetSuspiciousActivityScore(projectId, initiator) > 1000)
            {
                if (backerAccount != null)
                {
                    banBacker(projectId, initiator, BanReason.RepeatedFraudulentDisputes);
                }
                else if (manufacturerAccount != null)
                {
                    banManufacturer(projectId, initiator, BanReason.RepeatedFraudulentDisputes);
                }
            }

            BigInteger total = ProjectState.GetProjectTotalBalance(projectId);
            ProjectState.SetProjectTotalBalance(projectId, total + penaltyAmount);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    public static void handleGeneralEscalation(string projectId, string disputeId)
    {
        var total = ProjectState.GetProjectTotalBalance(projectId);
        BigInteger cautionaryFreeze = total / 20;
        if (cautionaryFreeze > 0 && cautionaryFreeze <= total)
        {
            lockFunds(projectId, cautionaryFreeze);
        }
    }


}








public partial class IF_MainGateway // bans penalties 
{
    public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
    {
        var project = getProjectAccount(projectId);

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only contract owner or project author can ban backers");

        if (!ProjectState.IsBackerEligible(projectId, backerAddress))
            throw new Exception("Backer is not part of this project");

        if (ProjectState.IsParticipantBanned(projectId, backerAddress))
            throw new Exception("Backer is already banned");

        AcquireLock();
        try
        {
            ProjectState.BanParticipant(projectId, backerAddress, false, (int)reason);
            applyBackerBanSanctions(projectId, backerAddress, reason);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
    {
        var project = getProjectAccount(projectId);


        if (!ProjectState.IsParticipantBanned(projectId, backerAddress))
            throw new Exception("Participant is not banned");

        BigInteger currentBalance = ProjectState.GetBackerDonation(projectId, backerAddress);
        if (amountToBlock > currentBalance)
            amountToBlock = currentBalance;

        if (amountToBlock <= 0)
            return;

        AcquireLock();
        try
        {
            ProjectState.UpdateLockedFunds(projectId, amountToBlock);
            ProjectState.SetBackerDonation(projectId, backerAddress, currentBalance - amountToBlock);

            BigInteger refundHistory = ProjectState.GetRefundHistory(projectId, backerAddress);
            ProjectState.SetRefundHistory(projectId, backerAddress, refundHistory + amountToBlock);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
    {
        BigInteger backerBalance = ProjectState.GetBackerDonation(projectId, backerAddress);

        switch (reason)
        {
            case BanReason.FraudulentActivity:
                blockBackerFinance(projectId, backerAddress, reason, backerBalance);
                break;

            case BanReason.SystemAbuse:
                blockBackerFinance(projectId, backerAddress, reason, backerBalance / 2);
                break;

            case BanReason.InappropriateBehavior:
                blockBackerFinance(projectId, backerAddress, reason, backerBalance / 4);
                break;

            case BanReason.ViolationOfTerms:
                blockBackerFinance(projectId, backerAddress, reason, backerBalance / 5);
                break;

            default:
                blockBackerFinance(projectId, backerAddress, reason, backerBalance / 10);
                break;
        }

        BigInteger currentScore = ProjectState.GetSuspiciousActivityScore(projectId, backerAddress);
        ProjectState.SetSuspiciousActivityScore(projectId, backerAddress, currentScore + getRiskScoreForBanReason(reason));
    }


    /// <summary>
    /// Получает оценку риска для причины бана
    /// </summary>
    public static BigInteger getRiskScoreForBanReason(BanReason reason)
    {
        switch (reason)
        {
            case BanReason.FraudulentActivity:
                return 100; // Максимальный риск
            case BanReason.SystemAbuse:
                return 50;
            case BanReason.SecurityBreach:
                return 40;
            case BanReason.InappropriateBehavior:
                return 25;
            case BanReason.ViolationOfTerms:
                return 20;
            default:
                return 10; // Базовый риск
        }
    }

    public static void banManufacturer(string projectId, UInt160 manufacturerAddress, BanReason reason)
    {
        var project = getProjectAccount(projectId);

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only contract owner or project author can ban manufacturers");

        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
            throw new Exception("Manufacturer is not part of this project");

        if (ProjectState.IsParticipantBanned(projectId, manufacturerAddress))
            throw new Exception("Manufacturer is already banned");

        AcquireLock();
        try
        {
            ProjectState.BanParticipant(projectId, manufacturerAddress, true, (int)reason);

            applyManufacturerBanSanctions(projectId, manufacturerAddress, reason);

            if (project.ManufacturerWinnerAddress == manufacturerAddress)
            {
                resetProjectWinnerStatus(projectId);
            }

            returnAllReservedInvestmentsFromCandidate(projectId, manufacturerAddress);

            removeManufacturerCandidate(projectId, manufacturerAddress);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void applyManufacturerBanSanctions(string projectId, UInt160 manufacturerAddress, BanReason reason)
    {
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
            return;

        ManufacturerAccount manufacturer = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);

        switch (reason)
        {
            case BanReason.FraudulentActivity:
                if (manufacturer.FreeBalance > 0)
                {
                    imposePenalty(projectId, manufacturerAddress, manufacturer.FreeBalance);
                }
                ProjectState.SetManufacturerQualityScore(projectId, manufacturerAddress, 0);
                ProjectState.SetManufacturerReliabilityTier(projectId, manufacturerAddress, (byte)1);
                break;

            case BanReason.MilestoneFailure:
                {
                    BigInteger milestoneFailurePenalty = manufacturer.FreeBalance * 30 / 100;
                    if (milestoneFailurePenalty > 0)
                    {
                        imposePenalty(projectId, manufacturerAddress, milestoneFailurePenalty);
                    }
                    BigInteger qs = ProjectState.GetManufacturerQualityScore(projectId, manufacturerAddress);
                    if (qs > 0)
                    {
                        ProjectState.SetManufacturerQualityScore(projectId, manufacturerAddress, qs / 2);
                    }
                    break;
                }

            case BanReason.QualityIssues:
                {
                    BigInteger qualityPenalty = manufacturer.FreeBalance * 20 / 100;
                    if (qualityPenalty > 0)
                    {
                        imposePenalty(projectId, manufacturerAddress, qualityPenalty);
                    }
                    break;
                }

            case BanReason.PaymentIssues:
                {
                    BigInteger paymentPenalty = manufacturer.FreeBalance * 15 / 100;
                    if (paymentPenalty > 0)
                    {
                        imposePenalty(projectId, manufacturerAddress, paymentPenalty);
                    }
                    break;
                }

            case BanReason.ViolationOfTerms:
                {
                    BigInteger termsPenalty = manufacturer.FreeBalance * 10 / 100;
                    if (termsPenalty > 0)
                    {
                        imposePenalty(projectId, manufacturerAddress, termsPenalty);
                    }
                    break;
                }

            default:
                {
                    BigInteger basePenalty = manufacturer.FreeBalance * 5 / 100;
                    if (basePenalty > 0)
                    {
                        imposePenalty(projectId, manufacturerAddress, basePenalty);
                    }
                    break;
                }
        }
    }

    /*    public static void resetProjectWinnerStatus(string projectId)
        {
            var project = getProjectAccount(projectId);

            project.IsProjectHasWinner = false;
            project.ManufacturerWinnerAddress = UInt160.Zero;
            project.ManufacturerWinnerProductId_Sha256 = string.Empty;
            project.ManufacturerWinnerProductDescription_NeoFS_Address = string.Empty;

            if (project.CurrentProjectStatus == ProjectStatus.Manufacturing || project.CurrentProjectStatus == ProjectStatus.Completed)
            {
                project.CurrentProjectStatus = ProjectStatus.Active;
            }
        }
    */
    public static void imposePenalty(string projectId, UInt160 manufacturerAddress, BigInteger penaltyAmount)
    {
        var project = getProjectAccount(projectId);

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Unauthorized penalty imposition");

        if (penaltyAmount <= 0)
            throw new Exception("Penalty amount must be positive");

        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
            throw new Exception("Manufacturer not found in project");

        ManufacturerAccount manufacturer = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);

        if (manufacturer.FreeBalance < penaltyAmount)
            throw new Exception("Insufficient manufacturer balance for penalty");

        AcquireLock();
        try
        {
            manufacturer.FreeBalance -= penaltyAmount;
            manufacturer.TotalBalance -= penaltyAmount;
            ManufacturerAccount.updateExistingManufacturerAccount(manufacturer);

            BigInteger current = ProjectState.GetManufacturerPenalty(projectId, manufacturerAddress);
            ProjectState.SetManufacturerPenalty(projectId, manufacturerAddress, current + penaltyAmount);
            ProjectState.SetPenaltyTimestamp(projectId, manufacturerAddress, Runtime.Time);

            BigInteger total = ProjectState.GetProjectTotalBalance(projectId);
            ProjectState.SetProjectTotalBalance(projectId, total + penaltyAmount);

            updateManufacturerReputationAfterPenalty(projectId, manufacturerAddress, penaltyAmount);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void updateManufacturerReputationAfterPenalty(string projectId, UInt160 manufacturerAddress, BigInteger penaltyAmount)
    {
        if (manufacturerAddress == null || manufacturerAddress.IsZero)
            throw new Exception("Invalid manufacturer address");

        if (penaltyAmount <= 0)
            throw new Exception("Penalty amount must be positive");

        ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);

        AcquireLock();
        try
        {
            BigInteger reputationPenalty;
            if (penaltyAmount < 1000)
                reputationPenalty = penaltyAmount / 20;
            else if (penaltyAmount < 10000)
                reputationPenalty = penaltyAmount / 10;
            else
                reputationPenalty = (penaltyAmount * 15) / 100;

            manufacturerAccount.ReputationScore -= reputationPenalty;
            if (manufacturerAccount.ReputationScore < 0)
                manufacturerAccount.ReputationScore = 0;

            BigInteger currentPenalties = ProjectState.GetManufacturerPenalty(projectId, manufacturerAddress);
            ProjectState.SetManufacturerPenalty(projectId, manufacturerAddress, currentPenalties + penaltyAmount);
            ProjectState.SetPenaltyTimestamp(projectId, manufacturerAddress, Runtime.Time);

            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

}



public partial class IF_MainGateway // Project State Checks and Fund Management
{
    public static bool isProjectOpen(string projectId)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (project.IsProjectHasWinner) return false;
        if (project.IsProjectClosed) return false;
        if (project.IsProjectPaused) return false;
        if (project.CurrentProjectStatus == ProjectStatus.Terminated) return false;
        if (project.CurrentProjectStatus == ProjectStatus.Completed) return false;

        return true;
    }
    public static void lockFunds(string projectId, BigInteger amount)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (!Runtime.CheckWitness(project.ProjectCreatorAddress) && !IsOwner() && !project.DirectInnForkProjectManagement)
            throw new Exception("Only project author or InnFork Gateway (if direct management) can lock funds");

        BigInteger MaxFundsLimit = project.FLMUSD_TotalProjectBalance;

        if (project.FLMUSD_TotalProjectBalance < amount)
            throw new Exception("Insufficient project balance");

        if (project.totalFundsLocked + amount > MaxFundsLimit)
            throw new Exception("Exceeds maximum funds limit");

        AcquireLock();
        try
        {
            project.totalFundsLocked += amount;

            if (project.FLMUSD_PrizeFundBalance >= amount)
            {
                project.FLMUSD_PrizeFundBalance -= amount;
            }
            else
            {
                project.FLMUSD_PrizeFundBalance = 0;
            }

            project.LastActivityTime = Runtime.Time;

            if (project.projectSettings.AutoPauseEnabled && project.FLMUSD_TotalProjectBalance > 0 &&
                (project.totalFundsLocked * 100 / project.FLMUSD_TotalProjectBalance) > project.projectSettings.AutoPauseLockThresholdPercent)
            {
                project.IsProjectPaused = true;
            }

            ProjectState.UpdateLockedFunds(projectId, amount);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }
    public static void unlockFunds(string projectId, BigInteger amount)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only project author can unlock funds");
        if (project.totalFundsLocked < amount)
            throw new Exception("Insufficient locked funds to unlock");

        AcquireLock();
        try
        {
            project.totalFundsLocked -= amount;

            ProjectState.UpdateLockedFunds(projectId, -amount);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    public static void returnAllReservedInvestmentsFromCandidate(string projectId, UInt160 manufacturerAddress)
    {
        if (manufacturerAddress == null || manufacturerAddress.IsZero) throw new Exception("Invalid manufacturer address");
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress)) return;

        ProjectAccount project = getProjectAccount(projectId);
        if (project == null) throw new Exception("Project not found");

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress) && !Runtime.CheckWitness(manufacturerAddress))
            throw new Exception("returnAllReservedInvestmentsFromCandidate: Authorization failed");

        BigInteger totalReturnedAmount = 0;

        AcquireLock();
        try
        {
            // Пробегаем по всем бэкерам и возвращаем зарезервированное у данного производителя
            UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
            for (int bi = 0; bi < backers.Length; bi++)
            {
                UInt160 backer = backers[bi];

                BigInteger reservedAmount = ProjectState.GetBackerReservation(projectId, backer, manufacturerAddress);
                if (reservedAmount <= 0) continue;

                BigInteger currentDonation = ProjectState.GetBackerDonation(projectId, backer);
                ProjectState.SetBackerDonation(projectId, backer, currentDonation + reservedAmount);

                project.FLMUSD_PrizeFundBalance += reservedAmount;

                ProjectState.SetBackerReservation(projectId, backer, manufacturerAddress, 0);

                totalReturnedAmount += reservedAmount;
            }

            // Корректируем "зарезервированные" средства производителя в проекте (если использовались для профита)
            BigInteger manufacturerReserved = ProjectState.GetReservedFunds(projectId, manufacturerAddress);
            BigInteger updatedReserved = manufacturerReserved - totalReturnedAmount;
            if (updatedReserved < 0) updatedReserved = 0;
            ProjectState.SetReservedFunds(projectId, manufacturerAddress, updatedReserved);

            // Снижаем агрегированные балансы производителя на возвращенную сумму
            try
            {
                ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
                if (manufacturerAccount != null)
                {
                    manufacturerAccount.TotalBalance -= totalReturnedAmount;
                    manufacturerAccount.FreeBalance -= totalReturnedAmount;
                    manufacturerAccount.InvestmentAmount -= totalReturnedAmount;

                    if (manufacturerAccount.TotalBalance < 0) manufacturerAccount.TotalBalance = 0;
                    if (manufacturerAccount.FreeBalance < 0) manufacturerAccount.FreeBalance = 0;
                    if (manufacturerAccount.InvestmentAmount < 0) manufacturerAccount.InvestmentAmount = 0;

                    ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);
                }
            }
            catch { }

            // Удаляем все milestones производителя в этом проекте
            for (byte step = 0; step < byte.MaxValue; step++)
            {
                var milestoneObj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, step);
                if (milestoneObj != null)
                {
                    ProjectState.DeleteMilestone(projectId, manufacturerAddress, step);
                }
            }

            // Аналитика возвратов
            BigInteger prevRefunds = ProjectState.GetRefundHistory(projectId, manufacturerAddress);
            ProjectState.SetRefundHistory(projectId, manufacturerAddress, prevRefunds + totalReturnedAmount);

            BigInteger totalRefundsPrev = ProjectState.GetTotalRefundsProcessed(projectId);
            ProjectState.SetTotalRefundsProcessed(projectId, totalRefundsPrev + totalReturnedAmount);

            // Безопасные клампы и синхронизация total balance проекта в StateStorage
            if (project.FLMUSD_TotalProjectBalance < 0) project.FLMUSD_TotalProjectBalance = 0;
            if (project.FLMUSD_PrizeFundBalance < 0) project.FLMUSD_PrizeFundBalance = 0;

            ProjectState.SetProjectTotalBalance(projectId, project.FLMUSD_TotalProjectBalance);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void removeManufacturerCandidate(string projectId, UInt160 ManufacturerAddress)
    {
        var project = getProjectAccount(projectId);

        if (!Runtime.CheckWitness(ManufacturerAddress) && !Runtime.CheckWitness(project.ProjectCreatorAddress) && !IsOwner())
            throw new Exception("Authorization failed. Only manufacturer, project author or contract owner can remove.");

        if (!ProjectState.IsManufacturerRegistered(projectId, ManufacturerAddress))
            throw new Exception("Manufacturer candidate is not registered in this project.");

        AcquireLock();
        try
        {
            // Вернуть все резервы инвестиций (ваш метод)
            returnAllReservedInvestmentsFromCandidate(projectId, ManufacturerAddress);

            // Сбрасываем резерв и удаляем кандидата из state
            ProjectState.SetReservedFunds(projectId, ManufacturerAddress, 0);
            ProjectState.UnregisterManufacturer(projectId, ManufacturerAddress);

            // Удаляем все milestone'ы кандидата (перебором шагов)
            byte maxSteps = project.projectSettings.MaxMilestoneSteps;
            for (byte step = 1; step <= maxSteps; step++)
            {
                var ms = ProjectState.GetMilestoneCompletionVotesStruct(projectId, ManufacturerAddress, step);
                if (ms != null)
                {
                    ProjectState.DeleteMilestone(projectId, ManufacturerAddress, step);
                }
            }

            // Обнулим агрегаты голосов кандидата (если хранились)
            CandidateWinnerVotesStruct emptyVotes = new CandidateWinnerVotesStruct
            {
                ManufacturerCandidate = ManufacturerAddress,
                //     BackerVotes_Map = new Map<UInt160, BackerVotesEnum>(),
                PositiveVotesCount = 0,
                NegativeVotesCount = 0,
                AbstainedVotesCount = 0,
                TotalVotesCount = 0,
                IsVotingSuccessful = false
            };
            ProjectState.SetCandidateWinnerVotes(projectId, ManufacturerAddress, emptyVotes);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }
    public static string[] getSerializedGlobalProjectsAccountsList()
    {
        if (IsOwner() == false) throw new Exception("Caller is not the owner");
        var bytes = ProjectState.GetGlobalProjectsList();
        if (bytes is null) return new string[0];
        return (string[])StdLib.Deserialize(bytes);
    }
    public static void removeManufacturerCandidateFromAllProjects(UInt160 manufacturerAddress)
    {
        if (!Runtime.CheckWitness(manufacturerAddress) && !IsOwner()) throw new Exception("Authorization failed");

        string[] all = getSerializedGlobalProjectsAccountsList();
        if (all == null || all.Length == 0) return;

        var res = new Neo.SmartContract.Framework.List<string>();
        for (int i = 0; i < all.Length; i++)
        {
            string projectAccountJson = all[i];
            if (string.IsNullOrEmpty(projectAccountJson)) continue;

            ProjectAccount projectAccount = (ProjectAccount)StdLib.Deserialize(projectAccountJson);
            if (projectAccount == null) continue;

            if (ProjectState.IsManufacturerRegistered(projectAccount.projectId, manufacturerAddress))
            {
                removeManufacturerCandidate(projectAccount.projectId, manufacturerAddress);
                continue;
            }
            res.Add(projectAccountJson);
        }
        ProjectState.SetGlobalProjectsList(StdLib.Serialize(res));
    }
}






public partial class IF_MainGateway // Milestone Auto Progression
{
    public static bool canWithdrawReservedForManufacturerFunds(string projectId, UInt160 backer, UInt160 manufacturer)
    {
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer)) return true;

        BigInteger reserved = ProjectState.GetBackerReservation(projectId, backer, manufacturer);
        if (reserved <= 0) return false;

        byte currentStep = getLatestMilestoneStepByManufacturer(projectId, manufacturer);
        if (currentStep > 0)
        {
            return checkMilestoneExpired(projectId, manufacturer, currentStep);
        }
        return false;
    }

    public static byte getLatestMilestoneStepByManufacturer(string projectId, UInt160 manufacturer)
    {
        var project = getProjectAccount(projectId);
        byte latest = 0;
        for (byte s = 1; s <= project.projectSettings.MaxMilestoneSteps; s++)
        {
            var ms = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, s);
            if (ms != null) latest = s; else break;
        }
        return latest;
    }

    public static void autoProgressMilestones(string projectId)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (project == null || !isProjectOpen(projectId))
        {
            return;
        }

        if (project.projectSettings == null || !project.projectSettings.AllowSteppedFinancing)
        {
            return;
        }

        bool changesMade = false;

        AcquireLock();
        try
        {
            UInt160[] manufacturers = ProjectState.GetManufacturerCandidates(projectId);
            if (manufacturers != null && manufacturers.Length > 0)
            {
                foreach (UInt160 manufacturerAddress in manufacturers)
                {
                    byte latestStep = getLatestMilestoneStepByManufacturer(projectId, manufacturerAddress);
                    byte maxSteps = project.projectSettings.MaxMilestoneSteps;

                    if (latestStep > 0 && latestStep < maxSteps)
                    {
                        MilestoneCompletionVotesStruct latestMilestone = (MilestoneCompletionVotesStruct)ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, latestStep);
                        if (latestMilestone != null)
                        {
                            if (latestMilestone.isVotingStepComplete && latestMilestone.isFundingSent && !latestMilestone.IsDisputed)
                            {
                                byte nextStepNumber = (byte)(latestStep + 1);

                                var nextMilestone = (MilestoneCompletionVotesStruct)ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, nextStepNumber);
                                if (nextMilestone == null)
                                {
                                    if (shouldAutoStartNextMilestone(projectId, manufacturerAddress, nextStepNumber))
                                    {
                                        autoStartNextMilestone(projectId, manufacturerAddress, nextStepNumber);
                                        changesMade = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        finally
        {
            ReleaseAcquireLock();
        }

        if (changesMade)
        {
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
    }

    public static bool shouldAutoStartNextMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        var project = getProjectAccount(projectId);

        if (project.IsProjectPaused || project.CurrentProjectStatus != ProjectStatus.Manufacturing)
        {
            return false;
        }

        if (project.FLMUSD_PrizeFundBalance <= 0)
        {
            return false;
        }

        return true;
    }

    public static void autoStartNextMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        ProjectAccount project = getProjectAccount(projectId);

        string templateType = ProjectState.GetManufacturerPreferredTemplate(projectId, manufacturer);
        if (templateType == null || templateType == "")
        {
            templateType = "default";
        }

        MilestoneTemplate template = getMilestoneTemplate(project, manufacturer, stepNumber, templateType);

        if (template != null)
        {
            ulong workDeadline = Runtime.Time + template.Duration;
            ulong votingDuration = project.projectSettings.DefaultVotingDuration;
            BigInteger minVotes = project.projectSettings.MinRequiredVotingParticipation;

            createMilestoneRequest(projectId,
                manufacturer,
                stepNumber,
                template.Name,
                template.Description,
                template.RequestedAmount,
                workDeadline,
                votingDuration,
                minVotes
            );
        }
    }

}





public partial class IF_MainGateway // Milestone Rollback and Refunds
{

    /////////////////////////////////////////////////////////////////ROLLBACK SYSTEM/////////////////////////////////////////////////////////////////

    // Хранилище для откатов финансирования этапов CoOwnerAddressToInvestedAmountStore_StorageMap - заменяется данными в ProjectAccount
    //  public static readonly StorageMap CoOwnerAddressToInvestedAmountStore_StorageMap = new StorageMap(StorageState.CurrentContext, Prefix_CoOwnerAddressToInvestedAmountStore); // co owner address to invested amount

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void rollbackMilestoneFunding(string projectId, UInt160 manufacturerAddress, byte stepNumber, string rollbackReason)
    {
        ProjectAccount project = getProjectAccount(projectId);

        bool isAuthorized = IsOwner() || Runtime.CheckWitness(project.ProjectCreatorAddress);
        if (!isAuthorized)
        {
            throw new Exception("Authorization failed. Only contract owner or project author can initiate rollback.");
        }

        if (manufacturerAddress == null || manufacturerAddress.IsZero)
        {
            throw new Exception("Invalid manufacturer address.");
        }
        if (stepNumber == 0)
        {
            throw new Exception("Milestone step number must be positive.");
        }

        MilestoneCompletionVotesStruct milestone = (MilestoneCompletionVotesStruct)ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, stepNumber);
        if (milestone == null)
        {
            throw new Exception("Milestone not found for the specified manufacturer and step number.");
        }

        if (!milestone.isFundingSent)
        {
            throw new Exception("Funding has not been sent for this milestone, nothing to roll back.");
        }

        BigInteger amountToRollback = milestone.FinancialAmount;
        if (amountToRollback <= 0)
        {
            throw new Exception("Milestone funding amount is zero or negative, nothing to roll back.");
        }

        ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
        if (manufacturerAccount == null)
        {
            throw new Exception("Manufacturer's global account not found.");
        }

        if (manufacturerAccount.FreeBalance < amountToRollback)
        {
            throw new Exception("Manufacturer has insufficient free balance to perform the rollback.");
        }

        AcquireLock();
        try
        {
            manufacturerAccount.FreeBalance -= amountToRollback;
            manufacturerAccount.TotalBalance -= amountToRollback;
            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);

            project.FLMUSD_PrizeFundBalance += amountToRollback;
            project.FLMUSD_TotalProjectBalance += amountToRollback;

            BigInteger stateTotal = ProjectState.GetProjectTotalBalance(projectId);
            ProjectState.SetProjectTotalBalance(projectId, stateTotal + amountToRollback);

            handleInvestorRollback(projectId, manufacturerAddress, amountToRollback);

            milestone.isFundingSent = false;
            milestone.isVotingStepComplete = false;
            milestone.IsVotingSuccessful = false;
            milestone.IsDisputed = false;
            milestone.PositiveVotesCount = 0;
            milestone.NegativeVotesCount = 0;
            milestone.AbstainedVotesCount = 0;
            milestone.TotalVotesCount = 0;

            ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, stepNumber, milestone);

            ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            saveProjectAccountToProjectsAccountStore(projectId, project);

            EventDispatcherAdapter.EmitMilestoneFundingRolledBack(projectId, manufacturerAddress, stepNumber, rollbackReason, amountToRollback);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void handleInvestorRollback(string projectId, UInt160 manufacturerAddress, BigInteger rolledBackAmount)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (project == null)
            throw new Exception("Project cannot be null");
        if (manufacturerAddress == null || manufacturerAddress.IsZero)
            throw new Exception("Invalid manufacturer address");
        if (rolledBackAmount <= 0)
            throw new Exception("Rollback amount must be positive");

        // Считаем общую сумму инвестиций (зарезервированных средств) через StateStorage
        BigInteger totalInvestorInvestments = 0;

        // Соберем срез по бэкерам с их текущими резервациями для производителя
        UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);

        // Чтобы не дергать хранилище еще раз в цикле распределения,
        // сохраним пары (backer, reserved) во временные списки
        var backersList = new Neo.SmartContract.Framework.List<UInt160>();
        var reservedList = new Neo.SmartContract.Framework.List<BigInteger>();

        for (int i = 0; i < backers.Length; i++)
        {
            UInt160 backer = backers[i];
            BigInteger reserved = ProjectState.GetBackerReservation(projectId, backer, manufacturerAddress);
            if (reserved > 0)
            {
                backersList.Add(backer);
                reservedList.Add(reserved);
                totalInvestorInvestments += reserved;
            }
        }

        if (totalInvestorInvestments == 0)
            return;

        BigInteger actualRollbackAmount = rolledBackAmount;
        if (actualRollbackAmount > totalInvestorInvestments)
            actualRollbackAmount = totalInvestorInvestments;

        AcquireLock();
        try
        {
            BigInteger totalReturned = 0;

            // Пропорционально возвращаем каждому бэкеру
            for (int i = 0; i < backersList.Count; i++)
            {
                UInt160 investorAddress = backersList[i];
                BigInteger investorInvestment = reservedList[i];

                BigInteger proportionalReturn = (investorInvestment * actualRollbackAmount) / totalInvestorInvestments;

                if (proportionalReturn > 0)
                {
                    // Возврат инвестору (в т.ч. обновление его глобального аккаунта)
                    returnInvestmentToInvestor(projectId, investorAddress, manufacturerAddress, proportionalReturn);
                    totalReturned += proportionalReturn;

                    // Обновляем остаток резерва в StateStorage
                    BigInteger newReserved = investorInvestment - proportionalReturn;
                    if (newReserved < 0) newReserved = 0;
                    ProjectState.SetBackerReservation(projectId, investorAddress, manufacturerAddress, newReserved);
                }
            }

            // Снижаем агрегированные балансы производителя на реально возвращенную сумму
            ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
            manufacturerAccount.TotalBalance -= totalReturned;
            manufacturerAccount.FreeBalance -= totalReturned;
            manufacturerAccount.InvestmentAmount -= totalReturned;

            if (manufacturerAccount.TotalBalance < 0) manufacturerAccount.TotalBalance = 0;
            if (manufacturerAccount.FreeBalance < 0) manufacturerAccount.FreeBalance = 0;
            if (manufacturerAccount.InvestmentAmount < 0) manufacturerAccount.InvestmentAmount = 0;

            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);

            // Обновляем аналитику возвратов
            project.TotalRefundsProcessed += totalReturned;

            BigInteger prevRefunds = ProjectState.GetTotalRefundsProcessed(projectId);
            ProjectState.SetTotalRefundsProcessed(projectId, prevRefunds + totalReturned);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void returnInvestmentToInvestor(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
    {
        try
        {
            /*         InvestorAccount investor = InvestorAccount.getInvestorAccount(investorAddress);
                     if (investor != null)
                     {
                         investor.FreeBalance += amount;
                         investor.TotalBalance += amount;
                         InvestorAccount.updateExistingInvestorAccount(investorAddress, investor);
                     }*/
        }
        catch
        {
        }
    }

    public static void autoRollbackOnDisputeResolution(string projectId, string disputeId, UInt160 manufacturerAddress, byte stepNumber)
    {
        bool resolved = ProjectState.GetConditionalVotingRule(projectId, "dispute_resolved_" + disputeId);
        if (resolved)
        {
            string rollbackReason = $"Automatic rollback due to dispute resolution. Dispute ID: {disputeId}";

            try
            {
                rollbackMilestoneFunding(projectId, manufacturerAddress, stepNumber, rollbackReason);
            }
            catch (Exception ex)
            {
                throw new Exception($"Auto-rollback failed for milestone {stepNumber}: {ex.Message}");
            }
        }
    }

    public static void checkAndRollbackExpiredMilestones(string projectId)
    {
        ulong currentTime = Runtime.Time;

        UInt160[] manufacturers = ProjectState.GetManufacturerCandidates(projectId);
        for (int m = 0; m < manufacturers.Length; m++)
        {
            UInt160 manufacturer = manufacturers[m];
            for (byte step = 0; step < byte.MaxValue; step++)
            {
                MilestoneCompletionVotesStruct milestone = (MilestoneCompletionVotesStruct)ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, step);
                if (milestone == null) continue;

                if (milestone.isFundingSent &&
                    milestone.Deadline_UnixTime > 0 &&
                    currentTime > milestone.Deadline_UnixTime &&
                    !milestone.IsVotingSuccessful)
                {
                    string rollbackReason = $"Milestone deadline expired. Deadline: {milestone.Deadline_UnixTime}, Current time: {currentTime}";

                    try
                    {
                        rollbackMilestoneFunding(projectId, manufacturer, step, rollbackReason);
                    }
                    catch
                    {
                        continue;
                    }
                }
            }
        }
    }

}






public partial class IF_MainGateway // Milestone Voting and Funding
{

    public static void processMilestoneFunding(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        if (!Runtime.CheckWitness(manufacturer) && !IsOwner())
            throw new Exception("Authorization failed. Only manufacturer or contract owner can trigger funding.");

        ProjectAccount project = getProjectAccount(projectId);

        var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber);
        if (obj == null)
            throw new Exception("Milestone step not found for funding.");

        var milestone = (MilestoneCompletionVotesStruct)obj;

        if (!milestone.isVotingStepComplete || !milestone.IsVotingSuccessful)
            throw new Exception("Milestone voting was not successfully completed.");

        if (milestone.isFundingSent)
            throw new Exception("Funding for this milestone has already been sent.");

        BigInteger amountToFund = milestone.FinancialAmount;
        if (amountToFund <= 0)
            throw new Exception("Milestone financial amount is not positive.");

        // Проверяем зарезервированные средства через стейт‑контракт
        BigInteger reserved = ProjectState.GetReservedFunds(projectId, manufacturer);
        if (reserved < amountToFund)
            throw new Exception("Insufficient funds reserved for this manufacturer to fund the milestone.");

        if (milestone.IsDisputed)
            throw new Exception("Cannot process funding, milestone has an active dispute.");

        ManufacturerAccount manufacturerGlobalAccount = ManufacturerAccount.getManufacturerAccount(manufacturer);

        AcquireLock();
        try
        {
            // Снижаем резерв для производителя
            ProjectState.SetReservedFunds(projectId, manufacturer, reserved - amountToFund);

            // Переводим средства производителю (глобальный аккаунт)
            manufacturerGlobalAccount.FreeBalance += amountToFund;
            manufacturerGlobalAccount.TotalBalance += amountToFund;
            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerGlobalAccount);

            // Обновляем milestone
            milestone.isFundingSent = true;
            ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber, milestone);

            saveProjectAccountToProjectsAccountStore(projectId, project);

            if (project.projectSettings.AutoFinishExpiredVotings)
            {
                autoProgressMilestones(projectId);
            }
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void requireMilestoneVerification(string projectId, string milestoneId, bool required)
    {
        var project = getProjectAccount(projectId);
        if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only project author can set milestone verification requirements");

        throw new Exception("Milestone verification flags are not available via ProjectState adapter. Use state contract-backed API.");
    }

    public static void verifyMilestone(string projectId, string milestoneId, bool verified)
    {
        var project = getProjectAccount(projectId);
        if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only project author can verify milestones");

        throw new Exception("Milestone verification flags are not available via ProjectState adapter. Use state contract-backed API.");
    }

    public static void requestMilestoneCompletion(UInt160 manufacturerAddress, string projectId, byte stepNumber,
        string completionProof, byte[] verificationData)
    {
        if (!Runtime.CheckWitness(manufacturerAddress))
            throw new Exception("Only manufacturer can request milestone completion");

        var project = getProjectAccount(projectId);
        if (project == null) throw new Exception("Project not found");

        var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, stepNumber);
        if (obj == null)
            throw new Exception("Milestone not found or not started");

        startMilestoneVoting(projectId, manufacturerAddress, stepNumber, project.DefaultVotingDuration, project.MinRequiredVotingParticipation);
        saveProjectAccountToProjectsAccountStore(projectId, project);
    }

    public static void processMilestoneConditionalFunding(UInt160 manufacturerAddress, string projectId,
        byte stepNumber, BigInteger conditionalAmount)
    {
        if (!IsOwner()) throw new Exception("Only contract owner can process conditional funding");

        ProjectAccount project = getProjectAccount(projectId);
        if (project == null) throw new Exception("Project not found");

        var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, stepNumber);
        if (obj == null)
            throw new Exception("Milestone not found");

        var milestone = (MilestoneCompletionVotesStruct)obj;
        if (!milestone.IsVotingSuccessful || milestone.isFundingSent)
            throw new Exception("Milestone not eligible for conditional funding");

        if (project.FLMUSD_PrizeFundBalance < conditionalAmount)
            throw new Exception("Insufficient prize fund balance for conditional funding");

        AcquireLock();
        try
        {
            project.FLMUSD_PrizeFundBalance -= conditionalAmount;
            milestone.FinancialAmount += conditionalAmount;

            ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
            manufacturerAccount.FreeBalance += conditionalAmount;
            manufacturerAccount.TotalBalance += conditionalAmount;
            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);

            ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, stepNumber, milestone);
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static bool getMilestoneCompletionVotingStatus(string projectId, UInt160 manufacturerAddress, byte milestoneStep)
    {
        var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, milestoneStep);
        if (obj == null) return false;

        var milestone = (MilestoneCompletionVotesStruct)obj;
        return milestone.isVotingStepComplete && milestone.IsVotingSuccessful;
    }

    public static void submitMilestoneVerification(UInt160 validatorAddress, string projectId,
        UInt160 manufacturerAddress, byte stepNumber, bool isVerified, string verificationReport)
    {
        if (!Runtime.CheckWitness(validatorAddress))
            throw new Exception("Authorization failed for validator");

        throw new Exception("Milestone verification flags are not available via ProjectState adapter. Use state contract-backed API.");
    }

    public static bool checkMilestoneExpired(string projectId, UInt160 manufacturer, byte checkMilestoneStep)
    {
        if (checkMilestoneStep == 0) return false;

        var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, checkMilestoneStep);
        if (obj == null) return false;

        var milestone = (MilestoneCompletionVotesStruct)obj;

        if (milestone.isVotingStepComplete) return false;

        if (milestone.Deadline_UnixTime > 0 && Runtime.Time > milestone.Deadline_UnixTime)
            return true;

        if (milestone.VotingStartTime > 0 && milestone.VotingDuration > 0 &&
            Runtime.Time > (milestone.VotingStartTime + milestone.VotingDuration))
            return true;

        return false;
    }

}


public partial class IF_MainGateway // Project Update Voting
{


    public static void finalizeProjectUpdateVoting(string projectId, string updateId)
    {
        var project = getProjectAccount(projectId);
        if (string.IsNullOrEmpty(updateId))
            throw new Exception("UpdateId cannot be null or empty");

        if (InnFork.NeoN3.ProjectState.IsProjectUpdateVotingFinalized(projectId, updateId))
            return;

        // Собираем голоса через snapshot для типа "ProjectUpdates:{updateId}"
        Map<UInt160, BackerVotesEnum> specificUpdateVotesMap = new Map<UInt160, BackerVotesEnum>();
        BigInteger currentPositiveRaw = 0;
        BigInteger currentNegativeRaw = 0;
        BigInteger currentAbstainedRaw = 0;
        BigInteger totalCastedRaw = 0;
        BigInteger eligibleVotersCount = InnFork.NeoN3.ProjectState.GetEligibleVotersCount(projectId);

        int skip = 0, take = 64;
        while (true)
        {
            object[] snap = InnFork.NeoN3.ProjectState.GetVotesSnapshot(projectId, "ProjectUpdates:" + updateId, skip, take);
            if (snap == null || snap.Length < 2) break;

            var voters = (UInt160[])snap[0];
            var votes = (BackerVotesEnum[])snap[1];
            if (voters == null || voters.Length == 0) break;

            for (int i = 0; i < voters.Length; i++)
            {
                specificUpdateVotesMap[voters[i]] = votes[i];
                totalCastedRaw++;
                if (votes[i] == BackerVotesEnum.Positive) currentPositiveRaw++;
                else if (votes[i] == BackerVotesEnum.Negative) currentNegativeRaw++;
                else if (votes[i] == BackerVotesEnum.Abstained) currentAbstainedRaw++;
            }

            skip += voters.Length;
            if (voters.Length < take) break;
        }

        bool canFinalize = false;
        ulong updateVotingDeadline = InnFork.NeoN3.ProjectState.GetProjectUpdateVotingDeadline(projectId, updateId);
        bool deadlineExists = updateVotingDeadline > 0;

        if (deadlineExists && Runtime.Time >= updateVotingDeadline)
            canFinalize = true;

        if (!canFinalize && project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings)
        {
            if (eligibleVotersCount > 0 && totalCastedRaw >= eligibleVotersCount)
                canFinalize = true;
        }

        if (!canFinalize) return;

        AcquireLock();
        try
        {
            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId,
                specificUpdateVotesMap,
                "ProjectUpdates:" + updateId,
                currentPositiveRaw,
                currentNegativeRaw,
                currentAbstainedRaw,
                totalCastedRaw
            );

            // Сохраняем финальные результаты в state
            InnFork.NeoN3.ProjectState.SetProjectUpdateVotingResults(
                projectId,
                updateId,
                outcome.FinalPositiveVotes,
                outcome.FinalNegativeVotes,
                outcome.FinalAbstainedVotes,
                outcome.TotalParticipatedOrAssigned
            );

            // Финализируем и помечаем как неактивное
            InnFork.NeoN3.ProjectState.SetProjectUpdateVotingStatus(projectId, updateId, false, true);

            // Отмечаем одобрение/неодобрение апдейта
            InnFork.NeoN3.ProjectState.SetApprovedUpdate(projectId, updateId, outcome.IsSuccessful);

            BackerVotesEnum finalResult = outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative;
            EventDispatcherAdapter.EmitVotingCompleted(projectId, "ProjectUpdate:" + updateId, finalResult);

            // По желанию можно обновить флаг проекта. Здесь не вычисляем наличие других активных апдейтов.
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    // ... внутри partial class ProjectAccount ...

    // === ПЕРЕГРУЗКА ДЛЯ Map<UInt160, BackerVotesEnum> ===
    public static CalculatedVoteOutcome calculateInternalVoteOutcome(
        string projectId,
        Map<UInt160, BackerVotesEnum> votesMap,
        string votingType,
        BigInteger explicitPositiveRaw,
        BigInteger explicitNegativeRaw,
        BigInteger explicitAbstainedRaw,
        BigInteger totalCastedRaw)
    {
        CalculatedVoteOutcome outcome = new CalculatedVoteOutcome();
        Map<UInt160, BigInteger> finalVoteWeights = new Map<UInt160, BigInteger>();
        Map<UInt160, BackerVotesEnum> finalVotes = new Map<UInt160, BackerVotesEnum>();

        var project = getProjectAccount(projectId);

        // Делегирование и агрегация весов
        foreach (UInt160 backer in votesMap.Keys)
        {
            if (!InnFork.NeoN3.ProjectState.IsBackerEligible(projectId, backer)) continue;

            UInt160 finalDelegate = InnFork.NeoN3.ProjectState.ResolveFinalDelegate(projectId, votingType, backer);
            BigInteger backerWeight = InnFork.NeoN3.ProjectState.GetBackerVoteWeight(projectId, backer);

            if (finalVoteWeights.HasKey(finalDelegate))
                finalVoteWeights[finalDelegate] += backerWeight;
            else
                finalVoteWeights[finalDelegate] = backerWeight;

            if (votesMap.HasKey(finalDelegate))
                finalVotes[finalDelegate] = votesMap[finalDelegate];
            else
                finalVotes[finalDelegate] = votesMap[backer];
        }

        // Общее число имеющих право голоса
        outcome.TotalEligibleVoters = InnFork.NeoN3.ProjectState.GetEligibleVotersCount(projectId);

        // Взвешенные итоги
        outcome.FinalPositiveVotes = 0;
        outcome.FinalNegativeVotes = 0;
        outcome.FinalAbstainedVotes = 0;

        BigInteger weightedTotalCastedActualVotes = 0;

        foreach (UInt160 voter in finalVotes.Keys)
        {
            if (!InnFork.NeoN3.ProjectState.IsBackerEligible(projectId, voter)) continue;

            BigInteger voteWeight = finalVoteWeights.HasKey(voter)
                ? finalVoteWeights[voter]
                : InnFork.NeoN3.ProjectState.GetBackerVoteWeight(projectId, voter);

            BackerVotesEnum vote = finalVotes[voter];
            if (vote == BackerVotesEnum.Positive) outcome.FinalPositiveVotes += voteWeight;
            else if (vote == BackerVotesEnum.Negative) outcome.FinalNegativeVotes += voteWeight;
            else if (vote == BackerVotesEnum.Abstained) outcome.FinalAbstainedVotes += voteWeight;

            weightedTotalCastedActualVotes += voteWeight;
        }

        outcome.TotalParticipatedOrAssigned = weightedTotalCastedActualVotes;

        // Безголосые -> воздержались
        if (project.AutoAssignVoicelessToAbstain && outcome.TotalEligibleVoters > weightedTotalCastedActualVotes)
        {
            BigInteger voiceless = outcome.TotalEligibleVoters - weightedTotalCastedActualVotes;
            outcome.FinalAbstainedVotes += voiceless;
            outcome.TotalParticipatedOrAssigned += voiceless;
        }

        // Воздержался = за
        if (project.AutoAbstainVoteAsSupport)
            outcome.FinalPositiveVotes += outcome.FinalAbstainedVotes;

        // Порог участия
        bool meetsMinParticipation = true;
        if (project.MinRequiredVotingParticipation > 0 && outcome.TotalEligibleVoters > 0)
            meetsMinParticipation = (outcome.TotalParticipatedOrAssigned * 100) >= (outcome.TotalEligibleVoters * project.MinRequiredVotingParticipation);
        else if (project.MinRequiredVotingParticipation > 0 && outcome.TotalEligibleVoters == 0)
            meetsMinParticipation = false;

        // Успешность
        outcome.IsSuccessful = false;
        if (meetsMinParticipation)
        {
            if (outcome.TotalParticipatedOrAssigned > 0)
                outcome.IsSuccessful = (outcome.FinalPositiveVotes * 100) >= (outcome.TotalParticipatedOrAssigned * project.MinApprovalPercentage);
            else if (project.MinApprovalPercentage == 0)
                outcome.IsSuccessful = true;
        }

        return outcome;
    }

    // === Обёртка под mini-adapter: InnerProxy не используется, сохранена сигнатура ===
    public static UInt160 getFinalDelegateForVoting(string projectId, Map<Map<string, UInt160>, UInt160> delegationMap, UInt160 backerAddress)
    {
        return InnFork.NeoN3.ProjectState.ResolveFinalDelegate(projectId, "Generic", backerAddress);
    }

    public static bool getBackerVoteStatusByComplexKey_BackerAddress_UpdateHash(string projectId, string UpdateHash, UInt160 backerAddress)
    {
        // Читаем голос из state
        int v = InnFork.NeoN3.ProjectState.GetProjectUpdateVote(projectId, UpdateHash, backerAddress);
        BackerVotesEnum vote = (BackerVotesEnum)v;
        if (vote == BackerVotesEnum.Positive) return true;
        if (vote == BackerVotesEnum.Negative || vote == BackerVotesEnum.Abstained) return false;

        throw new Exception("Vote not found for this update by the backer.");
    }

    public static void setBackerVoteStatusByComplexKey_BackerAddress_UpdateHash(string projectId, string UpdateHash, UInt160 backerAddress, BackerVotesEnum BackerVote)
    {
        if (!Runtime.CheckWitness(backerAddress))
            throw new Exception("setBackerVoteStatusByComplexKey_BackerAddress_UpdateHash failure: backerAddress address mismatch");

        AcquireLock();
        try
        {
            InnFork.NeoN3.ProjectState.SetProjectUpdateVote(projectId, UpdateHash, backerAddress, (int)BackerVote);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


}






public partial class IF_MainGateway

// Backer Voting Methods
{
    public static void voteForManufacturerWinner(string projectId, UInt160 backer, UInt160 manufacturer, BackerVotesEnum vote)
    {
        var project = getProjectAccount(projectId);

        if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");
        if (!isEligibleToVote(projectId, backer)) throw new Exception("Backer is not eligible to vote.");
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer)) throw new Exception("Manufacturer candidate not registered.");
        if (project.IsProjectHasWinner) throw new Exception("Project already has a winner.");
        if (project.ManufacturerSelectionVotingDeadline > 0 && Runtime.Time > project.ManufacturerSelectionVotingDeadline)
            throw new Exception("Manufacturer selection voting deadline has passed.");

        // Достаём агрегированную структуру (без локальной карты голосов)
        CandidateWinnerVotesStruct candidateVotes =
            (CandidateWinnerVotesStruct)ProjectState.GetCandidateWinnerVotes(projectId, manufacturer);

        if (candidateVotes == null)
        {
            candidateVotes = new CandidateWinnerVotesStruct
            {
                ProjectSha256_Id = projectId,
                ManufacturerCandidate = manufacturer,
                Sha256Hash_Id = IFHelper.createComplexKey(projectId, manufacturer),
                VotingStartTime = Runtime.Time,
                VotingDuration = project.DefaultVotingDuration,
                MinimumVotesRequired = project.MinRequiredVotingParticipation
            };
        }

        // Запрет повторного голосования: считаем, что Abstained тоже фиксирует голос
        var existingVote = (BackerVotesEnum)ProjectState.GetWinnerSelectionVote(projectId, backer, manufacturer);
        if (existingVote != BackerVotesEnum.Abstained)
            throw new Exception("Backer has already voted for this manufacturer candidate.");

        AcquireLock();
        try
        {
            // Пишем голос в StateStorage
            ProjectState.SetWinnerSelectionVote(projectId, backer, manufacturer, (int)vote);

            // Обновим агрегированную структуру (метаданные) и сохраним
            ProjectState.SetCandidateWinnerVotes(projectId, manufacturer, candidateVotes);

            project.LastActivityTime = Runtime.Time;
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static bool canBackerVote(string projectId, UInt160 backer, bool ignoreAlreadyVoted = false)
    {
        // Используем адаптер стейта для проверки права голоса и неучастия в бане
        return ProjectState.IsBackerEligible(projectId, backer);
    }

    public static void voteToMilestoneCompletionStep(string projectId, UInt160 backer, UInt160 manufacturerCandidate, byte stepNumber, BackerVotesEnum vote)
    {
        if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");
        if (!canBackerVote(projectId, backer)) throw new Exception("Backer is not eligible to vote.");
        if (stepNumber == 0) throw new Exception("Step number must be greater than 0");

        var milestoneObj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerCandidate, stepNumber);
        if (milestoneObj == null) throw new Exception("Milestone step not found or voting not initiated.");

        var milestone = (MilestoneCompletionVotesStruct)milestoneObj;

        if (milestone.isVotingStepComplete)
            throw new Exception("Voting for this milestone step is already complete.");

        // Проверка дедлайна
        if (milestone.VotingStartTime > 0 && milestone.VotingDuration > 0 &&
            Runtime.Time > (milestone.VotingStartTime + milestone.VotingDuration))
            throw new Exception("Voting deadline for this milestone step has passed.");

        // Запрещаем повторное голосование (включая реальный Abstained)
        if (ProjectState.HasMilestoneBackerVote(projectId, manufacturerCandidate, stepNumber, backer))
            throw new Exception("Backer already voted for this milestone step.");

        AcquireLock();
        try
        {
            // Храним голос в StateStorage, без модификации локальных карт
            ProjectState.SetMilestoneBackerVote(projectId, manufacturerCandidate, stepNumber, backer, (int)vote);

            // Дополнительно можно отметить время голосования для антифрода
            ProjectState.SetLastVoteTimestamp(projectId, backer, Runtime.Time);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void voteProjectUpdate(string projectId, UInt160 backer, string updateId, BackerVotesEnum vote)
    {
        if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");
        if (!isEligibleToVote(projectId, backer)) throw new Exception("Backer is not eligible to vote for project updates.");
        if (!isProjectOpen(projectId)) throw new Exception("Project is not open for update voting.");
        if (string.IsNullOrEmpty(updateId)) throw new Exception("Update ID cannot be null or empty.");

        // Уже финализировано?
        if (ProjectState.IsProjectUpdateVotingFinalized(projectId, updateId))
            throw new Exception("Voting for this project update has already been finalized.");

        // Дедлайн (если задан)
        ulong deadline = ProjectState.GetProjectUpdateVotingDeadline(projectId, updateId);
        if (deadline > 0 && Runtime.Time > deadline)
            throw new Exception("Voting deadline for project update " + updateId + " has passed.");

        // Запрет на повторное голосование (если уже есть запись отличная от дефолта)
        var existing = (BackerVotesEnum)ProjectState.GetProjectUpdateVote(projectId, updateId, backer);
        if (existing != BackerVotesEnum.Abstained && existing != 0) // 0 на случай дефолта
            throw new Exception("Backer has already voted for this update.");

        AcquireLock();
        try
        {
            // Помечаем голосование как активное
            ProjectState.SetProjectUpdateVotingStatus(projectId, updateId, true, false);

            // Записываем голос
            ProjectState.SetProjectUpdateVote(projectId, updateId, backer, (int)vote);

            // Обновляем активность проекта
            var project = getProjectAccount(projectId);
            project.IsProjectUpdatesVotingCompleted = false;
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void voteAbstain(string projectId, UInt160 voterAddress, int voteType, string updateHash)
    {
        if (!Runtime.CheckWitness(voterAddress)) throw new Exception("Voter address mismatch");
        if (!canBackerVote(projectId, voterAddress)) throw new Exception("Voter is not eligible to vote.");
        if (string.IsNullOrEmpty(updateHash) || updateHash.Length < 32) throw new Exception("Update hash cannot be empty.");

        voteProjectUpdate(projectId, voterAddress, updateHash, BackerVotesEnum.Abstained);
    }

    /// <summary>
    /// Вес голоса бэкера. Переведён на mini-adapter.
    /// </summary>
    public static BigInteger getBackerVoteWeight(string projectId, UInt160 backer)
    {
        BigInteger weight = ProjectState.GetBackerVoteWeight(projectId, backer);
        if (weight <= 0) weight = 1;

        // опционально сохраним кэш веса в state
        ProjectState.SetBackerVoteWeightValue(projectId, backer, weight);
        return weight;
    }


}









