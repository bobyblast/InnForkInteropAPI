﻿using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Attributes;
using System;
using System.ComponentModel;
using System.Numerics;
using InnFork.NeoN3.Enums;


namespace InnFork.NeoN3;




public partial class ProjectAccount // часть класса с переменными и методами подсистемы голосования по проекту
{

    private static readonly byte[] ContractVersionKey = "if:contract:version".ToByteArray();
    private static readonly byte[] ContractVersionChangelogKey = "if:contract:version:changelog".ToByteArray();

    [DisplayName("ContractVersionUpdated")]
    public static event Action<int, int, string> ContractVersionUpdated;

    public static int ContractVersion
    {
        get
        {
            ByteString value = Storage.Get(Storage.CurrentContext, ContractVersionKey);
            return value is null || value.Length == 0 ? 1 : (int)(BigInteger)value;
        }
        private set => Storage.Put(Storage.CurrentContext, ContractVersionKey, (BigInteger)value);
    }

    [Safe]
    public static int getContractVersion()
    {
        return ContractVersion;
    }

    [Safe]
    public static string getContractVersionChangelog()
    {
        ByteString value = Storage.Get(Storage.CurrentContext, ContractVersionChangelogKey);
        return value is null ? string.Empty : (string)value;
    }

    public static void updateContractVersion(int newVersion, string changelogHash)
    {
        if (!IF_MainGateway.IsOwner())
            throw new Exception("Only owner can update contract version");

        if (newVersion <= ContractVersion)
            throw new Exception("New version must be greater than current version");

        if (changelogHash is null || changelogHash.Length == 0)
            throw new Exception("Changelog hash is required");

        int previousVersion = ContractVersion;
        ContractVersion = newVersion;
        Storage.Put(Storage.CurrentContext, ContractVersionChangelogKey, changelogHash);

        ContractVersionUpdated(previousVersion, newVersion, changelogHash);
    }



    public static void saveProjectAccountToProjectsAccountStore(string projectId, ProjectAccount project)
    {
        if (project == null) throw new Exception("Project param is null: " + projectId);
        if (string.IsNullOrEmpty(projectId) || (projectId.Length != 32 && projectId.Length != 64))
            throw new Exception("saveProjectAccountToProjectsAccountStore: Invalid projectId format. Length is: " + (projectId == null ? 0 : projectId.Length));

        project.LastActivityTime = Runtime.Time;
        var coreDto = ToCoreDto(projectId, project);
        var coreBytes = StdLib.Serialize(coreDto);

        ProjectState.SetProjectCore(projectId, coreBytes);

        try { ProjectState.SetLastActivityTime(projectId, project.LastActivityTime); } catch { }
        try { ProjectState.SetProjectTotalBalance(projectId, project.FLMUSD_TotalProjectBalance); } catch { }
        try { ProjectState.SetLockedFunds(projectId, project.totalFundsLocked); } catch { }
        try { ProjectState.SetTotalRefundsProcessed(projectId, project.TotalRefundsProcessed); } catch { }
        try { ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, project.IsProjectHasWinner); } catch { }
        try { ProjectState.SetProjectStatus(projectId, (int)project.CurrentProjectStatus); } catch { }
        try { ProjectState.SetVotingConfiguration(projectId, project.MinRequiredVotingParticipation, project.MinApprovalPercentage, project.AutoAssignVoicelessToAbstain, project.AutoAbstainVoteAsSupport); } catch { }

        try
        {
            if (project.LaunchVotingDeadline > 0 || project.FundraisingDeadline > 0 || project.ManufacturerSelectionVotingDeadline > 0)
                ProjectState.SetProjectVotingDeadlines(projectId, project.LaunchVotingDeadline, project.FundraisingDeadline, project.ManufacturerSelectionVotingDeadline);

            ProjectState.SyncVotingDeadline(projectId, "LaunchApproval", project.LaunchVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "FundraisingCompletion", project.FundraisingCompletionVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "SuccessfulClosure", project.SuccessfulClosureVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "PauseResume", project.PauseResumeVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "ManufacturerSelection", project.ManufacturerSelectionVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "TerminationWithRefund", project.TerminationWithRefundVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "FundraisingIncrease", project.FundraisingIncreaseVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "ManagementTransfer", project.ManagementTransferVotingDeadline);
            ProjectState.SyncVotingDeadline(projectId, "MilestoneCompletion", project.MilestoneCompletionVotingDeadline);
        }
        catch { }
    }



    //TOSO: разобраться с загрузкой settings во всех проектах

    public ProjectSettings projectSettings { get; set; } = new ProjectSettings(); // <--- настройки проекта

    public string getProjectSettingsJson()
    {
        return StdLib.Serialize(this.projectSettings);
    }

    public void setProjectSettingsJson(string projectSettingsJson)
    {
        if (Runtime.CheckWitness(ProjectCreatorAddress) == false && DirectInnForkProjectManagement == false)
            throw new Exception("Only project creator can set project settings.");
        else
            if (DirectInnForkProjectManagement == true && IF_MainGateway.IsOwner() == false)
            throw new Exception("Only InnFork Gateway can set project settings.");


        // проверяем дедлайн по записи настроек от projectCreator. Если больше месяца с начала проекта - выходим

        projectSettings = (ProjectSettings)StdLib.Deserialize(projectSettingsJson);

        AutoAssignVoicelessToAbstain = projectSettings.AutoAssignVoicelessToAbstain;// <--- Флаг для автоматического учета безголосых как воздержавшихся
        AutoAbstainVoteAsSupport = projectSettings.AutoAbstainVoteAsSupport; // <--- Флаг для автоматического учета воздержавшихся голосов как поддерживающих

        // Настройки голосования
        MinimumVotesRequired = projectSettings.MinimumVotesRequired; // Минимальное количество голосов
        MinRequiredVotingParticipation = projectSettings.MinRequiredVotingParticipation; // Минимальная требуемая доля голосования
        MinApprovalPercentage = projectSettings.MinApprovalPercentage; // Минимальный процент одобрения

        // Настройки этапов финансирования
        DefaultFundingType = (MilestoneFundingType)projectSettings.DefaultFundingType; // Тип финансирования по умолчанию
        DefaultVotingDuration = projectSettings.DefaultVotingDuration; // Длительность голосования по умолчанию
        AllowSteppedFinancing = projectSettings.AllowSteppedFinancing; // Разрешить поэтапное финансирование
        MaxMilestoneSteps = projectSettings.MaxMilestoneSteps; // Максимальное количество этапов финансирования

        // Настройки производителей
        MaxManufacturers = projectSettings.MaxManufacturers;
        //   project.MinManufacturerInvestment = projectSettings.MinManufacturerInvestment; // Минимальная инвестиция от производителя
        DefaultPrizeFundAllocation = projectSettings.DefaultPrizeFundAllocation; // Доля призового фонда по умолчанию

        // Финансовые настройки
        CreatorFeePercentage = projectSettings.CreatorFeePercentage; // Процент комиссии создателя проекта
        CreatorFixedReward = projectSettings.CreatorFixedReward; // Фиксированная награда для создателя проекта
        FLMUSD_PrizeFundGoal = projectSettings.FLMUSD_PrizeFundGoal; // Целевая сумма в долларах для сбора средств

        // Настройки безопасности и мониторинга
        WithdrawalTimeout = projectSettings.WithdrawalTimeout; // Таймаут на вывод средств
        EnableFraudDetection = projectSettings.EnableFraudDetection; // Включить обнаружение мошенничества

        // Настройки автоматизации
        AutoDistributeConsentedFunds = projectSettings.AutoDistributeConsentedFunds; // Автоматически распределять согласованные средства
        AutoPauseEnabled = projectSettings.AutoPauseEnabled; // Автоматически приостанавливать проект при недостаточном финансировании
        AutoFinishExpiredVotings = projectSettings.AutoFinishExpiredVotings; // Автоматически завершать истекшие голосования

        // Настройки временных параметров

        FundraisingDeadline = projectSettings.FundraisingDeadline; // время окончания сбора средств
        ManufacturerSelectionDeadline = projectSettings.ManufacturerSelectionDeadline; // Дедлайн выбора производителей
        LaunchVotingDeadline = projectSettings.LaunchVotingDeadline; // Дедлайн запуска голосования
        FundraisingVotingDeadline = projectSettings.FundraisingVotingDeadline; // Дедлайн голосования по сбору средств


        // Базовые настройки проекта
        /*        if (projectSettings.ProjectName != null && projectSettings.ProjectName.Length > 0)
                    project.ProjectName = projectSettings.ProjectName;*/

        if (projectSettings.ProjectDescription_NeoFS_Address != null && projectSettings.ProjectDescription_NeoFS_Address.Length > 0)
            ProjectDescription_NeoFS_Address = projectSettings.ProjectDescription_NeoFS_Address;

        saveProjectAccountToProjectsAccountStore(projectId, this);
    }



    internal class ProjectCoreStateDto
    {
        public string ProjectId;
        public UInt160 ProjectCreatorAddress;
        public BigInteger FLMUSD_TotalProjectBalance;
        public BigInteger FLMUSD_PrizeFundBalance;
        public BigInteger TotalRefundsProcessed;
        public BigInteger TotalFundsLocked;
        public bool IsArchived;
        public bool IsProjectPaused;
        public bool IsProjectClosed;
        public bool IsProjectHasWinner;
        public int CurrentProjectStatus;
        public BigInteger MinRequiredVotingParticipation;
        public BigInteger MinApprovalPercentage;
        public bool AutoAssignVoicelessToAbstain;
        public bool AutoAbstainVoteAsSupport;
        public ulong LaunchVotingDeadline;
        public ulong FundraisingDeadline;
        public ulong FundraisingCompletionVotingDeadline;
        public ulong SuccessfulClosureVotingDeadline;
        public ulong PauseResumeVotingDeadline;
        public ulong ManufacturerSelectionVotingDeadline;
        public ulong TerminationWithRefundVotingDeadline;
        public ulong MilestoneCompletionVotingDeadline;
        public ulong ManagementTransferVotingDeadline;
        public ulong RegistrationTime;
        public ulong LastActivityTime;
        public string ProjectOfferId_Sha256;
    }

    private static ProjectCoreStateDto ToCoreDto(string projectId, ProjectAccount account)
    {
        return new ProjectCoreStateDto
        {
            ProjectId = projectId,
            ProjectCreatorAddress = account.ProjectCreatorAddress,
            FLMUSD_TotalProjectBalance = account.FLMUSD_TotalProjectBalance,
            FLMUSD_PrizeFundBalance = account.FLMUSD_PrizeFundBalance,
            TotalRefundsProcessed = account.TotalRefundsProcessed,
            TotalFundsLocked = account.totalFundsLocked,
            IsArchived = account.IsArchived,
            IsProjectPaused = account.IsProjectPaused,
            IsProjectClosed = account.IsProjectClosed,
            IsProjectHasWinner = account.IsProjectHasWinner,
            CurrentProjectStatus = (int)account.CurrentProjectStatus,
            MinRequiredVotingParticipation = account.MinRequiredVotingParticipation,
            MinApprovalPercentage = account.MinApprovalPercentage,
            AutoAssignVoicelessToAbstain = account.AutoAssignVoicelessToAbstain,
            AutoAbstainVoteAsSupport = account.AutoAbstainVoteAsSupport,
            LaunchVotingDeadline = account.LaunchVotingDeadline,
            FundraisingDeadline = account.FundraisingDeadline,
            FundraisingCompletionVotingDeadline = account.FundraisingCompletionVotingDeadline,
            SuccessfulClosureVotingDeadline = account.SuccessfulClosureVotingDeadline,
            PauseResumeVotingDeadline = account.PauseResumeVotingDeadline,
            ManufacturerSelectionVotingDeadline = account.ManufacturerSelectionVotingDeadline,
            TerminationWithRefundVotingDeadline = account.TerminationWithRefundVotingDeadline,
            MilestoneCompletionVotingDeadline = account.MilestoneCompletionVotingDeadline,
            ManagementTransferVotingDeadline = account.ManagementTransferVotingDeadline,
            RegistrationTime = account.RegistrationTime,
            LastActivityTime = account.LastActivityTime,
            ProjectOfferId_Sha256 = account.ProjectOfferId_Sha256
        };
    }

    private static void ApplyCoreDto(ProjectAccount account, ProjectCoreStateDto dto)
    {
        account.ProjectCreatorAddress = dto.ProjectCreatorAddress;
        account.FLMUSD_TotalProjectBalance = dto.FLMUSD_TotalProjectBalance;
        account.FLMUSD_PrizeFundBalance = dto.FLMUSD_PrizeFundBalance;
        account.TotalRefundsProcessed = dto.TotalRefundsProcessed;
        account.totalFundsLocked = dto.TotalFundsLocked;
        account.IsArchived = dto.IsArchived;
        account.IsProjectPaused = dto.IsProjectPaused;
        account.IsProjectClosed = dto.IsProjectClosed;
        account.IsProjectHasWinner = dto.IsProjectHasWinner;
        account.CurrentProjectStatus = (ProjectStatus)dto.CurrentProjectStatus;
        account.MinRequiredVotingParticipation = dto.MinRequiredVotingParticipation;
        account.MinApprovalPercentage = dto.MinApprovalPercentage;
        account.AutoAssignVoicelessToAbstain = dto.AutoAssignVoicelessToAbstain;
        account.AutoAbstainVoteAsSupport = dto.AutoAbstainVoteAsSupport;
        account.LaunchVotingDeadline = dto.LaunchVotingDeadline;
        account.FundraisingDeadline = dto.FundraisingDeadline;
        account.FundraisingCompletionVotingDeadline = dto.FundraisingCompletionVotingDeadline;
        account.SuccessfulClosureVotingDeadline = dto.SuccessfulClosureVotingDeadline;
        account.PauseResumeVotingDeadline = dto.PauseResumeVotingDeadline;
        account.ManufacturerSelectionVotingDeadline = dto.ManufacturerSelectionVotingDeadline;
        account.TerminationWithRefundVotingDeadline = dto.TerminationWithRefundVotingDeadline;
        account.MilestoneCompletionVotingDeadline = dto.MilestoneCompletionVotingDeadline;
        account.ManagementTransferVotingDeadline = dto.ManagementTransferVotingDeadline;
        account.RegistrationTime = dto.RegistrationTime;
        account.LastActivityTime = dto.LastActivityTime;
        account.ProjectOfferId_Sha256 = dto.ProjectOfferId_Sha256;
    }


    public static ProjectAccount getProjectAccount(string projectId)
    {
        if (projectId.Length != 32 && projectId.Length != 64)
            throw new Exception("getProjectAccount: Invalid projectId format. Lenght is: " + projectId.Length.ToString());

        var coreBytes = ProjectState.GetProjectCoreBytes(projectId);
        if (coreBytes is null) throw new Exception("getProjectAccount: Project not found");

        var dto = (ProjectCoreStateDto)StdLib.Deserialize(coreBytes);
        var p = new ProjectAccount();
        ApplyCoreDto(p, dto);
        p.projectId = projectId;
        return p;
    }

}






// Выносимая в другой контракт часть
public partial class IF_MainGateway : Neo.SmartContract.Framework.SmartContract
{


    public static string registerProjectEx(UInt160 ProjectCreatorId, string AuthorPubKey, string ProjectJson, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner,
                                            string ProjectOfferId_Sha256, bool bool_StoreOffer, string projectOfferJson,
                                            BigInteger WinnerDollars_GoalFund)
    {
        try
        {
            if (ProjectOfferId_Sha256.Length != 32 && ProjectOfferId_Sha256.Length != 64) throw new Exception("Invalid key format. Use 32-byte binary or 64-char hex");

            byte[] key = IFHelper.safeHexToBytes(ProjectOfferId_Sha256);

            var offerRaw = ProjectState.GetRawOfferPackage((ByteString)key);
            if (offerRaw is null)
                throw new Exception("ProjectOfferId_Sha256 is not registered : " + ProjectOfferId_Sha256 + " Lenght is: " + ProjectOfferId_Sha256.Length);

            ProjectOfferPackage offerPackage = (ProjectOfferPackage)StdLib.Deserialize(offerRaw);

            if (ProjectJson == null || ProjectJson.Length == 0) throw new Exception("ProjectJson is empty");
            if (ProjectOfferId_Sha256 == null || ProjectOfferId_Sha256.Length != 64) throw new Exception("Invalid ProjectOfferId_Sha256");

            if (pubKeyOfJsonSigner.Length != 33)
                throw new Exception("Invalid public projectIdSha256 format. Expected 33 bytes.");

            if (signatureOfJson.Length != 64)
                throw new Exception("Invalid signatureOfProjectJson length. Expected 64 bytes. Passed Lenght is: " + signatureOfJson.Length.ToString());

            if (ProjectCreatorId != IFHelper.pubKeyToAddress(AuthorPubKey.ToByteArray())) throw new Exception("pubKeyToAddress AuthroPubKey missmatch");

            if (CryptoLib.VerifyWithECDsa(ProjectJson, (ECPoint)pubKeyOfJsonSigner, (ByteString)signatureOfJson, NamedCurveHash.secp256r1SHA256) == false)
                throw new Exception("Verify Signature SHA256 ProjectJson failed.");

            if (offerPackage.AuthorAccount != ProjectCreatorId)
                throw new Exception("Offer document author mismatch");

            if (!IFHelper.verifySignatureSHA256(pubKeyOfJsonSigner, ProjectJson.ToByteArray(), signatureOfJson))
                throw new Exception("Invalid signature of ProjectJson");

            if (ProjectCreatorId.Length != 20) throw new Exception("Invalid ProjectCreatorId address format");

            string projectId = CryptoLib.Sha256(ProjectJson);

            if (ProjectState.GetProjectCoreBytes(projectId) != null)
                throw new Exception("Project already registered");

            ProjectCreatorAccount account = ProjectCreatorAccount.getProjectCreatorAccount(ProjectCreatorId);
            if (account == null)
            {
                ProjectCreatorAccount.createProjectCreatorAccount(ProjectCreatorId, AuthorPubKey);
            }

            if (bool_StoreOffer == true && projectOfferJson != null)
            {
                setProjectOfferShortJsonToExistingProject(projectOfferJson, ProjectOfferId_Sha256, IFHelper.safeHexToBytes(CryptoLib.Sha256(ProjectJson)));
            }

            ProjectPackage _ProjectPackage = new ProjectPackage
            {
                ProjectOfferShortJson = projectOfferJson,
                ProjectJson = ProjectJson,
                AuthorAccount = (UInt160)ProjectCreatorId,
                ProjectId_Sha256 = projectId,
                AuthorPubKey = pubKeyOfJsonSigner,
                Signature = signatureOfJson
            };

            ProjectState.SetRawProjectPackage(IFHelper.safeHexToBytes(projectId).ToByteString(), StdLib.Serialize(_ProjectPackage));

            ProjectAccount projectAccount = new ProjectAccount
            {
                ProjectCreatorAddress = ProjectCreatorId,
                FLMUSD_TotalProjectBalance = 0,
                FLMUSD_PrizeFundGoal = WinnerDollars_GoalFund,
                projectId = projectId,
                ProjectOfferId_Sha256 = ProjectOfferId_Sha256,
                RegistrationTime = Runtime.Time
            };

            saveProjectAccountToProjectsAccountStore(projectId, projectAccount);

            return projectId;
        }
        catch (Exception ex)
        {
            throw new Exception("registerProjectEx: " + ex.Message);
        }
    }


    public static string storeProjectOfferMetaData(UInt160 projectCreatorAddress, string AuthorPubKey, string JsonOfferDoc, byte[] signatureOfJson, byte[] pubKeyOfJsonSigner)// OK =======================   :)))   ===============================
    {
        if (!Runtime.CheckWitness(projectCreatorAddress))
            throw new Exception("projectCreatorAddress CheckWitness failed");

        if (pubKeyOfJsonSigner.Length != 33)
            throw new Exception("Invalid public key_documentIdSha256 format. Expected 33 bytes.");

        if (signatureOfJson.Length != 64)
            throw new Exception("Invalid signatureOfJson length. Expected 64 bytes.");

        if (projectCreatorAddress != IFHelper.pubKeyToAddress(AuthorPubKey.ToByteArray())) throw new Exception("pubKeyToAddress AuthroPubKey missmatch");

        ProjectCreatorAccount account = ProjectCreatorAccount.getProjectCreatorAccount(projectCreatorAddress);
        if (account == null)
        {
            ProjectCreatorAccount.createProjectCreatorAccount(projectCreatorAddress, AuthorPubKey);
        }

        if (!IFHelper.verifySignatureSHA256(pubKeyOfJsonSigner, JsonOfferDoc.ToByteArray(), signatureOfJson))
            throw new Exception("Invalid signature of JsonOfferDoc");

        string documentIdSha256 = CryptoLib.Sha256(JsonOfferDoc);

        ProjectOfferPackage package = new ProjectOfferPackage
        {
            AuthorAccount = (UInt160)projectCreatorAddress,
            ProjectOfferSha256Id = documentIdSha256,
            AuthorPubKey = pubKeyOfJsonSigner,
            Signature = signatureOfJson
        };

        updateProjectOfferPackage(package, documentIdSha256);

        return documentIdSha256;
    }

    public static ProjectOfferPackage getProjectOfferPack(string projectOfferId)
    {
        byte[] key = IFHelper.safeHexToBytes(projectOfferId);
        var raw = ProjectState.GetRawOfferPackage(((ByteString)key));
        ExecutionEngine.Assert(raw != null, "Key not found");
        return (ProjectOfferPackage)StdLib.Deserialize(raw);
    }

    private static void updateProjectOfferPackage(ProjectOfferPackage package, string documentIdSha256)
    {
        if (package == null) throw new ArgumentNullException("package is null");
        if (documentIdSha256 == null) throw new Exception(" projectOfferfferId_Sha256 is NULL");
        if (documentIdSha256.Length != 32) throw new Exception("updateProjectOfferPackage Invalid projectOfferfferId_Sha256/ Lenght is : " + documentIdSha256.Length.ToString());

        var keyBytes = IFHelper.safeHexToBytes(documentIdSha256);
        if (ProjectState.GetRawOfferPackage((ByteString)keyBytes) != null)
        {
            throw new Exception("Offer document already registered");
        }

        ProjectState.SetRawOfferPackage((ByteString)keyBytes, StdLib.Serialize(package));
    }
    private static void updateProjectOfferPack(ProjectOfferPackage package, string documentIdSha256)
    {
        if (package == null) throw new ArgumentNullException("package is null");
        if (documentIdSha256 == null) throw new Exception("Sha256 projectOfferId is NULL");
        if (documentIdSha256.Length != 32) throw new Exception("updateProjectOfferPackage Invalid projectOfferId_Sha256/ Lenght is : " + documentIdSha256.Length.ToString());

        ProjectOfferPackage OfferPack = getProjectOfferPack(documentIdSha256);
        if (OfferPack == null)
        {
            throw new Exception("Offer document not registered");
        }

        byte[] key_documentIdSha256 = IFHelper.hexToBytes(documentIdSha256);
        ProjectState.SetRawOfferPackage((ByteString)key_documentIdSha256, StdLib.Serialize(package));
    }

    private static string removeProjectOfferFromGlobalList(UInt160 projectCreator, byte[] pubKey, string offerSha256Id)
    {
        if (!Runtime.CheckWitness(projectCreator) && IsOwner() == false)
            throw new Exception("Author or Owner CheckWitness failed");

        if (pubKey.Length != 33)
            throw new Exception("Invalid public key_documentIdSha256 format. Expected 33 bytes.");

        if (projectCreator != IFHelper.pubKeyToAddress(pubKey))
        {
            throw new Exception("AuthorAccount and public Key not match");
        }

        var pkg = getProjectOfferPack(offerSha256Id);
        if (pkg.AuthorAccount == projectCreator && pkg.ProjectOfferSha256Id == offerSha256Id)
        {
            removeOffer(offerSha256Id);
            return "project offer is removed: " + pkg.ProjectOfferSha256Id;
        }

        return "project offer not found";
    }

    private static void removeProjectOffer(UInt160 projectCreator, byte[] pubKey, string offerSha256Id)
    {
        if (!Runtime.CheckWitness(projectCreator))
            throw new Exception("Project Creator CheckWitness failed");

        if (pubKey.Length != 33)
            throw new Exception("Invalid public key_documentIdSha256 format. Expected 33 bytes.");

        if (projectCreator != IFHelper.pubKeyToAddress(pubKey))
        {
            throw new Exception("AuthorAccount and public Key not match");
        }

        ProjectOfferPackage projectOfferPackage = getProjectOfferPack(offerSha256Id);

        if (projectOfferPackage.AuthorAccount != projectCreator || projectOfferPackage.AuthorPubKey != pubKey)
        {
            throw new Exception("projectCreatorAddress Account sign not match");
        }

        byte[] key_offerSha256Id = IFHelper.safeHexToBytes(offerSha256Id);
        ProjectState.DeleteRawOfferPackage((ByteString)key_offerSha256Id);
        removeOffer(offerSha256Id);
    }

    ///////////////////////////////////////////// DONATE Project Offer  //////////////////////////////////////////////////


    public static int getCountOf_Sha256Offers()
    {
        // Итерация по префиксу перенесена в стейт-контракт. Здесь можно реализовать прокси/снимок.
        return 0;
    }


    public static BigInteger getTotalReservedDonatesToOffer(string offerSha256Id)
    {
        // Проверяем существование оффера
        var pack = getProjectOfferPack(offerSha256Id);

        // Суммирование по бэкерам перенесено. Верните агрегат из стейт-контракта при необходимости.
        BigInteger totalReserved = 0;
        return totalReserved;
    }

    public static int getCountOfSelectedMapName(string MapName)
    {
        int count = 0;
        Iterator iterator = Storage.Find(Storage.CurrentContext, MapName, FindOptions.RemovePrefix);
        while (iterator.Next())
        {

            count++;
        }
        return count;
    }



    /// <summary>
    /// Удаляет предложение проекта по истечении времени.
    /// </summary>
    /// <param name="projectCreatorAddress">Адрес создателя проекта.</param>
    /// <param name="offerSha256Id">Хеш-идентификатор предложения.</param>
    /// <returns>Возвращает true, если удаление выполнено успешно.</returns>
    /// <remarks>
    /// Проверяет авторизацию по адресу создателя, время (при необходимости),
    /// а также проверяет соответствие предложения хранимым данным.
    /// </remarks>
    public static bool removeProjectOfferByTimeLine(UInt160 projectCreatorAddress, string offerSha256Id)
    {
        if (!Runtime.CheckWitness(projectCreatorAddress))
            throw new Exception("Authorization failed");

        if (Runtime.Time > 0)
        {
            // time check placeholder
        }

        var projectOfferPackage = getProjectOfferPack(offerSha256Id);
        if (projectOfferPackage.AuthorAccount != projectCreatorAddress)
            throw new Exception("AuthorAccount and offer not match");

        byte[] key_offerSha256Id = IFHelper.safeHexToBytes(offerSha256Id);
        ProjectState.DeleteRawOfferPackage((ByteString)key_offerSha256Id);

        return true;
    }

    public static void removeOffer(string offerSha256Id)
    {
        byte[] key = IFHelper.safeHexToBytes(offerSha256Id);
        ProjectState.DeleteRawOfferPackage((ByteString)key);
    }



    // Импорт настроек (как было)
    public static void ImportNewProjectSettings(string jsonSettings)
    {
        ProjectSettings s = (ProjectSettings)StdLib.Deserialize(jsonSettings);
    }


    public static void setProjectOfferShortJsonToExistingProject(string offerShortJson, string ProjectOfferId_Sha256, byte[] projectIdSha256)
    {
        if (offerShortJson == null || offerShortJson.Length == 0) throw new Exception("OfferShortJson is empty");
        if (ProjectOfferId_Sha256 == null || (ProjectOfferId_Sha256.Length != 32 && ProjectOfferId_Sha256.Length != 64)) throw new Exception("Invalid Sha256Json");

        var raw = ProjectState.GetRawProjectPackage((ByteString)projectIdSha256);
        if (raw is null) throw new Exception("setProjectOfferShortJsonToExistingProject method! Offer document not found");

        if (CryptoLib.Sha256((ByteString)offerShortJson) != ProjectOfferId_Sha256)
            throw new Exception("setProjectOfferShortJsonToExistingProject: ProjectOfferId_Sha256 mismatch");

        ProjectPackage package = (ProjectPackage)StdLib.Deserialize(raw);
        if (package.ProjectOfferId_Sha256 != ProjectOfferId_Sha256)
            throw new Exception("setProjectOfferShortJsonToExistingProject: ProjectOfferId_Sha256 mismatch");

        package.ProjectOfferShortJson = offerShortJson;

        ProjectState.SetRawProjectPackage((ByteString)projectIdSha256, StdLib.Serialize(package));
    }



    public static bool isProjectRegistered(string projectId)
    {
        ByteString core = ProjectState.GetProjectCoreBytes(projectId);

        if (core != null) return true;

        return false;
    }



    public static void removeProjectFromGlobalProjectsListsByProjectId(string projectId)
    {
        if (!IsOwner()) throw new Exception("Caller is not the owner");
        if (projectId == null || (projectId.Length != 32 && projectId.Length != 64)) throw new Exception("Invalid projectId format. Length is: " + projectId.Length.ToString());

        var bytes = ProjectState.GetGlobalProjectsList();
        if (bytes is null) return;

        string[] arr = (string[])StdLib.Deserialize(bytes);
        if (arr == null || arr.Length == 0) return;

        var res = new Neo.SmartContract.Framework.List<string>();
        for (int i = 0; i < arr.Length; i++)
        {
            string projectAccountJson = arr[i];
            if (string.IsNullOrEmpty(projectAccountJson)) continue;

            ProjectAccount projectAccount = (ProjectAccount)StdLib.Deserialize(projectAccountJson);
            if (projectAccount == null) continue;

            if (projectAccount.projectId != projectId)
                res.Add(projectAccountJson);
        }
        ProjectState.SetGlobalProjectsList(StdLib.Serialize(res));
    }

    public static void saveProjectToProjectsAccountStore(ProjectPackage package)
    {
        if (package == null) throw new ArgumentNullException("ProjectPackage is null");
        if (package.ProjectId_Sha256 == null || (package.ProjectId_Sha256.Length != 64 && package.ProjectId_Sha256.Length != 32))
            throw new Exception("Invalid projectId. projectId Lenght is: " + package.ProjectId_Sha256.Length.ToString());

        byte[] projectId_Key = IFHelper.safeHexToBytes(package.ProjectId_Sha256);
        ProjectState.SetRawProjectPackage((ByteString)projectId_Key, StdLib.Serialize(package));
    }

    public static void resumeProject(string projectId)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        if (!project.IsProjectPaused) return;

        AcquireLock();
        try
        {
            ulong currentTime = Runtime.Time;
            ulong pauseStartTime = project.LastActivityTime;
            ulong pauseDuration = currentTime - pauseStartTime;

            project.IsProjectPaused = false;
            if (project.CurrentProjectStatus == ProjectStatus.Paused)
                project.CurrentProjectStatus = ProjectStatus.Active;

            project.LastActivityTime = currentTime;

            // Сдвигаем дедлайны в локальном объекте
            if (project.FundraisingDeadline > 0 && project.FundraisingDeadline >= pauseStartTime) project.FundraisingDeadline += pauseDuration;
            if (project.ManufacturerSelectionDeadline > 0 && project.ManufacturerSelectionDeadline >= pauseStartTime) project.ManufacturerSelectionDeadline += pauseDuration;
            if (project.LaunchVotingDeadline > 0 && project.LaunchVotingDeadline >= pauseStartTime) project.LaunchVotingDeadline += pauseDuration;
            if (project.FundraisingCompletionVotingDeadline > 0 && project.FundraisingCompletionVotingDeadline >= pauseStartTime) project.FundraisingCompletionVotingDeadline += pauseDuration;
            if (project.SuccessfulClosureVotingDeadline > 0 && project.SuccessfulClosureVotingDeadline >= pauseStartTime) project.SuccessfulClosureVotingDeadline += pauseDuration;
            if (project.PauseResumeVotingDeadline > 0 && project.PauseResumeVotingDeadline >= pauseStartTime) project.PauseResumeVotingDeadline += pauseDuration;
            if (project.TerminationWithRefundVotingDeadline > 0 && project.TerminationWithRefundVotingDeadline >= pauseStartTime) project.TerminationWithRefundVotingDeadline += pauseDuration;
            if (project.FundraisingIncreaseVotingDeadline > 0 && project.FundraisingIncreaseVotingDeadline >= pauseStartTime) project.FundraisingIncreaseVotingDeadline += pauseDuration;

            // Отразим основные дедлайны в стейте
            ProjectState.SetProjectVotingDeadlines(
                projectId,
                project.LaunchVotingDeadline,
                project.FundraisingDeadline,
                project.ManufacturerSelectionDeadline
            );
            ProjectState.SetVotingDeadline(projectId, "FundraisingCompletion", project.FundraisingCompletionVotingDeadline);
            ProjectState.SetVotingDeadline(projectId, "PauseResume", project.PauseResumeVotingDeadline);
            ProjectState.SetVotingDeadline(projectId, "SuccessfulClosure", project.SuccessfulClosureVotingDeadline);
            ProjectState.SetVotingDeadline(projectId, "TerminationWithRefund", project.TerminationWithRefundVotingDeadline);
            ProjectState.SetVotingDeadline(projectId, "FundraisingIncrease", project.FundraisingIncreaseVotingDeadline);

            // Пересчёт дедлайнов для всех milestone через стейт‑контракт
            var manufacturers = ProjectState.GetManufacturerCandidates(projectId);
            if (manufacturers != null && manufacturers.Length > 0 && project.projectSettings != null && project.projectSettings.MaxMilestoneSteps > 0)
            {
                for (int mi = 0; mi < manufacturers.Length; mi++)
                {
                    var manu = manufacturers[mi];
                    for (byte step = 1; step <= project.projectSettings.MaxMilestoneSteps; step++)
                    {
                        var msObj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manu, step);
                        if (msObj == null) continue;

                        var milestone = (MilestoneCompletionVotesStruct)msObj;

                        if (milestone.Deadline_UnixTime > 0 && milestone.Deadline_UnixTime >= pauseStartTime)
                        {
                            milestone.Deadline_UnixTime += pauseDuration;
                        }
                        if (milestone.VotingStartTime > 0 && milestone.VotingStartTime >= pauseStartTime && milestone.VotingDuration > 0 && !milestone.isVotingStepComplete)
                        {
                            // Продлеваем длительность на период паузы
                            milestone.VotingDuration += pauseDuration;
                        }

                        ProjectState.SetMilestoneCompletionVotesStruct(projectId, manu, step, milestone);
                    }
                }
            }

            // Обновим флаги и статус в стейте
            ProjectState.SetProjectFlags(projectId, project.IsArchived, isPaused: false, project.IsProjectClosed, project.IsProjectHasWinner);
            ProjectState.SetProjectStatus(projectId, (int)project.CurrentProjectStatus);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            VotingCompleted(projectId, "PauseResume", BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    public static void autoSetToPause(string projectId)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        const ulong HALF_YEAR_SECONDS = 15768000;
        ulong currentTime = Runtime.Time;

        AcquireLock();
        try
        {
            if (project.IsProjectPaused)
            {
                // Если появился кандидат — резюмируем
                var candidates = ProjectState.GetManufacturerCandidates(projectId);
                if (candidates != null && candidates.Length > 0)
                {
                    // Возобновим проект
                    ReleaseAcquireLock(); // избежим вложенной блокировки
                    resumeProject(projectId);
                    return;
                }
            }
            else
            {
                var candidates = ProjectState.GetManufacturerCandidates(projectId);
                bool noManufacturers = candidates == null || candidates.Length == 0;

                if (project.AutoPauseEnabled &&
                    (Runtime.Time - project.RegistrationTime) >= HALF_YEAR_SECONDS &&
                    noManufacturers &&
                    !project.IsProjectClosed && !project.IsProjectHasWinner)
                {
                    project.IsProjectPaused = true;
                    project.CurrentProjectStatus = ProjectStatus.Paused;
                    project.LastActivityTime = currentTime;

                    // Отразим в контракте состояния
                    ProjectState.SetProjectFlags(projectId, project.IsArchived, isPaused: true, project.IsProjectClosed, project.IsProjectHasWinner);
                    ProjectState.SetProjectStatus(projectId, (int)ProjectStatus.Paused);
                    ProjectState.SetLastActivityTime(projectId, Runtime.Time);

                    saveProjectAccountToProjectsAccountStore(projectId, project);
                    VotingCompleted(projectId, "AutoPause", BackerVotesEnum.Positive);
                }
            }
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    public static string[] getProjectStatuses(string projectId)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        string[] statuses = new string[7];
        statuses[0] = project.IsProjectHasWinner ? "HasWinner" : "NoWinner";
        statuses[1] = project.IsProjectClosed ? "Closed" : "Open";
        statuses[2] = project.IsLaunchVotingFinalized ? "LaunchFinalized" : (project.IsLaunchVotingCompleted ? "LaunchVotingCompleted" : "LaunchVotingPending");
        statuses[3] = project.IsProjectPaused ? "Paused" : "Running";
        statuses[4] = project.IsFundraisingCompletionVotingFinalized ? "FundraisingFinalized" : (project.IsFundraisingCompletionVotingCompleted ? "FundraisingVotingCompleted" : "FundraisingVotingPending");
        statuses[5] = "UpdatesInfo(Check_ProjectUpdateVotingFinalized_Map)";
        statuses[6] = project.IsSuccessfulClosureVotingFinalized ? "SuccessfulClosureFinalized" : (project.IsSuccessfulClosureVotingCompleted ? "SuccessfulClosureCompleted" : "SuccessfulClosurePending");
        return statuses;
    }


    public static BigInteger calculateTotalReservedForOffer(string offerId)
    {
        return 0;
    }

    public static bool getProjectStatusAsBoolean(string ProjectId, ProjectStateRequest statusType)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(ProjectId);
        if (project == null) throw new Exception("Project is not registered: " + ProjectId);

        switch (statusType)
        {
            case ProjectStateRequest.HasWinner: return project.IsProjectHasWinner;
            case ProjectStateRequest.IsClosed: return project.IsProjectClosed;
            case ProjectStateRequest.IsApproved: return project.IsLaunchVotingCompleted;
            case ProjectStateRequest.Paused: return project.IsProjectPaused;
            case ProjectStateRequest.LaunchVotingCompleted: return project.IsLaunchVotingCompleted;
            case ProjectStateRequest.FundraisingCompleted: return project.IsFundraisingCompletionVotingCompleted;
            case ProjectStateRequest.UpdatesVotingCompleted: return project.IsProjectUpdatesVotingCompleted;
            case ProjectStateRequest.SuccessfulClosureCompleted: return project.IsSuccessfulClosureVotingCompleted;
            case ProjectStateRequest.PauseVotingCompleted: return project.IsProjectPaused;
            default: throw new Exception("Unknown project status type requested");
        }
    }



    public static bool validateProjectIsLiving(string projectId)
    {
        if (projectId == null) throw new Exception("validateProjectIsLiving call failed: ProjectAddress is not registered");
        if (projectId.Length != 32 && projectId.Length != 64) throw new Exception("validateProjectIsLiving call failed: Invalid ProjectId format");

        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);
        if (project == null) throw new Exception("validateProjectIsLiving call failed: Project is not registered: " + projectId);

        if (project.IsProjectClosed == true) throw new Exception("validateProjectIsLiving call failed: Project is closed");
        if (project.IsProjectHasWinner == true) throw new Exception("validateProjectIsLiving call failed: Project already has winner");
        if (project.IsProjectPaused == true) throw new Exception("validateProjectIsLiving call failed: Project is paused");
        if (project.CurrentProjectStatus == ProjectStatus.Completed) throw new Exception("validateProjectIsLiving call failed: Project is completed ");

        if (project.CurrentProjectStatus == ProjectStatus.Terminated) throw new Exception("validateProjectIsLiving call failed: Project is terminated");

        return true;

    }


    public static void saveToGlobalProjectsLists(ProjectAccount Account)
    {
        if (Account == null) throw new Exception("ProjectAccount is null");

        var bytes = ProjectState.GetGlobalProjectsList();
        string[] arr = bytes is null ? new string[0] : (string[])StdLib.Deserialize(bytes);

        string[] NewProjectsArray = new string[arr.Length + 1];
        for (int i = 0; i < arr.Length; i++) NewProjectsArray[i] = arr[i];
        NewProjectsArray[arr.Length] = StdLib.Serialize(Account);

        ProjectState.SetGlobalProjectsList(StdLib.Serialize(NewProjectsArray));
    }

    public static void removeProjectFromGlobalProjectsLists(ProjectAccount Account)
    {
        if (Account == null) throw new Exception("ProjectAccount is null");

        var bytes = ProjectState.GetGlobalProjectsList();
        if (bytes is null) return;

        string[] arr = (string[])StdLib.Deserialize(bytes);
        if (arr == null || arr.Length == 0) return;

        var res = new Neo.SmartContract.Framework.List<string>();
        for (int i = 0; i < arr.Length; i++)
        {
            string projectAccountJson = arr[i];
            if (string.IsNullOrEmpty(projectAccountJson)) continue;

            ProjectAccount projectAccount = (ProjectAccount)StdLib.Deserialize(projectAccountJson);
            if (projectAccount == null) continue;
            if (projectAccount.projectId != Account.projectId)
                res.Add(projectAccountJson);
        }
        ProjectState.SetGlobalProjectsList(StdLib.Serialize(res));
    }


    public static string[] getSerializedGlobalProjectsPackagesList()
    {
        var bytes = ProjectState.GetGlobalProjectPackagesList();
        if (bytes is null) return new string[0];
        return (string[])StdLib.Deserialize(bytes);
    }

    public static void updateProjectPackage(ProjectPackage package, byte[] projectId)
    {
        try
        {
            if (package == null) throw new ArgumentNullException("ProjectPackage is null");
            if (projectId == null || (projectId.Length != 64 && projectId.Length != 32))
                throw new Exception("Invalid projectId. projectId Lenght is: " + projectId.Length.ToString());

            if (ProjectState.GetRawProjectPackage((ByteString)projectId) != null)
                throw new Exception("Offer document already registered");

            ProjectState.SetRawProjectPackage((ByteString)projectId, StdLib.Serialize(package));
            saveProjectToProjectsAccountStore(package);
        }
        catch (Exception ex)
        {
            throw new Exception("updateProjectPackage: " + ex.Message);
        }
    }

    public static ProjectPackage getProjectPackWNull(string projectId, bool AllowReturnNull)
    {
        if (projectId.Length != 32 && projectId.Length != 64)
            throw new Exception("getProjectPackWNull: Invalid projectId format. Lenght is: " + projectId.Length.ToString());

        byte[] projectId_Key = IFHelper.safeHexToBytes(projectId);
        var raw = ProjectState.GetRawProjectPackage((ByteString)projectId_Key);
        if (raw != null)
        {
            return (ProjectPackage)StdLib.Deserialize(raw);
        }
        else
        {
            if (AllowReturnNull) return null;
            throw new Exception("Project not found");
        }
    }
    public static ProjectPackage getProjectPack(string projectId)
    {
        if (projectId.Length != 32 && projectId.Length != 64)
            throw new Exception("getProjectPackWNull: Invalid projectId format. Lenght is: " + projectId.Length.ToString());

        byte[] projectId_Key = IFHelper.safeHexToBytes(projectId);
        var raw = ProjectState.GetRawProjectPackage((ByteString)projectId_Key);
        if (raw != null)
        {
            return (ProjectPackage)StdLib.Deserialize(raw);
        }
        else
        {
            throw new Exception("Project not found");
        }
    }


    private static void closeProject(string projectId, ProjectCloseReason CloseReason = ProjectCloseReason.Banned)
    {
        if (IsOwner() == false) throw new Exception("Authorization failed");
        if (string.IsNullOrEmpty(projectId)) throw new Exception("projectId is null");
        if (projectId.Length != 64 && projectId.Length != 32) throw new Exception("Invalid projectId" + projectId.Length.ToString());

        ProjectAccount projectAccount = ProjectAccount.getProjectAccount(projectId);
        if (projectAccount == null) throw new Exception("Project not found");

        var creatorRaw = ProjectState.GetRawProjectCreatorAccount(projectAccount.ProjectCreatorAddress);
        var creator = creatorRaw is null ? null : (ProjectCreatorAccount)StdLib.Deserialize(creatorRaw);

        removeProjectFromGlobalProjectsListsByProjectId(projectId);
        ProjectState.SetProjectCloseReason(IFHelper.safeHexToBytes(projectId).ToByteString(), (int)CloseReason);
    }

}