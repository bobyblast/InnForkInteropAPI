using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using System;
using System.ComponentModel;
using System.Numerics;

namespace InnFork.NeoN3;

/// <summary>
/// ���������������� �������� � ������� ��� ��������� InnFork.
/// ����������� InnFork.NeoN3.Adapters.EventDispatcherAdapter ��� ������ ������� �� ���������� ����������.
/// </summary>
public partial class IF_MainGateway : Neo.SmartContract.Framework.SmartContract
{
    // ===== INVESTMENT AGREEMENT EVENTS =====

    public delegate void OnAgreementCreated(byte[] AgreementID, UInt160 investor, UInt160 manufacturer, BigInteger amount);
    public delegate void OnAgreementConfirmed(byte[] agreementId);
    public delegate void OnAgreementCompleted(byte[] agreementId);
    public delegate void OnAgreementDefaulted(byte[] AgreementID);
    public delegate void OnRepaymentMade(byte[] AgreementID, BigInteger amount);
    public delegate void OnInvestmentPaymentMade(byte[] AgreementID, BigInteger amount);

    [DisplayName("AgreementCreated")]
    public static event Action<byte[], UInt160, UInt160, BigInteger> AgreementCreated;

    [DisplayName("AgreementConfirmed")]
    public static event Action<byte[]> AgreementConfirmed;

    [DisplayName("AgreementCompleted")]
    public static event Action<byte[]> AgreementCompleted;

    [DisplayName("AgreementDefaulted")]
    public static event Action<byte[]> AgreementDefaulted;

    [DisplayName("RepaymentMade")]
    public static event Action<byte[], BigInteger> RepaymentMade;

    [DisplayName("InvestmentPaymentMade")]
    public static event Action<byte[], BigInteger> InvestmentPaymentMade;

    // ===== VOTING SYSTEM EVENTS =====

    public delegate void OnProjectLaunchApproval(string ProjectID, bool Approved);
    public delegate void OnFundraisingCompletionApproval(string ProjectID, bool Approved);
    public delegate void OnProjectUpdatesApproval(string ProjectID, bool Approved);
    public delegate void OnManufacturerSelectionApproval(string ProjectID, UInt160 ManufacturerAddress, bool Approved);
    public delegate void OnMilestoneCompletionApproval(string ProjectID, string MilestoneId, bool Approved);
    public delegate void OnProjectPauseResumeVote(string ProjectID, bool IsPause, bool Approved);
    public delegate void OnSuccessfulClosureApproval(string ProjectID, bool Approved);
    public delegate void OnTerminationWithRefundApproval(string ProjectID, bool Approved);
    public delegate void onVoteAbstained(string ProjectID, string VoteType, UInt160 VoterAddress);
    public delegate void OnVoteCasted(string ProjectID, UInt160 voterAddress, int voteValue);
    public delegate void OnVotingStarted(string ProjectID, string VoteType);
    public delegate void OnVotingCompleted(string ProjectID, string VoteType, BackerVotesEnum result);
    public delegate void OnVotingFinalized(string ProjectID, int VoteType);
    public delegate void OnWinnerSelected(string ProjectID, string winnerId);
    public delegate void OnManufacturerSelected(string ProjectID, UInt160 manufacturerAddress);

    [DisplayName("ProjectLaunchApproved")]
    public static event Action<string, bool> ProjectLaunchApproved;

    [DisplayName("FundraisingCompletionApproved")]
    public static event Action<string, bool> FundraisingCompletionApproved;

    [DisplayName("ProjectUpdatesApproved")]
    public static event Action<string, bool> ProjectUpdatesApproved;

    [DisplayName("ManufacturerWinnerSelectionApproved")]
    public static event Action<string, UInt160, bool> ManufacturerWinnerSelectionApproved;

    [DisplayName("MilestoneCompletionApproved")]
    public static event Action<string, string, bool> MilestoneCompletionApproved;

    [DisplayName("ProjectPauseResumeVoted")]
    public static event Action<string, bool, bool> ProjectPauseResumeVoted;

    [DisplayName("SuccessfulClosureApproved")]
    public static event Action<string, bool> SuccessfulClosureApproved;

    [DisplayName("TerminationWithRefundApproved")]
    public static event Action<string, bool> TerminationWithRefundApproved;

    [DisplayName("VoteAbstained")]
    public static event Action<string, string, UInt160> VoteAbstained;

    [DisplayName("VoteCasted")]
    public static event Action<string, UInt160, int> VoteCasted;

    [DisplayName("VotingStarted")]
    public static event Action<string, string> VotingStarted;

    [DisplayName("VotingCompleted")]
    public static event Action<string, string, BackerVotesEnum> VotingCompleted;

    [DisplayName("VotingFinalized")]
    public static event Action<string, int> VotingFinalized;

    [DisplayName("WinnerSelected")]
    public static event Action<string, string> WinnerSelected;

    [DisplayName("ManufacturerSelected")]
    public static event Action<string, UInt160> ManufacturerSelected;

    // ===== VOTE DELEGATION EVENTS =====

    public delegate void OnVoteDelegated(string ProjectID, string delegatorAddress, string delegateAddress, string votingType);
    public delegate void OnVoteDelegationRevoked(string ProjectID, string delegatorAddress, string delegateAddress, string votingType);
    public delegate void OnBulkDelegationRevoked(string ProjectID, string participantAddress, int revokedCount);
    public delegate void OnDelegationIntegrityViolation(string ProjectID, string participantAddress, string violationType, string details);

    [DisplayName("VoteDelegated")]
    public static event Action<string, string, string, string> VoteDelegated;

    [DisplayName("VoteDelegationRevoked")]
    public static event Action<string, string, string, string> VoteDelegationRevoked;

    [DisplayName("BulkDelegationRevoked")]
    public static event Action<string, string, int> BulkDelegationRevoked;

    [DisplayName("DelegationIntegrityViolation")]
    public static event Action<string, string, string, string> DelegationIntegrityViolation;

    // ===== MILESTONE SYSTEM EVENTS =====

    public delegate void OnMilestoneCompleted(string ProjectID, byte stepNumber, bool successful);
    public delegate void OnMilestoneFundingRolledBack(string ProjectID, UInt160 manufacturerAddress, byte stepNumber, string reason, BigInteger amount);
    public delegate void OnMilestoneResetForRestart(string ProjectID, UInt160 manufacturerAddress, byte stepNumber, string reason);

    [DisplayName("MilestoneCompleted")]
    public static event Action<string, byte, bool> MilestoneCompleted;

    [DisplayName("MilestoneFundingRolledBack")]
    public static event Action<string, UInt160, byte, string, BigInteger> MilestoneFundingRolledBack;

    [DisplayName("MilestoneResetForRestart")]
    public static event Action<string, UInt160, byte, string> MilestoneResetForRestart;

    // ===== DISPUTE SYSTEM EVENTS =====

    public delegate void OnDisputeCreated(string disputeId, UInt160 initiator, int disputeType, string description);
    public delegate void OnDisputeStatusChanged(string disputeId, int oldStatus, int newStatus);
    public delegate void OnDisputeStatusUpdated(string disputeId, DisputeStatus newStatus);

    [DisplayName("DisputeCreated")]
    public static event Action<string, UInt160, int, string> DisputeCreated;

    [DisplayName("DisputeStatusChanged")]
    public static event Action<string, int, int> DisputeStatusChanged;

    [DisplayName("DisputeStatusUpdated")]
    public static event Action<string, DisputeStatus> DisputeStatusUpdated;

    // ===== BAN & PENALTY EVENTS =====

    public delegate void OnManufacturerBanned(UInt160 manufacturerAddress, int banReason);
    public delegate void OnBackerBanned(UInt160 backerAddress, int banReason);
    public delegate void OnManufacturerPenalized(UInt160 manufacturerAddress, BigInteger penaltyAmount);
    public delegate void OnManufacturerPenaltyCleared(UInt160 manufacturerAddress, BigInteger clearedAmount);
    public delegate void OnBackerFundsBlocked(UInt160 backerAddress, BigInteger blockedAmount, int blockReason);
    public delegate void OnBackerFundsUnblocked(UInt160 backerAddress, BigInteger unblockedAmount);

    [DisplayName("ManufacturerBanned")]
    public static event Action<UInt160, int> ManufacturerBanned;

    [DisplayName("BackerBanned")]
    public static event Action<UInt160, int> BackerBanned;

    [DisplayName("ManufacturerPenalized")]
    public static event Action<UInt160, BigInteger> ManufacturerPenalized;

    [DisplayName("ManufacturerPenaltyCleared")]
    public static event Action<UInt160, BigInteger> ManufacturerPenaltyCleared;

    [DisplayName("BackerFundsBlocked")]
    public static event Action<UInt160, BigInteger, int> BackerFundsBlocked;

    [DisplayName("BackerFundsUnblocked")]
    public static event Action<UInt160, BigInteger> BackerFundsUnblocked;

    // ===== EMERGENCY & REFUND EVENTS =====

    public delegate void OnEmergencyRefundExecuted(string projectId, BigInteger refundAmount);

    [DisplayName("EmergencyRefundExecuted")]
    public static event Action<string, BigInteger> EmergencyRefundExecuted;

    // ===== GENERAL SYSTEM EVENTS =====

    public delegate void OnProjectSaved(string projectId, UInt160 Author);

    [DisplayName("ProjectSaved")]
    public static event Action<string, UInt160> ProjectSaved;
}
