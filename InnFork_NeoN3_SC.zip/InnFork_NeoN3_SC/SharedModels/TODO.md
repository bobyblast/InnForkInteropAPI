# Common TODO Checklist



## 🚧 In Progress / Deferred
- [ ] Perform a full authorization audit to verify `Runtime.CheckWitness` coverage for every externally callable method (scope too large for this iteration; tracked for dedicated security review).
- [ ] Refactor voting storage interactions (`SetWinnerSelectionVote`, `SetReservedFunds`) to resolve architectural issues highlighted in logic-two modules.
- [ ] Extend the storage contract models with BalanceManager APIs and related helpers (`sc IF Storage/StateStorgageContract_Models.cs`).
- [ ] Implement delegation-cycle detection utilities and comprehensive API tests for the storage contract (`sc IF Storage` TODOs).
- [ ] Finalize manufacturer reservation helpers inside `MiniAdapter/IFMiniAdapter.cs` (getter/setter stubs remain to be completed).

Each completed item references the code updates from this branch; deferred items carry explanatory notes for future planning.
