﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.IF_MainGateway;



namespace InnFork.NeoN3;






////////////////////////////////////////////////////////////////////////////////////////////////////////////////// уникальная часть контракта







public partial class IF_MainGateway


// Project related methods 
{
    public static void safeRefundAllDonations(string projectId)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("safeRefundAllDonations: Authorization failed. Only owner or project author can initiate refunds.");

        if (project.IsProjectHasWinner || project.CurrentProjectStatus == ProjectStatus.Completed)
            throw new Exception("Cannot refund donations for a completed or successful project.");

        if (project.EmergencyRefundInProgress || project.CurrentProjectStatus == ProjectStatus.Terminated)
            throw new Exception("Refund process is already in progress or completed.");

        AcquireLock();
        try
        {
            project.EmergencyRefundInProgress = true;
            project.IsProjectClosed = true;
            project.CurrentProjectStatus = ProjectStatus.Terminated;

            Map<UInt160, BigInteger> amountsToRefund = new Map<UInt160, BigInteger>();
            Map<UInt160, BigInteger> manufacturerReservedTotals = new Map<UInt160, BigInteger>();

            UInt160[] manufacturers = ProjectState.GetManufacturerCandidates(projectId);

            UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
            for (int bi = 0; bi < backers.Length; bi++)
            {
                UInt160 backer = backers[bi];
                if (ProjectState.IsParticipantBanned(projectId, backer)) continue;

                BigInteger donation = ProjectState.GetBackerDonation(projectId, backer);
                if (donation > 0)
                {
                    amountsToRefund[backer] = (amountsToRefund.HasKey(backer) ? amountsToRefund[backer] : 0) + donation;
                    ProjectState.SetBackerDonation(projectId, backer, 0);
                }

                for (int i = 0; i < manufacturers.Length; i++)
                {
                    UInt160 man = manufacturers[i];
                    BigInteger reserved = ProjectState.GetBackerReservation(projectId, backer, man);
                    if (reserved > 0)
                    {
                        amountsToRefund[backer] = (amountsToRefund.HasKey(backer) ? amountsToRefund[backer] : 0) + reserved;

                        BigInteger totalForMan = manufacturerReservedTotals.HasKey(man) ? manufacturerReservedTotals[man] : 0;
                        manufacturerReservedTotals[man] = totalForMan + reserved;

                        ProjectState.SetBackerReservation(projectId, backer, man, 0);
                    }
                }
            }

            for (int i = 0; i < manufacturers.Length; i++)
            {
                UInt160 man = manufacturers[i];
                if (manufacturerReservedTotals.HasKey(man))
                {
                    BigInteger currentReserved = ProjectState.GetReservedFunds(projectId, man);
                    BigInteger newReserved = currentReserved - manufacturerReservedTotals[man];
                    if (newReserved < 0) newReserved = 0;
                    ProjectState.SetReservedFunds(projectId, man, newReserved);
                }
            }

            BigInteger totalRefunded = 0;

            for (int bi = 0; bi < backers.Length; bi++)
            {
                UInt160 backer = backers[bi];
                if (!amountsToRefund.HasKey(backer)) continue;

                BigInteger amount = amountsToRefund[backer];
                if (amount <= 0) continue;

                BackerAccount backerAccount = BackerAccount.getBackerAccount(backer, true);
                backerAccount.FreeBalance += amount;
                BackerAccount.updateExistingBackerAccount(backerAccount);

                ProjectState.SetRefundHistory(projectId, backer, amount);

                totalRefunded += amount;
            }

            project.FLMUSD_TotalProjectBalance = 0;
            project.FLMUSD_PrizeFundBalance = 0;
            project.TotalRefundsProcessed = totalRefunded;
            project.EmergencyRefundInProgress = false;

            ProjectState.SetProjectTotalBalance(projectId, 0);
            ProjectState.SetTotalRefundsProcessed(projectId, totalRefunded);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void allocateFunds(string projectId, UInt160 backer, byte prizeFundPartAllocation)
    {
        if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");
        if (prizeFundPartAllocation > 100) throw new Exception("Prize fund allocation percentage must be between 0 and 100");

        AcquireLock();
        try
        {
            ProjectState.SetConditionalThreshold(projectId, "alloc_" + backer.ToString(), prizeFundPartAllocation);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void reserveBackerFundsForManufacturer(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount)
    {
        if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");
        if (amount <= 0) throw new Exception("Amount must be greater than 0");

        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer))
            throw new Exception("Manufacturer candidate not registered in this project.");

        BackerAccount backerAccount = BackerAccount.getBackerAccount(backer, true);
        if (backerAccount.FreeBalance < amount) throw new Exception("Backer doesn't have enough free funds");

        BigInteger donorAmount = ProjectState.GetBackerDonation(projectId, backer);
        if (donorAmount < amount)
            throw new Exception("Insufficient funds in project's prize fund from this backer to reserve for manufacturer.");

        AcquireLock();
        try
        {
            ProjectState.SetBackerDonation(projectId, backer, donorAmount - amount);

            project.FLMUSD_PrizeFundBalance -= amount;
            if (project.FLMUSD_PrizeFundBalance < 0) project.FLMUSD_PrizeFundBalance = 0;

            BigInteger currReserved = ProjectState.GetReservedFunds(projectId, manufacturer);
            ProjectState.SetReservedFunds(projectId, manufacturer, currReserved + amount);

            BigInteger currBackerRes = ProjectState.GetBackerReservation(projectId, backer, manufacturer);
            ProjectState.SetBackerReservation(projectId, backer, manufacturer, currBackerRes + amount);

            ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


}



public partial class IF_MainGateway // Milestone Template Params
{
    // CRUD через StateStorage
    public static void SetMilestoneBackerVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote, byte StepNumber) =>
        InnFork.NeoN3.ProjectState.SetMilestoneBackerVote(projectId, ManufacturerCandidate, StepNumber, backer, (int)vote);

    public static BackerVotesEnum GetMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber) =>
        (BackerVotesEnum)InnFork.NeoN3.ProjectState.GetMilestoneBackerVote(projectId, ManufacturerCandidate, StepNumber, backer);

    public static void RemoveMilestoneBackerVote(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber) =>
        InnFork.NeoN3.ProjectState.RemoveMilestoneBackerVote(projectId, ManufacturerCandidate, StepNumber, backer);

    public static void ClearMilestoneVotes(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
    {
        InnFork.NeoN3.ProjectState.ClearMilestoneVotes(projectId, ManufacturerCandidate, StepNumber);
    }

    public static void SetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, bool detected, byte StepNumber) =>
        InnFork.NeoN3.ProjectState.SetMilestoneFraudFlag(projectId, ManufacturerCandidate, StepNumber, backer, detected);

    public static bool GetMilestoneFraudFlag(string projectId, UInt160 ManufacturerCandidate, UInt160 backer, byte StepNumber) =>
        InnFork.NeoN3.ProjectState.GetMilestoneFraudFlag(projectId, ManufacturerCandidate, StepNumber, backer);

    public static void ClearMilestoneFraudFlags(string projectId, UInt160 ManufacturerCandidate, byte StepNumber) =>
        InnFork.NeoN3.ProjectState.ClearMilestoneFraudFlags(projectId, ManufacturerCandidate, StepNumber);



    public bool isMilestoneStepStillRunning(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
    {

        MilestoneCompletionVotesStruct milestoneCompletionVotesStruct = (MilestoneCompletionVotesStruct)ProjectState.GetMilestoneCompletionVotesStruct(projectId, ManufacturerCandidate, StepNumber);

        if (milestoneCompletionVotesStruct.isVotingStepComplete) return false;
        if (Runtime.Time > milestoneCompletionVotesStruct.Deadline_UnixTime) return false;
        return true;
    }

    public bool IsMilestoneStepCompletedSuccessfully(string projectId, UInt160 ManufacturerCandidate, byte StepNumber)
    {
        MilestoneCompletionVotesStruct milestoneCompletionVotesStruct = (MilestoneCompletionVotesStruct)ProjectState.GetMilestoneCompletionVotesStruct(projectId, ManufacturerCandidate, StepNumber);

        if (!milestoneCompletionVotesStruct.isVotingStepComplete) return false;
        return milestoneCompletionVotesStruct.IsVotingSuccessful;
    }


}



public partial class IF_MainGateway
// Manufacturer KPI Management
{
    // Управление KPI производителей
    public static void updateManufacturerKPI(string projectId, UInt160 manufacturer, BigInteger deliveryScore, BigInteger qualityScore)
    {
        var project = ProjectAccount.getProjectAccount(projectId);

        if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only project author can update manufacturer KPI");

        // Сохраним qualityScore и рассчитаем tier в state
        ProjectState.SetManufacturerQualityScore(projectId, manufacturer, qualityScore);
        byte reliabilityTier = calculateReliabilityTier(projectId, manufacturer);
        ProjectState.SetManufacturerReliabilityTier(projectId, manufacturer, reliabilityTier);
    }

    // Методы для получения уровня надежности
    public static byte calculateReliabilityTier(string projectId, UInt160 manufacturer)
    {
        BigInteger qualityScore = ProjectState.GetManufacturerQualityScore(projectId, manufacturer);

        // Расчет уровня от 1 до 5 (по аналогии с исходной логикой)
        if (qualityScore < 20) return 1;
        if (qualityScore < 40) return 2;
        if (qualityScore < 60) return 3;
        if (qualityScore < 80) return 4;
        return 5;
    }


    public void SetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, BackerVotesEnum vote) =>
        InnFork.NeoN3.ProjectState.SetWinnerSelectionVote(projectId, backer, ManufacturerCandidate, (int)vote);

    public BackerVotesEnum GetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 ManufacturerCandidate) =>
        (BackerVotesEnum)InnFork.NeoN3.ProjectState.GetWinnerSelectionVote(projectId, backer, ManufacturerCandidate);

    public void SetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate, bool detected) =>
        InnFork.NeoN3.ProjectState.SetWinnerVoteFraudFlag(projectId, ManufacturerCandidate, backer, detected);

    public bool GetWinnerVoteFraudFlag(string projectId, UInt160 backer, UInt160 ManufacturerCandidate) =>
        InnFork.NeoN3.ProjectState.GetWinnerVoteFraudFlag(projectId, ManufacturerCandidate, backer);

    public void ClearWinnerVoteFraudFlags(string projectId, UInt160 ManufacturerCandidate) =>
        InnFork.NeoN3.ProjectState.ClearWinnerVoteFraudFlags(projectId, ManufacturerCandidate);
}








public partial class IF_MainGateway // Milestone Template Params
{

    public static void SetMilestoneTemplateParam(string projectId, string templateId, string key, string value) =>
      InnFork.NeoN3.ProjectState.SetMilestoneTemplateParam(projectId, templateId, key, value);

    public static string GetMilestoneTemplateParam(string projectId, string templateId, string key) =>
        InnFork.NeoN3.ProjectState.GetMilestoneTemplateParam(projectId, templateId, key);

    public static void RemoveMilestoneTemplateParam(string projectId, string templateId, string key) =>
        InnFork.NeoN3.ProjectState.RemoveMilestoneTemplateParam(projectId, templateId, key);

    public static void ClearMilestoneTemplateParams(string projectId, string templateId) =>
        InnFork.NeoN3.ProjectState.ClearMilestoneTemplateParams(projectId, templateId);
}




public partial class IF_MainGateway
{


    public static void voteLaunchProject(string projectId, UInt160 backer, BackerVotesEnum vote)
    {
        const string votingType = "LaunchApproval";

        if (ProjectState.DetectFraudPattern(backer, projectId, votingType))
            throw new Exception("Fraudulent activity detected. Vote rejected.");


        if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

        AcquireLock();
        try
        {
            ProjectState.RecordVote(projectId, votingType, backer, (int)vote);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static bool canSelectWinner(string projectId)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        bool launchOk =
            project.IsLaunchVotingFinalized &&
            (project.CurrentProjectStatus == ProjectStatus.Fundraising ||
             project.CurrentProjectStatus == ProjectStatus.Active ||
             project.CurrentProjectStatus == ProjectStatus.Manufacturing);

        bool fundraisingOk;
        if (project.projectSettings.projectFundingType == ProjectFundingType.AllOrNothing || project.FundraisingCompletionVotingDeadline > 0)
        {
            fundraisingOk = project.IsFundraisingCompletionVotingFinalized && isFundingGoalReached(projectId);
        }
        else
        {
            fundraisingOk = isFundingGoalReached(projectId);
        }

        return launchOk &&
               fundraisingOk &&
               !project.IsProjectClosed &&
               !project.IsProjectPaused &&
               !project.IsProjectHasWinner;
    }

    public static void processProjectsWinner(string projectId, UInt160 FromAddress)
    {
        if (IsOwner() == false && Runtime.CheckWitness(FromAddress) == false) return;

        var bytes = ProjectState.GetGlobalProjectsList();
        if (bytes is null) return;

        string[] projectAccounts = (string[])StdLib.Deserialize(bytes);
        for (int i = 0; i < projectAccounts.Length; i++)
        {
            ProjectAccount iter_currentProjectAccount = (ProjectAccount)StdLib.Deserialize(projectAccounts[i]);
            if (iter_currentProjectAccount == null) continue;

            if (iter_currentProjectAccount.FLMUSD_TotalProjectBalance >= iter_currentProjectAccount.FLMUSD_PrizeFundGoal &&
                canSelectWinner(projectId))
            {
                selectWinnerManufacturer(projectId);
            }
        }
    }

    public static UInt160 selectWinnerManufacturer(string projectId)
    {
        var project = ProjectAccount.getProjectAccount(projectId);

        if (project.IsProjectHasWinner)
            return project.ManufacturerWinnerAddress;

        if (Runtime.Time <= project.FundraisingDeadline && project.FundraisingDeadline > 0)
            throw new Exception("Fundraising deadline has not passed yet.");
        if (Runtime.Time <= project.ManufacturerSelectionVotingDeadline && project.ManufacturerSelectionVotingDeadline > 0)
            throw new Exception("Manufacturer selection voting deadline has not passed yet.");
        if (!isFundingGoalReached(projectId) && project.projectSettings.projectFundingType == ProjectFundingType.AllOrNothing)
            throw new Exception("Funding goal not reached for AllOrNothing project type.");

        UInt160[] candidates = ProjectState.GetManufacturerCandidates(projectId) ?? new UInt160[0];
        if (candidates.Length == 0)
            throw new Exception("No manufacturer candidates to select from.");

        finalizeWinnerSelectionVoting(projectId);
        return project.ManufacturerWinnerAddress;
    }

    public static void calculateWinners(UInt160 FromAddress)
    {
        ByteString listBytes = ProjectState.GetGlobalProjectsList();
        if (listBytes == null) return;

        string[] serializedAccounts = (string[])StdLib.Deserialize(listBytes);
        if (serializedAccounts == null || serializedAccounts.Length == 0) return;


        for (int i = 0; i < serializedAccounts.Length; i++)
        {//TODO /check! deploy error there
            string projectAccountJson = serializedAccounts[i];
            if (projectAccountJson == null || projectAccountJson.Length < 10) continue;

            ProjectAccount project = (ProjectAccount)StdLib.Deserialize(projectAccountJson);
            if (project == null) continue;

            if (!project.IsProjectHasWinner &&
               !project.IsProjectClosed &&
               !project.IsProjectPaused &&
               project.ManufacturerSelectionVotingDeadline > 0 &&
               Runtime.Time >= project.ManufacturerSelectionVotingDeadline &&
               canSelectWinner(project.projectId))
            {
                try { selectWinnerManufacturer(project.projectId); } catch { }
            }
        }
    }


}


public partial class IF_MainGateway // General Voting Finalization
{
    public static bool isFundingGoalReached(string projectId)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);
        return project.FLMUSD_TotalProjectBalance >= project.FLMUSD_PrizeFundGoal;
    }
    public static void collectFeeForProjectAuthor(string projectId, UInt160 ProjectCreatorAddressParam)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        if (ProjectCreatorAddressParam == UInt160.Zero || ProjectCreatorAddressParam != project.ProjectCreatorAddress)
            throw new Exception("Project author address mismatch or invalid.");

        if (project.AuthorSuccessGetFee)
            throw new Exception("Project author has already received the fee.");

        if (!project.IsProjectHasWinner && !(isFundingGoalReached(projectId) && project.projectSettings.projectFundingType == ProjectFundingType.Flexible))
            throw new Exception("Fee can only be collected for successful projects.");

        ProjectCreatorAccount projectCreatorAcc = ProjectCreatorAccount.getProjectCreatorAccount(project.ProjectCreatorAddress);
        if (projectCreatorAcc == null)
            throw new Exception("Project creator account not found.");

        BigInteger feeAmount = 0;
        if (project.CreatorFeePercentage > 0 && project.FLMUSD_TotalProjectBalance > 0)
        {
            feeAmount = (project.FLMUSD_TotalProjectBalance * project.CreatorFeePercentage) / 100;
        }
        feeAmount += project.CreatorFixedReward;

        if (feeAmount <= 0)
        {
            project.AuthorSuccessGetFee = true;
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
            return;
        }

        if (project.FLMUSD_TotalProjectBalance < feeAmount)
            throw new Exception("Insufficient project balance to pay author's fee.");

        AcquireLock();
        try
        {
            project.FLMUSD_TotalProjectBalance -= feeAmount;

            BigInteger stateTotal = ProjectState.GetProjectTotalBalance(projectId);
            ProjectState.SetProjectTotalBalance(projectId, stateTotal - feeAmount);

            projectCreatorAcc.FreeFLMUSDBalance += feeAmount;
            projectCreatorAcc.TotalFLMUSDBalance += feeAmount;
            ProjectCreatorAccount.updateExistingProjectCreatorAccount(project.ProjectCreatorAddress, projectCreatorAcc);

            project.AuthorSuccessGetFee = true;

            ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }
    public static void finalizeWinnerSelectionVoting(string projectId)
    {
        var project = ProjectAccount.getProjectAccount(projectId);
        if (project.IsProjectHasWinner) return;

        bool canFinalize = (project.ManufacturerSelectionVotingDeadline > 0 && Runtime.Time >= project.ManufacturerSelectionVotingDeadline)
                           || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings);
        if (!canFinalize) return;

        UInt160 winner = UInt160.Zero;
        BigInteger maxSuccessfulVotes = -1;

        UInt160[] candidates = ProjectState.GetManufacturerCandidates(projectId) ?? new UInt160[0];
        foreach (UInt160 manufacturerCandidate in candidates)
        {
            CandidateWinnerVotesStruct candidateVotes =
                (CandidateWinnerVotesStruct)ProjectState.GetCandidateWinnerVotes(projectId, manufacturerCandidate);

            if (candidateVotes == null)
            {
                candidateVotes = new CandidateWinnerVotesStruct
                {
                    ProjectSha256_Id = projectId,
                    ManufacturerCandidate = manufacturerCandidate,
                    Sha256Hash_Id = IFHelper.createComplexKey(projectId, manufacturerCandidate),
                    VotingStartTime = Runtime.Time,
                    VotingDuration = project.DefaultVotingDuration,
                    MinimumVotesRequired = project.MinRequiredVotingParticipation
                };
            }

            // Сбор голосов из StateStorage
            BigInteger totalEligible = ProjectState.GetEligibleVotersCount(projectId);
            BigInteger positiveVotes = 0;
            BigInteger negativeVotes = 0;
            BigInteger abstainedVotes = 0;
            BigInteger totalCasted = 0;

            UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
            if (backers != null)
            {
                for (int i = 0; i < backers.Length; i++)
                {
                    UInt160 backer = backers[i];
                    if (!ProjectState.IsBackerEligible(projectId, backer)) continue;

                    BackerVotesEnum vote = (BackerVotesEnum)ProjectState.GetWinnerSelectionVote(projectId, backer, manufacturerCandidate);
                    BigInteger weight = ProjectState.GetBackerVoteWeight(projectId, backer);

                    // Учитываем все поданные голоса, включая Abstained
                    if (vote == BackerVotesEnum.Positive) { positiveVotes += weight; totalCasted += weight; }
                    else if (vote == BackerVotesEnum.Negative) { negativeVotes += weight; totalCasted += weight; }
                    else if (vote == BackerVotesEnum.Abstained) { abstainedVotes += weight; totalCasted += weight; }
                }
            }

            // Параметры порогов и автоприсвоений
            bool autoAssignVoiceless = project.projectSettings != null && project.projectSettings.AutoAssignVoicelessToAbstain;
            bool abstainAsSupport = project.projectSettings != null && project.projectSettings.AutoAbstainVoteAsSupport;
            BigInteger minParticipationPct = project.projectSettings != null ? project.projectSettings.MinRequiredVotingParticipation : 0;
            BigInteger minApprovalPct = project.projectSettings != null ? project.projectSettings.MinApprovalPercentage : 0;

            // Автоприсвоение безголосых
            BigInteger voiceless = totalEligible - totalCasted;
            if (autoAssignVoiceless && voiceless > 0)
            {
                abstainedVotes += voiceless;
                totalCasted += voiceless;
            }

            if (abstainAsSupport)
            {
                positiveVotes += abstainedVotes;
            }

            bool meetsMinParticipation = true;
            if (minParticipationPct > 0 && totalEligible > 0)
            {
                meetsMinParticipation = (totalCasted * 100) >= (totalEligible * minParticipationPct);
            }

            bool isSuccessful = false;
            if (meetsMinParticipation && totalCasted > 0)
            {
                isSuccessful = (positiveVotes * 100) >= (totalCasted * minApprovalPct);
            }

            // Обновляем агрегаты и сохраняем в StateStorage (без локальной карты голосов)
            candidateVotes.PositiveVotesCount = positiveVotes;
            candidateVotes.NegativeVotesCount = negativeVotes;
            candidateVotes.AbstainedVotesCount = abstainedVotes;
            candidateVotes.TotalVotesCount = totalCasted;
            candidateVotes.IsVotingSuccessful = isSuccessful;

            ProjectState.SetCandidateWinnerVotes(projectId, manufacturerCandidate, candidateVotes);

            if (isSuccessful && positiveVotes > maxSuccessfulVotes)
            {
                maxSuccessfulVotes = positiveVotes;
                winner = manufacturerCandidate;
            }
        }

        if (winner != UInt160.Zero)
        {
            AcquireLock();
            try
            {
                project.IsProjectHasWinner = true;
                project.projectSettings.IsWinnerSelectionFinalized = true;
                project.ManufacturerWinnerAddress = winner;

                if (!project.AuthorSuccessGetFee && project.ProjectCreatorAddress != UInt160.Zero)
                {
                    collectFeeForProjectAuthor(projectId, project.ProjectCreatorAddress);
                }
                if (!project.InnForkFeeCollected)
                {
                    // BalanceManagerAPI.collectInnForkFeeFromProject(Runtime.ExecutingScriptHash, projectId);
                }

                paymentPrizeFundToManufacturer(projectId, winner);

                project.CurrentProjectStatus = ProjectStatus.Completed;
                project.IsProjectClosed = true;

                ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, project.IsProjectHasWinner);

                WinnerSelected(projectId, winner.ToString());
                ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }
        else
        {
            project.projectSettings.IsWinnerSelectionFinalized = true;
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
    }
    public static void paymentPrizeFundToManufacturer(string projectId, UInt160 winnerAddress)
    {
        // Валидация входных параметров
        if (winnerAddress == null || winnerAddress.IsZero)
            throw new Exception("Invalid winner manufacturer address");

        var project = ProjectAccount.getProjectAccount(projectId); // Получаем ProjectAccount

        //     var projectStorage = ProjectAccountStorages.For(projectId);

        // Проверка что производитель действительно является победителем
        if (project.ManufacturerWinnerAddress != winnerAddress)
            throw new Exception("Manufacturer is not the project winner");

        // Проверка статуса проекта
        if (!project.IsProjectHasWinner)
            throw new Exception("Project does not have a winner selected");

        // Проверка наличия средств в призовом фонде
        if (project.FLMUSD_PrizeFundBalance <= 0)
            throw new Exception("Prize fund is empty");

        // Получение аккаунта производителя-победителя
        ManufacturerAccount winnerAccount = ManufacturerAccount.getManufacturerAccount(winnerAddress);

        // Расчет суммы к выплате (может включать вычеты за комиссии)
        BigInteger paymentAmount = project.FLMUSD_PrizeFundBalance;
        BigInteger feeAmount = 0;

        // Расчет комиссии создателя проекта если настроена
        if (project.CreatorFeePercentage > 0)
        {
            feeAmount = (paymentAmount * project.CreatorFeePercentage) / 100;
            paymentAmount -= feeAmount;
        }

        // Добавление фиксированной награды создателю
        if (project.CreatorFixedReward > 0)
        {
            if (paymentAmount >= project.CreatorFixedReward)
            {
                feeAmount += project.CreatorFixedReward;
                paymentAmount -= project.CreatorFixedReward;
            }
        }

        AcquireLock();
        try
        {
            // Перевод призового фонда победителю
            if (paymentAmount > 0)
            {
                winnerAccount.FreeBalance += paymentAmount;
                winnerAccount.TotalBalance += paymentAmount;

                // Увеличение репутации за победу в проекте
                BigInteger reputationBonus = paymentAmount / 10000; // 0.01% от выигрыша
                winnerAccount.ReputationScore += reputationBonus;

                ManufacturerAccount.updateExistingManufacturerAccount(winnerAccount);
            }

            // Выплата комиссии создателю проекта
            if (feeAmount > 0 && !project.AuthorSuccessGetFee)
            {
                ProjectCreatorAccount authorAccount = ProjectCreatorAccount.getProjectCreatorAccount(project.ProjectCreatorAddress);
                if (authorAccount != null)
                {
                    authorAccount.FreeFLMUSDBalance += feeAmount;
                    authorAccount.TotalFLMUSDBalance += feeAmount;
                    ProjectCreatorAccount.updateExistingProjectCreatorAccount(project.ProjectCreatorAddress, authorAccount);

                    project.AuthorSuccessGetFee = true;
                }
            }

            // Обновление балансов проекта
            project.FLMUSD_PrizeFundBalance = 0;
            project.FLMUSD_TotalProjectBalance -= (paymentAmount + feeAmount);

            // Обновление статуса проекта
            if (project.CurrentProjectStatus != ProjectStatus.Completed)
            {
                project.CurrentProjectStatus = ProjectStatus.Completed;
            }

            // Сохранение изменений проекта
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }
}


public partial class IF_MainGateway // Voting Core Internal Methods
{

    // Методы для многоуровневого голосования
    public static void setVoterTier(string projectId, string voteId, UInt160 voterAddress, byte tierLevel)
    {
        if (!Runtime.CheckWitness(voterAddress))
            throw new Exception("Only voter can set tier level");

        // mini-adapter
        ProjectState.SetMultiTierVoting(projectId, voteId, voterAddress, tierLevel);
    }


    /// <summary>
    /// Обёртка под mini-adapter для разрешения делегата.
    /// Параметр delegationMap не используется, сохранён для совместимости сигнатуры.
    /// </summary>
    public static UInt160 getFinalDelegateForVoting(string projectId, Map<UInt160, UInt160> delegationMap, UInt160 backerAddress)
    {
        return ProjectState.ResolveFinalDelegate(projectId, "Generic", backerAddress);
    }

    // Методы для дедлайнов и уведомлений
    public static void setVotingReminder(string projectId, int voteType, ulong reminderTimestamp)
    {
        var project = ProjectAccount.getProjectAccount(projectId);
        if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only project author can set voting reminders");

        ProjectState.SetVotingReminderTimestamp(projectId, voteType, reminderTimestamp);
    }

    public static void sendDeadlineNotifications(string projectId, int voteType)
    {
        var project = ProjectAccount.getProjectAccount(projectId);
        if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only project author can send deadline notifications");

        // mini-adapter: здесь нет перечисления участников в state, оставляем как no-op,
        // при необходимости уведомления должны рассылаться off-chain, используя GetNotificationPreference.
        ulong reminderTimestamp = ProjectState.GetVotingReminderTimestamp(projectId, voteType);
        _ = reminderTimestamp; // подавить предупреждение
    }


    public static void updateVotingTimeParameters(string projectId, string votingTypeAsString, ulong newDeadline)
    {
        var project = ProjectAccount.getProjectAccount(projectId);

        if (!Runtime.CheckWitness(project.ProjectCreatorAddress) && !(project.DirectInnForkProjectManagement && IsOwner()))
            throw new Exception("Authorization failed to update voting time parameters.");

        AcquireLock();
        try
        {
            if (votingTypeAsString == "LaunchApproval") project.LaunchVotingDeadline = newDeadline;
            else if (votingTypeAsString == "FundraisingCompletion") project.FundraisingCompletionVotingDeadline = newDeadline;
            else if (votingTypeAsString == "Fundraising") project.FundraisingDeadline = newDeadline;
            else if (votingTypeAsString == "SuccessfulClosure") project.SuccessfulClosureVotingDeadline = newDeadline;
            else if (votingTypeAsString == "PauseResume") project.PauseResumeVotingDeadline = newDeadline;
            else if (votingTypeAsString == "ManufacturerSelection") project.ManufacturerSelectionVotingDeadline = newDeadline;
            else if (votingTypeAsString == "TerminationWithRefund") project.TerminationWithRefundVotingDeadline = newDeadline;
            else if (votingTypeAsString == "FundraisingIncrease") project.FundraisingIncreaseVotingDeadline = newDeadline;
            else throw new Exception("Unknown voting type for deadline update: " + votingTypeAsString);

            // синхронизуем с state
            ProjectState.SetVotingDeadline(projectId, votingTypeAsString, newDeadline);

            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void configureVotingSystem(string projectId, BigInteger minRequiredParticipationPercent, BigInteger minApprovalPercent)
    {
        var project = ProjectAccount.getProjectAccount(projectId);

        if (!Runtime.CheckWitness(project.ProjectCreatorAddress) && !(project.DirectInnForkProjectManagement && IsOwner()))
            throw new Exception("Authorization failed to configure voting system.");

        if (minRequiredParticipationPercent < 0 || minRequiredParticipationPercent > 100)
            throw new Exception("Minimum required participation percentage must be between 0 and 100.");
        if (minApprovalPercent < 0 || minApprovalPercent > 100)
            throw new Exception("Minimum approval percentage must be between 0 and 100.");

        AcquireLock();
        try
        {
            project.MinRequiredVotingParticipation = minRequiredParticipationPercent;
            project.MinApprovalPercentage = minApprovalPercent;

            if (project.projectSettings == null) project.projectSettings = new ProjectSettings();
            project.projectSettings.MinRequiredVotingParticipation = minRequiredParticipationPercent;
            project.projectSettings.MinApprovalPercentage = minApprovalPercent;

            // синхронизируем конфигурацию голосования в state (используем текущие флаги из проекта)
            ProjectState.SetVotingConfiguration(projectId, minRequiredParticipationPercent, minApprovalPercent, project.AutoAssignVoicelessToAbstain, project.AutoAbstainVoteAsSupport);

            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }



}


public partial class IF_MainGateway // Referral System
{
    public static void registerReferrer(string projectId, UInt160 backerAddress, UInt160 referrerAddress)
    {

        if (!Runtime.CheckWitness(backerAddress))
            throw new Exception("Only the backer can register their referrer.");

        // Проверяем, что проект существует (опционально, но полезно)
        var project = ProjectAccount.getProjectAccount(projectId);
        if (project == null)
            throw new Exception("Project not found.");

        // Нельзя указать себя же реферером
        if (referrerAddress == backerAddress)
            throw new Exception("Referrer cannot be the same as backer.");

        // Уже зарегистрирован?
        if (ProjectState.GetReferrer(projectId, backerAddress) != UInt160.Zero)
            throw new Exception("Referrer is already registered for this backer.");

        // Запись в стейт-контракт
        ProjectState.SetReferrer(projectId, backerAddress, referrerAddress);

        // Обновим время активности проекта (не обязательно, но полезно для аналитики)
        ProjectState.SetLastActivityTime(projectId, Runtime.Time);
    }

    public static void distributeReferralReward(string projectId, UInt160 referrerAddress, BigInteger amount)
    {
        // Псевдокод:
        // 1) Валидируем входные данные (адрес, сумма)
        // 2) Получаем проект и проверяем достаточность средств у проекта
        // 3) Определяем тип реферера (бэкер или автор проекта), начисляем награду на глобальные аккаунты
        // 4) Обновляем локальные балансы проекта (Total/PrizeFund)
        // 5) Отражаем изменения в контракте состояния (ProjectState.SetProjectTotalBalance/SetLastActivityTime)
        // 6) Сохраняем проект и освобождаем блокировку

        if (referrerAddress == null || referrerAddress.IsZero)
            throw new Exception("Invalid referrer address");

        if (amount <= 0)
            throw new Exception("Reward amount must be positive");

        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);
        if (project == null)
            throw new Exception("Project not found.");

        // Проверка достаточно ли средств у проекта
        if (project.FLMUSD_TotalProjectBalance < amount)
            throw new Exception("Insufficient project balance for referral reward");

        // Попытка получить аккаунт бэкера-реферера
        BackerAccount referrerAccount = BackerAccount.getBackerAccount(referrerAddress, false);
        ProjectCreatorAccount creatorAccount = null;

        if (referrerAccount == null)
        {
            // Если это не бэкер — пробуем как автора проекта
            creatorAccount = ProjectCreatorAccount.getProjectCreatorAccount(referrerAddress);
            if (creatorAccount == null)
                throw new Exception("Referrer account not found");
        }

        AcquireLock();
        try
        {
            // Начисление награды рефереру
            if (referrerAccount != null)
            {
                referrerAccount.FreeBalance += amount;
                referrerAccount.TotalBalance += amount;
                BackerAccount.updateExistingBackerAccount(referrerAccount);
            }
            else
            {
                creatorAccount.FreeFLMUSDBalance += amount;
                creatorAccount.TotalFLMUSDBalance += amount;
                ProjectCreatorAccount.updateExistingProjectCreatorAccount(referrerAddress, creatorAccount);
            }

            // Обновление балансов проекта (локальный объект)
            project.FLMUSD_TotalProjectBalance -= amount;

            // Если выплата из призового фонда — уменьшаем его при наличии средств
            if (project.FLMUSD_PrizeFundBalance >= amount)
            {
                project.FLMUSD_PrizeFundBalance -= amount;
            }

            // Отражаем изменения в контракте состояния
            BigInteger stateTotal = ProjectState.GetProjectTotalBalance(projectId);
            ProjectState.SetProjectTotalBalance(projectId, stateTotal - amount);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            // Сохраняем проект
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

}



public partial class IF_MainGateway // Milestone Templates
{
    /*    public static void createMilestoneFromTemplate(UInt160 manufacturerAddress, string projectId,
                   byte stepNumber, string templateType, BigInteger customAmount)
        {
            if (!Runtime.CheckWitness(manufacturerAddress))
                throw new Exception("Only manufacturer can create milestone from template");

            ProjectAccount project = getProjectAccount(projectId);
            if (project == null) throw new Exception("Project not found");

            if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
                throw new Exception("Manufacturer not registered in project");

            MilestoneTemplate template = getMilestoneTemplate(project, manufacturerAddress, stepNumber, templateType);
            if (template == null) throw new Exception("Template not found");

            BigInteger amount = customAmount > 0 ? customAmount : template.RequestedAmount;

            createMilestoneRequest(
                projectId,
                manufacturerAddress,
                stepNumber,
                template.Name,
                template.Description,
                amount,
                Runtime.Time + template.Duration,
                project.projectSettings.DefaultVotingDuration,
                project.projectSettings.MinRequiredVotingParticipation
            );

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
    */


    public static void setBillingProductBuyContractCallbackAddressOwner(string projectId, UInt160 manufacturerAddress, UInt160 callbackAddress) //OK
    {
        if (!Runtime.CheckWitness(manufacturerAddress))
            throw new Exception("manufacturer address mismatch");

        var project = ProjectAccount.getProjectAccount(projectId);

        AcquireLock();
        try
        {

            //     project.BillingProductBuyContractAddressOwner_Map[manufacturerAddress] = callbackAddress;

            ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    // Архивирование проекта
    public static void archiveProject(string projectId)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Only project author can archive the project");

        if (!project.IsProjectClosed)
            throw new Exception("Only closed projects can be archived");

        AcquireLock();
        try
        {
            project.IsArchived = true;
            project.ProjectArchivingTime = Runtime.Time;

            // Отразим флаги в контракте состояния
            ProjectState.SetProjectFlags(
                projectId,
                isArchived: true,
                isPaused: project.IsProjectPaused,
                isClosed: project.IsProjectClosed,
                hasWinner: project.IsProjectHasWinner
            );

            ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    // Управление активностью проекта
    public static void updateProjectActivityScore(string projectId)
    {
        ulong currentTime = Runtime.Time;

        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        ulong last = project.LastActivityTime > 0 ? project.LastActivityTime : ProjectState.GetLastActivityTime(projectId);
        ulong daysSinceLastActivity = (currentTime - last) / 86400;

        AcquireLock();
        try
        {
            if (daysSinceLastActivity > 30)
            {
                project.ProjectActivityScore = project.ProjectActivityScore > 10 ? project.ProjectActivityScore - 10 : 0;
            }
            else
            {
                project.ProjectActivityScore += 5;
            }

            project.LastActivityTime = currentTime;

            // Зеркалим в контракте состояния
            ProjectState.SetProjectActivityScore(projectId, (BigInteger)project.ProjectActivityScore);
            ProjectState.SetLastActivityTime(projectId, currentTime);

            ProjectAccount.saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }



    // метод для проверки регистрации производителя-кандидата
    public static bool isManufacturerCandidateRegistered(string projectId, UInt160 manufacturerId)
    {
        return ProjectState.IsManufacturerRegistered(projectId, manufacturerId);
    }

    public static bool canWithdrawFromProject(string projectId, UInt160 backer)
    {
        ProjectAccount project = ProjectAccount.getProjectAccount(projectId);

        if (!Runtime.CheckWitness(backer))
            return false;

        if (project.IsProjectClosed || project.CurrentProjectStatus == ProjectStatus.Terminated || project.CurrentProjectStatus == ProjectStatus.Paused)
            return false;

        // Было: projectStorage.Backes_ToPrizeFundDonation_Map
        if (ProjectState.GetBackerDonation(projectId, backer) <= 0)
            return false;

        BigInteger multiplier = project.projectSettings.PrizeFundExcessWithdrawalMultiplier > 0
            ? project.projectSettings.PrizeFundExcessWithdrawalMultiplier
            : 1;

        if (project.FLMUSD_PrizeFundBalance > project.FLMUSD_PrizeFundGoal * multiplier)
        {
            if (Runtime.Time < (project.LastActivityTime + project.projectSettings.WithdrawalTimeout))
            {
                return false;
            }
            return true;
        }

        if (project.CurrentProjectStatus == ProjectStatus.Terminated && !project.IsProjectHasWinner)
        {
            return true;
        }

        return false;
    }

}
