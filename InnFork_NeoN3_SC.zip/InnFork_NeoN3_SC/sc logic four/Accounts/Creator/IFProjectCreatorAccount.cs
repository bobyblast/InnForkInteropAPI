using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;

// обасть работы с предложением проекта и аккаунтом автора 

// TODO: добавть фенкционал списание средств со счёта создателя проекта за публикацию проектного предложения\проекта


public partial class ProjectCreatorAccount
{
    public ProjectCreatorAccount(UInt160 wallet)
    {
        WalletAddress = wallet;
    }

    public static ProjectCreatorAccount getProjectCreatorAccount(UInt160 projectCreatorAccount)
    {
        var raw = ProjectState.GetRawProjectCreatorAccount(projectCreatorAccount);
        if (raw is null) return null;
        return (ProjectCreatorAccount)StdLib.Deserialize(raw);
    }
    public static void updateExistingProjectCreatorAccount(UInt160 CallerAddress, ProjectCreatorAccount account)
    {
        if (ProjectState.GetRawProjectCreatorAccount(account.WalletAddress) == null) throw new Exception("Project creator account not found");

        ProjectState.SetRawProjectCreatorAccount(account.WalletAddress, StdLib.Serialize(account));
    }
    public static ProjectCreatorAccount createProjectCreatorAccount(UInt160 projectCreatorAddress, string publicKey)
    {
        if (projectCreatorAddress.Length != 20) throw new Exception("Invalid address format");

        if (!Runtime.CheckWitness(projectCreatorAddress)) throw new Exception("Authorization failed");

        if (ProjectState.GetRawProjectCreatorAccount(projectCreatorAddress) != null)
            throw new Exception("Project creator account already exists");

        if (projectCreatorAddress != IFHelper.pubKeyToAddress(publicKey.ToByteArray())) throw new Exception("Address and public key_documentIdSha256 not match");

        ProjectCreatorAccount newProjectCreatorAccount = new ProjectCreatorAccount(projectCreatorAddress)
        {
            TotalFLMUSDBalance = 0,
            FreeFLMUSDBalance = 0,
            PublicKey = publicKey
        };

        ProjectState.SetRawProjectCreatorAccount(projectCreatorAddress, StdLib.Serialize(newProjectCreatorAccount));

        return newProjectCreatorAccount;
    }
}