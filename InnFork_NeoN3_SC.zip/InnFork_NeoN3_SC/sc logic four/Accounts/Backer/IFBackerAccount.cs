using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;


public partial class BackerAccount
{

    public BackerAccount()
    {
    }


    internal static void updateExistingBackerAccount(BackerAccount account)
    {
        var exists = ProjectState.GetRawBackerAccount(account.BackerWalletAddress);
        if (exists == null)
        {
            throw new Exception("BackerAccount not found");
        }
        else
        {
            ProjectState.SetRawBackerAccount(account.BackerWalletAddress, StdLib.Serialize(account));
        }
    }

    public static BackerAccount getBackerAccount(UInt160 backerAddress, bool ExceptionIfNull)
    {
        var raw = ProjectState.GetRawBackerAccount(backerAddress);
        if (raw is null)
        {
            if (ExceptionIfNull) throw new Exception("BackerAccount not found");
            return null;
        }
        return (BackerAccount)StdLib.Deserialize(raw);
    }

}