using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

using static InnFork.NeoN3.InnForkProjectStateStorage.IF_Constants;

namespace InnFork.NeoN3;

public static class ProjectAccountStorages
{
    private const byte PFX_Project = 0x70;

    private enum Sub : byte
    {
        // Updates
        ProjectUpdatesVotingDeadlines = 0x01,
        ProjectUpdateVotingFinalized = 0x05,
        ActiveProjectUpdateVotings = 0x15,
        ProjectUpdatesFinalPositive = 0x11,
        ProjectUpdatesFinalNegative = 0x12,
        ProjectUpdatesFinalAbstained = 0x13,
        ProjectUpdatesFinalTotal = 0x14,
        ComplexBackerUpdateVotes = 0x1C,
        ApprovedUpdates = 0xA1,

        // Donations/reservations
        BackesToPrizeFundDonation = 0x21,
        ManufacturerReservedFunds = 0x22,
        Complex_ReservedDonateValue = 0x92,

        // Voting weights/quality
        ManufacturerQualityScores = 0x30,
        ManufacturerVoteWeights = 0x31,
        BackerVoteWeights = 0x32,
        ManufacturerReliabilityTier = 0x04,

        // Milestones
        MilestoneCompletionStructs = 0x40,

        // Fraud / activity
        LastVoteTimestamp = 0x60,
        VoteSwitchingCount = 0x61,
        SuspiciousActivityScore = 0x62,

        // Notifications / referrals / analytics
        NotificationPreferences = 0x76,
        VotingReminderTimestamps = 0x83,
        DeadlineNotificationSent = 0x84,
        ReferrerByBacker = 0x80,
        ReferralRewards = 0x81,
        DailyParticipationStats = 0x89,

        // Bans / penalties
        BannedManufacturers = 0x72,
        BannedBackers = 0x73,
        ManufacturerPenalties = 0x86,
        PenaltyTimestamps = 0x87,

        // Conditional voting and tiers
        ConditionalVotingRules = 0x88,
        VoteWeightByTier = 0xC0,
        ConditionalThresholds = 0xC1,
        MultiTierVoting_Nested = 0x82,

        // Winner selection
        Complex_CandidateWinnerVoteStruct = 0x91
    }

    private static byte[] BuildPrefix(string projectId, Sub sub)
    {
        var head = new byte[] { PFX_Project, (byte)sub };
        var pid = StdLib.Serialize(projectId);
        var res = new byte[head.Length + pid.Length];
        for (int i = 0; i < head.Length; i++) res[i] = head[i];
        for (int i = 0; i < pid.Length; i++) res[head.Length + i] = pid[i];
        return res;
    }

    public readonly struct Handle
    {
        private readonly string _projectId;
        public Handle(string projectId)
        {
            _projectId = projectId;
        }

        // Prize fund / reservations
        public StorageBackedMap<UInt160, BigInteger> Backes_ToPrizeFundDonation_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.BackesToPrizeFundDonation)));

        public StorageBackedMap<UInt160, BigInteger> Manufacturer_ReservedFundsValue_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ManufacturerReservedFunds)));

        public StorageBackedMap<string, BigInteger> ComplexKey_ManufacturerAddr_BackerAddr_ToReservedDonateValue_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.Complex_ReservedDonateValue)));

        // Updates
        public StorageBackedMap<string, ulong> ProjectUpdatesVotingDeadlines_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ProjectUpdatesVotingDeadlines)));

        public StorageBackedMap<string, bool> ProjectUpdateVotingFinalized_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ProjectUpdateVotingFinalized)));

        public StorageBackedMap<string, bool> ActiveProjectUpdateVotings_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ActiveProjectUpdateVotings)));

        public StorageBackedMap<string, BigInteger> ProjectUpdatesFinalPositiveVotes_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ProjectUpdatesFinalPositive)));

        public StorageBackedMap<string, BigInteger> ProjectUpdatesFinalNegativeVotes_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ProjectUpdatesFinalNegative)));

        public StorageBackedMap<string, BigInteger> ProjectUpdatesFinalAbstainedVotes_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ProjectUpdatesFinalAbstained)));

        public StorageBackedMap<string, BigInteger> ProjectUpdatesFinalTotalParticipated_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ProjectUpdatesFinalTotal)));

        public StorageBackedMap<string, BackerVotesEnum> complex_UInt160_Backer_UInt256_ProjectUpdates_EnumVotes_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ComplexBackerUpdateVotes)));

        public StorageBackedMap<string, bool> ApprovedUpdates_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ApprovedUpdates)));

        // Winner selection
        public StorageBackedMap<string, CandidateWinnerVotesStruct> ComplexKey_ManufacturerAddr_BackerAddr_VoteStructValue_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.Complex_CandidateWinnerVoteStruct)));

        // Milestones
        public StorageBackedMap<string, MilestoneCompletionVotesStruct> Complex_Manufacturer_StepNumberByte_MilestoneCompletionVotingSctuctValue_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.MilestoneCompletionStructs)));

        // Fraud / activity
        public StorageBackedMap<UInt160, ulong> LastVoteTimestamp_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.LastVoteTimestamp)));

        public StorageBackedMap<UInt160, int> VoteSwitchingCount_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.VoteSwitchingCount)));

        public StorageBackedMap<UInt160, BigInteger> SuspiciousActivityScore_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.SuspiciousActivityScore)));

        public StorageBackedMap<ulong, BigInteger> dailyParticipationStats_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.DailyParticipationStats)));

        // Notifications / referrals
        public StorageBackedMap<UInt160, bool> NotificationPreferences_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.NotificationPreferences)));

        public StorageBackedMap<int, ulong> votingReminderTimestamps_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.VotingReminderTimestamps)));

        public StorageBackedMap<UInt160, bool> deadlineNotificationSent_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.DeadlineNotificationSent)));

        public StorageBackedMap<UInt160, UInt160> referrerByBacker_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ReferrerByBacker)));

        public StorageBackedMap<UInt160, BigInteger> referralRewards_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ReferralRewards)));

        // Bans / penalties
        public StorageBackedMap<UInt160, BanReason> BannedManufacturers_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.BannedManufacturers)));

        public StorageBackedMap<UInt160, BanReason> BannedBackers_Map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.BannedBackers)));

        public StorageBackedMap<UInt160, BigInteger> manufacturerPenalties_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ManufacturerPenalties)));

        public StorageBackedMap<UInt160, ulong> PenaltyTimestamps_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.PenaltyTimestamps)));

        // Weights / quality
        public StorageBackedMap<UInt160, BigInteger> ManufacturerQualityScores
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ManufacturerQualityScores)));

        public StorageBackedMap<UInt160, BigInteger> ManufacturerVoteWeights
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ManufacturerVoteWeights)));

        public StorageBackedMap<UInt160, BigInteger> BackerVoteWeights
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.BackerVoteWeights)));

        public StorageBackedMap<UInt160, byte> ManufacturerReliabilityTier
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ManufacturerReliabilityTier)));

        // Conditional voting and tiers
        public StorageBackedMap<string, bool> conditionalVotingRules_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ConditionalVotingRules)));

        public StorageBackedMap<string, BigInteger> voteWeightByTier_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.VoteWeightByTier)));

        public StorageBackedMap<string, BigInteger> conditionalThresholds_map
            => new(new StorageMap(Storage.CurrentContext, BuildPrefix(_projectId, Sub.ConditionalThresholds)));

        public StorageBackedNestedMap<string, UInt160, byte> multiTierVoting_map
            => new(BuildPrefix(_projectId, Sub.MultiTierVoting_Nested));
    }

    public static Handle For(string projectId)
    {
        if (projectId is null || (projectId.Length != 32 && projectId.Length != 64))
            throw new Exception("Invalid projectId format");
        return new Handle(projectId);
    }
}