using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;

namespace InnFork.NeoN3
{
    public sealed class StorageBackedMap<TKey, TValue>
    {
        private readonly StorageMap _map;

        public StorageBackedMap(StorageMap map)
        {
            _map = map;
        }

        private static ByteString EncKey(TKey key) => StdLib.Serialize(key);
        private static ByteString EncVal(TValue value) => StdLib.Serialize(value);
        private static TKey DecKey(ByteString bs) => (TKey)StdLib.Deserialize(bs);
        private static TValue DecVal(ByteString bs) => (TValue)StdLib.Deserialize(bs);

        public TValue this[TKey key]
        {
            get
            {
                var raw = _map.Get(EncKey(key));
                if (raw is null) throw new Exception("key not found");
                return DecVal(raw);
            }
            set
            {
                _map.Put(EncKey(key), EncVal(value));
            }
        }

        public bool HasKey(TKey key) => _map.Get(EncKey(key)) != null;

        public bool Remove(TKey key)
        {
            var k = EncKey(key);
            if (_map.Get(k) is null) return false;
            _map.Delete(k);
            return true;
        }

        public void Clear()
        {
            var it = _map.Find(FindOptions.KeysOnly);
            while (it.Next())
            {
                var k = (ByteString)it.Value;
                _map.Delete(k);
            }
        }

        public TKey[] Keys
        {
            get
            {
                int count = 0;
                var itCount = _map.Find(FindOptions.KeysOnly);
                while (itCount.Next()) count++;

                TKey[] result = new TKey[count];
                int i = 0;
                var it = _map.Find(FindOptions.KeysOnly);
                while (it.Next())
                {
                    result[i++] = DecKey((ByteString)it.Value);
                }
                return result;
            }
        }

        public TValue[] Values
        {
            get
            {
                int count = 0;
                var itCount = _map.Find(FindOptions.KeysOnly);
                while (itCount.Next()) count++;

                TValue[] result = new TValue[count];
                int i = 0;
                var it = _map.Find(FindOptions.None);
                while (it.Next())
                {
                    result[i++] = DecVal((ByteString)it.Value);
                }
                return result;
            }
        }

        public int Count
        {
            get
            {
                int c = 0;
                var it = _map.Find(FindOptions.KeysOnly);
                while (it.Next()) c++;
                return c;
            }
        }
    }

    public sealed class StorageBackedNestedMap<TOuterKey, TInnerKey, TValue>
    {
        private readonly byte[] _basePrefix;
        private readonly byte[] _outerIndexPrefix;

        public StorageBackedNestedMap(byte[] basePrefix)
        {
            _basePrefix = basePrefix;
            _outerIndexPrefix = Concat(basePrefix, new byte[] { 0xFF });
        }

        private static byte[] Concat(byte[] a, byte[] b)
        {
            var r = new byte[a.Length + b.Length];
            for (int i = 0; i < a.Length; i++) r[i] = a[i];
            for (int i = 0; i < b.Length; i++) r[a.Length + i] = b[i];
            return r;
        }

        private static ByteString EncOuter(TOuterKey x) => StdLib.Serialize(x);
        private static ByteString EncInner(TInnerKey x) => StdLib.Serialize(x);
        private static ByteString EncVal(TValue x) => StdLib.Serialize(x);

        private static TOuterKey DecOuter(ByteString x) => (TOuterKey)StdLib.Deserialize(x);
        private static TInnerKey DecInner(ByteString x) => (TInnerKey)StdLib.Deserialize(x);
        private static TValue DecVal(ByteString x) => (TValue)StdLib.Deserialize(x);

        private StorageMap InnerMap(TOuterKey outer)
        {
            var pfx = Concat(_basePrefix, (byte[])EncOuter(outer));
            return new StorageMap(Storage.CurrentContext, pfx);
        }

        private StorageMap OuterIndex() => new StorageMap(Storage.CurrentContext, _outerIndexPrefix);

        public void Set(TOuterKey outer, TInnerKey inner, TValue value)
        {
            var inn = InnerMap(outer);
            inn.Put(EncInner(inner), EncVal(value));
            OuterIndex().Put(EncOuter(outer), (ByteString)"1");
        }

        public TValue Get(TOuterKey outer, TInnerKey inner)
        {
            var inn = InnerMap(outer);
            var raw = inn.Get(EncInner(inner));
            if (raw is null) throw new Exception("key not found");
            return DecVal(raw);
        }

        public bool HasKey(TOuterKey outer, TInnerKey inner)
        {
            var inn = InnerMap(outer);
            return inn.Get(EncInner(inner)) != null;
        }

        public bool HasOuterKey(TOuterKey outer)
        {
            return OuterIndex().Get(EncOuter(outer)) != null;
        }

        public bool Remove(TOuterKey outer, TInnerKey inner)
        {
            var inn = InnerMap(outer);
            var key = EncInner(inner);
            if (inn.Get(key) is null) return false;
            inn.Delete(key);
            return true;
        }

        public void ClearOuter(TOuterKey outer)
        {
            var inn = InnerMap(outer);
            var iterator = inn.Find(FindOptions.KeysOnly);
            while (iterator.Next())
            {
                var key = (ByteString)iterator.Value;
                inn.Delete(key);
            }
        }

        public TInnerKey[] InnerKeys(TOuterKey outer)
        {
            int count = 0;
            var innCount = InnerMap(outer);
            var itCount = innCount.Find(FindOptions.KeysOnly);
            while (itCount.Next()) count++;

            TInnerKey[] result = new TInnerKey[count];
            int i = 0;
            var inn = InnerMap(outer);
            var it = inn.Find(FindOptions.KeysOnly);
            while (it.Next())
            {
                result[i++] = DecInner((ByteString)it.Value);
            }
            return result;
        }

        public TOuterKey[] OuterKeys()
        {
            int count = 0;
            var idxCount = OuterIndex();
            var itCount = idxCount.Find(FindOptions.KeysOnly);
            while (itCount.Next()) count++;

            TOuterKey[] result = new TOuterKey[count];
            int i = 0;
            var idx = OuterIndex();
            var it = idx.Find(FindOptions.KeysOnly);
            while (it.Next())
            {
                result[i++] = DecOuter((ByteString)it.Value);
            }
            return result;
        }

        public TOuterKey[] Keys => OuterKeys();

        public InnerProxy this[TOuterKey outer] => new InnerProxy(this, outer);

        public sealed class InnerProxy
        {
            private readonly StorageBackedNestedMap<TOuterKey, TInnerKey, TValue> _owner;
            private readonly TOuterKey _outer;

            public InnerProxy(StorageBackedNestedMap<TOuterKey, TInnerKey, TValue> owner, TOuterKey outer)
            {
                _owner = owner;
                _outer = outer;
            }

            public TValue this[TInnerKey inner]
            {
                get => _owner.Get(_outer, inner);
                set => _owner.Set(_outer, inner, value);
            }

            public bool HasKey(TInnerKey inner) => _owner.HasKey(_outer, inner);
            public bool Remove(TInnerKey inner) => _owner.Remove(_outer, inner);
            public void Clear() => _owner.ClearOuter(_outer);
            public TInnerKey[] Keys => _owner.InnerKeys(_outer);
        }
    }
}