using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Services;
using Neo.SmartContract.Framework.Native;
using System;
using System.Numerics;

namespace InnFork.NeoN3
{
    public partial class InnForkProjectStateStorage : SmartContract
    {
        // ===== �������� ����������� ���� (�� InnForkGateway) =====
        private const byte PFX_OfferId_To_OfferPack = 0x02;

        private const byte PFX_ProjectId_To_ProjectPack = 0x05;
        private const byte PFX_ProjectId_To_ProjectAccount = 0x0D;

        private const byte PFX_Owner_To_ProjectCreatorAccount = 0x08;
        private const byte PFX_Owner_To_BackerAccount = 0x09;
        private const byte PFX_Manufacturer_To_ManufacturerAccount = 0x0A;
        private const byte PFX_Owner_To_InvestorAccount = 0x0B;

        private const byte PFX_GlobalProjectsList = 0x13;
        private const byte PFX_GlobalProjectPackagesList = 0x14;

        private const byte PFX_InvestorManufacturerProjectInvestments = 0x20;
        private const byte PFX_InvestmentSystemState = 0x15;

        private const byte PFX_ProjectCloseReason = 0x16;
        private const byte PFX_GlobalProjectOffersPackages = 0x17;

        private static StorageMap Map_Offers => new(Storage.CurrentContext, PFX_OfferId_To_OfferPack);
        private static StorageMap Map_ProjectPackages => new(Storage.CurrentContext, PFX_ProjectId_To_ProjectPack);
        private static StorageMap Map_ProjectAccounts => new(Storage.CurrentContext, PFX_ProjectId_To_ProjectAccount);

        private static StorageMap Map_CreatorAccounts => new(Storage.CurrentContext, PFX_Owner_To_ProjectCreatorAccount);
        private static StorageMap Map_BackerAccounts => new(Storage.CurrentContext, PFX_Owner_To_BackerAccount);
        private static StorageMap Map_ManufacturerAccounts => new(Storage.CurrentContext, PFX_Manufacturer_To_ManufacturerAccount);
        private static StorageMap Map_InvestorAccounts => new(Storage.CurrentContext, PFX_Owner_To_InvestorAccount);

        private static StorageMap Map_GlobalProjectsList => new(Storage.CurrentContext, PFX_GlobalProjectsList);
        private static StorageMap Map_GlobalProjectPackagesList => new(Storage.CurrentContext, PFX_GlobalProjectPackagesList);

        private static StorageMap Map_Investments => new(Storage.CurrentContext, PFX_InvestorManufacturerProjectInvestments);
        private static StorageMap Map_InvestmentSystemState => new(Storage.CurrentContext, PFX_InvestmentSystemState);

        private static StorageMap Map_ProjectCloseReason => new(Storage.CurrentContext, PFX_ProjectCloseReason);
        private static StorageMap Map_GlobalProjectOffersPackages => new(Storage.CurrentContext, PFX_GlobalProjectOffersPackages);

        // ====== INTERNAL AUTH ======
        private static readonly byte[] KEY_LogicContract = "logic_contract".ToByteArray();
        private static StorageMap Sys => new(Storage.CurrentContext, (byte)0xF0);


        // ====== OFFER PACKS ======
        public static void SetRawOfferPackage(ByteString offerIdKey, ByteString serialized)
        {
            RequireAuth();
            if (offerIdKey is null || serialized is null) throw new Exception("Bad params");
            Map_Offers.Put(offerIdKey, serialized);
        }

        public static ByteString GetRawOfferPackage(ByteString offerIdKey)
        {
            return Map_Offers.Get(offerIdKey);
        }

        public static bool DeleteRawOfferPackage(ByteString offerIdKey)
        {
            var v = Map_Offers.Get(offerIdKey);
            if (v is null) return false;
            Map_Offers.Delete(offerIdKey);
            return true;
        }

        // ====== PROJECT PACKAGES ======
        public static void SetRawProjectPackage(ByteString projectIdKey, ByteString serialized)
        {
            RequireAuth();
            if (projectIdKey is null || serialized is null) throw new Exception("Bad params");
            Map_ProjectPackages.Put(projectIdKey, serialized);
        }

        public static ByteString GetRawProjectPackage(ByteString projectIdKey)
        {
            return Map_ProjectPackages.Get(projectIdKey);
        }

        // ====== PROJECT ACCOUNTS (legacy blob, ���� ��� �����) ======
        public static void SetRawProjectAccount(ByteString projectIdKey, ByteString serialized)
        {
            RequireAuth();
            Map_ProjectAccounts.Put(projectIdKey, serialized);
        }

        public static ByteString GetRawProjectAccount(ByteString projectIdKey)
        {
            return Map_ProjectAccounts.Get(projectIdKey);
        }

        public static bool DeleteRawProjectAccount(ByteString projectIdKey)
        {
            var v = Map_ProjectAccounts.Get(projectIdKey);
            if (v is null) return false;
            Map_ProjectAccounts.Delete(projectIdKey);
            return true;
        }

        // ====== PARTICIPANT ACCOUNTS ======
        public static void SetRawProjectCreatorAccount(UInt160 owner, ByteString serialized)
        {
            RequireAuth();
            Map_CreatorAccounts.Put(owner, serialized);
        }

        public static ByteString GetRawProjectCreatorAccount(UInt160 owner) => Map_CreatorAccounts.Get(owner);

        public static void SetRawBackerAccount(UInt160 owner, ByteString serialized)
        {
            RequireAuth();
            Map_BackerAccounts.Put(owner, serialized);
        }

        public static ByteString GetRawBackerAccount(UInt160 owner) => Map_BackerAccounts.Get(owner);

        public static void SetRawManufacturerAccount(UInt160 owner, ByteString serialized)
        {
            RequireAuth();
            Map_ManufacturerAccounts.Put(owner, serialized);
        }

        public static ByteString GetRawManufacturerAccount(UInt160 owner) => Map_ManufacturerAccounts.Get(owner);

        public static void SetRawInvestorAccount(UInt160 owner, ByteString serialized)
        {
            RequireAuth();
            Map_InvestorAccounts.Put(owner, serialized);
        }

        public static ByteString GetRawInvestorAccount(UInt160 owner) => Map_InvestorAccounts.Get(owner);

        // ====== AGREEMENTS ======
        private static StorageMap Map_Agreements => new(Storage.CurrentContext, "agreements");
        private static StorageMap Map_InvestorAgreements => new(Storage.CurrentContext, "investorAgreements");
        private static StorageMap Map_ManufacturerAgreements => new(Storage.CurrentContext, "manufacturerAgreements");

        public static void SetAgreement(ByteString agreementId, ByteString serialized)
        {
            RequireAuth();
            Map_Agreements.Put(agreementId, serialized);
        }

        public static ByteString GetAgreement(ByteString agreementId) => Map_Agreements.Get(agreementId);

        public static void LinkInvestorAgreement(UInt160 investor, ByteString agreementId)
        {
            RequireAuth();
            Map_InvestorAgreements.Put(investor, agreementId);
        }

        public static ByteString GetInvestorAgreement(UInt160 investor) => Map_InvestorAgreements.Get(investor);

        public static void LinkManufacturerAgreement(UInt160 manufacturer, ByteString agreementId)
        {
            RequireAuth();
            Map_ManufacturerAgreements.Put(manufacturer, agreementId);
        }

        public static ByteString GetManufacturerAgreement(UInt160 manufacturer) => Map_ManufacturerAgreements.Get(manufacturer);

        // ====== GLOBAL LISTS ======
        private static readonly ByteString KEY_ProjectAccountsList = (ByteString)"ProjectAccountsList";
        private static readonly ByteString KEY_ProjectPackagesList = (ByteString)"GlobalProjectPackagesList";

        public static void SetGlobalProjectsList(ByteString serializedArray)
        {
            RequireAuth();
            Map_GlobalProjectsList.Put(KEY_ProjectAccountsList, serializedArray);
        }

        public static ByteString GetGlobalProjectsList() => Map_GlobalProjectsList.Get(KEY_ProjectAccountsList);

        public static void SetGlobalProjectPackagesList(ByteString serializedArray)
        {
            RequireAuth();
            Map_GlobalProjectPackagesList.Put(KEY_ProjectPackagesList, serializedArray);
        }

        public static ByteString GetGlobalProjectPackagesList() => Map_GlobalProjectPackagesList.Get(KEY_ProjectPackagesList);

        // ====== INVESTMENTS ======
        public static void SetInvestmentRecord(ByteString compositeKey, ByteString serialized)
        {
            RequireAuth();
            Map_Investments.Put(compositeKey, serialized);
        }

        public static ByteString GetInvestmentRecord(ByteString compositeKey) => Map_Investments.Get(compositeKey);

        public static void SetInvestmentSystemState(ByteString key, ByteString serialized)
        {
            RequireAuth();
            Map_InvestmentSystemState.Put(key, serialized);
        }

        public static ByteString GetInvestmentSystemState(ByteString key) => Map_InvestmentSystemState.Get(key);

        // ====== CLOSE REASONS ======
        public static void SetProjectCloseReason(ByteString projectIdKey, int reason)
        {
            RequireAuth();
            Map_ProjectCloseReason.Put(projectIdKey, ((BigInteger)reason).ToByteArray());
        }

        public static int GetProjectCloseReason(ByteString projectIdKey)
        {
            var raw = Map_ProjectCloseReason.Get(projectIdKey);
            if (raw is null) return -1;
            return (int)(BigInteger)raw;
        }

        // ====== GLOBAL PROJECT OFFERS PACKAGES (���� ���������) ======
        public static void SetGlobalProjectOfferPackage(ByteString key, ByteString serialized)
        {
            RequireAuth();
            Map_GlobalProjectOffersPackages.Put(key, serialized);
        }

        public static ByteString GetGlobalProjectOfferPackage(ByteString key) => Map_GlobalProjectOffersPackages.Get(key);

        // ====== ITERATION HELPERS (�����������) ======
        public static Iterator EnumerateOfferKeys() => Map_Offers.Find(FindOptions.KeysOnly);
        public static Iterator EnumerateProjectPackageKeys() => Map_ProjectPackages.Find(FindOptions.KeysOnly);
        public static Iterator EnumerateProjectAccountKeys() => Map_ProjectAccounts.Find(FindOptions.KeysOnly);
    }
}