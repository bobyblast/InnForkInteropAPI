using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Attributes;
using Neo.SmartContract.Framework.Linq;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

using static InnFork.NeoN3.InnForkProjectStateStorage;
using static InnFork.NeoN3.InnForkProjectStateStorage.IF_Constants;


namespace InnFork.NeoN3;

public partial class InnForkProjectStateStorage : Neo.SmartContract.Framework.SmartContract
{
    public static void SetProjectUpdateVotingStatus(string projectId, string updateId, bool isActive, bool isFinalized)
    {
        RequireAuth();
        byte[] activeKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_active", updateId);
        byte[] finalizedKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_finalized", updateId);

        if (isActive)
            Storage.Put(Storage.CurrentContext, activeKey, 1);
        else
            Storage.Delete(Storage.CurrentContext, activeKey);

        if (isFinalized)
            Storage.Put(Storage.CurrentContext, finalizedKey, 1);
        else
            Storage.Delete(Storage.CurrentContext, finalizedKey);
    }
    public static void SetProjectCore(string projectId, ByteString coreBytes)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "core");
        Storage.Put(Storage.CurrentContext, key, coreBytes);
    }

    public static ByteString GetProjectCoreBytes(string projectId)
    {
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "core");
        return Storage.Get(Storage.CurrentContext, key);
    }

    private static bool IsAuthorized()
    {
        UInt160 logicContract = (UInt160)Storage.Get(Storage.CurrentContext, LogicContractHashKey);
        return Runtime.CallingScriptHash == logicContract;
    }

    private static void RequireAuth()
    {
        if (!IsAuthorized())
            throw new Exception("Unauthorized access");
    }

    public static void SetLogicContract(UInt160 newLogicContract)
    {
        if (!IsAuthorized())
            throw new Exception("Only current logic contract can update authorization");
        Storage.Put(Storage.CurrentContext, LogicContractHashKey, newLogicContract);
    }

    private static byte[] CreateProjectKey(byte[] prefix, string projectId)
    {
        return prefix.Concat(projectId.ToByteArray());
    }

    private static byte[] CreateProjectActorKey(byte[] prefix, string projectId, UInt160 actor)
    {
        return prefix.Concat(projectId.ToByteArray()).Concat(actor);
    }

    private static byte[] CreateProjectComplexKey(byte[] prefix, string projectId, string complexKey)
    {
        return prefix.Concat(projectId.ToByteArray()).Concat(complexKey.ToByteArray());
    }

    public static bool IsBackerEligible(string projectId, UInt160 backer)
    {
        byte[] key = CreateProjectActorKey(BackerDonationsPrefix, projectId, backer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        BigInteger donation = result != null ? (BigInteger)result : 0;

        byte[] banKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_backers", backer);
        bool isBanned = Storage.Get(Storage.CurrentContext, banKey) != null;

        return donation > 0 && !isBanned;
    }

    public static BigInteger GetBackerDonation(string projectId, UInt160 backer)
    {
        byte[] key = CreateProjectActorKey(BackerDonationsPrefix, projectId, backer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetBackerDonation(string projectId, UInt160 backer, BigInteger amount)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(BackerDonationsPrefix, projectId, backer);
        if (amount > 0)
            Storage.Put(Storage.CurrentContext, key, amount);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static BigInteger GetEligibleVotersCount(string projectId)
    {
        byte[] prefix = CreateProjectKey(BackerDonationsPrefix, projectId);
        Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.ValuesOnly);

        BigInteger count = 0;
        while (iterator.Next())
        {
            BigInteger value = (BigInteger)iterator.Value;
            if (value > 0)
            {
                count++;
            }
        }
        return count;
    }

    public static (UInt160[], BackerVotesEnum[]) GetVotesSnapshot(string projectId, string votingType, int skip, int take)
    {
        byte[] prefix = CreateProjectKey(VotingMapsPrefix, projectId + "_" + votingType);
        Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

        Neo.SmartContract.Framework.List<UInt160> voters = new Neo.SmartContract.Framework.List<UInt160>();
        Neo.SmartContract.Framework.List<BackerVotesEnum> votes = new Neo.SmartContract.Framework.List<BackerVotesEnum>();

        int current = 0;
        int taken = 0;

        while (iterator.Next() && taken < take)
        {
            if (current >= skip)
            {
                byte[] keyBytes = (byte[])iterator.Value;
                byte[] voterBytes = keyBytes.Range(keyBytes.Length - 20, 20);
                UInt160 voter = (UInt160)voterBytes;

                ByteString voteResult = Storage.Get(Storage.CurrentContext, keyBytes);
                BackerVotesEnum vote = (BackerVotesEnum)(int)(BigInteger)voteResult;

                if (IsBackerEligible(projectId, voter))
                {
                    voters.Add(voter);
                    votes.Add(vote);
                    taken++;
                }
            }
            current++;
        }

        return (voters, votes);
    }

    public static void RecordVote(string projectId, string votingType, UInt160 backer, BackerVotesEnum vote)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(VotingMapsPrefix, projectId + "_" + votingType, backer);
        Storage.Put(Storage.CurrentContext, key, (int)vote);
    }

    public static void ClearVotes(string projectId, string votingType)
    {
        RequireAuth();
        byte[] prefix = CreateProjectKey(VotingMapsPrefix, projectId + "_" + votingType);
        Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

        while (iterator.Next())
        {
            Storage.Delete(Storage.CurrentContext, (byte[])iterator.Value);
        }
    }

    public static CalculatedVoteOutcome CalculateVoteOutcome(string projectId, string votingType,
        bool autoAssignVoiceless, bool abstainAsSupport, BigInteger minParticipationPct, BigInteger minApprovalPct)
    {
        CalculatedVoteOutcome outcome = new CalculatedVoteOutcome();

        BigInteger totalEligible = GetEligibleVotersCount(projectId);
        outcome.TotalEligibleVoters = totalEligible;

        byte[] votingPrefix = CreateProjectKey(VotingMapsPrefix, projectId + "_" + votingType);
        Iterator votingIterator = Storage.Find(Storage.CurrentContext, votingPrefix, FindOptions.KeysOnly);

        BigInteger positiveVotes = 0;
        BigInteger negativeVotes = 0;
        BigInteger abstainedVotes = 0;
        BigInteger totalCasted = 0;

        while (votingIterator.Next())
        {
            byte[] keyBytes = (byte[])votingIterator.Value;
            byte[] voterBytes = keyBytes.Range(keyBytes.Length - 20, 20);
            UInt160 voter = (UInt160)voterBytes;

            if (IsBackerEligible(projectId, voter))
            {
                ByteString voteResult = Storage.Get(Storage.CurrentContext, keyBytes);
                BackerVotesEnum vote = (BackerVotesEnum)(int)(BigInteger)voteResult;
                BigInteger weight = GetBackerVoteWeight(projectId, voter);

                totalCasted += weight;

                if (vote == BackerVotesEnum.Positive)
                    positiveVotes += weight;
                else if (vote == BackerVotesEnum.Negative)
                    negativeVotes += weight;
                else if (vote == BackerVotesEnum.Abstained)
                    abstainedVotes += weight;
            }
        }

        BigInteger voiceless = totalEligible - totalCasted;
        if (autoAssignVoiceless && voiceless > 0)
        {
            abstainedVotes += voiceless;
            totalCasted += voiceless;
        }

        if (abstainAsSupport)
        {
            positiveVotes += abstainedVotes;
        }

        outcome.FinalPositiveVotes = positiveVotes;
        outcome.FinalNegativeVotes = negativeVotes;
        outcome.FinalAbstainedVotes = abstainedVotes;
        outcome.TotalParticipatedOrAssigned = totalCasted;

        bool meetsMinParticipation = true;
        if (minParticipationPct > 0 && totalEligible > 0)
        {
            meetsMinParticipation = (totalCasted * 100) >= (totalEligible * minParticipationPct);
        }

        outcome.IsSuccessful = false;
        if (meetsMinParticipation && totalCasted > 0)
        {
            outcome.IsSuccessful = (positiveVotes * 100) >= (totalCasted * minApprovalPct);
        }

        return outcome;
    }



    // ���������� �������� ��� �������� (���� ������������)
    public static bool ValidateDelegationIntegrity(string projectId)
    {
        // TODO: ��� ������������� ����������� �������� ������ �������������
        return true;
    }


    public static BigInteger GetBackerVoteWeight(string projectId, UInt160 backer)
    {
        BigInteger donation = GetBackerDonation(projectId, backer);
        if (donation <= 0) return 1;

        BigInteger totalProjectBalance = GetProjectTotalBalance(projectId);
        if (totalProjectBalance <= 0) return 1;

        BigInteger sharePercentage = (donation * 1000) / totalProjectBalance;
        BigInteger weight = 1 + (sharePercentage / 10);

        if (weight > 101) weight = 101;
        if (weight <= 0) weight = 1;

        return weight;
    }

    public static UInt160 ResolveFinalDelegate(string projectId, string votingType, UInt160 backer)
    {
        byte[] delegationKey = CreateProjectComplexKey(VoteDelegationPrefix, projectId, votingType);
        ByteString delegationData = Storage.Get(Storage.CurrentContext, delegationKey);
        Map<UInt160, UInt160> delegationMap;

        if (delegationData != null)
        {
            delegationMap = (Map<UInt160, UInt160>)StdLib.Deserialize(delegationData);
        }
        else
        {
            delegationMap = new Map<UInt160, UInt160>();
        }

        Map<UInt160, bool> visited = new Map<UInt160, bool>();
        UInt160 current = backer;
        int maxDepth = 100;

        for (int i = 0; i < maxDepth; i++)
        {
            if (visited.HasKey(current)) break;
            visited[current] = true;

            if (!delegationMap.HasKey(current)) return current;
            current = delegationMap[current];
        }

        return current;
    }

    public static ulong GetVotingDeadline(string projectId, string votingType)
    {
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_" + votingType);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (ulong)(BigInteger)result : 0;
    }

    public static void SetVotingDeadline(string projectId, string votingType, ulong deadline)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_" + votingType);
        Storage.Put(Storage.CurrentContext, key, (BigInteger)deadline);
    }

    public static BigInteger GetProjectTotalBalance(string projectId)
    {
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "total_balance");
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetProjectTotalBalance(string projectId, BigInteger balance)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "total_balance");
        Storage.Put(Storage.CurrentContext, key, balance);
    }

    public static bool IsManufacturerRegistered(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_candidates", manufacturer);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static void RegisterManufacturer(string projectId, UInt160 manufacturer, string data)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_candidates", manufacturer);
        Storage.Put(Storage.CurrentContext, key, data);
    }

    public static void UnregisterManufacturer(string projectId, UInt160 manufacturer)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(ManufacturerMapsPrefix, projectId + "_candidates", manufacturer);
        Storage.Delete(Storage.CurrentContext, key);
    }

    public static UInt160[] GetManufacturerCandidates(string projectId)
    {
        byte[] prefix = CreateProjectKey(ManufacturerMapsPrefix, projectId + "_candidates");
        Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

        Neo.SmartContract.Framework.List<UInt160> manufacturers = new Neo.SmartContract.Framework.List<UInt160>();
        while (iterator.Next())
        {
            byte[] keyBytes = (byte[])iterator.Value;
            byte[] manufacturerBytes = keyBytes.Range(keyBytes.Length - 20, 20);
            manufacturers.Add((UInt160)manufacturerBytes);
        }

        return manufacturers;
    }

    public static void SetReservedFunds(string projectId, UInt160 manufacturer, BigInteger amount)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(ReservedFundsPrefix, projectId, manufacturer);
        if (amount > 0)
            Storage.Put(Storage.CurrentContext, key, amount);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static BigInteger GetReservedFunds(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(ReservedFundsPrefix, projectId, manufacturer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetBackerReservation(string projectId, UInt160 backer, UInt160 manufacturer, BigInteger amount)
    {
        RequireAuth();
        string complexKey = backer.ToString() + "_" + manufacturer.ToString();
        byte[] key = CreateProjectComplexKey(ReservedFundsPrefix, projectId + "_backer_reservations", complexKey);
        if (amount > 0)
            Storage.Put(Storage.CurrentContext, key, amount);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static BigInteger GetBackerReservation(string projectId, UInt160 backer, UInt160 manufacturer)
    {
        string complexKey = backer.ToString() + "_" + manufacturer.ToString();
        byte[] key = CreateProjectComplexKey(ReservedFundsPrefix, projectId + "_backer_reservations", complexKey);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static MilestoneCompletionVotesStruct GetMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        string complexKey = manufacturer.ToString() + "_" + stepNumber.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId, complexKey);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) return null;
        return (MilestoneCompletionVotesStruct)StdLib.Deserialize(data);
    }

    public static void SetMilestone(string projectId, UInt160 manufacturer, byte stepNumber, MilestoneCompletionVotesStruct milestone)
    {
        RequireAuth();
        string complexKey = manufacturer.ToString() + "_" + stepNumber.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId, complexKey);
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(milestone));
    }

    public static void DeleteMilestone(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        RequireAuth();
        string complexKey = manufacturer.ToString() + "_" + stepNumber.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId, complexKey);
        Storage.Delete(Storage.CurrentContext, key);
    }

    public static string[] GetMilestoneKeys(string projectId, UInt160 manufacturer)
    {
        byte[] prefix = CreateProjectComplexKey(MilestoneMapsPrefix, projectId, manufacturer.ToString());
        Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

        Neo.SmartContract.Framework.List<string> keys = new Neo.SmartContract.Framework.List<string>();
        while (iterator.Next())
        {
            byte[] keyBytes = (byte[])iterator.Value;
            keys.Add(keyBytes.ToByteString());
        }

        return keys;
    }


    // ===================== OFFER RESERVATIONS (by offerSha256Id) =====================
    private static readonly byte[] OfferReservationsPrefix = "offer_reservations".ToByteArray();

    private static byte[] CreateOfferActorKey(string offerId, UInt160 backer)
    {
        return OfferReservationsPrefix.Concat(offerId.ToByteArray()).Concat(backer);
    }

    public static void SetOfferReservedDonation(string offerId, UInt160 backer, BigInteger amount)
    {
        RequireAuth();
        byte[] key = CreateOfferActorKey(offerId, backer);
        if (amount > 0)
            Storage.Put(Storage.CurrentContext, key, amount);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static BigInteger GetOfferReservedDonation(string offerId, UInt160 backer)
    {
        byte[] key = CreateOfferActorKey(offerId, backer);
        ByteString v = Storage.Get(Storage.CurrentContext, key);
        return v != null ? (BigInteger)v : 0;
    }

    // ===================== BAN MANAGEMENT =====================

    public static void BanParticipant(string projectId, UInt160 participant, bool isManufacturer, BanReason reason)
    {
        RequireAuth();
        string participantType = isManufacturer ? "_manufacturers" : "_backers";
        byte[] key = CreateProjectActorKey(BanMapsPrefix, projectId + participantType, participant);
        Storage.Put(Storage.CurrentContext, key, (int)reason);
    }

    public static void UnbanParticipant(string projectId, UInt160 participant, bool isManufacturer)
    {
        RequireAuth();
        string participantType = isManufacturer ? "_manufacturers" : "_backers";
        byte[] key = CreateProjectActorKey(BanMapsPrefix, projectId + participantType, participant);
        Storage.Delete(Storage.CurrentContext, key);
    }

    public static bool IsParticipantBanned(string projectId, UInt160 participant)
    {
        byte[] manufacturerKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_manufacturers", participant);
        byte[] backerKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_backers", participant);

        return Storage.Get(Storage.CurrentContext, manufacturerKey) != null ||
               Storage.Get(Storage.CurrentContext, backerKey) != null;
    }

    public static BanReason GetParticipantBanReason(string projectId, UInt160 participant)
    {
        byte[] manufacturerKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_manufacturers", participant);
        byte[] backerKey = CreateProjectActorKey(BanMapsPrefix, projectId + "_backers", participant);

        ByteString manufacturerResult = Storage.Get(Storage.CurrentContext, manufacturerKey);
        if (manufacturerResult != null)
        {
            return (BanReason)(int)(BigInteger)manufacturerResult;
        }

        ByteString backerResult = Storage.Get(Storage.CurrentContext, backerKey);
        if (backerResult != null)
        {
            return (BanReason)(int)(BigInteger)backerResult;
        }

        return BanReason.ViolationOfTerms;
    }

    // ===================== FRAUD DETECTION =====================

    public static void SetFraudScore(string projectId, UInt160 participant, BigInteger score)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_fraud_scores", participant);
        Storage.Put(Storage.CurrentContext, key, score);
    }

    public static BigInteger GetFraudScore(string projectId, UInt160 participant)
    {
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_fraud_scores", participant);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetLastVoteTimestamp(string projectId, UInt160 voter, ulong timestamp)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_last_vote", voter);
        Storage.Put(Storage.CurrentContext, key, (BigInteger)timestamp);
    }

    public static ulong GetLastVoteTimestamp(string projectId, UInt160 voter)
    {
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_last_vote", voter);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (ulong)(BigInteger)result : 0;
    }

    public static void SetVoteSwitchingCount(string projectId, UInt160 voter, int count)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_vote_switching", voter);
        Storage.Put(Storage.CurrentContext, key, count);
    }

    public static int GetVoteSwitchingCount(string projectId, UInt160 voter)
    {
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_vote_switching", voter);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (int)(BigInteger)result : 0;
    }

    public static void SetSuspiciousActivityScore(string projectId, UInt160 participant, BigInteger score)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_suspicious_score", participant);
        Storage.Put(Storage.CurrentContext, key, score);
    }

    public static BigInteger GetSuspiciousActivityScore(string projectId, UInt160 participant)
    {
        byte[] key = CreateProjectActorKey(FraudDetectionPrefix, projectId + "_suspicious_score", participant);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static bool DetectFraudPattern(string projectId, UInt160 voter, string votingType)
    {
        ulong currentTime = Runtime.Time;
        ulong lastVoteTime = GetLastVoteTimestamp(projectId, voter);

        if (lastVoteTime > 0 && (currentTime - lastVoteTime) < 5)
        {
            BigInteger fraudScore = GetFraudScore(projectId, voter);
            SetFraudScore(projectId, voter, fraudScore + 10);
            return true;
        }

        SetLastVoteTimestamp(projectId, voter, currentTime);
        return false;
    }

    public static FraudAnalysisResult AnalyzeFraudPatterns(string projectId, UInt160 voter)
    {
        FraudAnalysisResult result = new FraudAnalysisResult();

        result.SuspiciousScore = GetFraudScore(projectId, voter);
        result.VoteSwitchingCount = GetVoteSwitchingCount(projectId, voter);
        result.LastVoteTime = GetLastVoteTimestamp(projectId, voter);

        result.IsSuspicious = result.SuspiciousScore > 50 || result.VoteSwitchingCount > 3;
        result.RiskLevel = result.SuspiciousScore > 100 ? "HIGH" :
                          result.SuspiciousScore > 50 ? "MEDIUM" : "LOW";

        return result;
    }

    // ===================== MANAGEMENT TRANSFER VOTING =====================

    public static void SetManagementTransferVote(string projectId, UInt160 backer, BackerVotesEnum vote)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(ManagementTransferPrefix, projectId + "_votes", backer);
        Storage.Put(Storage.CurrentContext, key, (int)vote);
    }

    public static BackerVotesEnum GetManagementTransferVote(string projectId, UInt160 backer)
    {
        byte[] key = CreateProjectActorKey(ManagementTransferPrefix, projectId + "_votes", backer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BackerVotesEnum)(int)(BigInteger)result : BackerVotesEnum.Abstained;
    }

    public static void SetManagementTransferResults(string projectId, BigInteger positive, BigInteger negative, BigInteger abstained, BigInteger total)
    {
        RequireAuth();
        byte[] positiveKey = CreateProjectComplexKey(ManagementTransferPrefix, projectId, "positive");
        byte[] negativeKey = CreateProjectComplexKey(ManagementTransferPrefix, projectId, "negative");
        byte[] abstainedKey = CreateProjectComplexKey(ManagementTransferPrefix, projectId, "abstained");
        byte[] totalKey = CreateProjectComplexKey(ManagementTransferPrefix, projectId, "total");

        Storage.Put(Storage.CurrentContext, positiveKey, positive);
        Storage.Put(Storage.CurrentContext, negativeKey, negative);
        Storage.Put(Storage.CurrentContext, abstainedKey, abstained);
        Storage.Put(Storage.CurrentContext, totalKey, total);
    }

    // ===================== WINNER SELECTION =====================

    public static void SetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 manufacturer, BackerVotesEnum vote)
    {
        RequireAuth();
        string complexKey = backer.ToString() + "_" + manufacturer.ToString();
        byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId, complexKey);
        Storage.Put(Storage.CurrentContext, key, (int)vote);
    }

    public static BackerVotesEnum GetWinnerSelectionVote(string projectId, UInt160 backer, UInt160 manufacturer)
    {
        string complexKey = backer.ToString() + "_" + manufacturer.ToString();
        byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId, complexKey);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BackerVotesEnum)(int)(BigInteger)result : BackerVotesEnum.Abstained;
    }

    public static void SetCandidateWinnerVotes(string projectId, UInt160 manufacturer, CandidateWinnerVotesStruct votes)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(WinnerSelectionPrefix, projectId + "_candidates", manufacturer);
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(votes));
    }

    public static CandidateWinnerVotesStruct GetCandidateWinnerVotes(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(WinnerSelectionPrefix, projectId + "_candidates", manufacturer);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) return null;
        return (CandidateWinnerVotesStruct)StdLib.Deserialize(data);
    }

    // ===================== QUALITY SCORES & VOTE WEIGHTS =====================

    public static void SetManufacturerQualityScore(string projectId, UInt160 manufacturer, BigInteger score)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(QualityScoresPrefix, projectId + "_manufacturer_quality", manufacturer);
        Storage.Put(Storage.CurrentContext, key, score);
    }

    public static BigInteger GetManufacturerQualityScore(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(QualityScoresPrefix, projectId + "_manufacturer_quality", manufacturer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetManufacturerVoteWeight(string projectId, UInt160 manufacturer, BigInteger weight)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_manufacturer_weight", manufacturer);
        Storage.Put(Storage.CurrentContext, key, weight);
    }

    public static BigInteger GetManufacturerVoteWeight(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_manufacturer_weight", manufacturer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetBackerVoteWeightValue(string projectId, UInt160 backer, BigInteger weight)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_backer_weight", backer);
        Storage.Put(Storage.CurrentContext, key, weight);
    }

    public static BigInteger GetBackerVoteWeightValue(string projectId, UInt160 backer)
    {
        byte[] key = CreateProjectActorKey(VoteWeightsPrefix, projectId + "_backer_weight", backer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetManufacturerReliabilityTier(string projectId, UInt160 manufacturer, byte tier)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(QualityScoresPrefix, projectId + "_reliability_tier", manufacturer);
        Storage.Put(Storage.CurrentContext, key, tier);
    }

    public static byte GetManufacturerReliabilityTier(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(QualityScoresPrefix, projectId + "_reliability_tier", manufacturer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return (byte)(result != null ? (byte)(BigInteger)result : 1);
    }

    // ===================== MILESTONE TEMPLATES =====================

    public static void SetMilestoneTemplate(string projectId, string templateId, MilestoneTemplate template)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId, templateId);
        Storage.Put(Storage.CurrentContext, key, StdLib.Serialize(template));
    }

    public static MilestoneTemplate GetMilestoneTemplate(string projectId, string templateId)
    {
        byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId, templateId);
        ByteString data = Storage.Get(Storage.CurrentContext, key);
        if (data == null) return null;
        return (MilestoneTemplate)StdLib.Deserialize(data);
    }

    public static void SetManufacturerPreferredTemplate(string projectId, UInt160 manufacturer, string templateId)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(TemplatesPrefix, projectId + "_preferred", manufacturer);
        Storage.Put(Storage.CurrentContext, key, templateId);
    }

    public static string GetManufacturerPreferredTemplate(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(TemplatesPrefix, projectId + "_preferred", manufacturer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? result.ToString() : "";
    }

    // ===================== ANALYTICS & STATISTICS =====================

    public static Map<string, BigInteger> GetMilestonePerformanceAnalytics(string projectId, UInt160 manufacturer)
    {
        Map<string, BigInteger> analytics = new Map<string, BigInteger>();

        byte[] prefix = CreateProjectComplexKey(AnalyticsPrefix, projectId, manufacturer.ToString());
        Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

        while (iterator.Next())
        {
            byte[] keyBytes = (byte[])iterator.Value;
            ByteString value = Storage.Get(Storage.CurrentContext, keyBytes);
            if (value != null)
            {
                string metricName = keyBytes.ToByteString();
                analytics[metricName] = (BigInteger)value;
            }
        }

        return analytics;
    }

    public static void SetDailyParticipationStats(string projectId, ulong timestamp, BigInteger participantsCount)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "daily_" + timestamp.ToString());
        Storage.Put(Storage.CurrentContext, key, participantsCount);
    }

    public static BigInteger GetDailyParticipationStats(string projectId, ulong timestamp)
    {
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "daily_" + timestamp.ToString());
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetTotalRefundsProcessed(string projectId, BigInteger amount)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "total_refunds");
        Storage.Put(Storage.CurrentContext, key, amount);
    }

    public static BigInteger GetTotalRefundsProcessed(string projectId)
    {
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "total_refunds");
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetRefundHistory(string projectId, UInt160 participant, BigInteger amount)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(AnalyticsPrefix, projectId + "_refund_history", participant);
        Storage.Put(Storage.CurrentContext, key, amount);
    }

    public static BigInteger GetRefundHistory(string projectId, UInt160 participant)
    {
        byte[] key = CreateProjectActorKey(AnalyticsPrefix, projectId + "_refund_history", participant);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    // ===================== NOTIFICATIONS =====================

    public static void SetNotificationPreference(string projectId, UInt160 participant, bool enabled)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_preferences", participant);
        if (enabled)
            Storage.Put(Storage.CurrentContext, key, 1);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static bool GetNotificationPreference(string projectId, UInt160 participant)
    {
        byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_preferences", participant);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static void SetVotingReminderTimestamp(string projectId, int voteType, ulong timestamp)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(NotificationsPrefix, projectId, "reminder_" + voteType.ToString());
        Storage.Put(Storage.CurrentContext, key, (BigInteger)timestamp);
    }

    public static ulong GetVotingReminderTimestamp(string projectId, int voteType)
    {
        byte[] key = CreateProjectComplexKey(NotificationsPrefix, projectId, "reminder_" + voteType.ToString());
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (ulong)(BigInteger)result : 0;
    }

    public static void SetDeadlineNotificationSent(string projectId, UInt160 participant, bool sent)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_deadline_sent", participant);
        if (sent)
            Storage.Put(Storage.CurrentContext, key, 1);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static bool GetDeadlineNotificationSent(string projectId, UInt160 participant)
    {
        byte[] key = CreateProjectActorKey(NotificationsPrefix, projectId + "_deadline_sent", participant);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    // ===================== REFERRAL SYSTEM =====================

    public static void SetReferrer(string projectId, UInt160 backer, UInt160 referrer)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_referrers", backer);
        Storage.Put(Storage.CurrentContext, key, referrer);
    }

    public static UInt160 GetReferrer(string projectId, UInt160 backer)
    {
        byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_referrers", backer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (UInt160)result : UInt160.Zero;
    }

    public static void SetReferralReward(string projectId, UInt160 referrer, BigInteger amount)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_rewards", referrer);
        Storage.Put(Storage.CurrentContext, key, amount);
    }

    public static BigInteger GetReferralReward(string projectId, UInt160 referrer)
    {
        byte[] key = CreateProjectActorKey(ReferralPrefix, projectId + "_rewards", referrer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    // ===================== CONDITIONAL VOTING =====================
    public static string[] GetVotingTierWeightsKeys(string projectId)
    {
        // FIX: ������������ ����� �� �������, ��� ��� SetVoteWeightByTier
        byte[] prefix = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", "");
        Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
        Neo.SmartContract.Framework.List<string> keys = new Neo.SmartContract.Framework.List<string>();
        while (it.Next())
        {
            byte[] fullKey = (byte[])it.Value;
            keys.Add(fullKey.ToByteString());
        }
        return keys;
    }

    public static void ClearVotingTierWeights(string projectId)
    {
        RequireAuth();
        // FIX: ��� �� �������, ��� � ��� ��������� ������
        byte[] prefix = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", "");
        Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
        while (it.Next())
        {
            Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
        }
    }


    public static void SetConditionalVotingRule(string projectId, string ruleId, bool isActive)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_rules", ruleId);
        if (isActive)
            Storage.Put(Storage.CurrentContext, key, 1);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static bool GetConditionalVotingRule(string projectId, string ruleId)
    {
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_rules", ruleId);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static void SetConditionalThreshold(string projectId, string ruleId, BigInteger threshold)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_thresholds", ruleId);
        Storage.Put(Storage.CurrentContext, key, threshold);
    }

    public static BigInteger GetConditionalThreshold(string projectId, string ruleId)
    {
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_thresholds", ruleId);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetMultiTierVoting(string projectId, string voteId, UInt160 voter, byte tierLevel)
    {
        RequireAuth();
        string complexKey = voteId + "_" + voter.ToString();
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_multitier", complexKey);
        Storage.Put(Storage.CurrentContext, key, tierLevel);
    }

    public static byte GetMultiTierVoting(string projectId, string voteId, UInt160 voter)
    {
        string complexKey = voteId + "_" + voter.ToString();
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_multitier", complexKey);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return (byte)(result != null ? (byte)(BigInteger)result : 1);
    }

    public static void SetVoteWeightByTier(string projectId, string tierId, BigInteger weight)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", tierId);
        Storage.Put(Storage.CurrentContext, key, weight);
    }

    public static BigInteger GetVoteWeightByTier(string projectId, string tierId)
    {
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", tierId);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 1;
    }

    // NEW: VotingTierWeights CRUD helpers
    public static void RemoveVoteWeightByTier(string projectId, string tierId)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ConditionalVotingPrefix, projectId + "_tier_weights", tierId);
        Storage.Delete(Storage.CurrentContext, key);
    }



    // ===================== TOKEN REWARDS =====================

    public static void SetBackerTokenReward(string projectId, UInt160 backer, BigInteger tokenAmount)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(TokenRewardsPrefix, projectId + "_backer_tokens", backer);
        Storage.Put(Storage.CurrentContext, key, tokenAmount);
    }

    public static BigInteger GetBackerTokenReward(string projectId, UInt160 backer)
    {
        byte[] key = CreateProjectActorKey(TokenRewardsPrefix, projectId + "_backer_tokens", backer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    // ===================== PENALTIES =====================

    public static void SetManufacturerPenalty(string projectId, UInt160 manufacturer, BigInteger penaltyAmount)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_manufacturer_penalties", manufacturer);
        Storage.Put(Storage.CurrentContext, key, penaltyAmount);
    }

    public static BigInteger GetManufacturerPenalty(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_manufacturer_penalties", manufacturer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetPenaltyTimestamp(string projectId, UInt160 manufacturer, ulong timestamp)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_penalty_timestamps", manufacturer);
        Storage.Put(Storage.CurrentContext, key, (BigInteger)timestamp);
    }

    public static ulong GetPenaltyTimestamp(string projectId, UInt160 manufacturer)
    {
        byte[] key = CreateProjectActorKey(PenaltiesPrefix, projectId + "_penalty_timestamps", manufacturer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (ulong)(BigInteger)result : 0;
    }

    // ===================== PROJECT UPDATE VOTING =====================

    public static bool IsProjectUpdateVotingActive(string projectId, string updateId)
    {
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_active", updateId);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static bool IsProjectUpdateVotingFinalized(string projectId, string updateId)
    {
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_finalized", updateId);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static void SetProjectUpdateVotingResults(string projectId, string updateId,
        BigInteger positiveVotes, BigInteger negativeVotes, BigInteger abstainedVotes, BigInteger totalVotes)
    {
        RequireAuth();
        byte[] positiveKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_positive", updateId);
        byte[] negativeKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_negative", updateId);
        byte[] abstainedKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_abstained", updateId);
        byte[] totalKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_total", updateId);

        Storage.Put(Storage.CurrentContext, positiveKey, positiveVotes);
        Storage.Put(Storage.CurrentContext, negativeKey, negativeVotes);
        Storage.Put(Storage.CurrentContext, abstainedKey, abstainedVotes);
        Storage.Put(Storage.CurrentContext, totalKey, totalVotes);
    }

    public static (BigInteger positive, BigInteger negative, BigInteger abstained, BigInteger total)
        GetProjectUpdateVotingResults(string projectId, string updateId)
    {
        byte[] positiveKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_positive", updateId);
        byte[] negativeKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_negative", updateId);
        byte[] abstainedKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_abstained", updateId);
        byte[] totalKey = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_total", updateId);

        ByteString positiveResult = Storage.Get(Storage.CurrentContext, positiveKey);
        ByteString negativeResult = Storage.Get(Storage.CurrentContext, negativeKey);
        ByteString abstainedResult = Storage.Get(Storage.CurrentContext, abstainedKey);
        ByteString totalResult = Storage.Get(Storage.CurrentContext, totalKey);

        BigInteger positive = positiveResult != null ? (BigInteger)positiveResult : 0;
        BigInteger negative = negativeResult != null ? (BigInteger)negativeResult : 0;
        BigInteger abstained = abstainedResult != null ? (BigInteger)abstainedResult : 0;
        BigInteger total = totalResult != null ? (BigInteger)totalResult : 0;

        return (positive, negative, abstained, total);
    }

    public static void SetApprovedUpdate(string projectId, string updateId, bool approved)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_approved", updateId);
        if (approved)
            Storage.Put(Storage.CurrentContext, key, 1);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static bool IsUpdateApproved(string projectId, string updateId)
    {
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_approved", updateId);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static void SetProjectUpdateVote(string projectId, string updateId, UInt160 backer, BackerVotesEnum vote)
    {
        RequireAuth();
        string complexKey = updateId + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_votes", complexKey);
        Storage.Put(Storage.CurrentContext, key, (int)vote);
    }

    public static BackerVotesEnum GetProjectUpdateVote(string projectId, string updateId, UInt160 backer)
    {
        string complexKey = updateId + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_votes", complexKey);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BackerVotesEnum)(int)(BigInteger)result : BackerVotesEnum.Abstained;
    }

    public static void SetProjectUpdateVotingDeadline(string projectId, string updateId, ulong deadline)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_deadlines", updateId);
        Storage.Put(Storage.CurrentContext, key, (BigInteger)deadline);
    }

    public static ulong GetProjectUpdateVotingDeadline(string projectId, string updateId)
    {
        byte[] key = CreateProjectComplexKey(ProjectUpdateVotingPrefix, projectId + "_deadlines", updateId);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (ulong)(BigInteger)result : 0;
    }

    // ===================== PROJECT SETTINGS/VOTING DEADLINES ETC. =====================

    public static void SetProjectVotingDeadlines(string projectId, ulong launchDeadline, ulong fundraisingDeadline, ulong manufacturerSelectionDeadline)
    {
        RequireAuth();
        byte[] launchKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_launch");
        byte[] fundraisingKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_fundraising");
        byte[] selectionKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_selection");

        Storage.Put(Storage.CurrentContext, launchKey, (BigInteger)launchDeadline);
        Storage.Put(Storage.CurrentContext, fundraisingKey, (BigInteger)fundraisingDeadline);
        Storage.Put(Storage.CurrentContext, selectionKey, (BigInteger)manufacturerSelectionDeadline);
    }

    public static (ulong launch, ulong fundraising, ulong selection) GetProjectVotingDeadlines(string projectId)
    {
        byte[] launchKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_launch");
        byte[] fundraisingKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_fundraising");
        byte[] selectionKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "deadline_selection");

        ByteString launchResult = Storage.Get(Storage.CurrentContext, launchKey);
        ByteString fundraisingResult = Storage.Get(Storage.CurrentContext, fundraisingKey);
        ByteString selectionResult = Storage.Get(Storage.CurrentContext, selectionKey);

        ulong launch = launchResult != null ? (ulong)(BigInteger)launchResult : 0;
        ulong fundraising = fundraisingResult != null ? (ulong)(BigInteger)fundraisingResult : 0;
        ulong selection = selectionResult != null ? (ulong)(BigInteger)selectionResult : 0;

        return (launch, fundraising, selection);
    }

    public static void SetAutoSelectWinner(string projectId, UInt160 backer, UInt160 manufacturer)
    {
        RequireAuth();
        byte[] key = CreateProjectActorKey(AutoSelectionPrefix, projectId + "_auto_votes", backer);
        Storage.Put(Storage.CurrentContext, key, manufacturer);
    }

    public static UInt160 GetAutoSelectWinner(string projectId, UInt160 backer)
    {
        byte[] key = CreateProjectActorKey(AutoSelectionPrefix, projectId + "_auto_votes", backer);
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (UInt160)result : UInt160.Zero;
    }

    public static void ClearAutoSelections(string projectId)
    {
        RequireAuth();
        byte[] prefix = CreateProjectKey(AutoSelectionPrefix, projectId + "_auto_votes");
        Iterator iterator = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);

        while (iterator.Next())
        {
            Storage.Delete(Storage.CurrentContext, (byte[])iterator.Value);
        }
    }

    public static void SetVotingConfiguration(string projectId, BigInteger minParticipation, BigInteger minApproval,
        bool autoAssignVoiceless, bool abstainAsSupport)
    {
        RequireAuth();
        byte[] participationKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_participation");
        byte[] approvalKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_approval");
        byte[] voicelessKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "auto_assign_voiceless");
        byte[] abstainKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "abstain_as_support");

        Storage.Put(Storage.CurrentContext, participationKey, minParticipation);
        Storage.Put(Storage.CurrentContext, approvalKey, minApproval);
        Storage.Put(Storage.CurrentContext, voicelessKey, autoAssignVoiceless ? 1 : 0);
        Storage.Put(Storage.CurrentContext, abstainKey, abstainAsSupport ? 1 : 0);
    }

    public static VotingConfiguration GetVotingConfiguration(string projectId)
    {
        VotingConfiguration config = new VotingConfiguration();

        byte[] participationKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_participation");
        byte[] approvalKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "min_approval");
        byte[] voicelessKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "auto_assign_voiceless");
        byte[] abstainKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "abstain_as_support");

        ByteString participationResult = Storage.Get(Storage.CurrentContext, participationKey);
        ByteString approvalResult = Storage.Get(Storage.CurrentContext, approvalKey);
        ByteString voicelessResult = Storage.Get(Storage.CurrentContext, voicelessKey);
        ByteString abstainResult = Storage.Get(Storage.CurrentContext, abstainKey);

        config.MinParticipation = participationResult != null ? (BigInteger)participationResult : 0;
        config.MinApproval = approvalResult != null ? (BigInteger)approvalResult : 0;
        config.AutoAssignVoiceless = voicelessResult != null && (BigInteger)voicelessResult > 0;
        config.AbstainAsSupport = abstainResult != null && (BigInteger)abstainResult > 0;

        return config;
    }

    public static void SetVoteDelegation(string projectId, string votingType, UInt160 delegator, UInt160 delegateAddr)
    {
        RequireAuth();
        byte[] delegationKey = CreateProjectComplexKey(VoteDelegationPrefix, projectId, votingType);
        ByteString delegationData = Storage.Get(Storage.CurrentContext, delegationKey);

        Map<UInt160, UInt160> delegationMap;
        if (delegationData != null)
        {
            delegationMap = (Map<UInt160, UInt160>)StdLib.Deserialize(delegationData);
        }
        else
        {
            delegationMap = new Map<UInt160, UInt160>();
        }

        delegationMap[delegator] = delegateAddr;
        Storage.Put(Storage.CurrentContext, delegationKey, StdLib.Serialize(delegationMap));
    }

    public static void RemoveVoteDelegation(string projectId, string votingType, UInt160 delegator)
    {
        RequireAuth();
        byte[] delegationKey = CreateProjectComplexKey(VoteDelegationPrefix, projectId, votingType);
        ByteString delegationData = Storage.Get(Storage.CurrentContext, delegationKey);

        if (delegationData != null)
        {
            Map<UInt160, UInt160> delegationMap = (Map<UInt160, UInt160>)StdLib.Deserialize(delegationData);
            if (delegationMap.HasKey(delegator))
            {
                delegationMap.Remove(delegator);
                Storage.Put(Storage.CurrentContext, delegationKey, StdLib.Serialize(delegationMap));
            }
        }
    }

    public static void SetProjectActivityScore(string projectId, BigInteger score)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "activity_score");
        Storage.Put(Storage.CurrentContext, key, score);
    }

    public static BigInteger GetProjectActivityScore(string projectId)
    {
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "activity_score");
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void SetLastActivityTime(string projectId, ulong timestamp)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "last_activity");
        Storage.Put(Storage.CurrentContext, key, (BigInteger)timestamp);
    }

    public static ulong GetLastActivityTime(string projectId)
    {
        byte[] key = CreateProjectComplexKey(AnalyticsPrefix, projectId, "last_activity");
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (ulong)(BigInteger)result : 0;
    }

    public static void SetProjectStatus(string projectId, ProjectStatus status)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "status");
        Storage.Put(Storage.CurrentContext, key, (int)status);
    }

    public static ProjectStatus GetProjectStatus(string projectId)
    {
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "status");
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (ProjectStatus)(int)(BigInteger)result : ProjectStatus.Paused;
    }

    public static void SetProjectFlags(string projectId, bool isArchived, bool isPaused, bool isClosed, bool hasWinner)
    {
        RequireAuth();
        byte[] flagsKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flags");

        int flags = 0;
        if (isArchived) flags |= 1;
        if (isPaused) flags |= 2;
        if (isClosed) flags |= 4;
        if (hasWinner) flags |= 8;

        Storage.Put(Storage.CurrentContext, flagsKey, flags);
    }

    public static ProjectFlags GetProjectFlags(string projectId)
    {
        byte[] flagsKey = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "flags");
        ByteString result = Storage.Get(Storage.CurrentContext, flagsKey);
        int flags = result != null ? (int)(BigInteger)result : 0;

        return new ProjectFlags
        {
            IsArchived = (flags & 1) != 0,
            IsPaused = (flags & 2) != 0,
            IsClosed = (flags & 4) != 0,
            HasWinner = (flags & 8) != 0
        };
    }

    public static void SetLockedFunds(string projectId, BigInteger amount)
    {
        RequireAuth();
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "locked_funds");
        Storage.Put(Storage.CurrentContext, key, amount);
    }

    public static BigInteger GetLockedFunds(string projectId)
    {
        byte[] key = CreateProjectComplexKey(ProjectSettingsPrefix, projectId, "locked_funds");
        ByteString result = Storage.Get(Storage.CurrentContext, key);
        return result != null ? (BigInteger)result : 0;
    }

    public static void UpdateLockedFunds(string projectId, BigInteger deltaAmount)
    {
        RequireAuth();
        BigInteger currentLocked = GetLockedFunds(projectId);
        SetLockedFunds(projectId, currentLocked + deltaAmount);
    }

    // ===================== NEW: Milestone votes and fraud flags (externalized from in-memory maps) =====================

    public static void SetMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer, BackerVotesEnum vote)
    {
        RequireAuth();
        string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
        Storage.Put(Storage.CurrentContext, key, (int)vote);
    }

    public static BackerVotesEnum GetMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
    {
        string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
        ByteString v = Storage.Get(Storage.CurrentContext, key);
        return v != null ? (BackerVotesEnum)(int)(BigInteger)v : BackerVotesEnum.Abstained;
    }

    public static void RemoveMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
    {
        RequireAuth();
        string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
        Storage.Delete(Storage.CurrentContext, key);
    }

    public static void ClearMilestoneVotes(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        RequireAuth();
        string prefixKeyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_";
        byte[] prefix = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", prefixKeyPart);
        Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
        while (it.Next())
        {
            Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
        }
    }

    public static void SetMilestoneFraudFlag(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer, bool detected)
    {
        RequireAuth();
        string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_fraud", keyPart);
        if (detected)
            Storage.Put(Storage.CurrentContext, key, 1);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static bool GetMilestoneFraudFlag(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
    {
        string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_fraud", keyPart);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static void ClearMilestoneFraudFlags(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        RequireAuth();
        string prefixKeyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_";
        byte[] prefix = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_fraud", prefixKeyPart);
        Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
        while (it.Next())
        {
            Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
        }
    }

    // ===================== NEW: Winner vote fraud flags (externalized) =====================

    public static void SetWinnerVoteFraudFlag(string projectId, UInt160 manufacturer, UInt160 backer, bool detected)
    {
        RequireAuth();
        string keyPart = manufacturer.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_fraud", keyPart);
        if (detected)
            Storage.Put(Storage.CurrentContext, key, 1);
        else
            Storage.Delete(Storage.CurrentContext, key);
    }

    public static bool GetWinnerVoteFraudFlag(string projectId, UInt160 manufacturer, UInt160 backer)
    {
        string keyPart = manufacturer.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_fraud", keyPart);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

    public static void ClearWinnerVoteFraudFlags(string projectId, UInt160 manufacturer)
    {
        RequireAuth();
        string prefixPart = manufacturer.ToString() + "_";
        byte[] prefix = CreateProjectComplexKey(WinnerSelectionPrefix, projectId + "_fraud", prefixPart);
        Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
        while (it.Next())
        {
            Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
        }
    }

    // ===================== NEW: Milestone Template CustomParameters CRUD =====================

    public static void SetMilestoneTemplateParam(string projectId, string templateId, string paramKey, string paramValue)
    {
        RequireAuth();
        string bucket = "_template_params_" + templateId;
        byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, paramKey);
        Storage.Put(Storage.CurrentContext, key, paramValue);
    }

    public static string GetMilestoneTemplateParam(string projectId, string templateId, string paramKey)
    {
        string bucket = "_template_params_" + templateId;
        byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, paramKey);
        ByteString v = Storage.Get(Storage.CurrentContext, key);
        return v != null ? v.ToString() : "";
    }

    public static void RemoveMilestoneTemplateParam(string projectId, string templateId, string paramKey)
    {
        RequireAuth();
        string bucket = "_template_params_" + templateId;
        byte[] key = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, paramKey);
        Storage.Delete(Storage.CurrentContext, key);
    }

    public static void ClearMilestoneTemplateParams(string projectId, string templateId)
    {
        RequireAuth();
        string bucket = "_template_params_" + templateId;
        byte[] prefix = CreateProjectComplexKey(TemplatesPrefix, projectId + bucket, "");
        Iterator it = Storage.Find(Storage.CurrentContext, prefix, FindOptions.KeysOnly);
        while (it.Next())
        {
            Storage.Delete(Storage.CurrentContext, (byte[])it.Value);
        }
    }



    // ===================== NEW: Check existence of milestone vote =====================

    public static bool HasMilestoneBackerVote(string projectId, UInt160 manufacturer, byte stepNumber, UInt160 backer)
    {
        string keyPart = manufacturer.ToString() + "_" + stepNumber.ToString() + "_" + backer.ToString();
        byte[] key = CreateProjectComplexKey(MilestoneMapsPrefix, projectId + "_votes", keyPart);
        return Storage.Get(Storage.CurrentContext, key) != null;
    }

}














