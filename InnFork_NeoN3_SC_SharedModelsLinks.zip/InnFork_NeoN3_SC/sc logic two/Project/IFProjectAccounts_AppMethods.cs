﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.IF_MainGateway;
using static InnFork.NeoN3.IF_MainGateway.ProjectAccount;


namespace InnFork.NeoN3
{



    public partial class IF_MainGateway


    // диспуты 
    {

        /// <summary>
        /// Получает оценку риска для причины бана
        /// </summary>
        public static BigInteger getRiskScoreForBanReason(BanReason reason)
        {
            switch (reason)
            {
                case BanReason.FraudulentActivity:
                    return 100; // Максимальный риск
                case BanReason.SystemAbuse:
                    return 50;
                case BanReason.SecurityBreach:
                    return 40;
                case BanReason.InappropriateBehavior:
                    return 25;
                case BanReason.ViolationOfTerms:
                    return 20;
                default:
                    return 10; // Базовый риск
            }
        }

        /// <summary>
        /// Создает ключ для отслеживания заблокированных средств
        /// </summary>

        public static bool isParticipantBanned(string projectId, UInt160 participantAddress)
        {
            return ProjectState.IsParticipantBanned(projectId, participantAddress);
        }

        public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
        {
            var project = getProjectAccount(projectId);

            if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
                throw new Exception("Only contract owner or project author can ban backers");

            if (!ProjectState.IsBackerEligible(projectId, backerAddress))
                throw new Exception("Backer is not part of this project");

            if (ProjectState.IsParticipantBanned(projectId, backerAddress))
                throw new Exception("Backer is already banned");

            AcquireLock();
            try
            {
                ProjectState.BanParticipant(projectId, backerAddress, false, (int)reason);
                applyBackerBanSanctions(projectId, backerAddress, reason);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
        {
            var project = getProjectAccount(projectId);

            if (!isParticipantBanned(projectId, backerAddress))
                throw new Exception("Participant is not banned");

            BigInteger currentBalance = ProjectState.GetBackerDonation(projectId, backerAddress);
            if (amountToBlock > currentBalance)
                amountToBlock = currentBalance;

            if (amountToBlock <= 0)
                return;

            AcquireLock();
            try
            {
                ProjectState.UpdateLockedFunds(projectId, amountToBlock);
                ProjectState.SetBackerDonation(projectId, backerAddress, currentBalance - amountToBlock);

                BigInteger refundHistory = ProjectState.GetRefundHistory(projectId, backerAddress);
                ProjectState.SetRefundHistory(projectId, backerAddress, refundHistory + amountToBlock);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
        {
            BigInteger backerBalance = ProjectState.GetBackerDonation(projectId, backerAddress);

            switch (reason)
            {
                case BanReason.FraudulentActivity:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance);
                    break;

                case BanReason.SystemAbuse:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 2);
                    break;

                case BanReason.InappropriateBehavior:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 4);
                    break;

                case BanReason.ViolationOfTerms:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 5);
                    break;

                default:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 10);
                    break;
            }

            BigInteger currentScore = ProjectState.GetSuspiciousActivityScore(projectId, backerAddress);
            ProjectState.SetSuspiciousActivityScore(projectId, backerAddress, currentScore + getRiskScoreForBanReason(reason));
        }

    }




    public partial class IF_MainGateway // Fraud Detection and Prevention // выносится в контракт отдельный
    {

        ///////////////////////////////////////////////////////////// FRAUD DETECTION SYSTEM /////////////////////////////////////////////////////////

        public static bool detectSybilAttack(string projectId, UInt160 voterAddress)
        {
            BackerAccount backerAccount = BackerAccount.getBackerAccount(voterAddress, false);
            if (backerAccount == null) return false;

            int votingActivity = 0;
            string[] votingTypes = new[] { "LaunchApproval", "FundraisingCompletion", "TerminationWithRefund", "PauseResume", "ManagementTransfer" };
            foreach (var vt in votingTypes)
            {
                int skip = 0;
                const int PAGE = 64;
                const int MAX_ITERATIONS = 50;
                int iterations = 0;
                bool found = false;
                while (!found && iterations < MAX_ITERATIONS)
                {
                    var snap = ProjectState.GetVotesSnapshot(projectId, vt, skip, PAGE);
                    if (snap == null || snap.Length < 1) break;
                    var voters = (UInt160[])snap[0];
                    if (voters == null || voters.Length == 0) break;
                    for (int i = 0; i < voters.Length; i++)
                    {
                        if (voters[i] == voterAddress)
                        {
                            votingActivity++;
                            found = true;
                            break;
                        }
                    }
                    if (!found) skip += PAGE;
                    iterations++;
                }
            }

            if (backerAccount.TotalBalance < 1000 && backerAccount.FreeBalance < 100)
            {
                if (votingActivity >= 2) return true;
            }

            return checkIdenticalVotingPatterns(projectId, voterAddress);
        }

        public static bool checkIdenticalVotingPatterns(string projectId, UInt160 voterAddress)
        {
            // 1) Находим собственный голос бэкера
            int skip = 0;
            const int PAGE = 128;
            const int MAX_ITERATIONS = 50;
            int iterations = 0;

            bool hasVoterChoice = false;
            BackerVotesEnum voterChoice = BackerVotesEnum.Abstained;

            while (iterations < MAX_ITERATIONS)
            {
                var snap = ProjectState.GetVotesSnapshot(projectId, "LaunchApproval", skip, PAGE);
                if (snap == null || snap.Length < 2) break;

                var voters = (UInt160[])snap[0];
                var votes = (BackerVotesEnum[])snap[1];
                if (voters == null || voters.Length == 0) break;

                for (int i = 0; i < voters.Length; i++)
                {
                    if (voters[i] == voterAddress)
                    {
                        voterChoice = votes[i];
                        hasVoterChoice = true;
                        break;
                    }
                }

                if (hasVoterChoice) break;
                skip += PAGE;
                iterations++;
            }

            if (!hasVoterChoice)
                return false;

            // 2) Сравниваем голос данного бэкера с остальными в снапшотах
            int totalComparisons = 0;
            int identicalVotes = 0;
            int lowBalanceIdenticalVotes = 0;

            skip = 0;
            iterations = 0;
            while (iterations < MAX_ITERATIONS)
            {
                var snap = ProjectState.GetVotesSnapshot(projectId, "LaunchApproval", skip, PAGE);
                if (snap == null || snap.Length < 2) break;

                var voters = (UInt160[])snap[0];
                var votes = (BackerVotesEnum[])snap[1];
                if (voters == null || voters.Length == 0) break;

                for (int i = 0; i < voters.Length; i++)
                {
                    var otherVoter = voters[i];
                    var vote = votes[i];

                    if (otherVoter == voterAddress) continue;

                    totalComparisons++;
                    if (vote == voterChoice)
                    {
                        identicalVotes++;

                        BackerAccount otherAccount = BackerAccount.getBackerAccount(otherVoter, false);
                        if (otherAccount != null && otherAccount.TotalBalance < 1000)
                        {
                            lowBalanceIdenticalVotes++;
                        }
                    }
                }

                skip += PAGE;
                iterations++;
            }

            // 3) Эвристики «подозрительной корреляции»
            if (totalComparisons > 3 &&
                identicalVotes > (totalComparisons * 90 / 100) &&
                lowBalanceIdenticalVotes >= 3)
            {
                return true;
            }

            return false;
        }

        public static bool detectCollusionPattern(string projectId, UInt160 voterAddress)
        {
            ulong voterTimestamp = ProjectState.GetLastVoteTimestamp(projectId, voterAddress);
            if (voterTimestamp > 0)
            {
                int simultaneousVotes = 0;
                const ulong TIME_WINDOW = 60;

                int skip = 0;
                const int PAGE = 128;
                const int MAX_ITERATIONS = 50;
                int iterations = 0;
                while (iterations < MAX_ITERATIONS)
                {
                    var snap = ProjectState.GetVotesSnapshot(projectId, "LaunchApproval", skip, PAGE);
                    if (snap == null || snap.Length < 1) break;
                    var voters = (UInt160[])snap[0];
                    if (voters == null || voters.Length == 0) break;

                    for (int i = 0; i < voters.Length; i++)
                    {
                        if (voters[i] == voterAddress) continue;
                        ulong otherTimestamp = ProjectState.GetLastVoteTimestamp(projectId, voters[i]);
                        if (otherTimestamp >= voterTimestamp - TIME_WINDOW &&
                            otherTimestamp <= voterTimestamp + TIME_WINDOW)
                        {
                            simultaneousVotes++;
                        }
                    }
                    skip += PAGE;
                    iterations++;
                }

                if (simultaneousVotes >= 5) return true;
            }

            return analyzeAccountConnections(projectId, voterAddress);
        }

        public static bool analyzeAccountConnections(string projectId, UInt160 voterAddress)
        {
            int skip = 0;
            const int PAGE = 128;
            const int MAX_ITERATIONS = 50;
            int iterations = 0;

            Map<UInt160, int> referrerCounts = new Map<UInt160, int>();
            Map<BigInteger, int> donationCounts = new Map<BigInteger, int>();

            while (iterations < MAX_ITERATIONS)
            {
                var snap = ProjectState.GetVotesSnapshot(projectId, "LaunchApproval", skip, PAGE);
                if (snap == null || snap.Length < 1) break;
                var voters = (UInt160[])snap[0];
                if (voters == null || voters.Length == 0) break;

                for (int i = 0; i < voters.Length; i++)
                {
                    UInt160 referrer = ProjectState.GetReferrer(projectId, voters[i]);
                    if (referrer != UInt160.Zero)
                    {
                        if (!referrerCounts.HasKey(referrer)) referrerCounts[referrer] = 0;
                        referrerCounts[referrer]++;
                    }

                    BigInteger donation = ProjectState.GetBackerDonation(projectId, voters[i]);
                    if (!donationCounts.HasKey(donation)) donationCounts[donation] = 0;
                    donationCounts[donation]++;
                }

                skip += PAGE;
                iterations++;
            }

            foreach (var kv in referrerCounts.Values)
            {
                if (kv > 10) return true;
            }

            foreach (var kv in donationCounts.Keys)
            {
                if (kv > 0 && kv >= 5) return true;
            }

            return false;
        }

        public static bool detectBalanceManipulationFraud(string projectId, UInt160 voterAddress)
        {
            BackerAccount backerAccount = BackerAccount.getBackerAccount(voterAddress, false);
            if (backerAccount == null) return false;

            BigInteger currentBalance = backerAccount.TotalBalance;
            BigInteger donatedAmount = ProjectState.GetBackerDonation(projectId, voterAddress);

            if (donatedAmount > 0 && currentBalance > (donatedAmount * 50))
            {
                return true;
            }

            return detectCircularTransactions(projectId, voterAddress, backerAccount);
        }

        public static bool detectCircularTransactions(string projectId, UInt160 voterAddress, BackerAccount backerAccount)
        {
            if (backerAccount.TotalBalance > 10000 && backerAccount.FreeBalance < (backerAccount.TotalBalance / 10))
            {
                BigInteger totalProjectBalance = ProjectState.GetProjectTotalBalance(projectId);
                BigInteger voterDonation = ProjectState.GetBackerDonation(projectId, voterAddress);

                if (totalProjectBalance > 0 && voterDonation > (totalProjectBalance * 30 / 100))
                {
                    return true;
                }
            }

            return false;
        }

        public static bool detectTemporalVotingAnomalies(string projectId, UInt160 voterAddress)
        {
            ulong voteTime = ProjectState.GetLastVoteTimestamp(projectId, voterAddress);
            if (voteTime == 0) return false;

            if (voteTime % 3600 == 0 || voteTime % 60 == 0)
            {
                return true;
            }

            return analyzeVotingFrequency(projectId, voterAddress, voteTime);
        }

        public static bool analyzeVotingFrequency(string projectId, UInt160 voterAddress, ulong currentVoteTime)
        {
            int recentVotes = 0;
            string[] votingTypes = new[] { "LaunchApproval", "FundraisingCompletion", "TerminationWithRefund", "PauseResume" };
            foreach (var vt in votingTypes)
            {
                int skip = 0;
                const int PAGE = 64;
                const int MAX_ITERATIONS = 50;
                int iterations = 0;
                bool found = false;
                while (!found && iterations < MAX_ITERATIONS)
                {
                    var snap = ProjectState.GetVotesSnapshot(projectId, vt, skip, PAGE);
                    if (snap == null || snap.Length < 1) break;
                    var voters = (UInt160[])snap[0];
                    if (voters == null || voters.Length == 0) break;
                    for (int i = 0; i < voters.Length; i++)
                    {
                        if (voters[i] == voterAddress)
                        {
                            recentVotes++;
                            found = true;
                            break;
                        }
                    }
                    if (!found) skip += PAGE;
                    iterations++;
                }
            }

            if (recentVotes > 10) return true;

            return detectUniformVotingIntervals(projectId, voterAddress);
        }

        public static bool detectUniformVotingIntervals(string projectId, UInt160 voterAddress)
        {
            int switchCount = ProjectState.GetVoteSwitchingCount(projectId, voterAddress);
            if (switchCount > 5) return true;
            return false;
        }

        public static void applyGradedFraudPenalties(string projectId, UInt160 voterAddress, FraudType fraudType)
        {
            BigInteger currentScore = ProjectState.GetSuspiciousActivityScore(projectId, voterAddress);

            BigInteger penaltyScore = 0;
            BanReason banReason = BanReason.FraudSuspicion;

            switch (fraudType)
            {
                case FraudType.SybilAttack:
                    penaltyScore = 3;
                    banReason = BanReason.SybilAttack;
                    break;
                case FraudType.Collusion:
                    penaltyScore = 2;
                    banReason = BanReason.Collusion;
                    break;
                case FraudType.BalanceManipulation:
                    penaltyScore = 4;
                    banReason = BanReason.BalanceManipulation;
                    break;
                case FraudType.TemporalAnomaly:
                    penaltyScore = 1;
                    banReason = BanReason.BotActivity;
                    break;
                case FraudType.RapidVoting:
                    penaltyScore = 1;
                    banReason = BanReason.SpamVoting;
                    break;
                case FraudType.VoteSwitching:
                    penaltyScore = 2;
                    banReason = BanReason.VoteManipulation;
                    break;
                default:
                    penaltyScore = 1;
                    break;
            }

            currentScore += penaltyScore;
            ProjectState.SetSuspiciousActivityScore(projectId, voterAddress, currentScore);

            if (currentScore >= 10)
            {
                banBacker(projectId, voterAddress, banReason);
            }
            else if (currentScore >= 5)
            {
                BigInteger backerBalance = ProjectState.GetBackerDonation(projectId, voterAddress);
                if (backerBalance > 0)
                {
                    blockBackerFinance(projectId, voterAddress, banReason, backerBalance / 2);
                }
            }
        }

        public static bool detectVotingFraud(UInt160 voterAddress, string projectId, string votingType)
        {
            ProjectAccount project = getProjectAccount(projectId);
            if (project == null) return false;

            if (project.projectSettings == null || !project.projectSettings.EnableFraudDetection)
            {
                return false;
            }

            if (isParticipantBanned(projectId, voterAddress))
            {
                return true;
            }

            bool fraudDetected = false;
            Neo.SmartContract.Framework.List<FraudType> detectedFraudTypes = new();

            if (detectSybilAttack(projectId, voterAddress))
            {
                fraudDetected = true;
                detectedFraudTypes.Add(FraudType.SybilAttack);
            }

            if (detectCollusionPattern(projectId, voterAddress))
            {
                fraudDetected = true;
                detectedFraudTypes.Add(FraudType.Collusion);
            }

            if (detectBalanceManipulationFraud(projectId, voterAddress))
            {
                fraudDetected = true;
                detectedFraudTypes.Add(FraudType.BalanceManipulation);
            }

            if (detectTemporalVotingAnomalies(projectId, voterAddress))
            {
                fraudDetected = true;
                detectedFraudTypes.Add(FraudType.TemporalAnomaly);
            }

            if (detectRapidVotingPattern(projectId, voterAddress))
            {
                fraudDetected = true;
                detectedFraudTypes.Add(FraudType.RapidVoting);
            }

            if (detectVoteSwitchingFraud(projectId, voterAddress, votingType))
            {
                fraudDetected = true;
                detectedFraudTypes.Add(FraudType.VoteSwitching);
            }

            if (fraudDetected)
            {
                for (int i = 0; i < detectedFraudTypes.Count; i++)
                {
                    applyGradedFraudPenalties(projectId, voterAddress, detectedFraudTypes[i]);
                }
                return true;
            }

            ProjectState.SetLastVoteTimestamp(projectId, voterAddress, Runtime.Time);
            return false;
        }

        public static bool detectRapidVotingPattern(string projectId, UInt160 voterAddress)
        {
            const ulong VOTE_INTERVAL_THRESHOLD = 5;
            ulong lastVoteTime = ProjectState.GetLastVoteTimestamp(projectId, voterAddress);
            if (lastVoteTime > 0)
            {
                if (Runtime.Time - lastVoteTime < VOTE_INTERVAL_THRESHOLD)
                {
                    return true;
                }
            }
            ProjectState.SetLastVoteTimestamp(projectId, voterAddress, Runtime.Time);
            return false;
        }

        public static bool detectVoteSwitchingFraud(string projectId, UInt160 voterAddress, string votingType)
        {
            const int VOTE_SWITCH_THRESHOLD = 3;
            int currentSwitches = ProjectState.GetVoteSwitchingCount(projectId, voterAddress);
            if (currentSwitches >= VOTE_SWITCH_THRESHOLD)
            {
                return true;
            }
            ProjectState.SetVoteSwitchingCount(projectId, voterAddress, currentSwitches + 1);
            return false;
        }

        public static void applyFraudPenalties(string projectId, UInt160 voterAddress)
        {
            BigInteger currentScore = ProjectState.GetSuspiciousActivityScore(projectId, voterAddress);
            currentScore += 1;
            ProjectState.SetSuspiciousActivityScore(projectId, voterAddress, currentScore);

            if (currentScore > 5)
            {
                banBacker(projectId, voterAddress, BanReason.FraudSuspicion);
            }
        }
    }



    public partial class IF_MainGateway // Voting Integrity and Project Status Checks
    {
        public static bool isProjectOpen(string projectId)
        {
            ProjectAccount project = getProjectAccount(projectId);

            if (project.IsProjectHasWinner) return false;
            if (project.IsProjectClosed) return false;
            if (project.IsProjectPaused) return false;
            if (project.CurrentProjectStatus == ProjectStatus.Terminated) return false;
            if (project.CurrentProjectStatus == ProjectStatus.Completed) return false;

            return true;
        }

        public static bool validateVotingIntegrity(string projectId)
        {
            if (!isProjectOpen(projectId)) return false;
            return true;
        }
    }




    public partial class IF_MainGateway // Backer Investment and Prize Fund Management
    {
        public static bool isBackerDonatedToPrizeFund(string projectId, UInt160 backer)
        {
            if (backer == null || backer.IsZero) throw new Exception("Invalid backer address");
            return ProjectState.GetBackerDonation(projectId, backer) > 0;
        }

        public static BigInteger getBackerPrizeFundDonation(string projectId, UInt160 backer)
        {
            if (backer == null || backer.IsZero) throw new Exception("Invalid backer address");
            return ProjectState.GetBackerDonation(projectId, backer);
        }

        public static BigInteger getBackerReservedAmountForManufacturer(string projectId, UInt160 backer, UInt160 manufacturerCandidate)
        {
            if (backer == null || backer.IsZero) throw new Exception("Invalid backer address");
            if (manufacturerCandidate == null || manufacturerCandidate.IsZero) throw new Exception("Invalid manufacturer address");
            return ProjectState.GetBackerReservation(projectId, backer, manufacturerCandidate);
        }

        public static void setBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer, bool consent)
        {
            if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

            AcquireLock();
            try
            {
                ProjectState.SetConditionalVotingRule(projectId, "auto_consent_" + backer.ToString(), consent);
                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static bool getBackerAutoConsent_ToUsePrizeFundToMilestoneFunding(string projectId, UInt160 backer)
        {
            return ProjectState.GetConditionalVotingRule(projectId, "auto_consent_" + backer.ToString());
        }

        public static void moneyBackFromProjectToBackerAccount(string projectId, UInt160 backerAddress, BigInteger amount)
        {
            var project = getProjectAccount(projectId);

            bool isAuthorized = Runtime.CheckWitness(backerAddress) ||
                                (Runtime.CheckWitness(project.ProjectCreatorAddress) && (project.CurrentProjectStatus == ProjectStatus.Terminated || project.IsProjectClosed)) ||
                                (IsOwner() && (project.CurrentProjectStatus == ProjectStatus.Terminated || project.IsProjectClosed));

            if (!isAuthorized)
                throw new Exception("Authorization failed for money back operation.");

            if (amount <= 0)
                throw new Exception("Amount for money back must be positive.");

            if (project.IsProjectClosed && project.CurrentProjectStatus != ProjectStatus.Terminated)
                throw new Exception("Project is closed, money back not possible under current status.");

            if (project.IsProjectHasWinner && project.CurrentProjectStatus == ProjectStatus.Completed)
                throw new Exception("Project has a winner and is completed, direct money back might be restricted.");

            BackerAccount backerAccount = BackerAccount.getBackerAccount(backerAddress, true);

            BigInteger backerSpecificDonationInPrizeFund = ProjectState.GetBackerDonation(projectId, backerAddress);
            if (backerSpecificDonationInPrizeFund < amount)
                throw new Exception("Backer does not have sufficient donation in the project's prize fund.");

            if (project.FLMUSD_TotalProjectBalance < amount)
                throw new Exception("Project does not have sufficient total balance for money back.");

            AcquireLock();
            try
            {
                project.FLMUSD_TotalProjectBalance -= amount;
                project.FLMUSD_PrizeFundBalance -= amount;
                if (project.FLMUSD_PrizeFundBalance < 0) project.FLMUSD_PrizeFundBalance = 0;

                BigInteger stateTotal = ProjectState.GetProjectTotalBalance(projectId);
                ProjectState.SetProjectTotalBalance(projectId, stateTotal - amount);

                ProjectState.SetBackerDonation(projectId, backerAddress, backerSpecificDonationInPrizeFund - amount);

                if ((backerSpecificDonationInPrizeFund - amount) <= 0)
                {
                    ProjectState.SetConditionalThreshold(projectId, "alloc_" + backerAddress.ToString(), 0);
                }

                backerAccount.FreeBalance += amount;
                BackerAccount.updateExistingBackerAccount(backerAccount);

                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void processBackerPrizeFundDonation(string projectId, UInt160 backerAddress, BigInteger amount)
        {
            if (!Runtime.CheckWitness(backerAddress)) throw new Exception("Backer address mismatch");
            if (amount <= 0) throw new Exception("Donation amount must be positive.");

            BackerAccount backerAccount = BackerAccount.getBackerAccount(backerAddress, true);
            if (backerAccount.FreeBalance < amount)
                throw new Exception("Backer doesn't have enough funds");

            AcquireLock();
            var project = getProjectAccount(projectId);
            try
            {
                backerAccount.FreeBalance -= amount;
                BackerAccount.updateExistingBackerAccount(backerAccount);

                project.FLMUSD_TotalProjectBalance += amount;
                project.FLMUSD_PrizeFundBalance += amount;

                BigInteger currDonation = ProjectState.GetBackerDonation(projectId, backerAddress);
                ProjectState.SetBackerDonation(projectId, backerAddress, currDonation + amount);

                BigInteger stateTotal = ProjectState.GetProjectTotalBalance(projectId);
                ProjectState.SetProjectTotalBalance(projectId, stateTotal + amount);

                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void distributeConsentedFunds(string projectId, UInt160 manufacturer)
        {
            ProjectAccount project = getProjectAccount(projectId);

            if (!Runtime.CheckWitness(manufacturer) && !Runtime.CheckWitness(project.ProjectCreatorAddress) && !IsOwner())
                throw new Exception("distributeConsentedFunds : Authorization failed.");

            if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer))
                throw new Exception("Manufacturer is not registered in this project.");

            bool changesMade = false;
            AcquireLock();
            try
            {
                UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
                for (int i = 0; i < backers.Length; i++)
                {
                    UInt160 backer = backers[i];

                    if (!ProjectState.GetConditionalVotingRule(projectId, "auto_consent_" + backer.ToString()))
                        continue;

                    BigInteger donorAmount = ProjectState.GetBackerDonation(projectId, backer);
                    if (donorAmount <= 0) continue;

                    BigInteger amountToTransfer = donorAmount;

                    if (project.FLMUSD_PrizeFundBalance < amountToTransfer)
                    {
                        amountToTransfer = project.FLMUSD_PrizeFundBalance;
                        if (amountToTransfer <= 0) continue;
                    }

                    project.FLMUSD_PrizeFundBalance -= amountToTransfer;

                    ProjectState.SetBackerDonation(projectId, backer, donorAmount - amountToTransfer);

                    BigInteger currReserved = ProjectState.GetReservedFunds(projectId, manufacturer);
                    ProjectState.SetReservedFunds(projectId, manufacturer, currReserved + amountToTransfer);

                    BigInteger currBackerRes = ProjectState.GetBackerReservation(projectId, backer, manufacturer);
                    ProjectState.SetBackerReservation(projectId, backer, manufacturer, currBackerRes + amountToTransfer);

                    if ((donorAmount - amountToTransfer) <= 0)
                    {
                        ProjectState.SetConditionalThreshold(projectId, "alloc_" + backer.ToString(), 0);
                    }

                    changesMade = true;
                }
            }
            finally
            {
                ReleaseAcquireLock();
            }

            if (changesMade)
            {
                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
        }

    }



    public partial class IF_MainGateway // Manufacturer Financial Operations
    {
        public static void setManufacturerMinInvestment(string projectId, UInt160 manufacturerId, BigInteger amount)
        {
            var project = getProjectAccount(projectId);

            if (!Runtime.CheckWitness(manufacturerId) && !Runtime.CheckWitness(project.ProjectCreatorAddress))
                throw new Exception("Authorization failed. Only manufacturer or project author can set min investment.");

            if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerId))
                throw new Exception("Manufacturer is not a candidate in this project.");

            if (amount <= 0) throw new Exception("Amount must be greater than 0");

            ProjectState.SetConditionalThreshold(projectId, "min_inv_" + manufacturerId.ToString(), amount);
        }

        public static void proposeProfitShare(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger profitSharePercentage)
        {
            var project = getProjectAccount(projectId);

            if (!Runtime.CheckWitness(manufacturerAddress) && !Runtime.CheckWitness(project.ProjectCreatorAddress))
                throw new Exception("Only manufacturer or project author can propose profit share.");

            if (manufacturerAddress.Length != 20) throw new Exception("The parameter ManufacturerAddress SHOULD be a 20-byte address.");
            if (investorAddress.Length != 20) throw new Exception("The parameter InvestorAddress SHOULD be a 20-byte address.");

            if (profitSharePercentage <= 0 || profitSharePercentage > 100)
                throw new Exception("Profit share percentage must be between 1 and 100.");

            BigInteger currentInvestment = ProjectState.GetBackerReservation(projectId, investorAddress, manufacturerAddress);
            if (currentInvestment <= 0)
                throw new Exception("No investment found from this investor to this manufacturer to propose profit share for.");

            // TODO: ARCHITECTURAL ISSUE - Using SetWinnerSelectionVote for profit share pollutes voting storage.
            // This should use dedicated profit-share storage slots instead of hijacking BackerVotesEnum slots.
            // See audit finding #9 for details.
            AcquireLock();
            try
            {
                ProjectState.SetWinnerSelectionVote(projectId, investorAddress, manufacturerAddress, (int)profitSharePercentage);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void distributeManufacturerProfit(string projectId, UInt160 manufacturerAddress, BigInteger profitAmount)
        {
            if (!Runtime.CheckWitness(manufacturerAddress))
                throw new Exception("Only manufacturer can distribute their profit within the project.");

            if (manufacturerAddress.Length != 20) throw new Exception("The parameter ManufacturerAddress SHOULD be a 20-byte address.");
            if (profitAmount <= 0) throw new Exception("Profit amount must be greater than zero.");

            if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
                throw new Exception("Manufacturer not a candidate in this project.");

            // TODO: ARCHITECTURAL ISSUE - Using SetReservedFunds for manufacturer profit mixes investor capital with manufacturer payouts.
            // This should use dedicated manufacturer profit pool storage instead of the reserved-funds bucket.
            // See audit finding #9 for details.
            AcquireLock();
            try
            {
                BigInteger currentProfit = ProjectState.GetReservedFunds(projectId, manufacturerAddress);
                ProjectState.SetReservedFunds(projectId, manufacturerAddress, currentProfit + profitAmount);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

    }
}
