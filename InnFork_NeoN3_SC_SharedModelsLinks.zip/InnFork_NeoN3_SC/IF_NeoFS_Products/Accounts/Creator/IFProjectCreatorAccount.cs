using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : Neo.SmartContract.Framework.SmartContract
{


    public partial class ProjectCreatorAccount
    {
        public ProjectCreatorAccount(UInt160 wallet)
        {
            WalletAddress = wallet;
        }


        public static ProjectCreatorAccount getProjectCreatorAccount(UInt160 projectCreatorAccount)
        {
            var raw = ProjectState.GetRawProjectCreatorAccount(projectCreatorAccount);
            if (raw is null) return null;
            return (ProjectCreatorAccount)StdLib.Deserialize(raw);
        }

        public static void updateExistingProjectCreatorAccount(UInt160 CallerAddress, ProjectCreatorAccount account)
        {
            if (ProjectState.GetRawProjectCreatorAccount(account.WalletAddress) == null) throw new Exception("Project creator account not found");

            ProjectState.SetRawProjectCreatorAccount(account.WalletAddress, StdLib.Serialize(account));
        }
    }

}