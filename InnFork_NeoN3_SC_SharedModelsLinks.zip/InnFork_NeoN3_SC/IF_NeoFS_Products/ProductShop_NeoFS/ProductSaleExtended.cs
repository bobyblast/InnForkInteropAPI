
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Linq;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.ComponentModel;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{
    public static void registerCustomer(UInt160 customerAddress)
    {
        if (!Runtime.CheckWitness(customerAddress))
            throw new Exception("Customer authorization failed");

        ByteString existing = CustomerMap.Get(customerAddress);
        if (existing != null)
            throw new Exception("Customer already registered");

        Customer customer = new Customer
        {
            CustomerAddress = customerAddress,
            Balance = 0,
            RegisteredAt = Runtime.Time,
            TotalPurchases = 0
        };

        CustomerMap.Put((ByteString)customerAddress, StdLib.Serialize(customer));
    }

    public static void depositCustomerFunds(UInt160 customerAddress, UInt160 token, BigInteger amount)
    {
        if (!Runtime.CheckWitness(customerAddress))
            throw new Exception("Customer authorization failed");

        if (amount <= 0)
            throw new Exception("Amount must be positive");

        ByteString customerData = CustomerMap.Get(customerAddress);
        if (customerData == null)
            throw new Exception("Customer not registered");

        Customer customer = (Customer)StdLib.Deserialize(customerData);

        BigInteger fusdAmount = amount;
        if (token != FUSDToken)
        {
            fusdAmount = swapTokenToFUSD(customerAddress, token, amount);
        }
        else
        {
            bool transferSuccess = (bool)Contract.Call(token, "transfer",
                CallFlags.All, new object[] { customerAddress, Runtime.ExecutingScriptHash, amount, null });

            if (!transferSuccess)
                throw new Exception("Token transfer failed");
        }

        customer.Balance += fusdAmount;
        CustomerMap.Put((ByteString)customerAddress, StdLib.Serialize(customer));

        OnCustomerDeposit(customerAddress, token, amount, fusdAmount);
    }

    private static BigInteger getCustomerBalance(UInt160 customerAddress, UInt160 paymentToken)
    {
        ByteString data = CustomerMap.Get(customerAddress);
        if (data == null)
            return 0;

        Customer customer = (Customer)StdLib.Deserialize(data);
        return customer.Balance;
    }

    private static void deductCustomerBalance(UInt160 customerAddress, UInt160 paymentToken, BigInteger amount)
    {
        ByteString data = CustomerMap.Get(customerAddress);
        if (data == null)
            throw new Exception("Customer not found");

        Customer customer = (Customer)StdLib.Deserialize(data);

        if (customer.Balance < amount)
            throw new Exception("Insufficient balance");

        customer.Balance -= amount;
        customer.TotalPurchases += amount;
        CustomerMap.Put((ByteString)customerAddress, StdLib.Serialize(customer));
    }

    private static void distributeRevenue(SaleRecord sale, BigInteger totalRevenue)
    {
        BigInteger platformFee = (totalRevenue * 2) / 100;
        transferToPlatform(sale.PaymentToken, platformFee);

        BigInteger remainingRevenue = totalRevenue - platformFee;

        BigInteger backerRewards = (remainingRevenue * 10) / 100;
        if (!string.IsNullOrEmpty(sale.ProjectId))
        {
            distributeBackerRewards(sale.ProjectId, sale.ManufacturerAddress, backerRewards, sale.PaymentToken);
        }
        else
        {
            backerRewards = 0;
        }

        BigInteger investorRewards = (remainingRevenue * 15) / 100;
        distributeInvestorRewards(sale.ManufacturerAddress, investorRewards, sale.PaymentToken);

        BigInteger manufacturerShare = remainingRevenue - backerRewards - investorRewards;
        transferToManufacturer(sale.ManufacturerAddress, sale.PaymentToken, manufacturerShare);

        sale.RewardsDistributed = true;
    }

    private static void distributeBackerRewards(
        string projectId,
        UInt160 manufacturerAddress,
        BigInteger totalReward,
        UInt160 paymentToken)
    {
        if (totalReward <= 0) return;

        UInt160[] backers = InnFork.NeoN3.ProjectState.GetBackersWithDonations(projectId);
        if (backers == null || backers.Length == 0) return;

        BigInteger totalBackerContribution = 0;
        Map<UInt160, BigInteger> backerContributions = new Map<UInt160, BigInteger>();

        for (int i = 0; i < backers.Length; i++)
        {
            UInt160 backer = backers[i];
            BigInteger contribution = InnFork.NeoN3.ProjectState.GetBackerReservation(projectId, backer, manufacturerAddress);

            if (contribution > 0)
            {
                backerContributions[backer] = contribution;
                totalBackerContribution += contribution;
            }
        }

        if (totalBackerContribution == 0) return;


        foreach (var backer in backerContributions.Keys) // Limit to 10 iterations to avoid excessive gas usage
        {

            BigInteger contribution = backerContributions[backer];

            BigInteger backerReward = (totalReward * contribution) / totalBackerContribution;

            if (backerReward > 0)
            {
                transferRewardToBacker(backer, paymentToken, backerReward);
                recordBackerReward(projectId, backer, backerReward, paymentToken);
                OnBackerRewardDistributed(projectId, backer, backerReward);
            }
        }
    }

    private static void distributeInvestorRewards(
        UInt160 manufacturerAddress,
        BigInteger totalReward,
        UInt160 paymentToken)
    {
        if (totalReward <= 0) return;
    }

    private static void transferToManufacturer(
        UInt160 manufacturerAddress,
        UInt160 paymentToken,
        BigInteger amount)
    {
        if (amount <= 0) return;

        bool transferSuccess = (bool)Contract.Call(paymentToken, "transfer",
            CallFlags.All, new object[] { Runtime.ExecutingScriptHash, manufacturerAddress, amount, null });

        if (!transferSuccess)
            throw new Exception("Manufacturer transfer failed");
    }

    private static void transferRewardToBacker(
        UInt160 backerAddress,
        UInt160 paymentToken,
        BigInteger amount)
    {
        if (amount <= 0) return;

        bool transferSuccess = (bool)Contract.Call(paymentToken, "transfer",
            CallFlags.All, new object[] { Runtime.ExecutingScriptHash, backerAddress, amount, null });

        if (!transferSuccess)
            throw new Exception("Backer reward transfer failed");
    }

    private static void transferToPlatform(UInt160 paymentToken, BigInteger amount)
    {
        if (amount <= 0) return;

        UInt160 platformAddress = owner();

        bool transferSuccess = (bool)Contract.Call(paymentToken, "transfer",
            CallFlags.All, new object[] { Runtime.ExecutingScriptHash, platformAddress, amount, null });

        if (!transferSuccess)
            throw new Exception("Platform fee transfer failed");
    }

    private static void recordBackerReward(
        string projectId,
        UInt160 backerAddress,
        BigInteger rewardAmount,
        UInt160 paymentToken)
    {
        string key = projectId + "_" + backerAddress;

        ByteString currentData = BackerRewardsMap.Get(key);
        BigInteger currentRewards = currentData != null ? (BigInteger)currentData : 0;

        BackerRewardsMap.Put(key, currentRewards + rewardAmount);
    }

    private static string findProjectIdForManufacturer(UInt160 manufacturerAddress, UInt160 productId)
    {
        ByteString data = ProductStore.Get(productId);
        if (data == null)
            return string.Empty;

        Product product = (Product)StdLib.Deserialize(data);
        return product.ProjectId ?? string.Empty;
    }

    public delegate void OnCustomerDepositDelegate(UInt160 customer, UInt160 token, BigInteger amount, BigInteger fusdAmount);
    [DisplayName("CustomerDeposit")]
    public static event OnCustomerDepositDelegate OnCustomerDeposit;
}