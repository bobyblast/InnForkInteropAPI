﻿
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{
    public static ProductSalesStats getProductStatistics(UInt160 productId)
    {
        ByteString data = SalesStatisticsMap.Get(productId);

        if (data == null)
        {
            return new ProductSalesStats
            {
                ProductId = productId,
                TotalSales = 0,
                TotalRevenue = 0,
                TotalQuantitySold = 0,
                LastSaleTimestamp = 0
            };
        }

        return (ProductSalesStats)StdLib.Deserialize(data);
    }

    public static Map<string, BigInteger> getManufacturerSalesAnalytics(UInt160 manufacturerAddress)
    {
        Map<string, BigInteger> analytics = new Map<string, BigInteger>();

        // Ключи в ManufacturerProductsMap: Base64(manufacturer) + "_" + Base64(productId) -> productId
        // Поэтому используем Find по префиксу StorageMap и фильтруем ключи на уровне кода.
        Iterator iterator = ManufacturerProductsMap.Find(FindOptions.KeysOnly);

        BigInteger totalProducts = 0;
        BigInteger totalRevenue = 0;
        BigInteger totalSales = 0;

        string manuPrefix = StdLib.Base64Encode(manufacturerAddress) + "_";
        while (iterator.Next())
        {
            // В режиме KeysOnly Storage iterator возвращает ключ в iterator.Value
            byte[] keyBytes = (byte[])iterator.Value;
            if (keyBytes is null) continue;
            ByteString fullKey = keyBytes.ToByteString();
            if (!fullKey.StartWith(manuPrefix))
                continue;

            // Значение по этому ключу — productId
            ByteString pidBytes = ManufacturerProductsMap.Get(fullKey);
            if (pidBytes is null) continue;
            UInt160 productId = (UInt160)pidBytes;
            ProductSalesStats stats = getProductStatistics(productId);

            totalProducts += 1;
            totalRevenue += stats.TotalRevenue;
            totalSales += stats.TotalSales;
        }

        analytics["TotalProducts"] = totalProducts;
        analytics["TotalRevenue"] = totalRevenue;
        analytics["TotalSales"] = totalSales;
        analytics["AverageRevenuePerProduct"] = totalProducts > 0 ? totalRevenue / totalProducts : 0;

        return analytics;
    }

    public static BigInteger getTotalBackerRewards(string projectId, UInt160 backerAddress)
    {
        string key = projectId + "_" + backerAddress;
        ByteString result = BackerRewardsMap.Get(key);
        return result != null ? (BigInteger)result : 0;
    }

    private static void updateSalesStatistics(
        UInt160 productId,
        BigInteger quantity,
        BigInteger revenue)
    {
        ByteString data = SalesStatisticsMap.Get(productId);
        ProductSalesStats stats;

        if (data == null)
        {
            stats = new ProductSalesStats
            {
                ProductId = productId,
                TotalSales = 1,
                TotalRevenue = revenue,
                TotalQuantitySold = quantity,
                LastSaleTimestamp = Runtime.Time
            };
        }
        else
        {
            stats = (ProductSalesStats)StdLib.Deserialize(data);
            stats.TotalSales += 1;
            stats.TotalRevenue += revenue;
            stats.TotalQuantitySold += quantity;
            stats.LastSaleTimestamp = Runtime.Time;
        }

        SalesStatisticsMap.Put((ByteString)productId, StdLib.Serialize(stats));
    }
}