using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.ComponentModel;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{
    public struct SaleRecord
    {
        public UInt160 SaleId;
        public UInt160 ProductId;
        public UInt160 ManufacturerAddress;
        public UInt160 CustomerAddress;
        public BigInteger Quantity;
        public BigInteger TotalPrice;
        public UInt160 PaymentToken;
        public ulong SaleTimestamp;
        public string ProjectId;
        public bool RewardsDistributed;
    }

    public struct ProductSalesStats
    {
        public UInt160 ProductId;
        public BigInteger TotalSales;
        public BigInteger TotalRevenue;
        public BigInteger TotalQuantitySold;
        public ulong LastSaleTimestamp;
    }

    public struct Customer
    {
        public UInt160 CustomerAddress;
        public BigInteger Balance;
        public ulong RegisteredAt;
        public BigInteger TotalPurchases;
    }

    public static UInt160 purchaseProduct(
        UInt160 productId,
        UInt160 customerAddress,
        BigInteger quantity,
        UInt160 paymentToken)
    {
        if (customerAddress.Length != 20)
            throw new Exception("Invalid customer address");

        if (!Runtime.CheckWitness(customerAddress))
            throw new Exception("Customer authorization failed");

        ByteString productData = ProductStore.Get(productId);
        if (productData == null)
            throw new Exception("Product not found");

        Product product = (Product)StdLib.Deserialize(productData);

        if (product.Quantity < quantity)
            throw new Exception("Insufficient product quantity");

        BigInteger totalPrice = product.Price * quantity;

        if (product.IsDiscountActive && product.DiscountAmount > 0)
        {
            totalPrice = totalPrice - (totalPrice * product.DiscountAmount / 100);
        }

        BigInteger customerBalance = getCustomerBalance(customerAddress, paymentToken);
        if (customerBalance < totalPrice)
            throw new Exception("Insufficient customer balance");

        byte[] timeBytes = ((BigInteger)Runtime.Time).ToByteArray();
        byte[] data = Helper.Concat((byte[])productId, Helper.Concat((byte[])customerAddress, timeBytes));
        UInt160 saleId = (UInt160)CryptoLib.Ripemd160(data.ToByteString());

        string projectId = findProjectIdForManufacturer(product.ManufacturerAddress, productId);

        SaleRecord sale = new SaleRecord
        {
            SaleId = saleId,
            ProductId = productId,
            ManufacturerAddress = product.ManufacturerAddress,
            CustomerAddress = customerAddress,
            Quantity = quantity,
            TotalPrice = totalPrice,
            PaymentToken = paymentToken,
            SaleTimestamp = Runtime.Time,
            ProjectId = projectId,
            RewardsDistributed = false
        };

        deductCustomerBalance(customerAddress, paymentToken, totalPrice);

        distributeRevenue(sale, totalPrice);

        product.Quantity -= quantity;
        ProductStore.Put((ByteString)productId, StdLib.Serialize(product));

        ProductSalesMap.Put((ByteString)saleId, StdLib.Serialize(sale));

        updateSalesStatistics(productId, quantity, totalPrice);

        OnProductSold(productId, customerAddress, quantity, totalPrice);

        return saleId;
    }

    public delegate void OnProductSoldDelegate(UInt160 productId, UInt160 customer, BigInteger quantity, BigInteger price);
    [DisplayName("ProductSold")]
    public static event OnProductSoldDelegate OnProductSold;

    public delegate void OnBackerRewardDistributedDelegate(string projectId, UInt160 backer, BigInteger reward);
    [DisplayName("BackerRewardDistributed")]
    public static event OnBackerRewardDistributedDelegate OnBackerRewardDistributed;
}