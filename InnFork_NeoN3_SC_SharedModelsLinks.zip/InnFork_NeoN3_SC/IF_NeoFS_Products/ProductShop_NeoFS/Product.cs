
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System.Numerics;

namespace InnFork.NeoN3;

public partial class IF_MainGateway : SmartContract
{
    private static StorageMap ProductStore = new StorageMap(Storage.CurrentContext, "Products");
    private static StorageMap ManufacturerProductsStore = new StorageMap(Storage.CurrentContext, "ManufacturerProducts");
    private static StorageMap BackerRewardsMap = new StorageMap(Storage.CurrentContext, "BackerRewards");
    private static StorageMap CustomerMap = new StorageMap(Storage.CurrentContext, "Customers");
    private static StorageMap SalesStatisticsMap = new StorageMap(Storage.CurrentContext, "SalesStatistics");
    private static StorageMap ProductSalesMap = new StorageMap(Storage.CurrentContext, "ProductSales");


    public struct Product
    {
        public UInt160 ProductId { get; set; }
        public UInt160 ManufacturerAddress { get; set; }
        public string ProjectId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string NeoFSContainerId { get; set; }
        public string NeoFSObjectId { get; set; }
        public BigInteger Price { get; set; }
        public UInt160 PriceToken { get; set; }
        public BigInteger Quantity { get; set; }
        public ulong CreatedAt { get; set; }
        public bool IsActive { get; set; }
        public bool IsDiscountActive { get; set; }
        public BigInteger DiscountAmount { get; set; }
    }

}