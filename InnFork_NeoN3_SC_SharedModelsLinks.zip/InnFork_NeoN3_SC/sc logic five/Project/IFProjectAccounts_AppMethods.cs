﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.IF_MainGateway;
using static InnFork.NeoN3.IF_MainGateway.ProjectAccount;



namespace InnFork.NeoN3;




public partial class IF_MainGateway

// Voting Methods
{



    public static bool canBackerVote(string projectId, UInt160 backer, bool ignoreAlreadyVoted = false)
    {
        // Используем адаптер стейта для проверки права голоса и неучастия в бане
        return ProjectState.IsBackerEligible(projectId, backer);
    }

    /// <summary>
    /// Вес голоса бэкера. Переведён на mini-adapter.
    /// </summary>
    public static BigInteger getBackerVoteWeight(string projectId, UInt160 backer)
    {
        BigInteger weight = ProjectState.GetBackerVoteWeight(projectId, backer);
        if (weight <= 0) weight = 1;

        // опционально сохраним кэш веса в state
        ProjectState.SetBackerVoteWeightValue(projectId, backer, weight);
        return weight;
    }


    // УДАЛЕНО: Map<string, BigInteger> VotingTierWeights
    // CRUD через StateStorage
    public static void SetVotingTierWeight(string projectId, string tierId, BigInteger weight) =>
        InnFork.NeoN3.ProjectState.SetVoteWeightByTier(projectId, tierId, weight);

    public static BigInteger GetVotingTierWeight(string projectId, string tierId) =>
        InnFork.NeoN3.ProjectState.GetVoteWeightByTier(projectId, tierId);

    public static void RemoveVotingTierWeight(string projectId, string tierId) =>
        InnFork.NeoN3.ProjectState.RemoveVoteWeightByTier(projectId, tierId);

    public static string[] GetVotingTierIds(string projectId) =>
        InnFork.NeoN3.ProjectState.GetVotingTierWeightsKeys(projectId);

    public static void ClearVotingTierWeightsAll(string projectId) =>
        InnFork.NeoN3.ProjectState.ClearVotingTierWeights(projectId);

    public static void SetVoterTier(string projectId, string voteId, UInt160 voter, byte tier) =>
        InnFork.NeoN3.ProjectState.SetMultiTierVoting(projectId, voteId, voter, tier);

    public static byte GetVoterTier(string projectId, string voteId, UInt160 voter) =>
        InnFork.NeoN3.ProjectState.GetMultiTierVoting(projectId, voteId, voter);
}




public partial class IF_MainGateway // Manufacturer Management and Selection
{
    public static bool hasManufacturerUsedMilestoneFunding(string projectId, UInt160 manufacturerId)
    {
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerId)) return false;
        // Признаком считаем наличие хотя бы одного milestone
        string[] keys = ProjectState.GetMilestoneKeys(projectId, manufacturerId);
        return keys != null && keys.Length > 0;
    }

    public static void validateManufacturer(string projectId, UInt160 manufacturer)
    {
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer))
            throw new Exception("Manufacturer Candidate not registered");
    }

    public static bool canActivateManufacturer(string projectId, UInt160 manufacturer)
    {
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer)) return false;

        // Базовая логика: есть резерв средств или есть хотя бы один созданный этап
        if (ProjectState.GetReservedFunds(projectId, manufacturer) > 0) return true;

        string[] keys = ProjectState.GetMilestoneKeys(projectId, manufacturer);
        if (keys != null && keys.Length > 0) return true;

        return true; // по умолчанию разрешаем (как в исходнике)
    }


    public static BigInteger getExternalRating(string projectId, UInt160 manufacturer)
    {
        ManufacturerAccount manuAccount = ManufacturerAccount.getManufacturerAccount(manufacturer);
        return manuAccount != null ? manuAccount.ExternalRating : 0;
    }

    public static BigInteger calculateManufacturerFinalScore(string projectId, UInt160 manufacturer)
    {
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer)) return 0;

        ManufacturerAccount manuAcc = ManufacturerAccount.getManufacturerAccount(manufacturer);
        BigInteger reputation = manuAcc != null ? manuAcc.ReputationScore : 0;
        BigInteger externalRating = manuAcc != null ? manuAcc.ExternalRating : 0;
        BigInteger votesWeight = ProjectState.GetManufacturerVoteWeight(projectId, manufacturer);

        return reputation + externalRating + votesWeight;
    }

    public static BigInteger calculateManufacturerWeightedVoteResult(string projectId, UInt160 manufacturer)
    {
        BigInteger totalWeightedScore = 0;

        UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
        if (backers != null)
        {
            for (int i = 0; i < backers.Length; i++)
            {
                UInt160 backerAddress = backers[i];
                if (!ProjectState.IsBackerEligible(projectId, backerAddress)) continue;

                BigInteger backerWeight = getBackerVoteWeight(projectId, backerAddress);
                BackerVotesEnum vote = (BackerVotesEnum)ProjectState.GetWinnerSelectionVote(projectId, backerAddress, manufacturer);

                if (vote == BackerVotesEnum.Positive) totalWeightedScore += backerWeight;
                else if (vote == BackerVotesEnum.Negative) totalWeightedScore -= backerWeight;
                // Abstained — без влияния
            }
        }

        ProjectState.SetManufacturerVoteWeight(projectId, manufacturer, totalWeightedScore);
        return totalWeightedScore;
    }

    public static void setAutoSelectWinner(string projectId, UInt160 backer, UInt160 manufacturer)
    {
        if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");
        if (!canBackerVote(projectId, backer)) throw new Exception("Backer is not eligible to set auto-vote.");
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturer)) throw new Exception("Manufacturer candidate not registered.");

        ProjectState.SetAutoSelectWinner(projectId, backer, manufacturer);
    }

}












































public partial class IF_MainGateway // диспуты 
{

    public static void handleDisputeResolution(string projectId, string disputeId)
    {
        var rec = InnFork.NeoN3.ProjectState.GetDispute(projectId, disputeId);
        if (rec != null)
        {
            InnFork.NeoN3.ProjectState.SetDisputeBanReason(projectId, disputeId, MapBanReason(rec.Type));
        }
        const string status = "resolved";
        InnFork.NeoN3.ProjectState.ResolveDispute(projectId, disputeId, status);
        InnFork.NeoN3.ProjectState.ApplyDisputeSanctions(projectId, disputeId);
        InnFork.NeoN3.ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        EmitDisputeResolutionEvent(projectId, disputeId, status);
    }

    public static void handleMilestoneDisputeResolution(string projectId, string disputeId)
    {
        var rec = InnFork.NeoN3.ProjectState.GetDispute(projectId, disputeId);
        if (rec != null)
        {
            InnFork.NeoN3.ProjectState.SetDisputeBanReason(projectId, disputeId, BanReason.MilestoneFailure);
        }
        const string status = "milestone_resolved";
        InnFork.NeoN3.ProjectState.ResolveDispute(projectId, disputeId, status);
        InnFork.NeoN3.ProjectState.ApplyDisputeSanctions(projectId, disputeId);
        InnFork.NeoN3.ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        EmitDisputeResolutionEvent(projectId, disputeId, status);
    }

    public static void handlePaymentDisputeResolution(string projectId, string disputeId)
    {
        var rec = InnFork.NeoN3.ProjectState.GetDispute(projectId, disputeId);
        if (rec != null)
        {
            InnFork.NeoN3.ProjectState.SetDisputeBanReason(projectId, disputeId, BanReason.PaymentIssues);
        }
        const string status = "payment_resolved";
        InnFork.NeoN3.ProjectState.ResolveDispute(projectId, disputeId, status);
        InnFork.NeoN3.ProjectState.ApplyDisputeSanctions(projectId, disputeId);
        InnFork.NeoN3.ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        EmitDisputeResolutionEvent(projectId, disputeId, status);
    }

    public static void handleQualityDisputeResolution(string projectId, string disputeId)
    {
        var rec = InnFork.NeoN3.ProjectState.GetDispute(projectId, disputeId);
        if (rec != null)
        {
            InnFork.NeoN3.ProjectState.SetDisputeBanReason(projectId, disputeId, BanReason.QualityControlFailure);
        }
        const string status = "quality_resolved";
        InnFork.NeoN3.ProjectState.ResolveDispute(projectId, disputeId, status);
        InnFork.NeoN3.ProjectState.ApplyDisputeSanctions(projectId, disputeId);
        InnFork.NeoN3.ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        EmitDisputeResolutionEvent(projectId, disputeId, status);
    }

    public static void handleFraudDisputeResolution(string projectId, string disputeId)
    {
        var rec = InnFork.NeoN3.ProjectState.GetDispute(projectId, disputeId);
        if (rec != null)
        {
            InnFork.NeoN3.ProjectState.SetDisputeBanReason(projectId, disputeId, BanReason.FraudSuspicion);
        }
        const string status = "fraud_resolved";
        InnFork.NeoN3.ProjectState.ResolveDispute(projectId, disputeId, status);
        InnFork.NeoN3.ProjectState.ApplyDisputeSanctions(projectId, disputeId);
        InnFork.NeoN3.ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        EmitDisputeResolutionEvent(projectId, disputeId, status);
    }

    public static void handleContractBreachResolution(string projectId, string disputeId)
    {
        var rec = InnFork.NeoN3.ProjectState.GetDispute(projectId, disputeId);
        if (rec != null)
        {
            InnFork.NeoN3.ProjectState.SetDisputeBanReason(projectId, disputeId, BanReason.ContractViolation);
        }
        const string status = "contract_breach_resolved";
        InnFork.NeoN3.ProjectState.ResolveDispute(projectId, disputeId, status);
        InnFork.NeoN3.ProjectState.ApplyDisputeSanctions(projectId, disputeId);
        InnFork.NeoN3.ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        EmitDisputeResolutionEvent(projectId, disputeId, status);
    }

    public static void handleGeneralDisputeResolution(string projectId, string disputeId)
    {
        var rec = InnFork.NeoN3.ProjectState.GetDispute(projectId, disputeId);
        if (rec != null)
        {
            InnFork.NeoN3.ProjectState.SetDisputeBanReason(projectId, disputeId, MapBanReason(rec.Type));
        }
        const string status = "general_resolved";
        InnFork.NeoN3.ProjectState.ResolveDispute(projectId, disputeId, status);
        InnFork.NeoN3.ProjectState.ApplyDisputeSanctions(projectId, disputeId);
        InnFork.NeoN3.ProjectState.SetLastActivityTime(projectId, Runtime.Time);
        EmitDisputeResolutionEvent(projectId, disputeId, status);
    }

    public static void handleDisputeRejection(string projectId, string disputeId)
    {
        InnFork.NeoN3.ProjectState.RejectDispute(projectId, disputeId, "rejected");
    }

    public static void handleDisputeEscalation(string projectId, string disputeId)
    {
        InnFork.NeoN3.ProjectState.EscalateDispute(projectId, disputeId, "escalated");
    }

    public static void handleMilestoneEscalation(string projectId, string disputeId)
    {
        InnFork.NeoN3.ProjectState.EscalateDispute(projectId, disputeId, "milestone_escalated");
    }

    public static void handlePaymentEscalation(string projectId, string disputeId)
    {
        InnFork.NeoN3.ProjectState.EscalateDispute(projectId, disputeId, "payment_escalated");
    }

    public static void handleFraudEscalation(string projectId, string disputeId)
    {
        InnFork.NeoN3.ProjectState.EscalateDispute(projectId, disputeId, "fraud_escalated");
    }

    private static void EmitDisputeResolutionEvent(string projectId, string disputeId, string resolutionType)
    {
        OnDisputeResolved(projectId, disputeId, resolutionType);
    }

    private static void OnDisputeResolved(string projectId, string disputeId, string resolutionType)
    {
        //TODO : реализовать логику обработки события разрешения спора 


    }
}


public partial class IF_MainGateway
{

    private static BanReason MapBanReason(DisputeType type)
    {
        switch (type)
        {
            case DisputeType.MilestoneCompletion: return BanReason.MilestoneFailure;
            case DisputeType.ContractBreach: return BanReason.ContractViolation;
            case DisputeType.FraudAccusation: return BanReason.SmartContractExploit;
            case DisputeType.PaymentDispute: return BanReason.PaymentIssues;
            case DisputeType.QualityDispute: return BanReason.QualityIssues;
            case DisputeType.DeliveryDispute: return BanReason.DeliveryFailure;
            case DisputeType.IntellectualProperty: return BanReason.IntellectualPropertyTheft;
            case DisputeType.TechnicalIssues: return BanReason.TechnicalViolations;
            case DisputeType.CommunicationFailure: return BanReason.CommunicationIssues;
            case DisputeType.Fraud: return BanReason.FraudulentActivity;
            case DisputeType.Refund: return BanReason.ViolationOfTerms;
            default: return BanReason.ContractViolation;
        }
    }



}


