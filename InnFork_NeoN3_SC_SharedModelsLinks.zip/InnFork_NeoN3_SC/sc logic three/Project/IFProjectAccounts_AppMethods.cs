﻿using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.IF_MainGateway;
using static InnFork.NeoN3.IF_MainGateway.ProjectAccount;


namespace InnFork.NeoN3
{





    public partial class IF_MainGateway

    // диспуты 
    {
        /// <summary>
        /// Получает оценку риска для причины бана
        /// </summary>
        public static BigInteger getRiskScoreForBanReason(BanReason reason)
        {
            switch (reason)
            {
                case BanReason.FraudulentActivity:
                    return 100; // Максимальный риск
                case BanReason.SystemAbuse:
                    return 50;
                case BanReason.SecurityBreach:
                    return 40;
                case BanReason.InappropriateBehavior:
                    return 25;
                case BanReason.ViolationOfTerms:
                    return 20;
                default:
                    return 10; // Базовый риск
            }
        }

        public static void blockBackerFinance(string projectId, UInt160 backerAddress, BanReason banReason, BigInteger amountToBlock)
        {
            var project = getProjectAccount(projectId);

            if (!isParticipantBanned(projectId, backerAddress))
                throw new Exception("Participant is not banned");

            BigInteger currentBalance = ProjectState.GetBackerDonation(projectId, backerAddress);
            if (amountToBlock > currentBalance)
                amountToBlock = currentBalance;

            if (amountToBlock <= 0)
                return;

            AcquireLock();
            try
            {
                ProjectState.UpdateLockedFunds(projectId, amountToBlock);
                ProjectState.SetBackerDonation(projectId, backerAddress, currentBalance - amountToBlock);

                BigInteger refundHistory = ProjectState.GetRefundHistory(projectId, backerAddress);
                ProjectState.SetRefundHistory(projectId, backerAddress, refundHistory + amountToBlock);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void applyBackerBanSanctions(string projectId, UInt160 backerAddress, BanReason reason)
        {
            BigInteger backerBalance = ProjectState.GetBackerDonation(projectId, backerAddress);

            switch (reason)
            {
                case BanReason.FraudulentActivity:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance);
                    break;

                case BanReason.SystemAbuse:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 2);
                    break;

                case BanReason.InappropriateBehavior:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 4);
                    break;

                case BanReason.ViolationOfTerms:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 5);
                    break;

                default:
                    blockBackerFinance(projectId, backerAddress, reason, backerBalance / 10);
                    break;
            }

            BigInteger currentScore = ProjectState.GetSuspiciousActivityScore(projectId, backerAddress);
            ProjectState.SetSuspiciousActivityScore(projectId, backerAddress, currentScore + getRiskScoreForBanReason(reason));
        }

        public static string createDispute(string projectId, UInt160 initiator, DisputeType disputeType, string description, UInt160 manufacturerInvolved = null, byte milestoneStepInvolved = 0)
        {
            if (!Runtime.CheckWitness(initiator))
                throw new Exception("Dispute initiator authorization failed.");

            var project = getProjectAccount(projectId);

            bool isParticipant = (initiator == project.ProjectCreatorAddress) ||
                                 ProjectState.IsBackerEligible(projectId, initiator) ||
                                 ProjectState.IsManufacturerRegistered(projectId, initiator);

            if (!isParticipant)
                throw new Exception("Only project participants can create a dispute.");

            if (disputeType == DisputeType.MilestoneCompletion)
            {
                if (manufacturerInvolved == null || milestoneStepInvolved == 0)
                    throw new Exception("Manufacturer and milestone step must be provided for a milestone dispute.");

                if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerInvolved))
                    throw new Exception("The specified manufacturer is not a candidate in this project.");

                var milestone = (MilestoneCompletionVotesStruct)ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerInvolved, milestoneStepInvolved);
                if (milestone == null)
                    throw new Exception("Milestone not found.");

                if (milestone.IsDisputed)
                    throw new Exception("A dispute for this milestone is already open.");

                milestone.IsDisputed = true;
                ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturerInvolved, milestoneStepInvolved, milestone);
            }

            if (manufacturerInvolved == null) manufacturerInvolved = UInt160.Zero;
            string disputeId = ProjectState.CreateDispute(projectId, initiator, disputeType, description, manufacturerInvolved, milestoneStepInvolved);
            return disputeId;
        }

        public static bool isParticipantBanned(string projectId, UInt160 participantAddress)
        {
            return ProjectState.IsParticipantBanned(projectId, participantAddress);
        }

        public static void banBacker(string projectId, UInt160 backerAddress, BanReason reason)
        {
            var project = getProjectAccount(projectId);

            if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
                throw new Exception("Only contract owner or project author can ban backers");

            if (!ProjectState.IsBackerEligible(projectId, backerAddress))
                throw new Exception("Backer is not part of this project");

            if (ProjectState.IsParticipantBanned(projectId, backerAddress))
                throw new Exception("Backer is already banned");

            AcquireLock();
            try
            {
                ProjectState.BanParticipant(projectId, backerAddress, false, (int)reason);
                applyBackerBanSanctions(projectId, backerAddress, reason);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void createMilestoneDispute(UInt160 initiatorAddress, string projectId, UInt160 manufacturerAddress, byte stepNumber, string disputeReason)
        {
            if (!Runtime.CheckWitness(initiatorAddress))
                throw new Exception("Authorization failed for creating a dispute.");

            var project = getProjectAccount(projectId);
            if (project == null) throw new Exception("Project not found.");

            if (!ProjectState.IsBackerEligible(projectId, initiatorAddress))
                throw new Exception("Only project backers can create disputes.");

            var milestoneObj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, stepNumber);
            if (milestoneObj == null)
                throw new Exception("Milestone not found.");

            string milestoneId = IFHelper.createComplexKey(manufacturerAddress, stepNumber);
            string disputeId = projectId + milestoneId + initiatorAddress.ToString();

            createDispute(projectId, initiatorAddress, DisputeType.MilestoneCompletion, "Milestone " + stepNumber + ": " + disputeReason);



            //            ProjectState.CreateDispute(projectId, initiatorAddress, DisputeType.MilestoneCompletion, disputeReason, manufacturerAddress, stepNumber);




            var milestone = (MilestoneCompletionVotesStruct)milestoneObj;
            milestone.IsDisputed = true;
            ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, stepNumber, milestone);
        }

        public static void resolveDispute(string projectId, string disputeId, DisputeStatus newStatus, string resolutionNote)
        {
            if (!IsOwner())
                throw new Exception("Authorization failed. Only the contract owner can resolve disputes.");

            if (disputeId is null || disputeId.Length == 0)
                throw new Exception("Dispute identifier is required");

            if (newStatus == DisputeStatus.Created || newStatus == DisputeStatus.Open)
                throw new Exception("Target status must be a post-review state");

            if (resolutionNote is null)
                resolutionNote = string.Empty;

            var disputeObj = ProjectState.GetDispute(projectId, disputeId);
            if (disputeObj is null)
                throw new Exception("Dispute not found");


            DisputeRecord dispute = (DisputeRecord)disputeObj;
            if (!isValidStatusTransition(dispute.Status, newStatus))
                throw new Exception("Invalid dispute status transition");

            AcquireLock();
            try
            {
                switch (newStatus)
                {
                    case DisputeStatus.UnderReview:
                        ProjectState.SetDisputeStatusUnderReview(projectId, disputeId);
                        break;
                    case DisputeStatus.EvidenceCollection:
                    case DisputeStatus.Mediation:
                    case DisputeStatus.Arbitration:
                        ProjectState.UpdateDisputeStatus(projectId, disputeId, newStatus, resolutionNote);
                        break;
                    case DisputeStatus.Escalated:
                        ProjectState.EscalateDispute(projectId, disputeId, resolutionNote);
                        break;
                    case DisputeStatus.Resolved:
                        ProjectState.ResolveDispute(projectId, disputeId, resolutionNote);
                        ProjectState.ApplyDisputeSanctions(projectId, disputeId);
                        break;
                    case DisputeStatus.Rejected:
                        ProjectState.RejectDispute(projectId, disputeId, resolutionNote);
                        break;
                    case DisputeStatus.Closed:
                        ProjectState.CloseDispute(projectId, disputeId);
                        break;
                    default:
                        throw new Exception("Unsupported dispute status");
                }
            }
            finally
            {
                ReleaseAcquireLock();
            }
            //!!TODO: Events compile nccs.exe error read synthax tree
            /*      Action<string, int, int> statusChanged = DisputeStatusChanged;
                  statusChanged?.Invoke(disputeId, (int)dispute.Status, (int)newStatus);
   
            var statusUpdated = DisputeStatusUpdated;
            statusUpdated?.Invoke(disputeId, newStatus);   */
        }

        /// <summary>
        /// Проверяет корректность перехода между статусами спора
        /// </summary>
        public static bool isValidStatusTransition(DisputeStatus current, DisputeStatus next)
        {
            // Граф возможных переходов между статусами
            switch (current)
            {
                case DisputeStatus.Open:
                case DisputeStatus.Created:
                    // Из начального состояния можно перейти в любое активное состояние
                    return next == DisputeStatus.UnderReview ||
                           next == DisputeStatus.EvidenceCollection ||
                           next == DisputeStatus.Mediation ||
                           next == DisputeStatus.Resolved ||
                           next == DisputeStatus.Rejected ||
                           next == DisputeStatus.Escalated ||
                           next == DisputeStatus.Closed;

                case DisputeStatus.UnderReview:
                    // Из рассмотрения можно перейти к сбору доказательств, медиации, эскалации или завершению
                    return next == DisputeStatus.EvidenceCollection ||
                           next == DisputeStatus.Mediation ||
                           next == DisputeStatus.Escalated ||
                           next == DisputeStatus.Resolved ||
                           next == DisputeStatus.Rejected ||
                           next == DisputeStatus.Closed;

                case DisputeStatus.EvidenceCollection:
                    // После сбора доказательств переходим к медиации, арбитражу или завершению
                    return next == DisputeStatus.Mediation ||
                           next == DisputeStatus.Arbitration ||
                           next == DisputeStatus.Resolved ||
                           next == DisputeStatus.Rejected ||
                           next == DisputeStatus.Escalated;

                case DisputeStatus.Mediation:
                    // После медиации либо решение, либо арбитраж
                    return next == DisputeStatus.Arbitration ||
                           next == DisputeStatus.Resolved ||
                           next == DisputeStatus.Rejected ||
                           next == DisputeStatus.Escalated;

                case DisputeStatus.Arbitration:
                    // Арбитраж ведет к окончательному решению
                    return next == DisputeStatus.Resolved ||
                           next == DisputeStatus.Rejected ||
                           next == DisputeStatus.Closed;

                case DisputeStatus.Escalated:
                    // Из эскалированного состояния можно перейти к арбитражу или завершению
                    return next == DisputeStatus.Arbitration ||
                           next == DisputeStatus.Resolved ||
                           next == DisputeStatus.Rejected;

                case DisputeStatus.Resolved:
                case DisputeStatus.Rejected:
                    // Из завершенных состояний можно только закрыть
                    return next == DisputeStatus.Closed;

                case DisputeStatus.Closed:
                    // Закрытые споры нельзя изменить
                    return false;

                default:
                    return false;
            }
        }

        public static string createBlockedFundsKey(UInt160 backerAddress, BanReason reason)
        {
            return "BLOCKED_" + backerAddress.ToString() + "_" + ((int)reason).ToString() + "_" + Runtime.Time.ToString();
        }

    }



    public partial class IF_MainGateway // Token Reward System | независима, можно выносить в отдельный контракт!
    {

        // Методы для токенизированных вознаграждений
        public static void setRewardTokenContract(string projectId, UInt160 tokenContractAddress)
        {
            ProjectAccount project = getProjectAccount(projectId);
            if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
                throw new Exception("Only project author can set reward token contract");

            AcquireLock();
            try
            {
                project.rewardTokenContractAddress = tokenContractAddress;
                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        // Распределение токенов в качестве вознаграждения
        public static void distributeTokenRewards(string projectId, UInt160 backerAddress, BigInteger tokenAmount)
        {
            if (!Runtime.CheckWitness(backerAddress))
                throw new Exception("Only backer can receive token reward");
            if (tokenAmount <= 0)
                throw new Exception("Token reward amount must be positive");

            AcquireLock();
            try
            {
                BigInteger current = ProjectState.GetBackerTokenReward(projectId, backerAddress);
                ProjectState.SetBackerTokenReward(projectId, backerAddress, current + tokenAmount);
                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        // Методы для условного голосования
        public static void addConditionalVotingRule(string projectId, string ruleId, BigInteger threshold)
        {
            var project = getProjectAccount(projectId);
            if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
                throw new Exception("Only project author can add conditional voting rule");

            // Если правило уже активно — считаем его существующим
            if (ProjectState.GetConditionalVotingRule(projectId, ruleId))
                throw new Exception("Conditional voting rule already exists");

            AcquireLock();
            try
            {
                ProjectState.SetConditionalVotingRule(projectId, ruleId, true);
                ProjectState.SetConditionalThreshold(projectId, ruleId, threshold);
                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }


    }



    public partial class IF_MainGateway // Milestone Performance Analytics
    {
        // Аналитика производительности этапов
        public static Map<string, BigInteger> getMilestonePerformanceAnalytics(string projectId, UInt160 manufacturerAddress)
        {
            ProjectAccount project = getProjectAccount(projectId);
            if (project == null) throw new Exception("Project not found");

            Map<string, BigInteger> analytics = new Map<string, BigInteger>();
            BigInteger totalDuration = 0;
            BigInteger completedMilestones = 0;
            BigInteger totalRequestedAmount = 0;

            // Перебираем разумный диапазон шагов milestone (0..255)
            for (byte step = 0; step < byte.MaxValue; step++)
            {
                var msObj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturerAddress, step);
                if (msObj == null) continue;

                MilestoneCompletionVotesStruct milestone = (MilestoneCompletionVotesStruct)msObj;
                if (milestone.isVotingStepComplete)
                {
                    completedMilestones += 1;
                    totalDuration += (milestone.Deadline_UnixTime - milestone.VotingStartTime);
                    totalRequestedAmount += milestone.RequestedFinancialAmount;
                }
            }

            analytics["CompletedMilestones"] = completedMilestones;
            analytics["TotalRequestedAmount"] = totalRequestedAmount;
            analytics["AverageDuration"] = completedMilestones > 0 ? totalDuration / completedMilestones : 0;

            return analytics;
        }

        // Общая аналитика по проекту
        public static Map<string, BigInteger> getProjectAnalytics(string projectId)
        {
            ProjectAccount project = getProjectAccount(projectId);
            if (project == null) throw new Exception("Project not found");

            Map<string, BigInteger> analytics = new Map<string, BigInteger>();
            analytics["TotalUniqueVoters"] = project.TotalUniqueVoters;
            analytics["AverageVoterParticipation"] = project.AverageVoterParticipation;
            analytics["TotalBackers"] = ProjectState.GetEligibleVotersCount(projectId);
            analytics["PrizeFundBalance"] = project.FLMUSD_PrizeFundBalance;
            analytics["TotalProjectBalance"] = project.FLMUSD_TotalProjectBalance;

            return analytics;
        }

    }



    public partial class IF_MainGateway // Token Reward System | независима, можно выносить в отдельный контракт!
    {
        public static bool checkConditionalVotingStatus(string projectId, string ruleId)
        {
            return ProjectState.GetConditionalVotingRule(projectId, ruleId);
        }

        // Методы для аналитики
        public static void updateDailyParticipation(string projectId, ulong timestamp, BigInteger participantsCount)
        {
            ProjectAccount project = getProjectAccount(projectId);
            if (!Runtime.CheckWitness(project.ProjectCreatorAddress))
                throw new Exception("Only project author can update daily participation");
            if (participantsCount <= 0)
                throw new Exception("Participants count must be positive");

            AcquireLock();
            try
            {
                BigInteger current = ProjectState.GetDailyParticipationStats(projectId, timestamp);
                ProjectState.SetDailyParticipationStats(projectId, timestamp, current + participantsCount);
                ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static BigInteger getParticipationTrend(string projectId, ulong startTimestamp, ulong endTimestamp)
        {
            if (startTimestamp > endTimestamp)
                throw new Exception("Start timestamp must be less than end timestamp");

            const ulong DAY = 86400;
            BigInteger totalParticipation = 0;

            // Суммируем по дневным меткам в заданном диапазоне
            for (ulong ts = startTimestamp; ts <= endTimestamp; ts += DAY)
            {
                totalParticipation += ProjectState.GetDailyParticipationStats(projectId, ts);
                // Если шаг меньше суток (тот же день), предотвращаем бесконечный цикл
                if (DAY == 0) break;
                if (endTimestamp - ts < DAY && ts != endTimestamp && (ts + DAY) > endTimestamp)
                {
                    // Проверим и конечную границу, если она не совпадает ровно с шагом
                    totalParticipation += ProjectState.GetDailyParticipationStats(projectId, endTimestamp);
                    break;
                }
            }

            return totalParticipation;
        }

    }




    public partial class IF_MainGateway // Backer Voting Methods
    {
        public static BigInteger calculateVoteWeight(string projectId, UInt160 voterAddress, string voteId)
        {
            // mini-adapter: читаем уровень и вес по уровню
            byte tierLevel = ProjectState.GetMultiTierVoting(projectId, voteId, voterAddress);
            BigInteger weight = ProjectState.GetVoteWeightByTier(projectId, tierLevel.ToString());
            if (weight <= 0) weight = 1;
            return weight;
        }

        public static void voteIncreaseProjectBudget(string projectId, UInt160 backer, BackerVotesEnum vote)
        {
            if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

            var project = getProjectAccount(projectId);
            AcquireLock();
            try
            {
                ProjectState.RecordVote(projectId, "FundraisingIncrease", backer, (int)vote);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void voteFundraisingCompletion(string projectId, UInt160 backer, BackerVotesEnum vote)
        {
            if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

            var project = getProjectAccount(projectId);
            AcquireLock();
            try
            {
                ProjectState.RecordVote(projectId, "FundraisingCompletion", backer, (int)vote);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void voteSuccessfulClosure(string projectId, UInt160 backer, BackerVotesEnum vote)
        {
            if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

            AcquireLock();
            try
            {
                ProjectState.RecordVote(projectId, "SuccessfulClosure", backer, (int)vote);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void votePauseResume(string projectId, UInt160 backer, BackerVotesEnum vote)
        {
            if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

            var project = getProjectAccount(projectId);
            if (project.IsProjectClosed) throw new Exception("Project is closed, cannot vote on pause/resume.");

            AcquireLock();
            try
            {
                ProjectState.RecordVote(projectId, "PauseResume", backer, (int)vote);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void voteTerminationWithRefund(string projectId, UInt160 backer, BackerVotesEnum vote)
        {
            if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

            var project = getProjectAccount(projectId);
            if (project.IsProjectClosed) throw new Exception("Project is already closed.");

            AcquireLock();
            try
            {
                ProjectState.RecordVote(projectId, "TerminationWithRefund", backer, (int)vote);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

        public static void voteForTransferProjectManagementToInnFork(string projectId, UInt160 backer, bool votingFor)
        {
            if (!Runtime.CheckWitness(backer)) throw new Exception("Backer address mismatch");

            var project = getProjectAccount(projectId);

            // Только бэкеры с взносом и не забаненные
            if (!ProjectState.IsBackerEligible(projectId, backer))
                throw new Exception("Only backers who donated to the prize fund can vote for management transfer.");

            if (project.DirectInnForkProjectManagement)
                throw new Exception("Project management has already been transferred to InnFork.");

            BackerVotesEnum vote = votingFor ? BackerVotesEnum.Positive : BackerVotesEnum.Negative;

            AcquireLock();
            try
            {
                ProjectState.RecordVote(projectId, "ManagementTransfer", backer, (int)vote);
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }

    }



}