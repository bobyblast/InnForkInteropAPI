
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.ComponentModel;
using System.Numerics;
using static InnFork.NeoN3.IF_MainGateway;
using static InnFork.NeoN3.IFHelper;



namespace InnFork.NeoN3;

public partial class IF_MainGateway : Neo.SmartContract.Framework.SmartContract
{
    public partial class ProjectAccount // ����� ������ � ����������� � �������� ���������� ����������� �� �������
    {

        public static string[] getAllProjectsIds()
        {
            var bytes = ProjectState.GetGlobalProjectsList();
            if (bytes is null) throw new Exception("No projects found");

            string[] projectAccounts = (string[])StdLib.Deserialize(bytes);
            if (projectAccounts == null || projectAccounts.Length == 0) throw new Exception("No projects found");

            var list = new List<string>();
            for (int i = 0; i < projectAccounts.Length; i++)
            {
                var pj = (ProjectAccount)StdLib.Deserialize(projectAccounts[i]);
                if (pj != null && !string.IsNullOrEmpty(pj.projectId))
                    list.Add(pj.projectId);
            }
            return list;
        }
    }
}
