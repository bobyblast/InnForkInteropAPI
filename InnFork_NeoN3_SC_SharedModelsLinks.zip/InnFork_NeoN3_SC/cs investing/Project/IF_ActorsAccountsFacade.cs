﻿using InnFork.NeoN3;
using InnFork.NeoN3.Enums;
using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;
using static InnFork.NeoN3.IF_MainGateway.ProjectAccount;



namespace InnFork.NeoN3;


public partial class IF_MainGateway

// Manufacturer Management and Selection
{
    public static bool isProjectOpen(string projectId)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (project.IsProjectHasWinner) return false;
        if (project.IsProjectClosed) return false;
        if (project.IsProjectPaused) return false;
        if (project.CurrentProjectStatus == ProjectStatus.Terminated) return false;
        if (project.CurrentProjectStatus == ProjectStatus.Completed) return false;

        return true;
    }
    public static void registerNewManufacturerCandidate(UInt160 ManufacturerAddress, string projectId) // переименовал параметр во избежание конфликта с полем класса
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (!Runtime.CheckWitness(ManufacturerAddress) && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("Authorization failed. Only manufacturer or project author can register.");

        if (!isProjectOpen(projectId)) throw new Exception("Project is not open for new manufacturer candidates.");
        if (project == null) throw new Exception("Project not found");

        // Проверка лимита и дубликатов через state
        UInt160[] candidates = ProjectState.GetManufacturerCandidates(projectId) ?? new UInt160[0];
        if (candidates.Length >= project.projectSettings.MaxManufacturers)
            throw new Exception("Maximum number of manufacturer candidates reached.");

        if (ProjectState.IsManufacturerRegistered(projectId, ManufacturerAddress))
            throw new Exception("Manufacturer candidate already registered.");

        // Глобальный аккаунт производителя должен существовать
        ManufacturerAccount newManufacturerAccount = ManufacturerAccount.getManufacturerAccount(ManufacturerAddress);
        if (newManufacturerAccount == null)
            throw new Exception("Manufacturer global account not found. Manufacturer must be registered in the system first.");

        AcquireLock();
        try
        {
            if (project.IsProjectPaused) throw new Exception("Project is paused. Cannot register new manufacturer candidates.");

            // Регистрируем кандидата в state-хранилище
            ProjectState.RegisterManufacturer(projectId, ManufacturerAddress, ""); // data можно расширить при необходимости
            ProjectState.SetReservedFunds(projectId, ManufacturerAddress, 0);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }
}


public partial class IF_MainGateway // General Voting Finalization
{
    public static void refundOfferDonate(UInt160 backer, string offerSha256Id, BigInteger amount)
    {
        if (amount <= 0) throw new Exception("Amount must be positive");

        BackerAccount backerAccount = BackerAccount.getBackerAccount(backer, true);

        BigInteger reserved = ProjectState.GetOfferReservedDonation(offerSha256Id, backer);
        if (reserved < amount)
            throw new Exception("Insufficient reserved amount for refund");

        // Обновляем резерв и возвращаем на свободный баланс бэкера
        ProjectState.SetOfferReservedDonation(offerSha256Id, backer, reserved - amount);

        backerAccount.FreeBalance += amount;
        BackerAccount.updateExistingBackerAccount(backerAccount);
    }


    public static CalculatedVoteOutcome calculateInternalVoteOutcome(
    string projectId,
    Map<UInt160, BackerVotesEnum> votesMap,
    string votingType,
    BigInteger explicitPositiveRaw,
    BigInteger explicitNegativeRaw,
    BigInteger explicitAbstainedRaw,
    BigInteger totalCastedRaw)
    {
        CalculatedVoteOutcome outcome = new CalculatedVoteOutcome();
        Map<UInt160, BigInteger> finalVoteWeights = new Map<UInt160, BigInteger>();
        Map<UInt160, BackerVotesEnum> finalVotes = new Map<UInt160, BackerVotesEnum>();

        var project = getProjectAccount(projectId);

        // Делегирование и агрегация весов
        foreach (UInt160 backer in votesMap.Keys)
        {
            if (!InnFork.NeoN3.ProjectState.IsBackerEligible(projectId, backer)) continue;

            UInt160 finalDelegate = InnFork.NeoN3.ProjectState.ResolveFinalDelegate(projectId, votingType, backer);
            BigInteger backerWeight = InnFork.NeoN3.ProjectState.GetBackerVoteWeight(projectId, backer);

            if (finalVoteWeights.HasKey(finalDelegate))
                finalVoteWeights[finalDelegate] += backerWeight;
            else
                finalVoteWeights[finalDelegate] = backerWeight;

            if (votesMap.HasKey(finalDelegate))
                finalVotes[finalDelegate] = votesMap[finalDelegate];
            else
                finalVotes[finalDelegate] = votesMap[backer];
        }

        // Общее число имеющих право голоса
        outcome.TotalEligibleVoters = InnFork.NeoN3.ProjectState.GetEligibleVotersCount(projectId);

        // Взвешенные итоги
        outcome.FinalPositiveVotes = 0;
        outcome.FinalNegativeVotes = 0;
        outcome.FinalAbstainedVotes = 0;

        BigInteger weightedTotalCastedActualVotes = 0;

        foreach (UInt160 voter in finalVotes.Keys)
        {
            if (!InnFork.NeoN3.ProjectState.IsBackerEligible(projectId, voter)) continue;

            BigInteger voteWeight = finalVoteWeights.HasKey(voter)
                ? finalVoteWeights[voter]
                : InnFork.NeoN3.ProjectState.GetBackerVoteWeight(projectId, voter);

            BackerVotesEnum vote = finalVotes[voter];
            if (vote == BackerVotesEnum.Positive) outcome.FinalPositiveVotes += voteWeight;
            else if (vote == BackerVotesEnum.Negative) outcome.FinalNegativeVotes += voteWeight;
            else if (vote == BackerVotesEnum.Abstained) outcome.FinalAbstainedVotes += voteWeight;

            weightedTotalCastedActualVotes += voteWeight;
        }

        outcome.TotalParticipatedOrAssigned = weightedTotalCastedActualVotes;

        // Безголосые -> воздержались
        if (project.AutoAssignVoicelessToAbstain && outcome.TotalEligibleVoters > weightedTotalCastedActualVotes)
        {
            BigInteger voiceless = outcome.TotalEligibleVoters - weightedTotalCastedActualVotes;
            outcome.FinalAbstainedVotes += voiceless;
            outcome.TotalParticipatedOrAssigned += voiceless;
        }

        // Воздержался = за
        if (project.AutoAbstainVoteAsSupport)
            outcome.FinalPositiveVotes += outcome.FinalAbstainedVotes;

        // Порог участия
        bool meetsMinParticipation = true;
        if (project.MinRequiredVotingParticipation > 0 && outcome.TotalEligibleVoters > 0)
            meetsMinParticipation = (outcome.TotalParticipatedOrAssigned * 100) >= (outcome.TotalEligibleVoters * project.MinRequiredVotingParticipation);
        else if (project.MinRequiredVotingParticipation > 0 && outcome.TotalEligibleVoters == 0)
            meetsMinParticipation = false;

        // Успешность
        outcome.IsSuccessful = false;
        if (meetsMinParticipation)
        {
            if (outcome.TotalParticipatedOrAssigned > 0)
                outcome.IsSuccessful = (outcome.FinalPositiveVotes * 100) >= (outcome.TotalParticipatedOrAssigned * project.MinApprovalPercentage);
            else if (project.MinApprovalPercentage == 0)
                outcome.IsSuccessful = true;
        }

        return outcome;
    }

    public static void safeRefundAllDonations(string projectId)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (!IsOwner() && !Runtime.CheckWitness(project.ProjectCreatorAddress))
            throw new Exception("safeRefundAllDonations: Authorization failed. Only owner or project author can initiate refunds.");

        if (project.IsProjectHasWinner || project.CurrentProjectStatus == ProjectStatus.Completed)
            throw new Exception("Cannot refund donations for a completed or successful project.");

        if (project.EmergencyRefundInProgress || project.CurrentProjectStatus == ProjectStatus.Terminated)
            throw new Exception("Refund process is already in progress or completed.");

        AcquireLock();
        try
        {
            project.EmergencyRefundInProgress = true;
            project.IsProjectClosed = true;
            project.CurrentProjectStatus = ProjectStatus.Terminated;

            Map<UInt160, BigInteger> amountsToRefund = new Map<UInt160, BigInteger>();
            Map<UInt160, BigInteger> manufacturerReservedTotals = new Map<UInt160, BigInteger>();

            UInt160[] manufacturers = ProjectState.GetManufacturerCandidates(projectId);

            UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
            for (int bi = 0; bi < backers.Length; bi++)
            {
                UInt160 backer = backers[bi];
                if (ProjectState.IsParticipantBanned(projectId, backer)) continue;

                BigInteger donation = ProjectState.GetBackerDonation(projectId, backer);
                if (donation > 0)
                {
                    amountsToRefund[backer] = (amountsToRefund.HasKey(backer) ? amountsToRefund[backer] : 0) + donation;
                    ProjectState.SetBackerDonation(projectId, backer, 0);
                }

                for (int i = 0; i < manufacturers.Length; i++)
                {
                    UInt160 man = manufacturers[i];
                    BigInteger reserved = ProjectState.GetBackerReservation(projectId, backer, man);
                    if (reserved > 0)
                    {
                        amountsToRefund[backer] = (amountsToRefund.HasKey(backer) ? amountsToRefund[backer] : 0) + reserved;

                        BigInteger totalForMan = manufacturerReservedTotals.HasKey(man) ? manufacturerReservedTotals[man] : 0;
                        manufacturerReservedTotals[man] = totalForMan + reserved;

                        ProjectState.SetBackerReservation(projectId, backer, man, 0);
                    }
                }
            }

            for (int i = 0; i < manufacturers.Length; i++)
            {
                UInt160 man = manufacturers[i];
                if (manufacturerReservedTotals.HasKey(man))
                {
                    BigInteger currentReserved = ProjectState.GetReservedFunds(projectId, man);
                    BigInteger newReserved = currentReserved - manufacturerReservedTotals[man];
                    if (newReserved < 0) newReserved = 0;
                    ProjectState.SetReservedFunds(projectId, man, newReserved);
                }
            }

            BigInteger totalRefunded = 0;

            for (int bi = 0; bi < backers.Length; bi++)
            {
                UInt160 backer = backers[bi];
                if (!amountsToRefund.HasKey(backer)) continue;

                BigInteger amount = amountsToRefund[backer];
                if (amount <= 0) continue;

                BackerAccount backerAccount = BackerAccount.getBackerAccount(backer, true);
                backerAccount.FreeBalance += amount;
                BackerAccount.updateExistingBackerAccount(backerAccount);

                ProjectState.SetRefundHistory(projectId, backer, amount);

                totalRefunded += amount;
            }

            project.FLMUSD_TotalProjectBalance = 0;
            project.FLMUSD_PrizeFundBalance = 0;
            project.TotalRefundsProcessed = totalRefunded;
            project.EmergencyRefundInProgress = false;

            ProjectState.SetProjectTotalBalance(projectId, 0);
            ProjectState.SetTotalRefundsProcessed(projectId, totalRefunded);
            ProjectState.SetLastActivityTime(projectId, Runtime.Time);

            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static void finalizeLaunchVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsLaunchVotingFinalized) return;

        bool canFinalize = false;
        if (Runtime.Time >= project.LaunchVotingDeadline || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings))
        {
            BigInteger eligibleVotersCount = ProjectState.GetEligibleVotersCount(projectId);

            // Собираем голоса через state-адаптер
            Map<UInt160, BackerVotesEnum> votesMap = new Map<UInt160, BackerVotesEnum>();
            int skip = 0, take = 64;
            while (true)
            {
                object[] snap = ProjectState.GetVotesSnapshot(projectId, "LaunchApproval", skip, take);
                var voters = snap != null && snap.Length >= 2 ? (UInt160[])snap[0] : null;
                var votes = snap != null && snap.Length >= 2 ? (BackerVotesEnum[])snap[1] : null;
                if (voters == null || voters.Length == 0) break;
                for (int i = 0; i < voters.Length; i++)
                {
                    votesMap[voters[i]] = votes[i];
                }
                skip += voters.Length;
                if (voters.Length < take) break;
            }

            if (votesMap != null && votesMap.Count >= eligibleVotersCount && eligibleVotersCount > 0)
                canFinalize = true;
            else if (Runtime.Time >= project.LaunchVotingDeadline)
                canFinalize = true;

            if (!canFinalize) return;

            BigInteger currentPositiveRaw = 0, currentNegativeRaw = 0, currentAbstainedRaw = 0, totalCastedRaw = 0;
            if (votesMap != null)
            {
                foreach (UInt160 backer in votesMap.Keys)
                {
                    if (ProjectState.IsBackerEligible(projectId, backer))
                    {
                        totalCastedRaw++;
                        var vote = votesMap[backer];
                        if (vote == BackerVotesEnum.Positive) currentPositiveRaw++;
                        else if (vote == BackerVotesEnum.Negative) currentNegativeRaw++;
                        else if (vote == BackerVotesEnum.Abstained) currentAbstainedRaw++;
                    }
                }
            }

            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId, votesMap, "LaunchApproval",
                currentPositiveRaw, currentNegativeRaw, currentAbstainedRaw, totalCastedRaw
            );

            project.LaunchApprovalPositiveVotesCount = outcome.FinalPositiveVotes;
            project.LaunchApprovalNegativeVotesCount = outcome.FinalNegativeVotes;
            project.LaunchApprovalAbstainedVotesCount = outcome.FinalAbstainedVotes;
            project.LaunchApprovalTotalVotesCount = outcome.TotalParticipatedOrAssigned;

            project.IsLaunchVotingFinalized = true;
            project.IsLaunchVotingCompleted = outcome.IsSuccessful;

            if (outcome.IsSuccessful)
            {
                project.CurrentProjectStatus = ProjectStatus.Fundraising;
            }
            else
            {
                project.CurrentProjectStatus = ProjectStatus.Terminated;
                project.IsProjectClosed = true;
                safeRefundAllDonations(projectId);
            }

            VotingCompleted(projectId, "LaunchProject", outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);

            if (project.IsLaunchVotingFinalized)
            {
                ProjectState.ClearVotes(projectId, "LaunchApproval");
            }
        }
    }

    public static void finalizeFundraisingVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsFundraisingCompletionVotingFinalized) return;

        bool canFinalize = false;
        if (Runtime.Time >= project.FundraisingCompletionVotingDeadline || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings))
        {
            BigInteger eligibleVotersCount = ProjectState.GetEligibleVotersCount(projectId);

            Map<UInt160, BackerVotesEnum> votesMap = new Map<UInt160, BackerVotesEnum>();
            int skip = 0, take = 64;
            while (true)
            {
                object[] snap = ProjectState.GetVotesSnapshot(projectId, "FundraisingCompletion", skip, take);
                var voters = snap != null && snap.Length >= 2 ? (UInt160[])snap[0] : null;
                var votes = snap != null && snap.Length >= 2 ? (BackerVotesEnum[])snap[1] : null;
                if (voters == null || voters.Length == 0) break;
                for (int i = 0; i < voters.Length; i++) votesMap[voters[i]] = votes[i];
                skip += voters.Length;
                if (voters.Length < take) break;
            }

            if (votesMap != null && votesMap.Count >= eligibleVotersCount && eligibleVotersCount > 0)
                canFinalize = true;
            else if (Runtime.Time >= project.FundraisingCompletionVotingDeadline)
                canFinalize = true;

            if (!canFinalize) return;

            BigInteger currentPositiveRaw = 0, currentNegativeRaw = 0, currentAbstainedRaw = 0, totalCastedRaw = 0;
            if (votesMap != null)
            {
                foreach (UInt160 backer in votesMap.Keys)
                {
                    if (ProjectState.IsBackerEligible(projectId, backer))
                    {
                        totalCastedRaw++;
                        var vote = votesMap[backer];
                        if (vote == BackerVotesEnum.Positive) currentPositiveRaw++;
                        else if (vote == BackerVotesEnum.Negative) currentNegativeRaw++;
                        else if (vote == BackerVotesEnum.Abstained) currentAbstainedRaw++;
                    }
                }
            }

            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId, votesMap, "FundraisingCompletion",
                currentPositiveRaw, currentNegativeRaw, currentAbstainedRaw, totalCastedRaw
            );

            project.FundraisingCompletionPositiveVotesCount = outcome.FinalPositiveVotes;
            project.FundraisingCompletionNegativeVotesCount = outcome.FinalNegativeVotes;
            project.FundraisingCompletionAbstainedVotesCount = outcome.FinalAbstainedVotes;
            project.FundraisingCompletionTotalVotesCount = outcome.TotalParticipatedOrAssigned;

            project.IsFundraisingCompletionVotingFinalized = true;
            project.IsFundraisingCompletionVotingCompleted = outcome.IsSuccessful;

            if (outcome.IsSuccessful)
            {
                var candidates = ProjectState.GetManufacturerCandidates(projectId);
                project.CurrentProjectStatus = (candidates != null && candidates.Length > 0)
                    ? ProjectStatus.Manufacturing
                    : ProjectStatus.Active;
            }
            else
            {
                if (project.projectSettings != null && project.projectSettings.projectFundingType == ProjectFundingType.AllOrNothing)
                {
                    project.CurrentProjectStatus = ProjectStatus.Terminated;
                    project.IsProjectClosed = true;
                    safeRefundAllDonations(projectId);
                }
            }

            VotingCompleted(projectId, "FundraisingCompletion", outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);
            ProjectState.ClearVotes(projectId, "FundraisingCompletion");
        }
    }

    public static void finalizeSuccessfulClosureVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsSuccessfulClosureVotingFinalized) return;

        bool canFinalize = false;
        if (Runtime.Time >= project.SuccessfulClosureVotingDeadline || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings))
        {
            BigInteger eligibleVotersCount = ProjectState.GetEligibleVotersCount(projectId);

            Map<UInt160, BackerVotesEnum> votesMap = new Map<UInt160, BackerVotesEnum>();
            int skip = 0, take = 64;
            while (true)
            {
                object[] snap = ProjectState.GetVotesSnapshot(projectId, "SuccessfulClosure", skip, take);
                var voters = snap != null && snap.Length >= 2 ? (UInt160[])snap[0] : null;
                var votes = snap != null && snap.Length >= 2 ? (BackerVotesEnum[])snap[1] : null;
                if (voters == null || voters.Length == 0) break;
                for (int i = 0; i < voters.Length; i++) votesMap[voters[i]] = votes[i];
                skip += voters.Length;
                if (voters.Length < take) break;
            }

            if (votesMap != null && votesMap.Count >= eligibleVotersCount && eligibleVotersCount > 0)
                canFinalize = true;
            else if (Runtime.Time >= project.SuccessfulClosureVotingDeadline)
                canFinalize = true;

            if (!canFinalize) return;

            BigInteger currentPositiveRaw = 0, currentNegativeRaw = 0, currentAbstainedRaw = 0, totalCastedRaw = 0;
            if (votesMap != null)
            {
                foreach (UInt160 backer in votesMap.Keys)
                {
                    if (ProjectState.IsBackerEligible(projectId, backer))
                    {
                        totalCastedRaw++;
                        var vote = votesMap[backer];
                        if (vote == BackerVotesEnum.Positive) currentPositiveRaw++;
                        else if (vote == BackerVotesEnum.Negative) currentNegativeRaw++;
                        else if (vote == BackerVotesEnum.Abstained) currentAbstainedRaw++;
                    }
                }
            }

            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId, votesMap, "SuccessfulClosure",
                currentPositiveRaw, currentNegativeRaw, currentAbstainedRaw, totalCastedRaw
            );

            project.SuccessfulClosurePositiveVotesCount = outcome.FinalPositiveVotes;
            project.SuccessfulClosureNegativeVotesCount = outcome.FinalNegativeVotes;
            project.SuccessfulClosureAbstainedVotesCount = outcome.FinalAbstainedVotes;
            project.SuccessfulClosureTotalVotesCount = outcome.TotalParticipatedOrAssigned;

            project.IsSuccessfulClosureVotingFinalized = true;
            project.IsSuccessfulClosureVotingCompleted = outcome.IsSuccessful;

            if (outcome.IsSuccessful)
            {
                project.CurrentProjectStatus = ProjectStatus.Completed;
                project.IsProjectClosed = true;

                // Комиссии (опционально)
                if (!project.AuthorSuccessGetFee && project.ProjectCreatorAddress != UInt160.Zero)
                    collectFeeForProjectAuthor(projectId, project.ProjectCreatorAddress);
            }

            VotingCompleted(projectId, "SuccessfulClosure", outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);
            ProjectState.ClearVotes(projectId, "SuccessfulClosure");
        }
    }


    public static bool isFundingGoalReached(string projectId)
    {
        ProjectAccount project = getProjectAccount(projectId);
        return project.FLMUSD_TotalProjectBalance >= project.FLMUSD_PrizeFundGoal;
    }

    public static void collectFeeForProjectAuthor(string projectId, UInt160 ProjectCreatorAddressParam)
    {
        ProjectAccount project = getProjectAccount(projectId);

        if (ProjectCreatorAddressParam == UInt160.Zero || ProjectCreatorAddressParam != project.ProjectCreatorAddress)
            throw new Exception("Project author address mismatch or invalid.");

        if (project.AuthorSuccessGetFee)
            throw new Exception("Project author has already received the fee.");

        if (!project.IsProjectHasWinner && !(isFundingGoalReached(projectId) && project.projectSettings.projectFundingType == ProjectFundingType.Flexible))
            throw new Exception("Fee can only be collected for successful projects.");

        ProjectCreatorAccount projectCreatorAcc = ProjectCreatorAccount.getProjectCreatorAccount(project.ProjectCreatorAddress);
        if (projectCreatorAcc == null)
            throw new Exception("Project creator account not found.");

        BigInteger feeAmount = 0;
        if (project.CreatorFeePercentage > 0 && project.FLMUSD_TotalProjectBalance > 0)
        {
            feeAmount = (project.FLMUSD_TotalProjectBalance * project.CreatorFeePercentage) / 100;
        }
        feeAmount += project.CreatorFixedReward;

        if (feeAmount <= 0)
        {
            project.AuthorSuccessGetFee = true;
            saveProjectAccountToProjectsAccountStore(projectId, project);
            return;
        }

        if (project.FLMUSD_TotalProjectBalance < feeAmount)
            throw new Exception("Insufficient project balance to pay author's fee.");

        AcquireLock();
        try
        {
            project.FLMUSD_TotalProjectBalance -= feeAmount;

            BigInteger stateTotal = ProjectState.GetProjectTotalBalance(projectId);
            ProjectState.SetProjectTotalBalance(projectId, stateTotal - feeAmount);

            projectCreatorAcc.FreeFLMUSDBalance += feeAmount;
            projectCreatorAcc.TotalFLMUSDBalance += feeAmount;
            ProjectCreatorAccount.updateExistingProjectCreatorAccount(project.ProjectCreatorAddress, projectCreatorAcc);

            project.AuthorSuccessGetFee = true;

            ProjectState.SetLastActivityTime(projectId, Runtime.Time);
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    public static void finalizeWinnerSelectionVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsProjectHasWinner) return;

        bool canFinalize = (project.ManufacturerSelectionVotingDeadline > 0 && Runtime.Time >= project.ManufacturerSelectionVotingDeadline)
                           || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings);
        if (!canFinalize) return;

        UInt160 winner = UInt160.Zero;
        BigInteger maxSuccessfulVotes = -1;

        UInt160[] candidates = ProjectState.GetManufacturerCandidates(projectId) ?? new UInt160[0];
        foreach (UInt160 manufacturerCandidate in candidates)
        {
            CandidateWinnerVotesStruct candidateVotes =
                (CandidateWinnerVotesStruct)ProjectState.GetCandidateWinnerVotes(projectId, manufacturerCandidate);

            if (candidateVotes == null)
            {
                candidateVotes = new CandidateWinnerVotesStruct
                {
                    ProjectSha256_Id = projectId,
                    ManufacturerCandidate = manufacturerCandidate,
                    Sha256Hash_Id = IFHelper.createComplexKey(projectId, manufacturerCandidate),
                    VotingStartTime = Runtime.Time,
                    VotingDuration = project.DefaultVotingDuration,
                    MinimumVotesRequired = project.MinRequiredVotingParticipation
                };
            }

            // Сбор голосов из StateStorage
            BigInteger totalEligible = ProjectState.GetEligibleVotersCount(projectId);
            BigInteger positiveVotes = 0;
            BigInteger negativeVotes = 0;
            BigInteger abstainedVotes = 0;
            BigInteger totalCasted = 0;

            UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
            if (backers != null)
            {
                for (int i = 0; i < backers.Length; i++)
                {
                    UInt160 backer = backers[i];
                    if (!ProjectState.IsBackerEligible(projectId, backer)) continue;

                    BackerVotesEnum vote = (BackerVotesEnum)ProjectState.GetWinnerSelectionVote(projectId, backer, manufacturerCandidate);
                    BigInteger weight = ProjectState.GetBackerVoteWeight(projectId, backer);

                    // Учитываем все поданные голоса, включая Abstained
                    if (vote == BackerVotesEnum.Positive) { positiveVotes += weight; totalCasted += weight; }
                    else if (vote == BackerVotesEnum.Negative) { negativeVotes += weight; totalCasted += weight; }
                    else if (vote == BackerVotesEnum.Abstained) { abstainedVotes += weight; totalCasted += weight; }
                }
            }

            // Параметры порогов и автоприсвоений
            bool autoAssignVoiceless = project.projectSettings != null && project.projectSettings.AutoAssignVoicelessToAbstain;
            bool abstainAsSupport = project.projectSettings != null && project.projectSettings.AutoAbstainVoteAsSupport;
            BigInteger minParticipationPct = project.projectSettings != null ? project.projectSettings.MinRequiredVotingParticipation : 0;
            BigInteger minApprovalPct = project.projectSettings != null ? project.projectSettings.MinApprovalPercentage : 0;

            // Автоприсвоение безголосых
            BigInteger voiceless = totalEligible - totalCasted;
            if (autoAssignVoiceless && voiceless > 0)
            {
                abstainedVotes += voiceless;
                totalCasted += voiceless;
            }

            if (abstainAsSupport)
            {
                positiveVotes += abstainedVotes;
            }

            bool meetsMinParticipation = true;
            if (minParticipationPct > 0 && totalEligible > 0)
            {
                meetsMinParticipation = (totalCasted * 100) >= (totalEligible * minParticipationPct);
            }

            bool isSuccessful = false;
            if (meetsMinParticipation && totalCasted > 0)
            {
                isSuccessful = (positiveVotes * 100) >= (totalCasted * minApprovalPct);
            }

            // Обновляем агрегаты и сохраняем в StateStorage (без локальной карты голосов)
            candidateVotes.PositiveVotesCount = positiveVotes;
            candidateVotes.NegativeVotesCount = negativeVotes;
            candidateVotes.AbstainedVotesCount = abstainedVotes;
            candidateVotes.TotalVotesCount = totalCasted;
            candidateVotes.IsVotingSuccessful = isSuccessful;

            ProjectState.SetCandidateWinnerVotes(projectId, manufacturerCandidate, candidateVotes);

            if (isSuccessful && positiveVotes > maxSuccessfulVotes)
            {
                maxSuccessfulVotes = positiveVotes;
                winner = manufacturerCandidate;
            }
        }

        if (winner != UInt160.Zero)
        {
            AcquireLock();
            try
            {
                project.IsProjectHasWinner = true;
                project.projectSettings.IsWinnerSelectionFinalized = true;
                project.ManufacturerWinnerAddress = winner;

                if (!project.AuthorSuccessGetFee && project.ProjectCreatorAddress != UInt160.Zero)
                {
                    collectFeeForProjectAuthor(projectId, project.ProjectCreatorAddress);
                }
                if (!project.InnForkFeeCollected)
                {
                    // BalanceManagerAPI.collectInnForkFeeFromProject(Runtime.ExecutingScriptHash, projectId);
                }

                paymentPrizeFundToManufacturer(projectId, winner);

                project.CurrentProjectStatus = ProjectStatus.Completed;
                project.IsProjectClosed = true;

                ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, project.IsProjectHasWinner);

                WinnerSelected(projectId, winner.ToString());
                saveProjectAccountToProjectsAccountStore(projectId, project);
            }
            finally
            {
                ReleaseAcquireLock();
            }
        }
        else
        {
            project.projectSettings.IsWinnerSelectionFinalized = true;
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
    }


    public static void paymentPrizeFundToManufacturer(string projectId, UInt160 winnerAddress)
    {
        // Валидация входных параметров
        if (winnerAddress == null || winnerAddress.IsZero)
            throw new Exception("Invalid winner manufacturer address");

        var project = getProjectAccount(projectId); // Получаем ProjectAccount

        //     var projectStorage = ProjectAccountStorages.For(projectId);

        // Проверка что производитель действительно является победителем
        if (project.ManufacturerWinnerAddress != winnerAddress)
            throw new Exception("Manufacturer is not the project winner");

        // Проверка статуса проекта
        if (!project.IsProjectHasWinner)
            throw new Exception("Project does not have a winner selected");

        // Проверка наличия средств в призовом фонде
        if (project.FLMUSD_PrizeFundBalance <= 0)
            throw new Exception("Prize fund is empty");

        // Получение аккаунта производителя-победителя
        ManufacturerAccount winnerAccount = ManufacturerAccount.getManufacturerAccount(winnerAddress);

        // Расчет суммы к выплате (может включать вычеты за комиссии)
        BigInteger paymentAmount = project.FLMUSD_PrizeFundBalance;
        BigInteger feeAmount = 0;

        // Расчет комиссии создателя проекта если настроена
        if (project.CreatorFeePercentage > 0)
        {
            feeAmount = (paymentAmount * project.CreatorFeePercentage) / 100;
            paymentAmount -= feeAmount;
        }

        // Добавление фиксированной награды создателю
        if (project.CreatorFixedReward > 0)
        {
            if (paymentAmount >= project.CreatorFixedReward)
            {
                feeAmount += project.CreatorFixedReward;
                paymentAmount -= project.CreatorFixedReward;
            }
        }

        AcquireLock();
        try
        {
            // Перевод призового фонда победителю
            if (paymentAmount > 0)
            {
                winnerAccount.FreeBalance += paymentAmount;
                winnerAccount.TotalBalance += paymentAmount;

                // Увеличение репутации за победу в проекте
                BigInteger reputationBonus = paymentAmount / 10000; // 0.01% от выигрыша
                winnerAccount.ReputationScore += reputationBonus;

                ManufacturerAccount.updateExistingManufacturerAccount(winnerAccount);
            }

            // Выплата комиссии создателю проекта
            if (feeAmount > 0 && !project.AuthorSuccessGetFee)
            {
                ProjectCreatorAccount authorAccount = ProjectCreatorAccount.getProjectCreatorAccount(project.ProjectCreatorAddress);
                if (authorAccount != null)
                {
                    authorAccount.FreeFLMUSDBalance += feeAmount;
                    authorAccount.TotalFLMUSDBalance += feeAmount;
                    ProjectCreatorAccount.updateExistingProjectCreatorAccount(project.ProjectCreatorAddress, authorAccount);

                    project.AuthorSuccessGetFee = true;
                }
            }

            // Обновление балансов проекта
            project.FLMUSD_PrizeFundBalance = 0;
            project.FLMUSD_TotalProjectBalance -= (paymentAmount + feeAmount);

            // Обновление статуса проекта
            if (project.CurrentProjectStatus != ProjectStatus.Completed)
            {
                project.CurrentProjectStatus = ProjectStatus.Completed;
            }

            // Сохранение изменений проекта
            saveProjectAccountToProjectsAccountStore(projectId, project);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }


    public static void finalizePauseVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsPauseResumeVotingFinalized) return;

        bool canFinalize = false;
        if (Runtime.Time >= project.PauseResumeVotingDeadline || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings))
        {
            BigInteger eligibleVotersCount = ProjectState.GetEligibleVotersCount(projectId);

            Map<UInt160, BackerVotesEnum> votesMap = new Map<UInt160, BackerVotesEnum>();
            int skip = 0, take = 64;
            while (true)
            {
                object[] snap = ProjectState.GetVotesSnapshot(projectId, "PauseResume", skip, take);
                var voters = snap != null && snap.Length >= 2 ? (UInt160[])snap[0] : null;
                var votes = snap != null && snap.Length >= 2 ? (BackerVotesEnum[])snap[1] : null;
                if (voters == null || voters.Length == 0) break;
                for (int i = 0; i < voters.Length; i++) votesMap[voters[i]] = votes[i];
                skip += voters.Length;
                if (voters.Length < take) break;
            }

            if (votesMap != null && votesMap.Count >= eligibleVotersCount && eligibleVotersCount > 0)
                canFinalize = true;
            else if (Runtime.Time >= project.PauseResumeVotingDeadline)
                canFinalize = true;

            if (!canFinalize) return;

            BigInteger currentPositiveRaw = 0, currentNegativeRaw = 0, currentAbstainedRaw = 0, totalCastedRaw = 0;
            if (votesMap != null)
            {
                foreach (UInt160 backer in votesMap.Keys)
                {
                    if (ProjectState.IsBackerEligible(projectId, backer))
                    {
                        totalCastedRaw++;
                        var vote = votesMap[backer];
                        if (vote == BackerVotesEnum.Positive) currentPositiveRaw++;
                        else if (vote == BackerVotesEnum.Negative) currentNegativeRaw++;
                        else if (vote == BackerVotesEnum.Abstained) currentAbstainedRaw++;
                    }
                }
            }

            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId, votesMap, "PauseResume",
                currentPositiveRaw, currentNegativeRaw, currentAbstainedRaw, totalCastedRaw
            );

            project.PauseResumePositiveVotesCount = outcome.FinalPositiveVotes;
            project.PauseResumeNegativeVotesCount = outcome.FinalNegativeVotes;
            project.PauseResumeAbstainedVotesCount = outcome.FinalAbstainedVotes;
            project.PauseResumeTotalVotesCount = outcome.TotalParticipatedOrAssigned;

            project.IsPauseResumeVotingFinalized = true;

            if (outcome.IsSuccessful)
            {
                project.IsProjectPaused = !project.IsProjectPaused;
                project.CurrentProjectStatus = project.IsProjectPaused ? ProjectStatus.Paused : ProjectStatus.Active;
                ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, project.IsProjectHasWinner);
            }

            VotingCompleted(projectId, "PauseResume", outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);
            ProjectState.ClearVotes(projectId, "PauseResume");
        }
    }

    public static void finalizeTerminationWithRefundVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsTerminationWithRefundVotingFinalized) return;

        bool canFinalize = false;
        if (Runtime.Time >= project.TerminationWithRefundVotingDeadline || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings))
        {
            BigInteger eligibleVotersCount = ProjectState.GetEligibleVotersCount(projectId);

            Map<UInt160, BackerVotesEnum> votesMap = new Map<UInt160, BackerVotesEnum>();
            int skip = 0, take = 64;
            while (true)
            {
                object[] snap = ProjectState.GetVotesSnapshot(projectId, "TerminationWithRefund", skip, take);
                var voters = snap != null && snap.Length >= 2 ? (UInt160[])snap[0] : null;
                var votes = snap != null && snap.Length >= 2 ? (BackerVotesEnum[])snap[1] : null;
                if (voters == null || voters.Length == 0) break;
                for (int i = 0; i < voters.Length; i++) votesMap[voters[i]] = votes[i];
                skip += voters.Length;
                if (voters.Length < take) break;
            }

            if (votesMap != null && votesMap.Count >= eligibleVotersCount && eligibleVotersCount > 0)
                canFinalize = true;
            else if (Runtime.Time >= project.TerminationWithRefundVotingDeadline)
                canFinalize = true;

            if (!canFinalize) return;

            BigInteger currentPositiveRaw = 0, currentNegativeRaw = 0, currentAbstainedRaw = 0, totalCastedRaw = 0;
            if (votesMap != null)
            {
                foreach (UInt160 backer in votesMap.Keys)
                {
                    if (ProjectState.IsBackerEligible(projectId, backer))
                    {
                        totalCastedRaw++;
                        var vote = votesMap[backer];
                        if (vote == BackerVotesEnum.Positive) currentPositiveRaw++;
                        else if (vote == BackerVotesEnum.Negative) currentNegativeRaw++;
                        else if (vote == BackerVotesEnum.Abstained) currentAbstainedRaw++;
                    }
                }
            }

            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId, votesMap, "TerminationWithRefund",
                currentPositiveRaw, currentNegativeRaw, currentAbstainedRaw, totalCastedRaw
            );

            project.TerminationWithRefundPositiveVotesCount = outcome.FinalPositiveVotes;
            project.TerminationWithRefundNegativeVotesCount = outcome.FinalNegativeVotes;
            project.TerminationWithRefundAbstainedVotesCount = outcome.FinalAbstainedVotes;
            project.TerminationWithRefundTotalVotesCount = outcome.TotalParticipatedOrAssigned;

            project.IsTerminationWithRefundVotingFinalized = true;
            project.IsTerminationWithRefundVotingCompleted = outcome.IsSuccessful;

            if (outcome.IsSuccessful)
            {
                project.CurrentProjectStatus = ProjectStatus.Terminated;
                project.IsProjectClosed = true;
                ProjectState.SetProjectFlags(projectId, project.IsArchived, project.IsProjectPaused, project.IsProjectClosed, project.IsProjectHasWinner);
                safeRefundAllDonations(projectId);
            }

            VotingCompleted(projectId, "TerminationWithRefund", outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);
            ProjectState.ClearVotes(projectId, "TerminationWithRefund");
        }
    }

    public static void finalizeFundraisingIncreaseVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsFundraisingIncreaseVotingFinalized) return;

        bool canFinalize = false;
        if (Runtime.Time >= project.FundraisingIncreaseVotingDeadline || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings))
        {
            BigInteger eligibleVotersCount = ProjectState.GetEligibleVotersCount(projectId);

            Map<UInt160, BackerVotesEnum> votesMap = new Map<UInt160, BackerVotesEnum>();
            int skip = 0, take = 64;
            while (true)
            {
                object[] snap = ProjectState.GetVotesSnapshot(projectId, "FundraisingIncrease", skip, take);
                var voters = snap != null && snap.Length >= 2 ? (UInt160[])snap[0] : null;
                var votes = snap != null && snap.Length >= 2 ? (BackerVotesEnum[])snap[1] : null;
                if (voters == null || voters.Length == 0) break;
                for (int i = 0; i < voters.Length; i++) votesMap[voters[i]] = votes[i];
                skip += voters.Length;
                if (voters.Length < take) break;
            }

            if (votesMap != null && votesMap.Count >= eligibleVotersCount && eligibleVotersCount > 0)
                canFinalize = true;
            else if (Runtime.Time >= project.FundraisingIncreaseVotingDeadline)
                canFinalize = true;

            if (!canFinalize) return;

            BigInteger currentPositiveRaw = 0, currentNegativeRaw = 0, currentAbstainedRaw = 0, totalCastedRaw = 0;
            if (votesMap != null)
            {
                foreach (UInt160 backer in votesMap.Keys)
                {
                    if (ProjectState.IsBackerEligible(projectId, backer))
                    {
                        totalCastedRaw++;
                        var vote = votesMap[backer];
                        if (vote == BackerVotesEnum.Positive) currentPositiveRaw++;
                        else if (vote == BackerVotesEnum.Negative) currentNegativeRaw++;
                        else if (vote == BackerVotesEnum.Abstained) currentAbstainedRaw++;
                    }
                }
            }

            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId, votesMap, "FundraisingIncrease",
                currentPositiveRaw, currentNegativeRaw, currentAbstainedRaw, totalCastedRaw
            );

            project.FundraisingIncreasePositiveVotesCount = outcome.FinalPositiveVotes;
            project.FundraisingIncreaseNegativeVotesCount = outcome.FinalNegativeVotes;
            project.FundraisingIncreaseAbstainedVotesCount = outcome.FinalAbstainedVotes;
            project.FundraisingIncreaseTotalVotesCount = outcome.TotalParticipatedOrAssigned;

            project.IsFundraisingIncreaseVotingFinalized = true;
            project.IsFundraisingIncreaseVotingCompleted = outcome.IsSuccessful;

            if (outcome.IsSuccessful)
            {
                // При необходимости: применение результатов увеличения бюджета
            }

            VotingCompleted(projectId, "FundraisingIncrease", outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);
            ProjectState.ClearVotes(projectId, "FundraisingIncrease");
        }
    }

    public static void finalizeManagementTransferVoting(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (project.IsManagementTransferVotingFinalized) return;

        bool canFinalize = false;
        if (Runtime.Time >= project.ManagementTransferVotingDeadline || (project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings))
        {
            // Предполагаем, что голоса записывались через универсальную карту голосований (RecordVote)
            BigInteger eligibleVotersCount = ProjectState.GetEligibleVotersCount(projectId);

            Map<UInt160, BackerVotesEnum> votesMap = new Map<UInt160, BackerVotesEnum>();
            int skip = 0, take = 64;
            while (true)
            {
                object[] snap = ProjectState.GetVotesSnapshot(projectId, "ManagementTransfer", skip, take);
                var voters = snap != null && snap.Length >= 2 ? (UInt160[])snap[0] : null;
                var votes = snap != null && snap.Length >= 2 ? (BackerVotesEnum[])snap[1] : null;
                if (voters == null || voters.Length == 0) break;
                for (int i = 0; i < voters.Length; i++) votesMap[voters[i]] = votes[i];
                skip += voters.Length;
                if (voters.Length < take) break;
            }

            if (votesMap != null && votesMap.Count >= eligibleVotersCount && eligibleVotersCount > 0)
                canFinalize = true;
            else if (Runtime.Time >= project.ManagementTransferVotingDeadline)
                canFinalize = true;

            if (!canFinalize) return;

            BigInteger currentPositiveRaw = 0, currentNegativeRaw = 0, currentAbstainedRaw = 0, totalCastedRaw = 0;
            if (votesMap != null)
            {
                foreach (UInt160 backer in votesMap.Keys)
                {
                    if (ProjectState.IsBackerEligible(projectId, backer))
                    {
                        totalCastedRaw++;
                        var vote = votesMap[backer];
                        if (vote == BackerVotesEnum.Positive) currentPositiveRaw++;
                        else if (vote == BackerVotesEnum.Negative) currentNegativeRaw++;
                    }
                }
            }

            CalculatedVoteOutcome outcome = calculateInternalVoteOutcome(
                projectId, votesMap, "ManagementTransfer",
                currentPositiveRaw, currentNegativeRaw, currentAbstainedRaw, totalCastedRaw
            );

            project.ManagementTransferPositiveVotesCount = outcome.FinalPositiveVotes;
            project.ManagementTransferNegativeVotesCount = outcome.FinalNegativeVotes;
            project.ManagementTransferAbstainedVotesCount = outcome.FinalAbstainedVotes;
            project.ManagementTransferTotalVotesCount = outcome.TotalParticipatedOrAssigned;

            project.IsManagementTransferVotingFinalized = true;
            project.IsManagementTransferVotingCompleted = outcome.IsSuccessful;

            if (outcome.IsSuccessful)
            {
                project.DirectInnForkProjectManagement = true;
            }

            VotingCompleted(projectId, "ManagementTransfer", outcome.IsSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative);
            saveProjectAccountToProjectsAccountStore(projectId, project);
            ProjectState.ClearVotes(projectId, "ManagementTransfer");
        }
    }

    public static void autoFinalizeAllExpiredVotings(string projectId)
    {
        var project = getProjectAccount(projectId);
        if (!project.AutoFinishExpiredVotings) return;

        // Проверяем просроченные соглашения по кандидатам-производителям через state
        var manufacturers = ProjectState.GetManufacturerCandidates(projectId);
        if (manufacturers != null)
        {
            foreach (UInt160 manufacturerAddress in manufacturers)
            {
                InvestmentAgreement.checkAllExpiredAgreements(manufacturerAddress);
            }
        }

        ulong currentTime = Runtime.Time;

        if (!project.IsLaunchVotingFinalized && project.LaunchVotingDeadline > 0 && currentTime > project.LaunchVotingDeadline)
            finalizeLaunchVoting(projectId);

        if (!project.IsFundraisingIncreaseVotingFinalized && project.FundraisingIncreaseVotingDeadline > 0 && currentTime > project.FundraisingIncreaseVotingDeadline)
            finalizeFundraisingIncreaseVoting(projectId);

        if (!project.IsFundraisingCompletionVotingFinalized && project.FundraisingCompletionVotingDeadline > 0 && currentTime > project.FundraisingCompletionVotingDeadline)
            finalizeFundraisingVoting(projectId);

        if (!project.IsSuccessfulClosureVotingFinalized && project.SuccessfulClosureVotingDeadline > 0 && currentTime > project.SuccessfulClosureVotingDeadline)
            finalizeSuccessfulClosureVoting(projectId);

        if (!project.IsPauseResumeVotingFinalized && project.PauseResumeVotingDeadline > 0 && currentTime > project.PauseResumeVotingDeadline)
            finalizePauseVoting(projectId);

        if (!project.IsTerminationWithRefundVotingFinalized && project.TerminationWithRefundVotingDeadline > 0 && currentTime > project.TerminationWithRefundVotingDeadline)
            finalizeTerminationWithRefundVoting(projectId);

        if (!project.IsProjectHasWinner && !project.projectSettings.IsWinnerSelectionFinalized && project.ManufacturerSelectionVotingDeadline > 0 && currentTime > project.ManufacturerSelectionVotingDeadline)
            finalizeWinnerSelectionVoting(projectId);

        if (!project.IsManagementTransferVotingFinalized && project.ManagementTransferVotingDeadline > 0 && currentTime > project.ManagementTransferVotingDeadline)
            finalizeManagementTransferVoting(projectId);

        // Автофинализация голосований по обновлениям проекта: потребуется перечисление активных обновлений в state (не реализовано адаптером)
        // Используйте ProjectState.IsProjectUpdateVotingActive/ GetProjectUpdateVotingDeadline при наличии списка updateId.
        checkAllMilestoneVotings(projectId);
    }

    public static void checkAllMilestoneVotings(string projectId)
    {
        var project = getProjectAccount(projectId);

        var candidates = ProjectState.GetManufacturerCandidates(projectId);
        if (candidates == null || candidates.Length == 0)
            return;

        foreach (var manufacturer in candidates)
        {
            for (byte step = 1; step <= project.projectSettings.MaxMilestoneSteps; step++)
            {
                var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, step);
                if (obj == null) break;

                var milestone = (MilestoneCompletionVotesStruct)obj;
                if (!milestone.isVotingStepComplete && milestone.Deadline_UnixTime > 0 && Runtime.Time > milestone.Deadline_UnixTime)
                {
                    checkAndFinalizeMilestoneVoting(projectId, manufacturer, step);
                }
            }
        }
    }

    public static bool checkAndFinalizeMilestoneVoting(string projectId, UInt160 manufacturer, byte stepNumber)
    {
        if (manufacturer == null || manufacturer.IsZero) throw new Exception("Manufacturer address cannot be null or zero.");
        if (stepNumber == 0) throw new Exception("Step number must be greater than 0.");

        var project = getProjectAccount(projectId);

        var obj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber);
        if (obj == null) return false;

        var milestone = (MilestoneCompletionVotesStruct)obj;
        if (milestone.isVotingStepComplete)
            return milestone.IsVotingSuccessful;

        // Определяем дедлайн
        ulong deadline = milestone.Deadline_UnixTime > 0
            ? milestone.Deadline_UnixTime
            : milestone.VotingStartTime + milestone.VotingDuration;

        bool autoFinish = project.projectSettings != null && project.projectSettings.AutoFinishExpiredVotings;

        // Разрешаем финализацию по дедлайну или при включенной автофинализации
        if (!(Runtime.Time >= deadline || autoFinish))
            return false;

        // Данные для расчета
        BigInteger totalEligible = ProjectState.GetEligibleVotersCount(projectId);

        BigInteger positiveVotes = 0;
        BigInteger negativeVotes = 0;
        BigInteger abstainedVotes = 0;
        BigInteger totalCasted = 0;

        // Собираем голоса из StateStorage
        UInt160[] backers = ProjectState.GetBackersWithDonations(projectId);
        if (backers != null)
        {
            for (int i = 0; i < backers.Length; i++)
            {
                UInt160 backer = backers[i];
                if (!ProjectState.IsBackerEligible(projectId, backer)) continue;

                BackerVotesEnum vote = (BackerVotesEnum)ProjectState.GetMilestoneBackerVote(projectId, manufacturer, stepNumber, backer);
                BigInteger weight = ProjectState.GetBackerVoteWeight(projectId, backer);

                // Считаем все зарегистрированные голоса, включая Abstained (как и в общей логике)
                totalCasted += weight;

                if (vote == BackerVotesEnum.Positive) positiveVotes += weight;
                else if (vote == BackerVotesEnum.Negative) negativeVotes += weight;
                else if (vote == BackerVotesEnum.Abstained) abstainedVotes += weight;
            }
        }

        // Параметры голосования из настроек проекта
        bool autoAssignVoiceless = project.projectSettings != null && project.projectSettings.AutoAssignVoicelessToAbstain;
        bool abstainAsSupport = project.projectSettings != null && project.projectSettings.AutoAbstainVoteAsSupport;
        BigInteger minParticipationPct = project.projectSettings != null ? project.projectSettings.MinRequiredVotingParticipation : 0;
        BigInteger minApprovalPct = project.projectSettings != null ? project.projectSettings.MinApprovalPercentage : 0;

        // Автоприсвоение безголосых как воздержавшихся (по аналогии с CalculateVoteOutcome)
        BigInteger voiceless = totalEligible - totalCasted;
        if (autoAssignVoiceless && voiceless > 0)
        {
            abstainedVotes += voiceless;
            totalCasted += voiceless;
        }

        if (abstainAsSupport)
        {
            positiveVotes += abstainedVotes;
        }

        // Порог участия
        bool meetsMinParticipation = true;
        if (minParticipationPct > 0 && totalEligible > 0)
        {
            meetsMinParticipation = (totalCasted * 100) >= (totalEligible * minParticipationPct);
        }

        bool isSuccessful = false;
        if (meetsMinParticipation && totalCasted > 0)
        {
            isSuccessful = (positiveVotes * 100) >= (totalCasted * minApprovalPct);
        }

        // Записываем итог
        milestone.PositiveVotesCount = positiveVotes;
        milestone.NegativeVotesCount = negativeVotes;
        milestone.AbstainedVotesCount = abstainedVotes;
        milestone.TotalVotesCount = totalCasted;
        milestone.IsVotingSuccessful = isSuccessful;
        milestone.isVotingStepComplete = true;

        ProjectState.SetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber, milestone);

        VotingCompleted(
            projectId,
            "MilestoneCompletion:" + manufacturer.ToString() + "_step" + stepNumber.ToString(),
            isSuccessful ? BackerVotesEnum.Positive : BackerVotesEnum.Negative
        );

        saveProjectAccountToProjectsAccountStore(projectId, project);
        return isSuccessful;
    }


    public static bool isMilestoneVotingCompleteSuccess(UInt160 manufacturer, string projectId, byte stepNumber)
    {
        var msObj = ProjectState.GetMilestoneCompletionVotesStruct(projectId, manufacturer, stepNumber);
        if (msObj == null) return false;

        var milestone = (MilestoneCompletionVotesStruct)msObj;
        return milestone.isVotingStepComplete && milestone.IsVotingSuccessful;
    }

}


public partial class IF_MainGateway // Facade  methods
{
    public static void withdrawBackerBalance(UInt160 backerAddress, BigInteger amount)
    {
        BackerAccount.WithdrawFromMainBalance(backerAddress, amount);
    }

    public static void withdrawInvestorBalance(UInt160 investorAddress, BigInteger amount)
    {
        InvestorAccount.WithdrawFromMainBalance(investorAddress, amount);
    }

    public static void withdrawManufacturerBalance(UInt160 manufacturerAddress, BigInteger amount)
    {
        ManufacturerAccount account = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
        account.withdrawFromMainBalance(manufacturerAddress, amount);
    }

    public static void withdrawProjectCreatorBalance(UInt160 projectCreatorAddress, BigInteger amount)
    {
        ProjectCreatorAccount.WithdrawFromMainBalance(projectCreatorAddress, amount);
    }


    // Оставляем no-op: перечисления инвесторов в ProjectState нет.
    // Возвраты должны выполняться на уровне проекта до removeManufacturerAccount.
    private static void processManufacturerInvestmentReturns(ManufacturerAccount manufacturer)
    {
    }


    public static void donateToProjectManufacturerAsInvestor(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
    {
        if (investorAddress == null || investorAddress.IsZero)
            throw new Exception("Invalid investor address");

        if (manufacturerAddress == null || manufacturerAddress.IsZero)
            throw new Exception("Invalid manufacturer address");

        if (amount <= 0)
            throw new Exception("Investment amount must be positive");

        if (!Runtime.CheckWitness(investorAddress))
            throw new Exception("Authorization failed for investor");

        InvestorAccount investor = InvestorAccount.getInvestorAccount(investorAddress);
        ManufacturerAccount manufacturer = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);

        if (investor.FreeBalance < amount)
            throw new Exception("Investor has insufficient free balance");

        InvestmentAgreement.checkAllExpiredAgreements(investorAddress);
        InvestmentAgreement.checkAllExpiredAgreements(manufacturerAddress);

        AcquireLock();
        try
        {
            byte[] assetId = new byte[20];
            BigInteger repaymentAmount = amount;
            ulong dueDate = Runtime.Time + 31536000;

            byte[] agreementId = InvestmentAgreement.createAgreementForProjectInvestment(
                investorAddress,
                manufacturerAddress,
                amount,
                assetId,
                repaymentAmount,
                dueDate
            );

            InvestmentAgreement.confirmAgreement(agreementId);

            InvestorAccount investorForUpdate = InvestorAccount.getInvestorAccount(investorAddress);
            investorForUpdate.FreeBalance -= amount;
            InvestorAccount.updateExistingInvestorAccount(investorAddress, investorForUpdate);

            ByteString rawAgreement = ProjectState.GetAgreement((ByteString)agreementId);
            if (rawAgreement == null)
                throw new Exception("Failed to retrieve created agreement");

            InvestmentAgreement agreement = (InvestmentAgreement)StdLib.Deserialize(rawAgreement);

            InvestmentAgreement.handleInvestmentPayment(
                agreement,
                agreementId,
                investorAddress,
                amount,
                (UInt160)assetId
            );

            FinancialOperations.RecordInvestment(
                investorAddress,
                manufacturerAddress,
                "DIRECT_INVESTMENT",
                amount,
                agreementId
            );

            InvestmentPaymentMade(agreementId, amount);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    public static bool canWithdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
    {
        if (manufacturerAddress.Length != 20) throw new Exception("The parameter ManufacturerAddress SHOULD be a 20-byte address.");
        if (investorAddress.Length != 20) throw new Exception("The parameter InvestorAddress SHOULD be a 20-byte address.");

        string key = investorAddress.ToString() + manufacturerAddress.ToString();

        var project = getProjectAccount(projectId);

        BigInteger currentInvestment = ProjectState.GetBackerReservation(projectId, investorAddress, manufacturerAddress);
        if (currentInvestment <= 0)
            return false;

        if (project.IsProjectClosed && project.CurrentProjectStatus != ProjectStatus.Terminated) return false;
        if (project.IsProjectPaused) return false;

        if (ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
        {
            ManufacturerAccount projectManufacturer = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
            if (projectManufacturer == null) return false;
            if (projectManufacturer.FreeBalance < currentInvestment)
                return false;
        }
        else
        {
            return false;
        }

        return true;
    }


    // Локальный helper: загрузка аккаунта по Caller с CheckWitness
    static ManufacturerAccount RequireCallerAndLoadAccount(object[] a, int callerIndex = 0)
    {
        if (a.Length <= callerIndex) throw new Exception("Caller argument is missing");
        UInt160 caller = (UInt160)a[callerIndex];
        if (!Runtime.CheckWitness(caller)) throw new Exception("Authorization failed");

        ByteString raw = ProjectState.GetRawManufacturerAccount(caller);
        if (raw is null || raw.Length == 0) throw new Exception("Manufacturer account not found for caller");
        return (ManufacturerAccount)StdLib.Deserialize(raw);
    }

}

public partial class IF_MainGateway // Facade  methods
{
    public static string callManufacturerAccountFacade(string operation, object[] args)
    {
        if (args == null)
            throw new Exception("Invalid arguments: args cannot be null");

        string methodName = operation;
        string SerializedReturnedValue = StdLib.Serialize("void Method");


        switch (methodName)
        {
            // -------------------- Экземплярные методы (первый аргумент: Caller) --------------------

            case "payProfitToInvestor":
                {
                    if (args.Length < 2) throw new Exception("Not enough arguments for payProfitToInvestor");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    bool result = account.payProfitToInvestor((BigInteger)args[1]);
                    ManufacturerAccount.updateExistingManufacturerAccount(account);
                    SerializedReturnedValue = StdLib.Serialize(result);
                    break;
                }

            case "canRefundInvestment":
                {
                    if (args.Length < 4) throw new Exception("Not enough arguments for canRefundInvestment");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    bool result = account.canRefundInvestment((string)args[1], (UInt160)args[2], (BigInteger)args[3]);
                    SerializedReturnedValue = StdLib.Serialize(result);
                    break;
                }

            case "refundInvestment":
                {
                    if (args.Length < 4) throw new Exception("Not enough arguments for refundInvestment");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    bool result = account.refundInvestment((string)args[1], (UInt160)args[2], (BigInteger)args[3]);
                    ManufacturerAccount.updateExistingManufacturerAccount(account);
                    SerializedReturnedValue = StdLib.Serialize(result);
                    break;
                }

            case "canPayProfit":
                {
                    if (args.Length < 2) throw new Exception("Not enough arguments for canPayProfit");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    bool result = account.canPayProfit((BigInteger)args[1]);
                    SerializedReturnedValue = StdLib.Serialize(result);
                    break;
                }

            case "processInvestorInvestments":
                {
                    if (args.Length < 4) throw new Exception("Not enough arguments for processInvestorInvestments");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    account.processInvestorInvestments((UInt160)args[1], (BigInteger)args[2], (byte[])args[3]);
                    ManufacturerAccount.updateExistingManufacturerAccount(account);
                    break;
                }

            case "processRepayment":
                {
                    if (args.Length < 3) throw new Exception("Not enough arguments for processRepayment");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    account.processRepayment((byte[])args[1], (BigInteger)args[2]);
                    ManufacturerAccount.updateExistingManufacturerAccount(account);
                    break;
                }

            case "processManufacturerRepayment":
                {
                    if (args.Length < 3) throw new Exception("Not enough arguments for processManufacturerRepayment");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    account.processManufacturerRepayment((byte[])args[1], (BigInteger)args[2]);
                    // Метод внутри уже обновляет manufacturer, но безопасно повторно синхронизировать и caller-аккаунт
                    ManufacturerAccount.updateExistingManufacturerAccount(account);
                    break;
                }

            case "processInvestorWithdraw":
                {
                    if (args.Length < 4) throw new Exception("Not enough arguments for processInvestorWithdraw");
                    var account = RequireCallerAndLoadAccount(args, 0);
                    account.processInvestorWithdraw((string)args[1], (UInt160)args[2], (BigInteger)args[3]);
                    ManufacturerAccount.updateExistingManufacturerAccount(account);
                    break;
                }

            // -------------------- Статические методы --------------------

            case "getManufacturerAccount":
                {
                    if (args.Length < 1) throw new Exception("Not enough arguments for getManufacturerAccount");
                    SerializedReturnedValue = StdLib.Serialize(ManufacturerAccount.getManufacturerAccount((UInt160)args[0]));
                    break;
                }

            case "createManufacturerAccount":
                {
                    if (args.Length < 2) throw new Exception("Not enough arguments for createManufacturerAccount");
                    SerializedReturnedValue = StdLib.Serialize(ManufacturerAccount.createManufacturerAccount((UInt160)args[0], (byte[])args[1]));
                    break;
                }

            case "updateExistingManufacturerAccount":
                {
                    if (args.Length < 1) throw new Exception("Not enough arguments for updateExistingManufacturerAccount");
                    ManufacturerAccount.updateExistingManufacturerAccount((ManufacturerAccount)args[0]);
                    break;
                }

            case "getTotalBalanceOfManufacturerAccount":
                {
                    if (args.Length < 1) throw new Exception("Not enough arguments for getTotalBalanceOfManufacturerAccount");
                    SerializedReturnedValue = StdLib.Serialize(ManufacturerAccount.getTotalBalanceOfManufacturerAccount((UInt160)args[0]));
                    break;
                }

            case "getFreeBalanceOfManufacturerAccount":
                {
                    if (args.Length < 1) throw new Exception("Not enough arguments for getFreeBalanceOfManufacturerAccount");
                    SerializedReturnedValue = StdLib.Serialize(ManufacturerAccount.getFreeBalanceOfManufacturerAccount((UInt160)args[0]));
                    break;
                }

            case "removeManufacturerAccount":
                {
                    if (args.Length < 1) throw new Exception("Not enough arguments for removeManufacturerAccount");
                    ManufacturerAccount.removeManufacturerAccount((UInt160)args[0]);
                    break;
                }

            case "withdrawFromMainBalance":
                {
                    if (args.Length < 2) throw new Exception("Not enough arguments for withdrawFromMainBalance");
                    ManufacturerAccount account = ManufacturerAccount.getManufacturerAccount((UInt160)args[0]);
                    account.withdrawFromMainBalance((UInt160)args[0], (BigInteger)args[1]);
                    break;
                }

            default:
                return StdLib.Serialize($"Unknown method: {methodName}");
        }

        return SerializedReturnedValue;
    }

    public static string callInvestorAccountFacade(string operation, object[] args)
    {
        if (args == null)
            throw new Exception("Invalid arguments: args cannot be null");

        string methodName = operation;

        string SerializedReturnedValue = StdLib.Serialize("void Method");

        switch (methodName)
        {
            // InvestorAccount
            case "getInvestorAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getInvestorAccount");
                SerializedReturnedValue = StdLib.Serialize(InvestorAccount.getInvestorAccount((UInt160)args[0]));
                break;

            case "updateExistingInvestorAccount":
                if (args.Length < 2) throw new Exception("Not enough arguments for updateExistingInvestorAccount");
                InvestorAccount.updateExistingInvestorAccount((UInt160)args[0], (InvestorAccount)args[1]);
                break;

            case "withdrawInvestment":
                if (args.Length < 3) throw new Exception("Not enough arguments for withdrawInvestment");
                InvestorAccount.withdrawInvestment((string)args[0], (UInt160)args[1], (UInt160)args[2]);
                break;

            case "investAsInvestorToManufacturerCandidate":
                if (args.Length < 3) throw new Exception("Not enough arguments for investAsInvestorToManufacturerCandidate");
                InvestorAccount.investAsInvestorToManufacturerCandidate((UInt160)args[0], (UInt160)args[1], (BigInteger)args[2]);
                break;

            case "createInvestorAccount":
                if (args.Length < 2) throw new Exception("Not enough arguments for createInvestorAccount");
                InvestorAccount.createInvestorAccount((UInt160)args[0], (byte[])args[1]);
                break;

            case "moveFromInvestorBalanceToInnFork":
                if (args.Length < 3) throw new Exception("Not enough arguments for moveFromInvestorBalanceToInnFork");
                InvestorAccount.moveFromInvestorBalanceToInnFork((string)args[0], (UInt160)args[1], (BigInteger)args[2]);
                break;

            case "withdrawFromMainBalance":
                if (args.Length < 2) throw new Exception("Not enough arguments for withdrawFromMainBalance");
                InvestorAccount.WithdrawFromMainBalance((UInt160)args[0], (BigInteger)args[1]);
                break;

            case "getTotalBalanceOfInvestorAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getTotalBalanceOfInvestorAccount");
                SerializedReturnedValue = StdLib.Serialize(InvestorAccount.getTotalBalanceOfInvestorAccount((UInt160)args[0]));
                break;

            case "getFreeBalanceOfInvestorAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getFreeBalanceOfInvestorAccount");
                SerializedReturnedValue = StdLib.Serialize(InvestorAccount.getFreeBalanceOfInvestorAccount((UInt160)args[0]));
                break;

            case "removeInvestorAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for removeInvestorAccount");
                InvestorAccount.removeInvestorAccount((UInt160)args[0]);
                break;







            // FinancialOperations
            case "RecordInvestment":
                if (args.Length < 5) throw new Exception("Not enough arguments for RecordInvestment");
                FinancialOperations.RecordInvestment(
                    (UInt160)args[0],
                    (UInt160)args[1],
                    (string)args[2],
                    (BigInteger)args[3],
                    (byte[])args[4]
                );
                break;

            case "GetInvestmentAmount":
                if (args.Length < 3) throw new Exception("Not enough arguments for GetInvestmentAmount");
                SerializedReturnedValue = StdLib.Serialize(
                    FinancialOperations.GetInvestmentAmount(
                        (UInt160)args[0],
                        (UInt160)args[1],
                        (string)args[2]
                    )
                );
                break;








            // InvestmentAgreement
            case "trackAgreementParties":
                if (args.Length < 3) throw new Exception("Not enough arguments for trackAgreementParties");
                InvestmentAgreement.trackAgreementParties((byte[])args[0], (UInt160)args[1], (UInt160)args[2]);
                break;

            case "handleRepayment":
                if (args.Length < 5) throw new Exception("Not enough arguments for handleRepayment");
                InvestmentAgreement.handleRepayment(
                    (InvestmentAgreement)args[0],
                    (byte[])args[1],
                    (UInt160)args[2],
                    (BigInteger)args[3],
                    (UInt160)args[4]
                );
                break;

            case "scheduledAgreementMaintenance":
                if (args.Length != 0) throw new Exception("scheduledAgreementMaintenance takes no arguments");
                InvestmentAgreement.scheduledAgreementMaintenance();
                break;

            case "processLimitedExpiredAgreements":
                if (args.Length != 0) throw new Exception("processLimitedExpiredAgreements takes no arguments");
                InvestmentAgreement.processLimitedExpiredAgreements();
                break;

            case "processAgreementsList":
                if (args.Length < 1) throw new Exception("Not enough arguments for processAgreementsList");
                InvestmentAgreement.processAgreementsList((byte[])args[0]);
                break;

            case "checkSingleAgreementStatus":
                if (args.Length < 2) throw new Exception("Not enough arguments for checkSingleAgreementStatus");
                InvestmentAgreement.checkSingleAgreementStatus((InvestmentAgreement)args[0], (byte[])args[1]);
                break;

            case "generateAgreementId":
                if (args.Length < 3) throw new Exception("Not enough arguments for generateAgreementId");
                SerializedReturnedValue = StdLib.Serialize(
                    InvestmentAgreement.generateAgreementId((UInt160)args[0], (UInt160)args[1], (BigInteger)args[2])
                );
                break;

            case "checkAgreementStatus":
                if (args.Length < 1) throw new Exception("Not enough arguments for checkAgreementStatus");
                InvestmentAgreement.checkAgreementStatus((byte[])args[0]);
                break;

            case "createAgreement":
                if (args.Length < 6) throw new Exception("Not enough arguments for createAgreement");
                InvestmentAgreement.createAgreement(
                    (UInt160)args[0],
                    (UInt160)args[1],
                    (BigInteger)args[2],
                    (byte[])args[3],
                    (BigInteger)args[4],
                    (ulong)args[5]
                );
                break;

            case "createAgreementForProjectInvestment":
                if (args.Length < 6) throw new Exception("Not enough arguments for createAgreementForProjectInvestment");
                SerializedReturnedValue = StdLib.Serialize(
                    InvestmentAgreement.createAgreementForProjectInvestment(
                        (UInt160)args[0],
                        (UInt160)args[1],
                        (BigInteger)args[2],
                        (byte[])args[3],
                        (BigInteger)args[4],
                        (ulong)args[5]
                    )
                );
                break;

            case "confirmAgreement":
                if (args.Length < 1) throw new Exception("Not enough arguments for confirmAgreement");
                InvestmentAgreement.confirmAgreement((byte[])args[0]);
                break;

            case "checkAllExpiredAgreements":
                if (args.Length < 1) throw new Exception("Not enough arguments for checkAllExpiredAgreements");
                InvestmentAgreement.checkAllExpiredAgreements((UInt160)args[0]);
                break;

            case "handleInvestmentPayment":
                if (args.Length < 5) throw new Exception("Not enough arguments for handleInvestmentPayment");
                InvestmentAgreement.handleInvestmentPayment(
                    (InvestmentAgreement)args[0],
                    (byte[])args[1],
                    (UInt160)args[2],
                    (BigInteger)args[3],
                    (UInt160)args[4]
                );
                break;

            case "checkExpiredAgreementsForParticipant":
                if (args.Length < 1) throw new Exception("Not enough arguments for checkExpiredAgreementsForParticipant");
                InvestmentAgreement.checkExpiredAgreementsForParticipant((UInt160)args[0]);
                break;

            case "processAllExpiredAgreements":
                if (args.Length != 0) throw new Exception("processAllExpiredAgreements takes no arguments");
                InvestmentAgreement.processAllExpiredAgreements();
                break;

            case "safeTransfer":
                if (args.Length < 3) throw new Exception("Not enough arguments for safeTransfer");
                InvestmentAgreement.safeTransfer((UInt160)args[0], (UInt160)args[1], (BigInteger)args[2]);
                break;

            default:
                return StdLib.Serialize($"Unknown method: {methodName}");
        }

        return SerializedReturnedValue;
    }

    public static string callBackerAccountFacade(string operation, object[] args)// // params - можно передавать любое количество аргументов
    {
        if (args == null)
            throw new Exception("Invalid arguments: args cannot be null");

        string methodName = operation;

        string SerializedReturnedValue = StdLib.Serialize("void Method");

        switch (methodName)
        {

            case "createBackerAccount":
                if (args.Length == 1)
                {
                    BackerAccount.createBackerAccount((UInt160)args[0]);
                }
                else if (args.Length >= 2)
                {
                    BackerAccount.createBackerAccount((UInt160)args[0], (byte[])args[1]);
                }
                else
                {
                    throw new Exception("Not enough arguments for createBackerAccount");
                }
                break;

            case "updateExistingBackerAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for updateExistingBackerAccount");
                BackerAccount.updateExistingBackerAccount((BackerAccount)args[0]);
                break;

            case "getBackerAccount":
                if (args.Length < 2) throw new Exception("Not enough arguments for getBackerAccount");
                SerializedReturnedValue = StdLib.Serialize(BackerAccount.getBackerAccount((UInt160)args[0], (bool)args[1]));
                break;

            case "getTotalBalanceOfBackerAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getTotalBalanceOfBackerAccount");
                SerializedReturnedValue = StdLib.Serialize(BackerAccount.getTotalBalanceOfBackerAccount((UInt160)args[0]));
                break;

            case "getFreeBalanceOfBackerAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getFreeBalanceOfBackerAccount");
                SerializedReturnedValue = StdLib.Serialize(BackerAccount.getFreeBalanceOfBackerAccount((UInt160)args[0]));
                break;

            case "withdrawFromMainBalance":
                if (args.Length < 2) throw new Exception("Not enough arguments for withdrawFromMainBalance");
                BackerAccount.WithdrawFromMainBalance((UInt160)args[0], (BigInteger)args[1]);
                break;


            default:
                return StdLib.Serialize($"Unknown method: {methodName}");
        }

        return SerializedReturnedValue;
    }

    public static string callProjectCreatorAccountFacade(string operation, object[] args)
    {
        if (args == null)
            throw new Exception("Invalid arguments: args cannot be null");

        string methodName = operation;

        string SerializedReturnedValue = StdLib.Serialize("void Method");

        switch (methodName)
        {
            case "createProjectCreatorAccount":
                if (args.Length < 2) throw new Exception("Not enough arguments for createProjectCreatorAccount");
                SerializedReturnedValue = StdLib.Serialize(ProjectCreatorAccount.createProjectCreatorAccount((UInt160)args[0], (string)args[1]));
                break;

            case "withdrawFromMainBalance":
                if (args.Length < 2) throw new Exception("Not enough arguments for withdrawFromMainBalance");
                ProjectCreatorAccount.WithdrawFromMainBalance((UInt160)args[0], (BigInteger)args[1]);
                break;

            case "updateExistingProjectCreatorAccount":
                if (args.Length < 2) throw new Exception("Not enough arguments for updateExistingProjectCreatorAccount");
                ProjectCreatorAccount.updateExistingProjectCreatorAccount((UInt160)args[0], (ProjectCreatorAccount)args[1]);
                break;

            case "getProjectCreatorAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getProjectCreatorAccount");
                SerializedReturnedValue = StdLib.Serialize(ProjectCreatorAccount.getProjectCreatorAccount((UInt160)args[0]));
                break;

            case "getTotalBalanceOfProjectCreatorAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getTotalBalanceOfProjectCreatorAccount");
                SerializedReturnedValue = StdLib.Serialize(ProjectCreatorAccount.getTotalBalanceOfProjectCreatorAccount((UInt160)args[0]));
                break;

            case "getFreeBalanceOfProjectCreatorAccount":
                if (args.Length < 1) throw new Exception("Not enough arguments for getFreeBalanceOfProjectCreatorAccount");
                SerializedReturnedValue = StdLib.Serialize(ProjectCreatorAccount.getFreeBalanceOfProjectCreatorAccount((UInt160)args[0]));
                break;

            case "getProjectCreatorAccountByProjectId":
                if (args.Length == 1)
                {
                    SerializedReturnedValue = StdLib.Serialize(ProjectCreatorAccount.getProjectCreatorAccountByProjectId((string)args[0]));
                }
                else if (args.Length >= 2)
                {
                    SerializedReturnedValue = StdLib.Serialize(ProjectCreatorAccount.getProjectCreatorAccountByProjectId((string)args[0], (bool)args[1]));
                }
                else
                {
                    throw new Exception("Not enough arguments for getProjectCreatorAccountByProjectId");
                }
                break;

            case "setPublicKey":
                if (args.Length < 4) throw new Exception("Not enough arguments for setPublicKey");
                ProjectCreatorAccount account = ProjectCreatorAccount.getProjectCreatorAccount((UInt160)args[0]);
                if (account == null) throw new Exception("Account not found");
                SerializedReturnedValue = StdLib.Serialize(account.setPublicKey((UInt160)args[0], (string)args[1], (string)args[2], (string)args[3]));
                break;

            case "setPublicKeyBytes":
                if (args.Length < 4) throw new Exception("Not enough arguments for setPublicKeyBytes");
                ProjectCreatorAccount accountBytes = ProjectCreatorAccount.getProjectCreatorAccount((UInt160)args[0]);
                if (accountBytes == null) throw new Exception("Account not found");
                SerializedReturnedValue = StdLib.Serialize(accountBytes.setPublicKeyBytes((UInt160)args[0], (byte[])args[1], (byte[])args[2], (byte[])args[3]));
                break;

            case "executeProjectCreatorRefund":
                if (args.Length < 2) throw new Exception("Not enough arguments for executeProjectCreatorRefund");
                ProjectCreatorAccount refundAccount = ProjectCreatorAccount.getProjectCreatorAccount((UInt160)args[0]);
                if (refundAccount == null) throw new Exception("Account not found");
                refundAccount.executeProjectCreatorRefund((UInt160)args[0], (BigInteger)args[1]);
                break;

            default:
                return StdLib.Serialize($"Unknown method: {methodName}");
        }

        return SerializedReturnedValue;
    }

}

public partial class IF_MainGateway
{
    /*
        Примечания: Каждый метод использует в качестве примера передачу пользователю токена NEP-17, принадлежащего контракту.На практике, если используется определенный стейблкоин(FLMUSD), метод контракта этого токена будет называться аналогичным образом.Перед обновлением сальдо мы проверяем успешное выполнение перевода (возвращаем true). Мы также поддерживаем постоянство в : здесь он рассматривается как общая сумма средств пользователя по контракту, поэтому он уменьшается при выводе.Gas.TransfertransferTotalBalance

        (Кроме того, у BackerAccount была временная инициализация тестового баланса (TotalBalance = 10000000 в качестве заглушки). В производственных условиях это следует убрать, чтобы балансы бэкеров отражали только реальные депозиты.)

    2. Инвестирование в производителя(investToManufacturer)

    Выпуск: Логика в нем неполна в том, как он обрабатывает «акции» для участия в прибыли для нескольких инвесторов, и не сохраняет все изменения правильно.Конкретно:IF_MainGateway.investToManufacturer

    Он сохраняет начальное значение доли в состоянии проекта только в том случае, если значение не существовало. Вероятно, это было предназначено для отслеживания доли прибыли инвестора или веса голоса, но он просто использует первую сумму инвестиций, приведенную к int, и не обновляется, если происходит больше инвестиций. Это не правильный и не масштабируемый способ определения доли прибыли между несколькими инвесторами.ProjectState.SetWinnerSelectionVote(projectId, investor, manufacturer, (int) amount)

    Код увеличивает остатки на счетах производителя (, , ) на инвестированную сумму, но не вызывает.Это означает, что обновленные балансы не будут сохранены в хранилище.InvestmentAmountTotalBalanceFreeBalanceManufacturerAccount.updateExistingManufacturerAccount

    Не проводится проверка для предотвращения инвестиций после того, как у проекта уже есть победитель (или он завершен), что может быть упущением.Инвесторы не должны иметь возможности вкладывать средства в проект, если выбран производитель или завершена фаза финансирования.

    Исправление: Мы изменяем следующим образом:investToManufacturer

    Отслеживание распределения акций/прибыли: Вместо того, чтобы использовать его в качестве заполнителя для акций, ведите надлежащий учет инвестиций. Мы будем аккумулировать общие инвестиции каждого инвестора на каждого производителя в проекте (контракт уже делает это с помощью сопоставления средств (инвестор→производитель)). Для распределения прибыли мы рассчитываем процент или долю в момент вывода средств, а не сохраняем потенциально устаревший процент.Это обеспечивает правильную работу с несколькими инвесторами. (В качестве альтернативы можно каждый раз обновлять процент доли в хранилище, но расчет в реальном времени проще и позволяет избежать проблем с округлением.)WinnerSelectionVoteProjectState.SetBackerReservation

    Обновления штата: После корректировки объекта учетной записи производителя вызовите метод update для сохранения изменений.Также обновите учетную запись инвестора (что код уже делает для инвестора).

    Ратификация: Если статус проекта таков, что дальнейшие инвестиции не должны приниматься(например, победитель уже выбран), мы предотвращаем новые инвестиции.Мы можем проверить или убедиться, что проект находится в открытой инвестиционной стадии.ProjectAccount.IsProjectHasWinnerCurrentProjectStatus

    Ниже приведен исправленный метод:investToManufacturer
    */
    // In IF_MainGateway (ActorsAccountsFacade partial) – investToManufacturer
    public static void investToManufacturer(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress, BigInteger amount)
    {
        if (manufacturerAddress.Length != 20 || investorAddress.Length != 20)
            throw new Exception("ManufacturerAddress and InvestorAddress must be 20-byte addresses.");
        if (!Runtime.CheckWitness(investorAddress))
            throw new Exception("Only the investor can invoke this method for their investments.");

        // Ensure the project is still open for investments (no winner chosen yet)
        ProjectAccount project = getProjectAccount(projectId);
        if (project.IsProjectHasWinner || project.CurrentProjectStatus == ProjectStatus.Completed)
            throw new Exception("Investments are closed for this project (winner already selected or project completed).");

        // Basic validations
        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
            throw new Exception("The manufacturer is not a registered candidate in this project.");
        if (amount <= 0)
            throw new Exception("Investment amount must be greater than zero.");
        // Optional minimum investment threshold check
        BigInteger minInvestment = ProjectState.GetConditionalThreshold(projectId, "min_inv_" + manufacturerAddress.ToString());
        if (minInvestment > 0 && amount < minInvestment)
            throw new Exception($"Investment amount {amount} is below the minimum required {minInvestment} for this manufacturer.");

        InvestorAccount investorAccount = InvestorAccount.getInvestorAccount(investorAddress);
        if (investorAccount.FreeBalance < amount)
            throw new Exception("The investor has insufficient free funds in their account.");
        ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
        if (manufacturerAccount == null)
            throw new Exception("Internal error: manufacturer account not found.");

        // Before proceeding, handle any expired investment agreements (cleanup)
        InvestmentAgreement.checkAllExpiredAgreements(investorAddress);
        InvestmentAgreement.checkAllExpiredAgreements(manufacturerAddress);

        AcquireLock();
        try
        {
            // Create a new investment agreement/record (with a predefined expiration, e.g., 1 year from now)
            byte[] agreementId = InvestmentAgreement.createAgreementForProjectInvestment(
                                    investorAddress, manufacturerAddress, amount, projectId.ToByteArray(), amount,
                                    Runtime.Time + 31536000 /* 1 year */);
            // Deduct from investor's balance and update investor account
            investorAccount.FreeBalance -= amount;
            InvestorAccount.updateExistingInvestorAccount(investorAddress, investorAccount);

            // Record the investment in project state (accumulate if already invested before)
            BigInteger priorInvestment = ProjectState.GetBackerReservation(projectId, investorAddress, manufacturerAddress);
            ProjectState.SetBackerReservation(projectId, investorAddress, manufacturerAddress, priorInvestment + amount);

            // Update total invested amount for manufacturer in this project (accumulate in manufacturer account if tracked)
            manufacturerAccount.InvestmentAmount += amount;
            // Increase manufacturer's available balance (the funds are now at their disposal in contract)
            manufacturerAccount.FreeBalance += amount;
            manufacturerAccount.TotalBalance += amount;
            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);

            // (Optional) Update share percentage if we store it: 
            // We won't store a fixed percentage here; profit share will be computed at withdrawal time based on actual investments.
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }

    /*
        Примечания:

    Мы добавили чек для предотвращения инвестирования, когда у проекта уже есть выбранный победитель или он завершен.Это гарантирует, что инвестиции происходят только на этапе сбора средств.

    Мы убрали использование для хранения общих ресурсов.Вместо этого мы полагаемся на накопленные инвестиции(через ) и на счет производителя для расчета доли прибыли позже.Это позволяет избежать неверного предположения о том, что первая сумма инвестиций является окончательной долей.SetWinnerSelectionVoteSetBackerReservationInvestmentAmount

    Звоним сохранять обновленные остатки производителя.Уже был назначен вычет остатка инвестора.ManufacturerAccount.updateExistingManufacturerAccountInvestorAccount.updateExistingInvestorAccount

    Создание объекта сохраняется (при условии, что в нем регистрируется соглашение об инвестициях с истечением срока действия). Мы передаем(переводим в байты) в него, чтобы договор можно было привязать к проекту.Это необходимо для ведения учета; Его внутренняя реализация должна учитывать право на возврат средств после истечения срока его действия.InvestmentAgreementprojectId

    Благодаря этим исправлениям несколько инвесторов могут инвестировать в одного и того же производителя, и каждая инвестиция регистрируется и отражается в балансе счета.

    3. Инвестор выводит инвестиции (withdrawInvestment)

    Выпуск: Этот метод позволяет инвестору отозвать свои инвестиции.Тем не менее, ему не хватало некоторых важных проверок и обновлений:withdrawInvestment(projectId, investorAddress, manufacturerAddress)

    Он не проверял, разрешен ли вывод средств с учетом состояния проекта. Например, если производитель уже выбран победителем проекта (и, предположительно, вложенные средства направлены на реализацию проекта), инвестор не должен выводить свои инвестиции по своему усмотрению.В исходном коде это не проверялось.

    Как и в случае с инвестиционным методом, он обновил учетную запись производителя с помощью, но не сохранил эти изменения, вызвав.Уменьшение FreeBalance производителем может не сохраниться.refundInvestmentupdateExistingManufacturerAccount

    Он также должен убедиться, что производитель действительно должен инвестору эту сумму (отображение на складе равно >0, которое он проверил) и что у производителя достаточно свободного баланса для возврата средств(чек частично покрывает это путем проверки баланса).canRefundInvestment

    Исправление: Мы улучшаем следующим образом:withdrawInvestment

    Проверка состояния проекта: Если в проекте уже определен победитель и этим победителем является тот же производитель, мы предотвращаем вывод средств, поскольку инвестиции теперь заблокированы(производитель выполняет проект). Инвесторам в производителя-победителя следует ждать прибыли, а не возврата денег.Если у проекта другой победитель или он был прекращен, можно смело выводить инвестиции из непобедивших производителей.Мы используем данные(и, возможно, какой производитель победил, с помощью идентификатора, если он доступен в штате). Если победителем является рассматриваемый производитель, мы выбрасываем исключение.ProjectAccountIsProjectHasWinner

    Убедитесь, что производитель может покрыть возмещение, а инвестор может его получить(эти проверки существовали: и ). Мы доверяем им проверку остатков и любых других условий(например, срок действия соглашения не истек или он уже не погашен).canRefundInvestmentcanReceiveRefund

    После звонка и, мы сохраняем обновленные учетные записи.Мы вызываем и . Исходный код только обновил счет инвестора.projectManufacturerAccount.refundInvestment(...)globalInvestorAccount.receiveInvestmentRefund(...)ManufacturerAccount.updateExistingManufacturerAccountInvestorAccount.updateExistingInvestorAccount

    Мы поддерживаем существующее обновление для сопоставления состояний проекта: чтобы очистить записанные инвестиции для этого проекта.SetBackerReservation(projectId, investor, manufacturer, 0)

    Вот исправлено:withdrawInvestment
    */
    // In IF_MainGateway (ActorsAccountsFacade partial) – withdrawInvestment
    public static void withdrawInvestment(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
    {
        if (manufacturerAddress.Length != 20 || investorAddress.Length != 20)
            throw new Exception("ManufacturerAddress and InvestorAddress should be 20-byte addresses.");
        if (!Runtime.CheckWitness(investorAddress))
            throw new Exception("Only the investor can withdraw their own investment.");

        BigInteger investmentAmount = ProjectState.GetBackerReservation(projectId, investorAddress, manufacturerAddress);
        if (investmentAmount <= 0)
            throw new Exception("No investment found for this investor-manufacturer pair in the project.");

        // Prevent withdrawal if the manufacturer is already the selected winner of the project
        ProjectAccount project = getProjectAccount(projectId);
        if (project.IsProjectHasWinner && ProjectState.GetManufacturerWinner(projectId) == manufacturerAddress)
            throw new Exception("Cannot withdraw investment after this manufacturer has been selected as the project winner.");
        // (Assuming ProjectState.GetWinner returns the winning manufacturer's address for the project)

        if (!ProjectState.IsManufacturerRegistered(projectId, manufacturerAddress))
            throw new Exception("Manufacturer is not a candidate in this project (invalid manufacturer).");

        ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
        InvestorAccount investorAccount = InvestorAccount.getInvestorAccount(investorAddress);

        if (!manufacturerAccount.canRefundInvestment(projectId, investorAddress, investmentAmount))
            throw new Exception("Manufacturer has insufficient balance or no record to refund this investment.");
        if (!investorAccount.canReceiveRefund(investmentAmount))
            throw new Exception("Refund amount is invalid for investor account.");

        AcquireLock();
        try
        {
            // Deduct from manufacturer's balance and possibly other records
            if (!manufacturerAccount.refundInvestment(projectId, investorAddress, investmentAmount))
                throw new Exception("Failed to process the investment refund from manufacturer.");
            // Credit the investor's free balance
            if (!investorAccount.receiveInvestmentRefund(investmentAmount))
                throw new Exception("Failed to process the investment refund to investor.");

            // Update stored accounts after successful refund
            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);
            InvestorAccount.updateExistingInvestorAccount(investorAddress, investorAccount);

            // Remove the investment record from project state
            ProjectState.SetBackerReservation(projectId, investorAddress, manufacturerAddress, 0);
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }
    /*

        Примечания:

    Мы ввели проверку с помощью(эта функция предполагается или должна быть реализована для получения адреса победителя по проекту). Если производитель совпадает, вывод средств блокируется.Это не позволяет инвестору вывести средства, которые уже вложены в победившую ставку.ProjectState.GetWinner(projectId)

    Метод, скорее всего, вычитает сумму из производителя и, возможно, из поля.Мы гарантируем, что он возвращает true (это означает, что операция была внутренне действительной). После этого и счета инвестора мы сохраняем оба счета.Этого не хватало в исходной логике.refundInvestmentManufacturerAccountFreeBalanceInvestmentAmountreceiveInvestmentRefund

    После снятия блокировки инвестор получит свои средства обратно на свой FreeBalance (и при желании сможет вывести их из контракта с помощью ранее реализованного метода вывода). Запись о состоянии проекта очищается, так что эти инвестиции больше не считаются активными.Если проект в конечном итоге будет прекращен или победит другой производитель, это гарантирует, что отозванные инвестиции не останутся ошибочно в записях.

    4. Вывод прибыли инвестора (withdrawInvestorProfit)

    Выпуск: Предполагается, что метод позволяет инвестору получить свою долю прибыли после успешного проекта.В предоставленном коде эта логика была неполной или ошибочной по нескольким параметрам:withdrawInvestorProfit(projectId, investorAddress, manufacturerAddress)

    Он вычисляет путем извлечения, которое было установлено в целое число (часто просто сумма инвестиций или 0). Затем код выполняет.Это означает, что они должны быть фактическим процентом(0–100). Однако, как уже отмечалось, хранение этой стоимости не было обновлено должным образом для нескольких инвесторов и, вероятно, не отражает истинный процент.Это может привести к неправильным расчетам прибыли или обнулению, если его не установить.sharePercentageProjectState.GetWinnerSelectionVote(projectId, investor, manufacturer)profitToWithdraw = (totalManufacturerProfit* sharePercentage) / 100sharePercentage

    Метод не проверяет, готова ли фаза распределения прибыли проекта.В идеале вывод прибыли должен происходить только после того, как проект будет завершен и производитель получит призовые фонды(пул прибыли) для распределения.Код не проверял, завершен ли проект или проведено ли голосование по контрольным точкам. Он только проверил это и то, что пул прибыли производителя () равен > 0.sharePercentage > 0ReservedFunds

    Как и другие методы, он обновил счет инвестора, но не обновил счет производителя после вычета прибыли. Производитель уменьшает его с помощью , но без сохранения изменение может не сохраниться.FreeBalancepayProfitToInvestor

    Исправление: Дорабатываем следующим образом:withdrawInvestorProfit

    Расчет динамической доли прибыли: Вместо того, чтобы полагаться на накопленный процент, рассчитайте долю инвестора на основе фактических инвестиций по сравнению с общим объемом инвестиций на момент распределения прибыли.У нас есть данные: инвестиции каждого инвестора и общая сумма, вложенная в этого производителя (по проекту), может быть выведена.Счет производителя есть, который мы увеличивали для каждой инвестиции. Если мы предполагаем, что представляет собой общую сумму инвестиций в этого производителя для этого проекта (примечание: здесь предполагается один контекст проекта; если он глобальный, нам может потребоваться другой подход, например, суммирование всех резерваций инвесторов для этого проекта). На данный момент мы предположим, что использование специфично для проекта.С их помощью:ProjectState.GetBackerReservationInvestmentAmountmanufacturerAccount.InvestmentAmount

    investorInvestment = ProjectState.GetBackerReservation(projectId, investor, manufacturer)

    totalInvestedInManufacturer = manufacturerAccount.InvestmentAmount(или сумма всех таких бронирований для этого проекта)

    Тогда доля прибыли инвестора = .investorInvestment / totalInvestedInManufacturer

    profitToWithdraw = totalManufacturerProfitInProject* (investorInvestment) / totalInvestedInManufacturer.
    Это дает результат BigInteger(деление этажа для любого остатка). Такой подход правильно распределяет прибыль пропорционально инвестициям, охватывая дело нескольких инвесторов.Мы полностью избегаем использования возможно неправильного значения.WinnerSelectionVote

    Государственные проверки: Убедитесь, что прибыль может быть выведена только после завершения проекта.Мы проверяем (или похожий флаг) и, возможно, что голосование завершилось.Код уже проверяет структуру вехи и крайний срок во вспомогательном устройстве.Мы можем гарантировать, что прибыль не будет выведена до тех пор, пока не будет завершено голосование по финальным этапам(что означает, что реализация проекта завершилась успешно). Если такие флаги существуют(например, и, возможно, ), мы их используем.Это предотвращает преждевременные заявления о прибыли.project.CurrentProjectStatus == CompletedisVotingStepCompleteisMilestoneStepStillRunningproject.IsProjectHasWinnerproject.CurrentProjectStatus == Completed

    Используйте в качестве пула прибыли производителя (как это было сделано в коде). Мы подтверждаем, что это значение() положительное.Вероятно, это представляет собой общую сумму призовых фондов, выделенных этому производителю(которая становится их доходом/прибылью от успеха проекта).ProjectState.GetReservedFunds(projectId, manufacturerAddress) totalManufacturerProfit

    Приступаем к выплатам: производитель платит инвестору, а инвестор получает прибыль.Затем обновите обе учетные записи и сохраненные зарезервированные средства. Оригинал сделал обновление (вычитая из него выведенную прибыль) и обновил аккаунт инвестора, но пропустил обновление аккаунта производителя в хранилище.Мы добавляем это обновление.ReservedFunds

    Вот исправленная реализация:withdrawInvestorProfit
    */
    // In IF_MainGateway (ActorsAccountsFacade partial) – withdrawInvestorProfit
    public static void withdrawInvestorProfit(string projectId, UInt160 investorAddress, UInt160 manufacturerAddress)
    {
        if (investorAddress.Length != 20 || manufacturerAddress.Length != 20)
            throw new Exception("InvestorAddress and ManufacturerAddress must be 20-byte addresses.");
        if (!Runtime.CheckWitness(investorAddress))
            throw new Exception("Only the investor can withdraw their profit share.");

        // Ensure project is completed and had a winner (profit distribution phase)
        ProjectAccount project = getProjectAccount(projectId);
        if (!project.IsProjectHasWinner || project.CurrentProjectStatus != ProjectStatus.Completed)
            throw new Exception("Profit withdrawal is only allowed after the project is successfully completed with a winner.");
        // Also ensure the specified manufacturer is the winner of the project
        if (ProjectState.GetManufacturerWinner(projectId) != manufacturerAddress)
            throw new Exception("The specified manufacturer is not the winner of this project, no profit available here.");

        // Determine total profit pool for the manufacturer in this project
        BigInteger totalManufacturerProfit = ProjectState.GetReservedFunds(projectId, manufacturerAddress);
        if (totalManufacturerProfit <= 0)
            throw new Exception("No profit available for distribution for this manufacturer (perhaps already withdrawn or not applicable).");

        // Calculate this investor's share of the profit based on investment proportion
        BigInteger investorInvestment = ProjectState.GetBackerReservation(projectId, investorAddress, manufacturerAddress);
        if (investorInvestment <= 0)
            throw new Exception("This investor has no investment in the winning manufacturer, so no profit share.");

        ManufacturerAccount manufacturerAccount = ManufacturerAccount.getManufacturerAccount(manufacturerAddress);
        InvestorAccount investorAccount = InvestorAccount.getInvestorAccount(investorAddress);
        // Total amount all investors put into this manufacturer for the project
        BigInteger totalInvestedInManufacturer = manufacturerAccount.InvestmentAmount;
        if (totalInvestedInManufacturer <= 0)
            throw new Exception("Internal error: total invested in manufacturer is zero or not set.");

        // Profit to withdraw = totalProfit * (investorInvestment / totalInvested)
        BigInteger profitToWithdraw = (totalManufacturerProfit * investorInvestment) / totalInvestedInManufacturer;
        if (profitToWithdraw <= 0)
            throw new Exception("Calculated profit share is zero; nothing to withdraw or already withdrawn.");

        // Ensure manufacturer has enough free balance to pay out (should have received the profit funds)
        if (!manufacturerAccount.canPayProfit(profitToWithdraw))
            throw new Exception("Manufacturer has insufficient free balance to pay this profit share.");

        if (!investorAccount.canReceiveProfit(profitToWithdraw))
            throw new Exception("Investor cannot receive this profit amount (invalid amount).");

        AcquireLock();
        try
        {
            // Deduct profit from manufacturer and add to investor
            if (!manufacturerAccount.payProfitToInvestor(profitToWithdraw))
                throw new Exception("Failed to deduct profit from manufacturer's account.");
            if (!investorAccount.receiveProfitPayment(profitToWithdraw))
                throw new Exception("Failed to credit profit to investor's account.");

            // Update both accounts in storage
            ManufacturerAccount.updateExistingManufacturerAccount(manufacturerAccount);
            InvestorAccount.updateExistingInvestorAccount(investorAddress, investorAccount);

            // Decrease the remaining profit pool for this manufacturer in project state
            BigInteger remainingProfit = totalManufacturerProfit - profitToWithdraw;
            if (remainingProfit < 0) remainingProfit = 0;
            ProjectState.SetReservedFunds(projectId, manufacturerAddress, remainingProfit);

            // (Optional) Record that this profit withdrawal occurred (could log an event or set a flag if needed)
        }
        finally
        {
            ReleaseAcquireLock();
        }
    }/*


    Примечания:

Мы добавили проверку, чтобы подтвердить, что указанный manufacturerAddress действительно является победителем проекта.Это предотвращает попытки вывода «прибыли», привязанной к непобедителю производителя.

При расчете прибыли используется пропорциональное распределение. Это гарантирует, что если инвесторов несколько, каждый из них может снять свою справедливую долю. Например, если инвестор А вложил 60 NEO, а инвестор B вложил 40 NEO в производителя (всего 100), а пул прибыли составляет 50 NEO, то А может вывести 30, а В — 20. Код вычисляет это соответствующим образом. (Первоначальный подход, использующий хранящийся целочисленный процент, мог исказить такие соотношения, особенно если не обновлять их для нескольких вкладов.)

Мы гарантируем общую сумму инвестиций для производителя этого проекта.Если бы в проекте контракта были учтены счета производителей по всему миру, возможно, потребовалось бы отслеживать общую сумму инвестиций по проекту в другом месте.Учитывая, как он был использован сразу после каждого из них, кажется, что он предназначен для использования в каждом проекте (вероятно, сброс или отдельный экземпляр для каждого проекта в контексте). Мы предполагаем, что здесь.manufacturerAccount.InvestmentAmountInvestmentAmountinvestToManufacturer

После выплаты мы обновляемся, чтобы уменьшить доступную прибыль.Если это значение достигнет нуля, любые дальнейшие коллы не обнаружат прибыли для вывода. Это предотвращает двойной вывод средств. (Если несколько инвесторов выводят средства в отдельных транзакциях, каждый из них соответственно уменьшит этот пул в соответствии с блокировкой.)ProjectState.SetReservedFunds

Обновление учетных записей для обеих сторон обеспечивает правильное хранение балансов.Например, FreeBalance производителя уменьшается на, а FreeBalance и TotalBalance инвестора увеличиваются на эту прибыль.profitToWithdraw

Наконец, в этих реализациях обрабатываются все ключевые методы, помеченные TODO, и неполные логические пути. Мы внедрили необходимые проверки (авторизация и состояние состояния) и обеспечили атомарный характер и постоянное обновление баланса.Теперь бизнес-процесс отражает ожидаемую логику реального мира:

Пользователи могут вносить и выводить средства со своих личных балансов по контракту. (Депозиты будут обрабатываться с помощью перевода токенов в контракт, который должен быть реализован с помощью OnNEP17Payment или аналогичного устройства, не показанного в исходном коде.Для полноты картины следует добавить обработчик OnPayment для увеличения FreeBalance счета отправителя при получении токенов.)

Спонсоры делают пожертвования проектам(не подробно описано выше, но, предположительно, с помощью метода, который перемещает их FreeBalance в призовой фонд проекта). Если проект терпит неудачу или прекращает свое существование, верните эти пожертвования обратно на FreeBalance спонсоров, а затем спонсоры могут вывести их, используя новый метод вывода.safeRefundAllDonations

Инвесторы вкладывают средства в кандидатов в производители на этапе отбора проекта.Они не могут вывести средства после того, как производитель выбран победителем (их средства затем выделяются), но могут вывести средства, если производитель не был выбран или проект отменен.

Когда проект завершается успешно, зарезервированные средства производителя-победителя становятся пулом для распределения прибыли.Инвесторы могут претендовать на свою прибыль пропорционально после завершения проекта.Балансы счетов производителей и инвесторов обновляются соответствующим образом, и никакая посторонняя сторона не может инициировать эти финансовые шаги.

Каждый частичный класс теперь содержит корректную реализацию своего ранее неполного метода, соответствующую предполагаемой бизнес-логике краудфандинговой/инвестиционной платформы.
*/
}