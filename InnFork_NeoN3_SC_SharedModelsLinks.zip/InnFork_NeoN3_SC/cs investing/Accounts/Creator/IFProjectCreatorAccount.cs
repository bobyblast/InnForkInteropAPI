using Neo.SmartContract.Framework;
using Neo.SmartContract.Framework.Native;
using Neo.SmartContract.Framework.Services;
using System;
using System.Numerics;

namespace InnFork.NeoN3;

// ������ ������ � ������������ ������� � ��������� ������ 
public partial class IF_MainGateway : Neo.SmartContract.Framework.SmartContract
{


    public partial class ProjectCreatorAccount
    {


        // In ProjectCreatorAccount partial class
        public bool withdrawFromMainBalance(UInt160 projectCreatorAddress, BigInteger amount)
        {
            if (!Runtime.CheckWitness(projectCreatorAddress))
                throw new Exception("Authorization failed. Only the project creator can withdraw their funds.");
            ProjectCreatorAccount account = getProjectCreatorAccount(projectCreatorAddress);
            if (account == null)
                throw new Exception("Project creator account not found.");
            if (amount <= 0 || amount > account.FreeFLMUSDBalance)  // assuming FLMUSDBalance/FreeBalance holds available funds
                throw new Exception("Invalid withdrawal amount.");
            if (!Neo.SmartContract.Framework.Native.GAS.Transfer(Runtime.ExecutingScriptHash, projectCreatorAddress, amount))
                throw new Exception("Token transfer failed during withdrawal.");
            // Update balances
            account.FreeFLMUSDBalance -= amount;
            if (account.TotalFLMUSDBalance >= amount)
                account.TotalFLMUSDBalance -= amount;
            else
                account.TotalFLMUSDBalance = 0;
            updateExistingProjectCreatorAccount(projectCreatorAddress, account);
            return true;
        }




        public static void WithdrawFromMainBalance(UInt160 projectCreatorAddress, BigInteger amount)
        {
            if (projectCreatorAddress is null || projectCreatorAddress.IsZero)
                throw new Exception("Invalid project creator address");

            if (!Runtime.CheckWitness(projectCreatorAddress))
                throw new Exception("Authorization failed");

            if (amount <= 0)
                throw new Exception("Withdrawal amount must be positive");

            ProjectCreatorAccount account = getProjectCreatorAccount(projectCreatorAddress);
            if (account == null)
                throw new Exception("Project creator account not found");

            if (account.FreeFLMUSDBalance < amount)
                throw new Exception("Insufficient free balance");

            bool transferOk = GAS.Transfer(Runtime.ExecutingScriptHash, projectCreatorAddress, amount, null);
            if (!transferOk)
                throw new Exception("GAS transfer failed");

            account.FreeFLMUSDBalance -= amount;
            if (account.TotalFLMUSDBalance >= amount)
                account.TotalFLMUSDBalance -= amount;
            else
                account.TotalFLMUSDBalance = 0;

            ProjectState.SetRawProjectCreatorAccount(projectCreatorAddress, StdLib.Serialize(account));
        }



        public ProjectCreatorAccount(UInt160 wallet)
        {
            WalletAddress = wallet;
        }

        public bool setPublicKey(UInt160 projectCreatorAddress, string publicKeyBytes, string message, string signature)
        {
            if (!Runtime.CheckWitness(projectCreatorAddress)) throw new Exception("Authorization failed");

            ProjectCreatorAccount account = getProjectCreatorAccount(projectCreatorAddress);

            if (account != null)
            {
                return account.verifyAndSetPublicKey(projectCreatorAddress, publicKeyBytes.ToByteArray(), message.ToByteArray(), signature.ToByteArray());
            }
            else
            {
                throw new Exception("Account not found");
            }
        }
        public bool setPublicKeyBytes(UInt160 projectCreatorAddress, byte[] publicKeyBytes, byte[] message, byte[] signature)
        {
            if (!Runtime.CheckWitness(projectCreatorAddress))
                throw new Exception("Authorization failed");

            ProjectCreatorAccount account = getProjectCreatorAccount(projectCreatorAddress);

            if (account != null)
            {
                return account.verifyAndSetPublicKey(projectCreatorAddress, publicKeyBytes, message, signature);
            }
            else
            {
                throw new Exception("Account not found");
            }
        }

        public bool verifyAndSetPublicKey(UInt160 projectCreatorAddress, byte[] publicKeyBytes, byte[] message, byte[] signature)
        {

            // �������� witness ������ ���� � ������ ���������
            if (!Runtime.CheckWitness(projectCreatorAddress))
                throw new Exception("Authorization failed");

            // �������� ������� ���������� �����
            if (!IFHelper.verifySignatureSHA256(publicKeyBytes, message, signature))
                throw new Exception("Invalid signature");

            ProjectCreatorAccount account = getProjectCreatorAccount(projectCreatorAddress);

            if (account != null)
            {
                account.PublicKey = publicKeyBytes.ToByteString();

                updateExistingProjectCreatorAccount(projectCreatorAddress, account);

                return true;
            }
            else
            {
                throw new Exception("Account not found");
            }
        }
        public void executeProjectCreatorRefund(UInt160 projectCreatorAddress, BigInteger amount)
        {
            if (!Runtime.CheckWitness(projectCreatorAddress)) throw new Exception("Authorization failed"); // ������ �������� �������� ����� �������� ���

            if (WalletAddress != projectCreatorAddress) throw new Exception("Authorization failed - CallerAddress != account.WalletAddress");

            //TODO /check!BalanceManagerAPI.withdrawFromMainBalance(projectCreatorAddress, amount);
        }

        public static ProjectCreatorAccount getProjectCreatorAccount(UInt160 projectCreatorAccount)
        {
            var raw = ProjectState.GetRawProjectCreatorAccount(projectCreatorAccount);
            if (raw is null) return null;
            return (ProjectCreatorAccount)StdLib.Deserialize(raw);
        }

        public static ProjectCreatorAccount createProjectCreatorAccount(UInt160 projectCreatorAddress, string publicKey)
        {
            if (projectCreatorAddress.Length != 20) throw new Exception("Invalid address format");

            if (!Runtime.CheckWitness(projectCreatorAddress)) throw new Exception("Authorization failed");

            if (ProjectState.GetRawProjectCreatorAccount(projectCreatorAddress) != null)
                throw new Exception("Project creator account already exists");

            if (projectCreatorAddress != IFHelper.pubKeyToAddress(publicKey.ToByteArray())) throw new Exception("Address and public key_documentIdSha256 not match");

            ProjectCreatorAccount newProjectCreatorAccount = new ProjectCreatorAccount(projectCreatorAddress)
            {
                TotalFLMUSDBalance = 0,
                FreeFLMUSDBalance = 0,
                PublicKey = publicKey
            };

            ProjectState.SetRawProjectCreatorAccount(projectCreatorAddress, StdLib.Serialize(newProjectCreatorAccount));

            return newProjectCreatorAccount;
        }
        public static void updateExistingProjectCreatorAccount(UInt160 CallerAddress, ProjectCreatorAccount account)
        {
            if (ProjectState.GetRawProjectCreatorAccount(account.WalletAddress) == null) throw new Exception("Project creator account not found");

            ProjectState.SetRawProjectCreatorAccount(account.WalletAddress, StdLib.Serialize(account));
        }

        public static BigInteger getTotalBalanceOfProjectCreatorAccount(UInt160 projectCreatorAddress)
        {
            return getProjectCreatorAccount(projectCreatorAddress).TotalFLMUSDBalance;
        }
        public static BigInteger getFreeBalanceOfProjectCreatorAccount(UInt160 projectCreatorAddress)
        {
            return getProjectCreatorAccount(projectCreatorAddress).FreeFLMUSDBalance;
        }

        public static ProjectCreatorAccount getProjectCreatorAccountByProjectId(string projectId_Sha256, bool AllowReturnNull = false)
        {
            if (projectId_Sha256.Length != 32)
                throw new Exception("getProjectCreatorAccountByProjectId: Invalid ProjectCreatorId address format");

            ProjectAccount Project = getProjectAccount(projectId_Sha256); // �������� ������ �� ��������������

            if (Project != null)
            {
                var raw = ProjectState.GetRawProjectCreatorAccount(Project.ProjectCreatorAddress);
                if (raw is null)
                {
                    if (AllowReturnNull) return null;
                    throw new Exception("ProjectCreatorAccount not found");
                }
                return (ProjectCreatorAccount)StdLib.Deserialize(raw);
            }
            else
            {
                if (AllowReturnNull)
                {
                    return null;
                }
                else
                {
                    throw new Exception("ProjectCreatorAccount not found");
                }
            }
        }

    }








}